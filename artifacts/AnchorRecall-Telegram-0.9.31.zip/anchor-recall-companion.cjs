/*!
Anchor Recall
SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 Gregory T.
Project license: https://polyformproject.org/licenses/noncommercial/1.0.0
The project license applies to Anchor Recall's own code, not to bundled third-party components.
Third-party components retain their original licenses and notices below.

# Third-party notices

The PolyForm Noncommercial 1.0.0 license in `LICENSE` applies to Anchor Recall's
own code. It does not replace or restrict the licenses of the third-party
components listed here. Their original permissions and notice obligations remain
in effect. This document is embedded in the generated `main.js` release bundle.

Anchor Recall bundles the following open-source packages in `main.js` to provide scheduling, local FSRS parameter optimization and Markdown formatting. They are used locally and no learning data is sent to their authors or services.

| Package | Version | License | Project |
| --- | ---: | --- | --- |
| `marked` | 18.1.1 | MIT, Markdown notice below | https://github.com/markedjs/marked |
| `ts-fsrs` | 5.4.1 | MIT | https://github.com/open-spaced-repetition/ts-fsrs |
| `@open-spaced-repetition/binding` | 0.5.0 | MIT | https://github.com/open-spaced-repetition/ts-fsrs |
| `@open-spaced-repetition/binding-wasm32-wasi` | 0.5.0 | MIT | https://github.com/open-spaced-repetition/ts-fsrs |
| `@napi-rs/wasm-runtime` | 1.2.3 | MIT | https://github.com/napi-rs/napi-rs |
| `@emnapi/core`, `@emnapi/runtime`, `@emnapi/wasi-threads` | 1.x | MIT | https://github.com/toyobayashi/emnapi |
| `@tybys/wasm-util` | 0.10.3 | MIT | https://github.com/toyobayashi/wasm-util |
| `tslib` | 2.8.1 | 0BSD | https://github.com/microsoft/tslib |

## MIT License text

Copyright belongs to the respective package authors and contributors. The
following original notices accompany the shared MIT terms below:

- `marked` (installed package `LICENSE`):

  Copyright (c) 2018+, MarkedJS (https://github.com/markedjs/)

  Copyright (c) 2011-2018, Christopher Jeffrey (https://github.com/chjj/)

- `ts-fsrs`, `@open-spaced-repetition/binding`, and `@open-spaced-repetition/binding-wasm32-wasi` (installed package `LICENSE` files):

  Copyright (c) 2026 Open Spaced Repetition

- `@emnapi/core`, `@emnapi/runtime`, and `@emnapi/wasi-threads` (installed package `LICENSE` files):

  Copyright (c) 2021-present Toyobayashi

- `@napi-rs/wasm-runtime` (MIT declared in the installed package; notices from the [upstream NAPI-RS license](https://github.com/napi-rs/napi-rs/blob/main/LICENSE)):

  Copyright (c) 2020-present LongYinan

  Copyright (c) 2018 GitHub

- `@tybys/wasm-util` declares MIT and author `toyobayashi` in its installed package metadata. Copyright remains with its authors and contributors.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## 0BSD text (`tslib`)

Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

## Markdown notice (included with `marked`)

Copyright © 2004, John Gruber
http://daringfireball.net/
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
* Neither the name “Markdown” nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

This software is provided by the copyright holders and contributors “as is” and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. In no event shall the copyright owner or contributors be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.
*/

// src/infrastructure/companion/server/cli-shared.ts
var import_node_fs7 = require("node:fs");
var import_promises8 = require("node:fs/promises");

// src/domain/cards/recall-core.ts
var normalizeTestAnswer = (value) => value.normalize("NFKC").trim().toLocaleLowerCase("ru-RU").replace(/ё/g, "\u0435").replace(/\s+/g, " ").replace(/[.!?,;:]+$/g, "");
var isExplicitTestAnswerCorrect = (answer, expected, mode = "text") => {
  const normalize = mode === "literal" ? (value) => value.replace(/\r\n?/g, "\n").trim() : normalizeTestAnswer;
  const actual = normalize(answer);
  return Boolean(actual) && expected.some((value) => actual === normalize(value));
};
var isExactTestAnswerCorrect = (answer, expected, mode = "text") => {
  if (mode === "literal") {
    const normalize = (value) => value.replace(/\r\n?/g, "\n").trim();
    const actual = normalize(answer);
    return Boolean(actual) && actual === normalize(expected);
  }
  const normalized2 = normalizeTestAnswer(answer);
  return Boolean(normalized2) && expected.split(/[\n|]+/).map(normalizeTestAnswer).filter(Boolean).includes(normalized2);
};

// src/domain/cards/card-attachments.ts
var CARD_ATTACHMENT_EXTENSIONS = {
  image: ["png", "jpg", "jpeg", "gif", "webp", "avif", "bmp"],
  audio: ["mp3", "wav", "ogg", "oga", "m4a", "flac", "opus", "webm"],
  video: ["mp4", "webm", "ogv", "mov", "m4v", "mkv"]
};

// src/domain/companion/media.ts
var MAX_COMPANION_MEDIA_BYTES = 5e7;
var COMPANION_MEDIA_CHUNK_BYTES = 128 * 1024;
var MAX_COMPANION_MEDIA_CHUNK_BYTES = 256 * 1024;
var MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES = 1024 * 1024;
var MAX_COMPANION_MEDIA_STATUS_ASSETS = 200;
function check(value) {
  if (!value) throw new Error("Invalid companion media");
}
function object(value) {
  check(value && typeof value === "object" && !Array.isArray(value));
}
function fields(value, allowed) {
  check(Object.keys(value).every((key2) => allowed.includes(key2)));
}
function isCompanionMediaId(value) {
  return typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
}
function validateCompanionMediaIdentity(value, attachment = false) {
  object(value);
  fields(value, attachment ? ["id", "kind", "format", "bytes", "side", "caption", "alt"] : ["id", "kind", "format", "bytes"]);
  check(isCompanionMediaId(value.id) && ["image", "audio", "video"].includes(String(value.kind)));
  check(typeof value.format === "string" && CARD_ATTACHMENT_EXTENSIONS[value.kind].includes(value.format));
  check(Number.isSafeInteger(value.bytes) && Number(value.bytes) > 0 && Number(value.bytes) <= MAX_COMPANION_MEDIA_BYTES);
}
function validateCompanionMediaAttachment(value) {
  validateCompanionMediaIdentity(value, true);
  const v = value;
  check(v.side === "question" || v.side === "answer");
  check(v.caption === void 0 || typeof v.caption === "string" && v.caption.length <= 500);
  check(v.alt === void 0 || typeof v.alt === "string" && v.alt.length <= 300);
}
function validateCompanionMediaChunk(value, maxChunkBytes = MAX_COMPANION_MEDIA_CHUNK_BYTES) {
  object(value);
  fields(value, ["operation", "asset", "offset", "data"]);
  check(value.operation === "media-chunk");
  validateCompanionMediaIdentity(value.asset);
  check(Number.isSafeInteger(value.offset) && Number(value.offset) >= 0 && Number(value.offset) < value.asset.bytes && Number(value.offset) % COMPANION_MEDIA_CHUNK_BYTES === 0);
  check(typeof value.data === "string" && value.data.length > 0 && value.data.length <= Math.ceil(maxChunkBytes / 3) * 4 && value.data.length % 4 === 0);
  const padding = value.data.endsWith("==") ? 2 : value.data.endsWith("=") ? 1 : 0;
  check(!/[^A-Za-z0-9+/]/.test(value.data.slice(0, value.data.length - padding)));
  const bytes = value.data.length / 4 * 3 - padding;
  check(bytes > 0 && bytes <= maxChunkBytes && Number(value.offset) + bytes <= value.asset.bytes);
}
function validateCompanionMediaStatusAssets(value) {
  check(Array.isArray(value) && value.length <= MAX_COMPANION_MEDIA_STATUS_ASSETS);
  const ids = /* @__PURE__ */ new Set();
  for (const asset of value) {
    validateCompanionMediaIdentity(asset);
    check(!ids.has(asset.id));
    ids.add(asset.id);
  }
}
function validateCompanionMediaAck(value, asset) {
  object(value);
  fields(value, ["id", "offset", "complete"]);
  check(value.id === asset.id && Number.isSafeInteger(value.offset) && Number(value.offset) >= 0 && Number(value.offset) <= asset.bytes && typeof value.complete === "boolean" && (value.complete ? value.offset === asset.bytes : Number(value.offset) < asset.bytes));
}

// src/domain/review/sibling-spacing.ts
var MAX_SIBLING_SPACING_MINUTES = Math.floor(Number.MAX_SAFE_INTEGER / 6e4);

// src/domain/cards/recall-test-core.ts
var MAX_STRUCTURED_TEST_ITEMS = 12;
var MAX_SELF_CHECK_CRITERIA = 12;
var MAX_SELF_CHECK_CRITERION_LENGTH = 500;
var extractClozeAnswers = (template) => {
  const answers = [];
  const expression = /\{\{([^{}]+)\}\}/g;
  let match;
  while ((match = expression.exec(template)) && answers.length < MAX_STRUCTURED_TEST_ITEMS) {
    const answer = match[1].trim().slice(0, 500);
    if (answer) answers.push(answer);
  }
  return answers;
};
var sameIndexes = (actual, expected) => actual.length === expected.length && actual.every((value, index2) => value === expected[index2]);
var evaluateRecallTest = (test, response) => {
  if (test.kind === "free") return test.evaluationMode === "self" ? null : test.acceptedAnswers !== void 0 ? isExplicitTestAnswerCorrect(response.text, test.acceptedAnswers, test.answerMatchMode) : isExactTestAnswerCorrect(response.text, test.expectedAnswer, test.answerMatchMode);
  if (test.kind === "single" || test.kind === "multiple") {
    const actual = [...new Set(response.selectedOptionIndexes)].sort((a, b) => a - b);
    const expected = [...test.correctOptionIndexes].sort((a, b) => a - b);
    return sameIndexes(actual, expected);
  }
  if (test.kind === "cloze") {
    const expected = extractClozeAnswers(test.clozeTemplate);
    return response.clozeAnswers.length === expected.length && expected.every((answer, index2) => isExactTestAnswerCorrect(response.clozeAnswers[index2] ?? "", answer, test.answerMatchMode));
  }
  if (test.kind === "matching") return sameIndexes(response.matches, test.pairs.map((_, index2) => index2));
  return sameIndexes(response.order, test.orderItems.map((_, index2) => index2));
};

// src/domain/companion/exercises.ts
var check2 = (condition) => {
  if (!condition) throw new Error("invalid companion exercise");
};
var embeddedMedia = /!\[|<(?:img|audio|video|iframe|object|embed|svg|picture|canvas)\b/i;
var boundedText = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max && !embeddedMedia.test(value);
function validateCompanionPermutation(value, count) {
  check2(Array.isArray(value) && value.length >= 2 && value.length <= 12 && (count === void 0 || value.length === count) && Array.from(value).every((index2) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < value.length) && new Set(value).size === value.length);
}
function validateCompanionExercise(value) {
  check2(value !== null && typeof value === "object" && !Array.isArray(value));
  const ex = value;
  if (ex.kind === "single" || ex.kind === "multiple") {
    check2(Object.keys(ex).every((key2) => ["kind", "options", "correctOptionIndexes"].includes(key2)));
    check2(Array.isArray(ex.options) && ex.options.length >= 2 && ex.options.length <= 12 && Array.from(ex.options).every((option) => boundedText(option, 500)));
    const options = ex.options, indexes = ex.correctOptionIndexes;
    check2(Array.isArray(indexes) && indexes.length > 0 && indexes.length <= options.length && (ex.kind !== "single" || indexes.length === 1));
    check2(Array.from(indexes).every((index2) => Number.isSafeInteger(index2) && Number(index2) >= 0 && Number(index2) < options.length) && new Set(indexes).size === indexes.length);
  } else if (ex.kind === "matching") {
    check2(Object.keys(ex).every((key2) => ["kind", "pairs"].includes(key2)) && Array.isArray(ex.pairs) && ex.pairs.length >= 2 && ex.pairs.length <= 12);
    const pairs = ex.pairs;
    check2(Array.from(pairs).every((pair) => pair !== null && typeof pair === "object" && !Array.isArray(pair) && Object.keys(pair).every((key2) => ["left", "right"].includes(key2)) && boundedText(pair.left, 500) && boundedText(pair.right, 500)));
    check2(new Set(pairs.map((pair) => normalizeTestAnswer(pair.left))).size === pairs.length && new Set(pairs.map((pair) => normalizeTestAnswer(pair.right))).size === pairs.length);
  } else if (ex.kind === "ordering") {
    check2(Object.keys(ex).every((key2) => ["kind", "orderItems"].includes(key2)) && Array.isArray(ex.orderItems) && ex.orderItems.length >= 2 && ex.orderItems.length <= 12);
    const items = ex.orderItems;
    check2(Array.from(items).every((item) => boundedText(item, 500)) && new Set(items.map(normalizeTestAnswer)).size === items.length);
  } else {
    check2(ex.kind === "cloze" && Object.keys(ex).every((key2) => ["kind", "clozeTemplate", "answerMatchMode"].includes(key2)));
    check2(boundedText(ex.clozeTemplate, 1800) && (ex.answerMatchMode === void 0 || ex.answerMatchMode === "text" || ex.answerMatchMode === "literal"));
    const matches = [...ex.clozeTemplate.matchAll(/\{\{([^{}]+)\}\}/g)];
    check2(matches.length > 0 && matches.length <= 12 && matches.every((match) => match[1].trim().length > 0 && match[1].trim().length <= 500));
    check2(ex.answerMatchMode !== "literal" || matches.length === 1 || matches.every((match) => !/[\r\n]/.test(match[1].trim())));
  }
  check2(companionExerciseReference(value).length <= 1800);
}
function companionExerciseReference(ex) {
  return ex.kind === "cloze" ? ex.clozeTemplate.replace(/\{\{([^{}]+)\}\}/g, (_, answer) => answer.trim()) : ex.kind === "matching" ? ex.pairs.map((pair) => `${pair.left} \u2192 ${pair.right}`).join("\n") : ex.kind === "ordering" ? ex.orderItems.map((item, index2) => `${index2 + 1}. ${item}`).join("\n") : ex.options.filter((_, index2) => ex.correctOptionIndexes.includes(index2)).join("\n");
}
function companionExerciseQuestion(ex, prompt) {
  if (ex.kind === "matching" || ex.kind === "ordering") return prompt;
  let index2 = 0;
  const body = ex.kind === "cloze" ? ex.clozeTemplate.replace(/\{\{([^{}]+)\}\}/g, () => `[${++index2}] _____`) : ex.options.map((option, index3) => `${index3 + 1}. ${option}`).join("\n");
  return `${prompt}

${body}`;
}
function companionExerciseBlankCount(ex) {
  return ex.kind === "cloze" ? extractClozeAnswers(ex.clozeTemplate).length : 0;
}
function evaluateCompanionExercise(ex, response) {
  validateCompanionExercise(ex);
  const selected = response.selectedOptionIndexes ?? [], answers = response.clozeAnswers ?? [];
  check2(Array.isArray(selected) && selected.length <= 12 && Array.from(selected).every((index2) => Number.isSafeInteger(index2) && index2 >= 0 && (ex.kind === "single" || ex.kind === "multiple") && index2 < ex.options.length));
  check2(Array.isArray(answers) && answers.length <= 12 && Array.from(answers).every((answer) => typeof answer === "string" && answer.length <= 2e3));
  if (ex.kind === "matching" || ex.kind === "ordering") {
    check2(response.selectedOptionIndexes === void 0 && response.clozeAnswers === void 0 && (ex.kind === "matching" ? response.order === void 0 : response.matches === void 0));
    validateCompanionPermutation(ex.kind === "matching" ? response.matches : response.order, ex.kind === "matching" ? ex.pairs.length : ex.orderItems.length);
  } else check2(response.matches === void 0 && response.order === void 0);
  const choice = ex.kind === "single" || ex.kind === "multiple" ? ex : void 0;
  const definition = {
    kind: ex.kind,
    prompt: "Telegram",
    evaluationMode: "exact",
    expectedAnswer: "",
    hints: [],
    options: choice?.options ?? [],
    correctOptionIndexes: choice?.correctOptionIndexes ?? [],
    clozeTemplate: ex.kind === "cloze" ? ex.clozeTemplate : "",
    pairs: ex.kind === "matching" ? ex.pairs : [],
    orderItems: ex.kind === "ordering" ? ex.orderItems : [],
    ...ex.kind === "cloze" && ex.answerMatchMode ? { answerMatchMode: ex.answerMatchMode } : {}
  };
  return evaluateRecallTest(definition, { text: "", selectedOptionIndexes: selected, clozeAnswers: answers, matches: response.matches ?? [], order: response.order ?? [] }) === true;
}

// node_modules/ts-fsrs/dist/index.mjs
var FSRSError = class _FSRSError extends Error {
  constructor(message = "FSRS Error") {
    super(message);
    this.name = "FSRSError";
    Error.captureStackTrace?.(this, _FSRSError);
  }
};
var FSRSValidationError = class _FSRSValidationError extends FSRSError {
  constructor(message) {
    super(message);
    this.name = "FSRSValidationError";
    Error.captureStackTrace?.(this, _FSRSValidationError);
  }
};
var State = /* @__PURE__ */ ((State2) => {
  State2[State2["New"] = 0] = "New";
  State2[State2["Learning"] = 1] = "Learning";
  State2[State2["Review"] = 2] = "Review";
  State2[State2["Relearning"] = 3] = "Relearning";
  return State2;
})(State || {});
var Rating = /* @__PURE__ */ ((Rating2) => {
  Rating2[Rating2["Manual"] = 0] = "Manual";
  Rating2[Rating2["Again"] = 1] = "Again";
  Rating2[Rating2["Hard"] = 2] = "Hard";
  Rating2[Rating2["Good"] = 3] = "Good";
  Rating2[Rating2["Easy"] = 4] = "Easy";
  return Rating2;
})(Rating || {});
var TypeConvert = class _TypeConvert {
  static card(card) {
    return {
      ...card,
      state: _TypeConvert.state(card.state),
      due: _TypeConvert.time(card.due),
      last_review: card.last_review ? _TypeConvert.time(card.last_review) : void 0
    };
  }
  static rating(value) {
    if (typeof value === "string") {
      const firstLetter = value.charAt(0).toUpperCase();
      const restOfString = value.slice(1).toLowerCase();
      const ret = Rating[`${firstLetter}${restOfString}`];
      if (ret === void 0) {
        throw new FSRSValidationError(`Invalid rating:[${value}]`);
      }
      return ret;
    } else if (typeof value === "number") {
      return value;
    }
    throw new FSRSValidationError(`Invalid rating:[${value}]`);
  }
  static state(value) {
    if (typeof value === "string") {
      const firstLetter = value.charAt(0).toUpperCase();
      const restOfString = value.slice(1).toLowerCase();
      const ret = State[`${firstLetter}${restOfString}`];
      if (ret === void 0) {
        throw new FSRSValidationError(`Invalid state:[${value}]`);
      }
      return ret;
    } else if (typeof value === "number") {
      return value;
    }
    throw new FSRSValidationError(`Invalid state:[${value}]`);
  }
  static time(value) {
    if (value instanceof Date) {
      return value;
    }
    const date = new Date(value);
    if (typeof value === "object" && value !== null && !Number.isNaN(Date.parse(value) || +date)) {
      return date;
    } else if (typeof value === "string") {
      const timestamp4 = Date.parse(value);
      if (!Number.isNaN(timestamp4)) {
        return new Date(timestamp4);
      } else {
        throw new FSRSValidationError(`Invalid date:[${value}]`);
      }
    } else if (typeof value === "number") {
      return new Date(value);
    }
    throw new FSRSValidationError(`Invalid date:[${value}]`);
  }
  static review_log(log) {
    return {
      ...log,
      due: _TypeConvert.time(log.due),
      rating: _TypeConvert.rating(log.rating),
      state: _TypeConvert.state(log.state),
      review: _TypeConvert.time(log.review)
    };
  }
};
/* istanbul ignore next -- @preserve */
Date.prototype.scheduler = function(t, isDay) {
  return date_scheduler(this, t, isDay);
};
/* istanbul ignore next -- @preserve */
Date.prototype.diff = function(pre, unit) {
  return date_diff(this, pre, unit);
};
/* istanbul ignore next -- @preserve */
Date.prototype.format = function() {
  return formatDate(this);
};
/* istanbul ignore next -- @preserve */
Date.prototype.dueFormat = function(last_review, unit, timeUnit) {
  return show_diff_message(this, last_review, unit, timeUnit);
};
function date_scheduler(now, t, isDay) {
  return new Date(
    isDay ? TypeConvert.time(now).getTime() + t * 24 * 60 * 60 * 1e3 : TypeConvert.time(now).getTime() + t * 60 * 1e3
  );
}
function date_diff(now, pre, unit) {
  if (!now || !pre) {
    throw new FSRSValidationError("Invalid date");
  }
  const diff = TypeConvert.time(now).getTime() - TypeConvert.time(pre).getTime();
  let r = 0;
  switch (unit) {
    case "days":
      r = Math.floor(diff / (24 * 60 * 60 * 1e3));
      break;
    case "minutes":
      r = Math.floor(diff / (60 * 1e3));
      break;
  }
  return r;
}
function formatDate(dateInput) {
  const date = TypeConvert.time(dateInput);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day2 = date.getDate();
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();
  return `${year}-${padZero(month)}-${padZero(day2)} ${padZero(hours)}:${padZero(
    minutes
  )}:${padZero(seconds)}`;
}
function padZero(num) {
  return num < 10 ? `0${num}` : `${num}`;
}
var TIMEUNIT = [60, 60, 24, 31, 12];
var TIMEUNITFORMAT = ["second", "min", "hour", "day", "month", "year"];
function show_diff_message(due, last_review, unit, timeUnit = TIMEUNITFORMAT) {
  due = TypeConvert.time(due);
  last_review = TypeConvert.time(last_review);
  if (timeUnit.length !== TIMEUNITFORMAT.length) {
    timeUnit = TIMEUNITFORMAT;
  }
  let diff = due.getTime() - last_review.getTime();
  let i = 0;
  diff /= 1e3;
  for (i = 0; i < TIMEUNIT.length; i++) {
    if (diff < TIMEUNIT[i]) {
      break;
    } else {
      diff /= TIMEUNIT[i];
    }
  }
  return `${Math.floor(diff)}${unit ? timeUnit[i] : ""}`;
}
/* istanbul ignore next -- @preserve */
/* istanbul ignore next -- @preserve */
/* istanbul ignore next -- @preserve */
var Grades = Object.freeze([
  Rating.Again,
  Rating.Hard,
  Rating.Good,
  Rating.Easy
]);
var FUZZ_RANGES = [
  {
    start: 2.5,
    end: 7,
    factor: 0.15
  },
  {
    start: 7,
    end: 20,
    factor: 0.1
  },
  {
    start: 20,
    end: Infinity,
    factor: 0.05
  }
];
function get_fuzz_range(interval, elapsed_days, maximum_interval) {
  let delta = 1;
  for (const range of FUZZ_RANGES) {
    delta += range.factor * Math.max(Math.min(interval, range.end) - range.start, 0);
  }
  interval = Math.min(interval, maximum_interval);
  let min_ivl = Math.max(2, Math.round(interval - delta));
  const max_ivl = Math.min(Math.round(interval + delta), maximum_interval);
  if (interval > elapsed_days) {
    min_ivl = Math.max(min_ivl, elapsed_days + 1);
  }
  min_ivl = Math.min(min_ivl, max_ivl);
  return { min_ivl, max_ivl };
}
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}
function roundTo(num, decimals) {
  const factor = 10 ** decimals;
  return Math.round(num * factor) / factor;
}
function dateDiffInDays(last, cur) {
  const utc1 = Date.UTC(
    last.getUTCFullYear(),
    last.getUTCMonth(),
    last.getUTCDate()
  );
  const utc2 = Date.UTC(
    cur.getUTCFullYear(),
    cur.getUTCMonth(),
    cur.getUTCDate()
  );
  return Math.floor(
    (utc2 - utc1) / 864e5
    /** 1000 * 60 * 60 * 24*/
  );
}
var ConvertStepUnitToMinutes = (step) => {
  const unit = step.slice(-1);
  const value = parseInt(step.slice(0, -1), 10);
  if (Number.isNaN(value) || !Number.isFinite(value) || value < 0) {
    throw new FSRSValidationError(`Invalid step value: ${step}`);
  }
  switch (unit) {
    case "m":
      return value;
    case "h":
      return value * 60;
    case "d":
      return value * 1440;
    default:
      throw new FSRSValidationError(
        `Invalid step unit: ${step}, expected m/h/d`
      );
  }
};
var BasicLearningStepsStrategy = (params, state, cur_step) => {
  const learning_steps = state === State.Relearning || state === State.Review ? params.relearning_steps : params.learning_steps;
  const steps_length = learning_steps.length;
  if (steps_length === 0 || cur_step >= steps_length) return {};
  const firstStep = learning_steps[0];
  const toMinutes = ConvertStepUnitToMinutes;
  const getAgainInterval = () => {
    return toMinutes(firstStep);
  };
  const getHardInterval = () => {
    if (steps_length === 1) return Math.round(toMinutes(firstStep) * 1.5);
    const nextStep = learning_steps[1];
    return Math.round((toMinutes(firstStep) + toMinutes(nextStep)) / 2);
  };
  const getStepInfo = (index2) => {
    if (index2 < 0 || index2 >= steps_length) {
      return null;
    } else {
      return learning_steps[index2];
    }
  };
  const getGoodMinutes = (step) => {
    return toMinutes(step);
  };
  const result = {};
  const step_info = getStepInfo(Math.max(0, cur_step));
  if (state === State.Review) {
    result[Rating.Again] = {
      scheduled_minutes: toMinutes(step_info),
      next_step: 0
    };
    return result;
  } else {
    result[Rating.Again] = {
      scheduled_minutes: getAgainInterval(),
      next_step: 0
    };
    result[Rating.Hard] = {
      scheduled_minutes: getHardInterval(),
      next_step: cur_step
    };
    const next_info = getStepInfo(cur_step + 1);
    if (next_info) {
      const nextMin = getGoodMinutes(next_info);
      if (nextMin) {
        result[Rating.Good] = {
          scheduled_minutes: Math.round(nextMin),
          next_step: cur_step + 1
        };
      }
    }
  }
  return result;
};
function DefaultInitSeedStrategy() {
  const time3 = this.review_time.getTime();
  const reps = this.current.reps;
  const mul = this.current.difficulty * this.current.stability;
  return `${time3}_${reps}_${mul}`;
}
var StrategyMode = /* @__PURE__ */ ((StrategyMode2) => {
  StrategyMode2["SCHEDULER"] = "Scheduler";
  StrategyMode2["LEARNING_STEPS"] = "LearningSteps";
  StrategyMode2["SEED"] = "Seed";
  return StrategyMode2;
})(StrategyMode || {});
var AbstractScheduler = class {
  last;
  current;
  review_time;
  next = /* @__PURE__ */ new Map();
  algorithm;
  strategies;
  elapsed_days = 0;
  // init
  constructor(card, now, algorithm, strategies) {
    this.algorithm = algorithm;
    this.last = TypeConvert.card(card);
    this.current = TypeConvert.card(card);
    this.review_time = TypeConvert.time(now);
    this.strategies = strategies;
    this.init();
  }
  checkGrade(grade) {
    if (!Number.isFinite(grade) || grade < 1 || grade > 4) {
      throw new FSRSValidationError(`Invalid grade "${grade}",expected 1-4`);
    }
  }
  init() {
    const { state, last_review } = this.current;
    let interval = 0;
    if (state !== State.New && last_review) {
      interval = dateDiffInDays(last_review, this.review_time);
    }
    this.current.last_review = this.review_time;
    this.elapsed_days = interval;
    this.current.elapsed_days = interval;
    this.current.reps += 1;
    let seed_strategy = DefaultInitSeedStrategy;
    if (this.strategies) {
      const custom_strategy = this.strategies.get(StrategyMode.SEED);
      if (custom_strategy) {
        seed_strategy = custom_strategy;
      }
    }
    this.algorithm.seed = seed_strategy.call(this);
  }
  preview() {
    return {
      [Rating.Again]: this.review(Rating.Again),
      [Rating.Hard]: this.review(Rating.Hard),
      [Rating.Good]: this.review(Rating.Good),
      [Rating.Easy]: this.review(Rating.Easy),
      [Symbol.iterator]: this.previewIterator.bind(this)
    };
  }
  *previewIterator() {
    for (const grade of Grades) {
      yield this.review(grade);
    }
  }
  review(grade) {
    const { state } = this.last;
    let item;
    this.checkGrade(grade);
    switch (state) {
      case State.New:
        item = this.newState(grade);
        break;
      case State.Learning:
      case State.Relearning:
        item = this.learningState(grade);
        break;
      case State.Review:
        item = this.reviewState(grade);
        break;
    }
    return item;
  }
  buildLog(rating) {
    const { last_review, due, elapsed_days } = this.last;
    return {
      rating,
      state: this.current.state,
      due: last_review || due,
      stability: this.current.stability,
      difficulty: this.current.difficulty,
      elapsed_days: this.elapsed_days,
      last_elapsed_days: elapsed_days,
      scheduled_days: this.current.scheduled_days,
      learning_steps: this.current.learning_steps,
      review: this.review_time
    };
  }
};
var Alea = class {
  c;
  s0;
  s1;
  s2;
  constructor(seed) {
    const mash = Mash();
    this.c = 1;
    this.s0 = mash(" ");
    this.s1 = mash(" ");
    this.s2 = mash(" ");
    if (seed == null) seed = Date.now();
    this.s0 -= mash(seed);
    if (this.s0 < 0) this.s0 += 1;
    this.s1 -= mash(seed);
    if (this.s1 < 0) this.s1 += 1;
    this.s2 -= mash(seed);
    if (this.s2 < 0) this.s2 += 1;
  }
  next() {
    const t = 2091639 * this.s0 + this.c * 23283064365386963e-26;
    this.s0 = this.s1;
    this.s1 = this.s2;
    this.c = t | 0;
    this.s2 = t - this.c;
    return this.s2;
  }
  set state(state) {
    this.c = state.c;
    this.s0 = state.s0;
    this.s1 = state.s1;
    this.s2 = state.s2;
  }
  get state() {
    return {
      c: this.c,
      s0: this.s0,
      s1: this.s1,
      s2: this.s2
    };
  }
};
function Mash() {
  let n = 4022871197;
  return function mash(data) {
    data = String(data);
    for (let i = 0; i < data.length; i++) {
      n += data.charCodeAt(i);
      let h = 0.02519603282416938 * n;
      n = h >>> 0;
      h -= n;
      h *= n;
      n = h >>> 0;
      h -= n;
      n += h * 4294967296;
    }
    return (n >>> 0) * 23283064365386963e-26;
  };
}
function alea(seed) {
  const xg = new Alea(seed);
  const prng = () => xg.next();
  prng.int32 = () => xg.next() * 4294967296 | 0;
  prng.double = () => prng() + (prng() * 2097152 | 0) * 11102230246251565e-32;
  prng.state = () => xg.state;
  prng.importState = (state) => {
    xg.state = state;
    return prng;
  };
  return prng;
}
var version = "5.4.1";
var default_request_retention = 0.9;
var default_maximum_interval = 36500;
var default_enable_fuzz = false;
var default_enable_short_term = true;
var default_learning_steps = Object.freeze([
  "1m",
  "10m"
]);
var default_relearning_steps = Object.freeze([
  "10m"
]);
var FSRSVersion = `v${version} using FSRS-6.0`;
var S_MIN = 1e-3;
var INIT_S_MAX = 100;
var FSRS5_DEFAULT_DECAY = 0.5;
var FSRS6_DEFAULT_DECAY = 0.1542;
var default_w = Object.freeze([
  0.212,
  1.2931,
  2.3065,
  8.2956,
  6.4133,
  0.8334,
  3.0194,
  1e-3,
  1.8722,
  0.1666,
  0.796,
  1.4835,
  0.0614,
  0.2629,
  1.6483,
  0.6014,
  1.8729,
  0.5425,
  0.0912,
  0.0658,
  FSRS6_DEFAULT_DECAY
]);
var W17_W18_Ceiling = 2;
var CLAMP_PARAMETERS = (w17_w18_ceiling, enable_short_term = default_enable_short_term) => [
  [S_MIN, INIT_S_MAX],
  [S_MIN, INIT_S_MAX],
  [S_MIN, INIT_S_MAX],
  [S_MIN, INIT_S_MAX],
  [1, 10],
  [1e-3, 4],
  [1e-3, 4],
  [1e-3, 0.75],
  [0, 4.5],
  [0, 0.8],
  [1e-3, 3.5],
  [1e-3, 5],
  [1e-3, 0.25],
  [1e-3, 0.9],
  [0, 4],
  [0, 1],
  [1, 6],
  [0, w17_w18_ceiling],
  [0, w17_w18_ceiling],
  [
    enable_short_term ? 0.01 : 0,
    0.8
  ],
  [0.1, 0.8]
];
var clipParameters = (parameters, numRelearningSteps, enableShortTerm = default_enable_short_term) => {
  const clip = CLAMP_PARAMETERS(W17_W18_Ceiling, enableShortTerm).slice(
    0,
    parameters.length
  );
  if (Math.max(0, numRelearningSteps) > 1) {
    const w11 = clamp(parameters[11] || 0, clip[11][0], clip[11][1]);
    const w13 = clamp(parameters[13] || 0, clip[13][0], clip[13][1]);
    const w14 = clamp(parameters[14] || 0, clip[14][0], clip[14][1]);
    const value = -(Math.log(w11) + Math.log(Math.pow(2, w13) - 1) + w14 * 0.3) / numRelearningSteps;
    const w17_w18_ceiling = clamp(
      roundTo(Math.sqrt(Math.max(value, 0)), 8),
      0.01,
      W17_W18_Ceiling
    );
    if (clip[17]) clip[17] = [clip[17][0], w17_w18_ceiling];
    if (clip[18]) clip[18] = [clip[18][0], w17_w18_ceiling];
  }
  return clip.map(
    ([min, max], index2) => clamp(parameters[index2] || 0, min, max)
  );
};
var migrateParameters = (parameters, numRelearningSteps = 0, enableShortTerm = default_enable_short_term) => {
  if (parameters === void 0) {
    return [...default_w];
  }
  switch (parameters.length) {
    case 21:
      return clipParameters(
        Array.from(parameters),
        numRelearningSteps,
        enableShortTerm
      );
    case 19:
      console.debug("[FSRS-6]auto fill w from 19 to 21 length");
      return clipParameters(
        Array.from(parameters),
        numRelearningSteps,
        enableShortTerm
      ).concat([0, FSRS5_DEFAULT_DECAY]);
    case 17: {
      const w = clipParameters(
        Array.from(parameters),
        numRelearningSteps,
        enableShortTerm
      );
      w[4] = +(w[5] * 2 + w[4]).toFixed(8);
      w[5] = +(Math.log(w[5] * 3 + 1) / 3).toFixed(8);
      w[6] = +(w[6] + 0.5).toFixed(8);
      console.debug("[FSRS-6]auto fill w from 17 to 21 length");
      return w.concat([0, 0, 0, FSRS5_DEFAULT_DECAY]);
    }
    default:
      console.warn("[FSRS]Invalid parameters length, using default parameters");
      return [...default_w];
  }
};
var generatorParameters = (props) => {
  const learning_steps = Array.isArray(props?.learning_steps) ? props.learning_steps : default_learning_steps;
  const relearning_steps = Array.isArray(props?.relearning_steps) ? props.relearning_steps : default_relearning_steps;
  const enable_short_term = props?.enable_short_term ?? default_enable_short_term;
  const w = migrateParameters(
    props?.w,
    relearning_steps.length,
    enable_short_term
  );
  return {
    request_retention: props?.request_retention || default_request_retention,
    maximum_interval: props?.maximum_interval || default_maximum_interval,
    w,
    enable_fuzz: props?.enable_fuzz ?? default_enable_fuzz,
    enable_short_term,
    learning_steps,
    relearning_steps
  };
};
function createEmptyCard(now, afterHandler) {
  const emptyCard = {
    due: now ? TypeConvert.time(now) : /* @__PURE__ */ new Date(),
    stability: 0,
    difficulty: 0,
    elapsed_days: 0,
    scheduled_days: 0,
    reps: 0,
    lapses: 0,
    learning_steps: 0,
    state: State.New,
    last_review: void 0
  };
  if (afterHandler && typeof afterHandler === "function") {
    return afterHandler(emptyCard);
  } else {
    return emptyCard;
  }
}
var computeDecayFactor = (decayOrParams) => {
  const decay = typeof decayOrParams === "number" ? -decayOrParams : -decayOrParams[20];
  const factor = Math.exp(Math.pow(decay, -1) * Math.log(0.9)) - 1;
  return { decay, factor: roundTo(factor, 8) };
};
function forgetting_curve(decayOrParams, elapsed_days, stability) {
  const { decay, factor } = computeDecayFactor(decayOrParams);
  return roundTo(Math.pow(1 + factor * elapsed_days / stability, decay), 8);
}
var FSRSAlgorithm = class {
  param;
  intervalModifier;
  _seed;
  constructor(params) {
    this.param = new Proxy(
      generatorParameters(params),
      this.params_handler_proxy()
    );
    this.intervalModifier = this.calculate_interval_modifier(
      this.param.request_retention
    );
    this.forgetting_curve = forgetting_curve.bind(this, this.param.w);
  }
  get interval_modifier() {
    return this.intervalModifier;
  }
  set seed(seed) {
    this._seed = seed;
  }
  /**
   * @see https://github.com/open-spaced-repetition/fsrs4anki/wiki/The-Algorithm#fsrs-5
   *
   * The formula used is: $$I(r,s) = (r^{\frac{1}{DECAY}} - 1) / FACTOR \times s$$
   * @param request_retention 0<request_retention<=1,Requested retention rate
   * @throws {Error} Requested retention rate should be in the range (0,1]
   */
  calculate_interval_modifier(request_retention) {
    if (request_retention <= 0 || request_retention > 1) {
      throw new FSRSValidationError(
        "Requested retention rate should be in the range (0,1]"
      );
    }
    const { decay, factor } = computeDecayFactor(this.param.w);
    return roundTo((Math.pow(request_retention, 1 / decay) - 1) / factor, 8);
  }
  /**
   * Get the parameters of the algorithm.
   */
  get parameters() {
    return this.param;
  }
  /**
   * Set the parameters of the algorithm.
   * @param params Partial<FSRSParameters>
   */
  set parameters(params) {
    this.update_parameters(params);
  }
  params_handler_proxy() {
    const _this = this;
    return {
      set: function(target, prop, value) {
        if (prop === "request_retention" && Number.isFinite(value)) {
          _this.intervalModifier = _this.calculate_interval_modifier(
            Number(value)
          );
        } else if (prop === "w") {
          value = migrateParameters(
            value,
            target.relearning_steps.length,
            target.enable_short_term
          );
          _this.forgetting_curve = forgetting_curve.bind(this, value);
          _this.intervalModifier = _this.calculate_interval_modifier(
            Number(target.request_retention)
          );
        }
        Reflect.set(target, prop, value);
        return true;
      }
    };
  }
  update_parameters(params) {
    const _params = generatorParameters(params);
    for (const key2 in _params) {
      const paramKey = key2;
      this.param[paramKey] = _params[paramKey];
    }
  }
  /**
     * The formula used is :
     * $$ S_0(G) = w_{G-1}$$
     * $$S_0 = \max \lbrace S_0,0.1\rbrace $$
  
     * @param g Grade (rating at Anki) [1.again,2.hard,3.good,4.easy]
     * @return Stability (interval when R=90%)
     */
  init_stability(g) {
    return Math.max(this.param.w[g - 1], 0.1);
  }
  /**
   * The formula used is :
   * $$D_0(G) = w_4 - e^{(G-1) \cdot w_5} + 1 $$
   * $$D_0 = \min \lbrace \max \lbrace D_0(G),1 \rbrace,10 \rbrace$$
   * where the $$D_0(1)=w_4$$ when the first rating is good.
   *
   * @param {Grade} g Grade (rating at Anki) [1.again,2.hard,3.good,4.easy]
   * @return {number} Difficulty $$D \in [1,10]$$
   */
  init_difficulty(g) {
    const w = this.param.w;
    const d = w[4] - Math.exp((g - 1) * w[5]) + 1;
    return roundTo(d, 8);
  }
  /**
   * If fuzzing is disabled or ivl is less than 2.5, it returns the original interval.
   * @param {number} ivl - The interval to be fuzzed.
   * @param {number} elapsed_days t days since the last review
   * @return {number} - The fuzzed interval.
   **/
  apply_fuzz(ivl, elapsed_days) {
    if (!this.param.enable_fuzz || ivl < 2.5) return Math.round(ivl);
    const generator = alea(this._seed);
    const fuzz_factor = generator();
    const { min_ivl, max_ivl } = get_fuzz_range(
      ivl,
      elapsed_days,
      this.param.maximum_interval
    );
    return Math.floor(fuzz_factor * (max_ivl - min_ivl + 1) + min_ivl);
  }
  /**
   *   @see The formula used is : {@link FSRSAlgorithm.calculate_interval_modifier}
   *   @param {number} s - Stability (interval when R=90%)
   *   @param {number} elapsed_days t days since the last review
   */
  next_interval(s, elapsed_days) {
    const newInterval = Math.min(
      Math.max(1, Math.round(s * this.intervalModifier)),
      this.param.maximum_interval
    );
    return this.apply_fuzz(newInterval, elapsed_days);
  }
  /**
   * @see https://github.com/open-spaced-repetition/fsrs4anki/issues/697
   */
  linear_damping(delta_d, old_d) {
    return roundTo(delta_d * (10 - old_d) / 9, 8);
  }
  /**
   * The formula used is :
   * $$\text{delta}_d = -w_6 \cdot (g - 3)$$
   * $$\text{next}_d = D + \text{linear damping}(\text{delta}_d , D)$$
   * $$D^\prime(D,R) = w_7 \cdot D_0(4) +(1 - w_7) \cdot \text{next}_d$$
   * @param {number} d Difficulty $$D \in [1,10]$$
   * @param {Grade} g Grade (rating at Anki) [1.again,2.hard,3.good,4.easy]
   * @return {number} $$\text{next}_D$$
   */
  next_difficulty(d, g) {
    const delta_d = -this.param.w[6] * (g - 3);
    const next_d = d + this.linear_damping(delta_d, d);
    return clamp(
      this.mean_reversion(this.init_difficulty(Rating.Easy), next_d),
      1,
      10
    );
  }
  /**
   * The formula used is :
   * $$w_7 \cdot \text{init} +(1 - w_7) \cdot \text{current}$$
   * @param {number} init $$w_2 : D_0(3) = w_2 + (R-2) \cdot w_3= w_2$$
   * @param {number} current $$D - w_6 \cdot (R - 2)$$
   * @return {number} difficulty
   */
  mean_reversion(init, current) {
    const w = this.param.w;
    return roundTo(w[7] * init + (1 - w[7]) * current, 8);
  }
  /**
   * The formula used is :
   * $$S^\prime_r(D,S,R,G) = S\cdot(e^{w_8}\cdot (11-D)\cdot S^{-w_9}\cdot(e^{w_{10}\cdot(1-R)}-1)\cdot w_{15}(\text{if} G=2) \cdot w_{16}(\text{if} G=4)+1)$$
   * @param {number} d Difficulty D \in [1,10]
   * @param {number} s Stability (interval when R=90%)
   * @param {number} r Retrievability (probability of recall)
   * @param {Grade} g Grade (Rating[0.again,1.hard,2.good,3.easy])
   * @return {number} S^\prime_r new stability after recall
   */
  next_recall_stability(d, s, r, g) {
    const w = this.param.w;
    const hard_penalty = Rating.Hard === g ? w[15] : 1;
    const easy_bound = Rating.Easy === g ? w[16] : 1;
    return roundTo(
      clamp(
        s * (1 + Math.exp(w[8]) * (11 - d) * Math.pow(s, -w[9]) * (Math.exp((1 - r) * w[10]) - 1) * hard_penalty * easy_bound),
        S_MIN,
        36500
      ),
      8
    );
  }
  /**
   * The formula used is :
   * $$S^\prime_f(D,S,R) = w_{11}\cdot D^{-w_{12}}\cdot ((S+1)^{w_{13}}-1) \cdot e^{w_{14}\cdot(1-R)}$$
   * enable_short_term = true : $$S^\prime_f \in \min \lbrace \max \lbrace S^\prime_f,0.01\rbrace, \frac{S}{e^{w_{17} \cdot w_{18}}} \rbrace$$
   * enable_short_term = false : $$S^\prime_f \in \min \lbrace \max \lbrace S^\prime_f,0.01\rbrace, S \rbrace$$
   * @param {number} d Difficulty D \in [1,10]
   * @param {number} s Stability (interval when R=90%)
   * @param {number} r Retrievability (probability of recall)
   * @return {number} S^\prime_f new stability after forgetting
   */
  next_forget_stability(d, s, r) {
    const w = this.param.w;
    return roundTo(
      clamp(
        w[11] * Math.pow(d, -w[12]) * (Math.pow(s + 1, w[13]) - 1) * Math.exp((1 - r) * w[14]),
        S_MIN,
        36500
      ),
      8
    );
  }
  /**
   * The formula used is :
   * $$S^\prime_s(S,G) = S \cdot e^{w_{17} \cdot (G-3+w_{18})}$$
   * @param {number} s Stability (interval when R=90%)
   * @param {Grade} g Grade (Rating[0.again,1.hard,2.good,3.easy])
   */
  next_short_term_stability(s, g) {
    const w = this.param.w;
    const sinc = Math.pow(s, -w[19]) * Math.exp(w[17] * (g - 3 + w[18]));
    const maskedSinc = g >= Rating.Hard ? Math.max(sinc, 1) : sinc;
    return roundTo(clamp(s * maskedSinc, S_MIN, 36500), 8);
  }
  /**
   * The formula used is :
   * $$R(t,S) = (1 + \text{FACTOR} \times \frac{t}{9 \cdot S})^{\text{DECAY}}$$
   * @param {number} elapsed_days t days since the last review
   * @param {number} stability Stability (interval when R=90%)
   * @return {number} r Retrievability (probability of recall)
   */
  forgetting_curve;
  /**
   * Calculates the next state of memory based on the current state, time elapsed, and grade.
   *
   * @param memory_state - The current state of memory, which can be null.
   * @param t - The time elapsed since the last review.
   * @param {Rating} g Grade (Rating[0.Manual,1.Again,2.Hard,3.Good,4.Easy])
   * @param r - Optional retrievability value. If not provided, it will be calculated.
   * @returns The next state of memory with updated difficulty and stability.
   */
  next_state(memory_state, t, g, r) {
    const { difficulty: d, stability: s } = memory_state ?? {
      difficulty: 0,
      stability: 0
    };
    if (t < 0) {
      throw new FSRSValidationError(`Invalid delta_t "${t}"`);
    }
    if (g < 0 || g > 4) {
      throw new FSRSValidationError(`Invalid grade "${g}"`);
    }
    if (d === 0 && s === 0) {
      return {
        difficulty: clamp(this.init_difficulty(g), 1, 10),
        stability: this.init_stability(g)
      };
    }
    if (g === 0) {
      return {
        difficulty: d,
        stability: s
      };
    }
    if (d < 1 || s < S_MIN) {
      throw new FSRSValidationError(
        `Invalid memory state { difficulty: ${d}, stability: ${s} }`
      );
    }
    const w = this.param.w;
    r = typeof r === "number" ? r : this.forgetting_curve(t, s);
    let new_s;
    if (t === 0 && this.param.enable_short_term) {
      new_s = this.next_short_term_stability(s, g);
    } else if (g === 1) {
      const s_after_fail = this.next_forget_stability(d, s, r);
      let [w_17, w_18] = [0, 0];
      if (this.param.enable_short_term) {
        w_17 = w[17];
        w_18 = w[18];
      }
      const next_s_min = s / Math.exp(w_17 * w_18);
      new_s = clamp(roundTo(next_s_min, 8), S_MIN, s_after_fail);
    } else {
      new_s = this.next_recall_stability(d, s, r, g);
    }
    const new_d = this.next_difficulty(d, g);
    return { difficulty: new_d, stability: new_s };
  }
};
var BasicScheduler = class extends AbstractScheduler {
  learningStepsStrategy;
  constructor(card, now, algorithm, strategies) {
    super(card, now, algorithm, strategies);
    let learningStepStrategy = BasicLearningStepsStrategy;
    if (this.strategies) {
      const custom_strategy = this.strategies.get(StrategyMode.LEARNING_STEPS);
      if (custom_strategy) {
        learningStepStrategy = custom_strategy;
      }
    }
    this.learningStepsStrategy = learningStepStrategy;
  }
  getLearningInfo(card, grade) {
    const parameters = this.algorithm.parameters;
    card.learning_steps = card.learning_steps || 0;
    const steps_strategy = this.learningStepsStrategy(
      parameters,
      card.state,
      card.learning_steps
    );
    const scheduled_minutes = Math.max(
      0,
      steps_strategy[grade]?.scheduled_minutes ?? 0
    );
    const next_steps = Math.max(0, steps_strategy[grade]?.next_step ?? 0);
    return {
      scheduled_minutes,
      next_steps
    };
  }
  /**
   * @description This function applies the learning steps based on the current card's state and grade.
   */
  applyLearningSteps(nextCard2, grade, to_state) {
    const { scheduled_minutes, next_steps } = this.getLearningInfo(
      this.current,
      grade
    );
    if (scheduled_minutes > 0 && scheduled_minutes < 1440) {
      nextCard2.learning_steps = next_steps;
      nextCard2.scheduled_days = 0;
      nextCard2.state = to_state;
      nextCard2.due = date_scheduler(
        this.review_time,
        Math.round(scheduled_minutes),
        false
        /** true:days false: minute */
      );
    } else {
      nextCard2.state = State.Review;
      if (scheduled_minutes >= 1440) {
        nextCard2.learning_steps = next_steps;
        nextCard2.due = date_scheduler(
          this.review_time,
          Math.round(scheduled_minutes),
          false
          /** true:days false: minute */
        );
        nextCard2.scheduled_days = Math.floor(scheduled_minutes / 1440);
      } else {
        nextCard2.learning_steps = 0;
        const interval = this.algorithm.next_interval(
          nextCard2.stability,
          this.elapsed_days
        );
        nextCard2.scheduled_days = interval;
        nextCard2.due = date_scheduler(this.review_time, interval, true);
      }
    }
  }
  newState(grade) {
    const exist = this.next.get(grade);
    if (exist) {
      return exist;
    }
    const next = this.next_ds(this.elapsed_days, grade);
    this.applyLearningSteps(next, grade, State.Learning);
    const item = {
      card: next,
      log: this.buildLog(grade)
    };
    this.next.set(grade, item);
    return item;
  }
  learningState(grade) {
    const exist = this.next.get(grade);
    if (exist) {
      return exist;
    }
    const next = this.next_ds(this.elapsed_days, grade);
    this.applyLearningSteps(
      next,
      grade,
      this.last.state
      /** Learning or Relearning */
    );
    const item = {
      card: next,
      log: this.buildLog(grade)
    };
    this.next.set(grade, item);
    return item;
  }
  reviewState(grade) {
    const exist = this.next.get(grade);
    if (exist) {
      return exist;
    }
    const interval = this.elapsed_days;
    const retrievability = this.algorithm.forgetting_curve(
      interval,
      this.current.stability
    );
    const next_again = this.next_ds(interval, Rating.Again, retrievability);
    const next_hard = this.next_ds(interval, Rating.Hard, retrievability);
    const next_good = this.next_ds(interval, Rating.Good, retrievability);
    const next_easy = this.next_ds(interval, Rating.Easy, retrievability);
    this.next_interval(next_hard, next_good, next_easy, interval);
    this.next_state(next_hard, next_good, next_easy);
    this.applyLearningSteps(next_again, Rating.Again, State.Relearning);
    next_again.lapses += 1;
    const item_again = {
      card: next_again,
      log: this.buildLog(Rating.Again)
    };
    const item_hard = {
      card: next_hard,
      log: super.buildLog(Rating.Hard)
    };
    const item_good = {
      card: next_good,
      log: super.buildLog(Rating.Good)
    };
    const item_easy = {
      card: next_easy,
      log: super.buildLog(Rating.Easy)
    };
    this.next.set(Rating.Again, item_again);
    this.next.set(Rating.Hard, item_hard);
    this.next.set(Rating.Good, item_good);
    this.next.set(Rating.Easy, item_easy);
    return this.next.get(grade);
  }
  /**
   * Review next_ds
   */
  next_ds(t, g, r) {
    const next_state = this.algorithm.next_state(
      {
        difficulty: this.current.difficulty,
        stability: this.current.stability
      },
      t,
      g,
      r
    );
    const card = TypeConvert.card(this.current);
    card.difficulty = next_state.difficulty;
    card.stability = next_state.stability;
    return card;
  }
  /**
   * Review next_interval
   */
  next_interval(next_hard, next_good, next_easy, interval) {
    let hard_interval, good_interval;
    hard_interval = this.algorithm.next_interval(next_hard.stability, interval);
    good_interval = this.algorithm.next_interval(next_good.stability, interval);
    hard_interval = Math.min(hard_interval, good_interval);
    good_interval = Math.max(good_interval, hard_interval + 1);
    const easy_interval = Math.max(
      this.algorithm.next_interval(next_easy.stability, interval),
      good_interval + 1
    );
    next_hard.scheduled_days = hard_interval;
    next_hard.due = date_scheduler(this.review_time, hard_interval, true);
    next_good.scheduled_days = good_interval;
    next_good.due = date_scheduler(this.review_time, good_interval, true);
    next_easy.scheduled_days = easy_interval;
    next_easy.due = date_scheduler(this.review_time, easy_interval, true);
  }
  /**
   * Review next_state
   */
  next_state(next_hard, next_good, next_easy) {
    next_hard.state = State.Review;
    next_hard.learning_steps = 0;
    next_good.state = State.Review;
    next_good.learning_steps = 0;
    next_easy.state = State.Review;
    next_easy.learning_steps = 0;
  }
};
var LongTermScheduler = class extends AbstractScheduler {
  newState(grade) {
    const exist = this.next.get(grade);
    if (exist) {
      return exist;
    }
    this.current.scheduled_days = 0;
    this.current.elapsed_days = 0;
    const first_interval = 0;
    const next_again = this.next_ds(first_interval, Rating.Again);
    const next_hard = this.next_ds(first_interval, Rating.Hard);
    const next_good = this.next_ds(first_interval, Rating.Good);
    const next_easy = this.next_ds(first_interval, Rating.Easy);
    this.next_interval(
      next_again,
      next_hard,
      next_good,
      next_easy,
      first_interval
    );
    this.next_state(next_again, next_hard, next_good, next_easy);
    this.update_next(next_again, next_hard, next_good, next_easy);
    return this.next.get(grade);
  }
  next_ds(t, g, r) {
    const next_state = this.algorithm.next_state(
      {
        difficulty: this.current.difficulty,
        stability: this.current.stability
      },
      t,
      g,
      r
    );
    const card = TypeConvert.card(this.current);
    card.difficulty = next_state.difficulty;
    card.stability = next_state.stability;
    return card;
  }
  /**
   * @see https://github.com/open-spaced-repetition/ts-fsrs/issues/98#issuecomment-2241923194
   */
  learningState(grade) {
    return this.reviewState(grade);
  }
  reviewState(grade) {
    const exist = this.next.get(grade);
    if (exist) {
      return exist;
    }
    const interval = this.elapsed_days;
    const retrievability = this.algorithm.forgetting_curve(
      interval,
      this.current.stability
    );
    const next_again = this.next_ds(interval, Rating.Again, retrievability);
    const next_hard = this.next_ds(interval, Rating.Hard, retrievability);
    const next_good = this.next_ds(interval, Rating.Good, retrievability);
    const next_easy = this.next_ds(interval, Rating.Easy, retrievability);
    this.next_interval(next_again, next_hard, next_good, next_easy, interval);
    this.next_state(next_again, next_hard, next_good, next_easy);
    next_again.lapses += 1;
    this.update_next(next_again, next_hard, next_good, next_easy);
    return this.next.get(grade);
  }
  /**
   * Review/New next_interval
   */
  next_interval(next_again, next_hard, next_good, next_easy, interval) {
    let again_interval, hard_interval, good_interval, easy_interval;
    again_interval = this.algorithm.next_interval(
      next_again.stability,
      interval
    );
    hard_interval = this.algorithm.next_interval(next_hard.stability, interval);
    good_interval = this.algorithm.next_interval(next_good.stability, interval);
    easy_interval = this.algorithm.next_interval(next_easy.stability, interval);
    again_interval = Math.min(again_interval, hard_interval);
    hard_interval = Math.max(hard_interval, again_interval + 1);
    good_interval = Math.max(good_interval, hard_interval + 1);
    easy_interval = Math.max(easy_interval, good_interval + 1);
    next_again.scheduled_days = again_interval;
    next_again.due = date_scheduler(this.review_time, again_interval, true);
    next_hard.scheduled_days = hard_interval;
    next_hard.due = date_scheduler(this.review_time, hard_interval, true);
    next_good.scheduled_days = good_interval;
    next_good.due = date_scheduler(this.review_time, good_interval, true);
    next_easy.scheduled_days = easy_interval;
    next_easy.due = date_scheduler(this.review_time, easy_interval, true);
  }
  /**
   * Review/New next_state
   */
  next_state(next_again, next_hard, next_good, next_easy) {
    next_again.state = State.Review;
    next_again.learning_steps = 0;
    next_hard.state = State.Review;
    next_hard.learning_steps = 0;
    next_good.state = State.Review;
    next_good.learning_steps = 0;
    next_easy.state = State.Review;
    next_easy.learning_steps = 0;
  }
  update_next(next_again, next_hard, next_good, next_easy) {
    const item_again = {
      card: next_again,
      log: this.buildLog(Rating.Again)
    };
    const item_hard = {
      card: next_hard,
      log: super.buildLog(Rating.Hard)
    };
    const item_good = {
      card: next_good,
      log: super.buildLog(Rating.Good)
    };
    const item_easy = {
      card: next_easy,
      log: super.buildLog(Rating.Easy)
    };
    this.next.set(Rating.Again, item_again);
    this.next.set(Rating.Hard, item_hard);
    this.next.set(Rating.Good, item_good);
    this.next.set(Rating.Easy, item_easy);
  }
};
var Reschedule = class {
  fsrs;
  /**
   * Creates an instance of the `Reschedule` class.
   * @param fsrs - An instance of the FSRS class used for scheduling.
   */
  constructor(fsrs2) {
    this.fsrs = fsrs2;
  }
  /**
   * Replays a review for a card and determines the next review date based on the given rating.
   * @param card - The card being reviewed.
   * @param reviewed - The date the card was reviewed.
   * @param rating - The grade given to the card during the review.
   * @returns A `RecordLogItem` containing the updated card and review log.
   */
  replay(card, reviewed, rating) {
    return this.fsrs.next(card, reviewed, rating);
  }
  /**
   * Processes a manual review for a card, allowing for custom state, stability, difficulty, and due date.
   * @param card - The card being reviewed.
   * @param state - The state of the card after the review.
   * @param reviewed - The date the card was reviewed.
   * @param elapsed_days - The number of days since the last review.
   * @param stability - (Optional) The stability of the card.
   * @param difficulty - (Optional) The difficulty of the card.
   * @param due - (Optional) The due date for the next review.
   * @returns A `RecordLogItem` containing the updated card and review log.
   * @throws Will throw an error if the state or due date is not provided when required.
   */
  handleManualRating(card, state, reviewed, elapsed_days, stability, difficulty, due) {
    if (typeof state === "undefined") {
      throw new FSRSValidationError(
        "reschedule: state is required for manual rating"
      );
    }
    let log;
    let next_card;
    if (state === State.New) {
      log = {
        rating: Rating.Manual,
        state,
        due: due ?? reviewed,
        stability: card.stability,
        difficulty: card.difficulty,
        elapsed_days,
        last_elapsed_days: card.elapsed_days,
        scheduled_days: card.scheduled_days,
        learning_steps: card.learning_steps,
        review: reviewed
      };
      next_card = createEmptyCard(reviewed);
      next_card.last_review = reviewed;
    } else {
      if (typeof due === "undefined") {
        throw new FSRSValidationError(
          "reschedule: due is required for manual rating"
        );
      }
      const scheduled_days = date_diff(due, reviewed, "days");
      log = {
        rating: Rating.Manual,
        state: card.state,
        due: card.last_review || card.due,
        stability: card.stability,
        difficulty: card.difficulty,
        elapsed_days,
        last_elapsed_days: card.elapsed_days,
        scheduled_days: card.scheduled_days,
        learning_steps: card.learning_steps,
        review: reviewed
      };
      next_card = {
        ...card,
        state,
        due,
        last_review: reviewed,
        stability: stability || card.stability,
        difficulty: difficulty || card.difficulty,
        elapsed_days,
        scheduled_days,
        reps: card.reps + 1
      };
    }
    return { card: next_card, log };
  }
  /**
   * Reschedules a card based on its review history.
   *
   * @param current_card - The card to be rescheduled.
   * @param reviews - An array of review history objects.
   * @returns An array of record log items representing the rescheduling process.
   */
  reschedule(current_card, reviews) {
    const collections = [];
    let cur_card = createEmptyCard(current_card.due);
    for (const review of reviews) {
      let item;
      review.review = TypeConvert.time(review.review);
      if (review.rating === Rating.Manual) {
        let interval = 0;
        if (cur_card.state !== State.New && cur_card.last_review) {
          interval = date_diff(review.review, cur_card.last_review, "days");
        }
        item = this.handleManualRating(
          cur_card,
          review.state,
          review.review,
          interval,
          review.stability,
          review.difficulty,
          review.due ? TypeConvert.time(review.due) : void 0
        );
      } else {
        item = this.replay(cur_card, review.review, review.rating);
      }
      collections.push(item);
      cur_card = item.card;
    }
    return collections;
  }
  calculateManualRecord(current_card, now, record_log_item, update_memory) {
    if (!record_log_item) {
      return null;
    }
    const { card: reschedule_card, log } = record_log_item;
    const cur_card = TypeConvert.card(current_card);
    if (cur_card.due.getTime() === reschedule_card.due.getTime()) {
      return null;
    }
    cur_card.scheduled_days = date_diff(
      reschedule_card.due,
      cur_card.due,
      "days"
    );
    return this.handleManualRating(
      cur_card,
      reschedule_card.state,
      TypeConvert.time(now),
      log.elapsed_days,
      update_memory ? reschedule_card.stability : void 0,
      update_memory ? reschedule_card.difficulty : void 0,
      reschedule_card.due
    );
  }
};
function applyAfterHandler(value, afterHandler) {
  return typeof afterHandler === "function" ? afterHandler(value) : value;
}
var FSRS = class extends FSRSAlgorithm {
  strategyHandler = /* @__PURE__ */ new Map();
  Scheduler;
  constructor(param) {
    super(param);
    const { enable_short_term } = this.parameters;
    this.Scheduler = enable_short_term ? BasicScheduler : LongTermScheduler;
  }
  params_handler_proxy() {
    const _this = this;
    return {
      set: function(target, prop, value) {
        if (prop === "request_retention" && Number.isFinite(value)) {
          _this.intervalModifier = _this.calculate_interval_modifier(
            Number(value)
          );
        } else if (prop === "enable_short_term") {
          _this.Scheduler = value === true ? BasicScheduler : LongTermScheduler;
        } else if (prop === "w") {
          value = migrateParameters(
            value,
            target.relearning_steps.length,
            target.enable_short_term
          );
          _this.forgetting_curve = forgetting_curve.bind(this, value);
          _this.intervalModifier = _this.calculate_interval_modifier(
            Number(target.request_retention)
          );
        }
        Reflect.set(target, prop, value);
        return true;
      }
    };
  }
  useStrategy(mode, handler) {
    this.strategyHandler.set(mode, handler);
    return this;
  }
  clearStrategy(mode) {
    if (mode) {
      this.strategyHandler.delete(mode);
    } else {
      this.strategyHandler.clear();
    }
    return this;
  }
  getScheduler(card, now) {
    const schedulerStrategy = this.strategyHandler.get(
      StrategyMode.SCHEDULER
    );
    const Scheduler = schedulerStrategy || this.Scheduler;
    const instance = new Scheduler(card, now, this, this.strategyHandler);
    return instance;
  }
  /**
   * Display the collection of cards and logs for the four scenarios after scheduling the card at the current time.
   * @param card Card to be processed
   * @param now Current time or scheduled time
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const card: Card = createEmptyCard(new Date());
   * const f = fsrs();
   * const recordLog = f.repeat(card, new Date());
   * ```
   * @example
   * ```typescript
   * interface RevLogUnchecked
   *   extends Omit<ReviewLog, "due" | "review" | "state" | "rating"> {
   *   cid: string;
   *   due: Date | number;
   *   state: StateType;
   *   review: Date | number;
   *   rating: RatingType;
   * }
   *
   * interface RepeatRecordLog {
   *   card: CardUnChecked; //see method: createEmptyCard
   *   log: RevLogUnchecked;
   * }
   *
   * function repeatAfterHandler(recordLog: RecordLog) {
   *     const record: { [key in Grade]: RepeatRecordLog } = {} as {
   *       [key in Grade]: RepeatRecordLog;
   *     };
   *     for (const grade of Grades) {
   *       record[grade] = {
   *         card: {
   *           ...(recordLog[grade].card as Card & { cid: string }),
   *           due: recordLog[grade].card.due.getTime(),
   *           state: State[recordLog[grade].card.state] as StateType,
   *           last_review: recordLog[grade].card.last_review
   *             ? recordLog[grade].card.last_review!.getTime()
   *             : null,
   *         },
   *         log: {
   *           ...recordLog[grade].log,
   *           cid: (recordLog[grade].card as Card & { cid: string }).cid,
   *           due: recordLog[grade].log.due.getTime(),
   *           review: recordLog[grade].log.review.getTime(),
   *           state: State[recordLog[grade].log.state] as StateType,
   *           rating: Rating[recordLog[grade].log.rating] as RatingType,
   *         },
   *       };
   *     }
   *     return record;
   * }
   * const card: Card = createEmptyCard(new Date(), cardAfterHandler); //see method:  createEmptyCard
   * const f = fsrs();
   * const recordLog = f.repeat(card, new Date(), repeatAfterHandler);
   * ```
   */
  repeat(card, now, afterHandler) {
    const instance = this.getScheduler(card, now);
    const recordLog = instance.preview();
    return applyAfterHandler(recordLog, afterHandler);
  }
  /**
   * Display the collection of cards and logs for the card scheduled at the current time, after applying a specific grade rating.
   * @param card Card to be processed
   * @param now Current time or scheduled time
   * @param grade Rating of the review (Again, Hard, Good, Easy)
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const card: Card = createEmptyCard(new Date());
   * const f = fsrs();
   * const recordLogItem = f.next(card, new Date(), Rating.Again);
   * ```
   * @example
   * ```typescript
   * interface RevLogUnchecked
   *   extends Omit<ReviewLog, "due" | "review" | "state" | "rating"> {
   *   cid: string;
   *   due: Date | number;
   *   state: StateType;
   *   review: Date | number;
   *   rating: RatingType;
   * }
   *
   * interface NextRecordLog {
   *   card: CardUnChecked; //see method: createEmptyCard
   *   log: RevLogUnchecked;
   * }
   *
  function nextAfterHandler(recordLogItem: RecordLogItem) {
    const recordItem = {
      card: {
        ...(recordLogItem.card as Card & { cid: string }),
        due: recordLogItem.card.due.getTime(),
        state: State[recordLogItem.card.state] as StateType,
        last_review: recordLogItem.card.last_review
          ? recordLogItem.card.last_review!.getTime()
          : null,
      },
      log: {
        ...recordLogItem.log,
        cid: (recordLogItem.card as Card & { cid: string }).cid,
        due: recordLogItem.log.due.getTime(),
        review: recordLogItem.log.review.getTime(),
        state: State[recordLogItem.log.state] as StateType,
        rating: Rating[recordLogItem.log.rating] as RatingType,
      },
    };
    return recordItem
  }
   * const card: Card = createEmptyCard(new Date(), cardAfterHandler); //see method:  createEmptyCard
   * const f = fsrs();
   * const recordLogItem = f.repeat(card, new Date(), Rating.Again, nextAfterHandler);
   * ```
   */
  next(card, now, grade, afterHandler) {
    const instance = this.getScheduler(card, now);
    const g = TypeConvert.rating(grade);
    if (g === Rating.Manual) {
      throw new FSRSValidationError("Cannot review a manual rating");
    }
    const recordLogItem = instance.review(g);
    return applyAfterHandler(recordLogItem, afterHandler);
  }
  /**
   * Get the retrievability of the card
   * @param card  Card to be processed
   * @param now  Current time or scheduled time
   * @param format  default:true , Convert the result to another type. (Optional)
   * @returns  The retrievability of the card,if format is true, the result is a string, otherwise it is a number
   */
  get_retrievability(card, now, format = true) {
    const processedCard = TypeConvert.card(card);
    now = now ? TypeConvert.time(now) : /* @__PURE__ */ new Date();
    const t = processedCard.state !== State.New ? Math.max(date_diff(now, processedCard.last_review, "days"), 0) : 0;
    const r = processedCard.state !== State.New ? this.forgetting_curve(t, +processedCard.stability.toFixed(8)) : 0;
    return format ? `${(r * 100).toFixed(2)}%` : r;
  }
  /**
   *
   * @param card Card to be processed
   * @param log last review log
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const now = new Date();
   * const f = fsrs();
   * const emptyCardFormAfterHandler = createEmptyCard(now);
   * const repeatFormAfterHandler = f.repeat(emptyCardFormAfterHandler, now);
   * const { card, log } = repeatFormAfterHandler[Rating.Hard];
   * const rollbackFromAfterHandler = f.rollback(card, log);
   * ```
   *
   * @example
   * ```typescript
   * const now = new Date();
   * const f = fsrs();
   * const emptyCardFormAfterHandler = createEmptyCard(now, cardAfterHandler);  //see method: createEmptyCard
   * const repeatFormAfterHandler = f.repeat(emptyCardFormAfterHandler, now, repeatAfterHandler); //see method: fsrs.repeat()
   * const { card, log } = repeatFormAfterHandler[Rating.Hard];
   * const rollbackFromAfterHandler = f.rollback(card, log, cardAfterHandler);
   * ```
   */
  rollback(card, log, afterHandler) {
    const processedCard = TypeConvert.card(card);
    const processedLog = TypeConvert.review_log(log);
    if (processedLog.rating === Rating.Manual) {
      throw new FSRSValidationError("Cannot rollback a manual rating");
    }
    let last_due;
    let last_review;
    let last_lapses;
    switch (processedLog.state) {
      case State.New:
        last_due = processedLog.due;
        last_review = void 0;
        last_lapses = 0;
        break;
      case State.Learning:
      case State.Relearning:
      case State.Review:
        last_due = processedLog.review;
        last_review = processedLog.due;
        last_lapses = processedCard.lapses - (processedLog.rating === Rating.Again && processedLog.state === State.Review ? 1 : 0);
        break;
    }
    const prevCard = {
      ...processedCard,
      due: last_due,
      stability: processedLog.stability,
      difficulty: processedLog.difficulty,
      elapsed_days: processedLog.last_elapsed_days,
      scheduled_days: processedLog.scheduled_days,
      reps: Math.max(0, processedCard.reps - 1),
      lapses: Math.max(0, last_lapses),
      learning_steps: processedLog.learning_steps,
      state: processedLog.state,
      last_review
    };
    return applyAfterHandler(prevCard, afterHandler);
  }
  /**
   *
   * @param card Card to be processed
   * @param now Current time or scheduled time
   * @param reset_count Should the review count information(reps,lapses) be reset. (Optional)
   * @param afterHandler Convert the result to another type. (Optional)
   * @example
   * ```typescript
   * const now = new Date();
   * const f = fsrs();
   * const emptyCard = createEmptyCard(now);
   * const scheduling_cards = f.repeat(emptyCard, now);
   * const { card, log } = scheduling_cards[Rating.Hard];
   * const forgetCard = f.forget(card, new Date(), true);
   * ```
   *
   * @example
   * ```typescript
   * interface RepeatRecordLog {
   *   card: CardUnChecked; //see method: createEmptyCard
   *   log: RevLogUnchecked; //see method: fsrs.repeat()
   * }
   *
   * function forgetAfterHandler(recordLogItem: RecordLogItem): RepeatRecordLog {
   *     return {
   *       card: {
   *         ...(recordLogItem.card as Card & { cid: string }),
   *         due: recordLogItem.card.due.getTime(),
   *         state: State[recordLogItem.card.state] as StateType,
   *         last_review: recordLogItem.card.last_review
   *           ? recordLogItem.card.last_review!.getTime()
   *           : null,
   *       },
   *       log: {
   *         ...recordLogItem.log,
   *         cid: (recordLogItem.card as Card & { cid: string }).cid,
   *         due: recordLogItem.log.due.getTime(),
   *         review: recordLogItem.log.review.getTime(),
   *         state: State[recordLogItem.log.state] as StateType,
   *         rating: Rating[recordLogItem.log.rating] as RatingType,
   *       },
   *     };
   * }
   * const now = new Date();
   * const f = fsrs();
   * const emptyCardFormAfterHandler = createEmptyCard(now, cardAfterHandler); //see method:  createEmptyCard
   * const repeatFormAfterHandler = f.repeat(emptyCardFormAfterHandler, now, repeatAfterHandler); //see method: fsrs.repeat()
   * const { card } = repeatFormAfterHandler[Rating.Hard];
   * const forgetFromAfterHandler = f.forget(card, date_scheduler(now, 1, true), false, forgetAfterHandler);
   * ```
   */
  forget(card, now, reset_count = false, afterHandler) {
    const processedCard = TypeConvert.card(card);
    now = TypeConvert.time(now);
    const scheduled_days = processedCard.state === State.New ? 0 : date_diff(now, processedCard.due, "days");
    const forget_log = {
      rating: Rating.Manual,
      state: processedCard.state,
      due: processedCard.due,
      stability: processedCard.stability,
      difficulty: processedCard.difficulty,
      elapsed_days: 0,
      last_elapsed_days: processedCard.elapsed_days,
      scheduled_days,
      learning_steps: processedCard.learning_steps,
      review: now
    };
    const forget_card = {
      ...processedCard,
      due: now,
      stability: 0,
      difficulty: 0,
      elapsed_days: 0,
      scheduled_days: 0,
      reps: reset_count ? 0 : processedCard.reps,
      lapses: reset_count ? 0 : processedCard.lapses,
      learning_steps: 0,
      state: State.New,
      last_review: processedCard.last_review
    };
    const recordLogItem = { card: forget_card, log: forget_log };
    return applyAfterHandler(recordLogItem, afterHandler);
  }
  /**
   * Reschedules the current card and returns the rescheduled collections and reschedule item.
   *
   * @template T - The type of the record log item.
   * @param {CardInput | Card} current_card - The current card to be rescheduled.
   * @param {Array<FSRSHistory>} reviews - The array of FSRSHistory objects representing the reviews.
   * @param {Partial<RescheduleOptions<T>>} options - The optional reschedule options.
   * @returns {IReschedule<T>} - The rescheduled collections and reschedule item.
   *
   * @example
   * ```typescript
   * const f = fsrs()
   * const grades: Grade[] = [Rating.Good, Rating.Good, Rating.Good, Rating.Good]
   * const reviews_at = [
   *   new Date(2024, 8, 13),
   *   new Date(2024, 8, 13),
   *   new Date(2024, 8, 17),
   *   new Date(2024, 8, 28),
   * ]
   *
   * const reviews: FSRSHistory[] = []
   * for (let i = 0; i < grades.length; i++) {
   *   reviews.push({
   *     rating: grades[i],
   *     review: reviews_at[i],
   *   })
   * }
   *
   * const results_short = scheduler.reschedule(
   *   createEmptyCard(),
   *   reviews,
   *   {
   *     skipManual: false,
   *   }
   * )
   * console.log(results_short)
   * ```
   */
  reschedule(current_card, reviews = [], options = {}) {
    const {
      recordLogHandler,
      reviewsOrderBy,
      skipManual = true,
      now = /* @__PURE__ */ new Date(),
      update_memory_state: updateMemoryState = false
    } = options;
    if (reviewsOrderBy && typeof reviewsOrderBy === "function") {
      reviews.sort(reviewsOrderBy);
    }
    if (skipManual) {
      reviews = reviews.filter((review) => review.rating !== Rating.Manual);
    }
    const rescheduleSvc = new Reschedule(this);
    const collections = rescheduleSvc.reschedule(
      options.first_card || createEmptyCard(),
      reviews
    );
    const len = collections.length;
    const cur_card = TypeConvert.card(current_card);
    const manual_item = rescheduleSvc.calculateManualRecord(
      cur_card,
      now,
      len ? collections[len - 1] : void 0,
      updateMemoryState
    );
    return {
      collections: typeof recordLogHandler === "function" ? collections.map(recordLogHandler) : collections,
      reschedule_item: manual_item ? applyAfterHandler(manual_item, recordLogHandler) : null
    };
  }
};
var fsrs = (params) => {
  return new FSRS(params || {});
};

// src/shared/sha256.ts
var roundConstants = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var rotate = (word, bits) => word >>> bits | word << 32 - bits;
function sha256TextChunks(chunks) {
  const hash2 = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const words = new Uint32Array(64), pending = new Uint8Array(64), encoder = new TextEncoder();
  let used = 0, total = 0;
  const block = (view, offset) => {
    for (let index2 = 0; index2 < 16; index2++) words[index2] = view.getUint32(offset + index2 * 4);
    for (let index2 = 16; index2 < 64; index2++) {
      const first = words[index2 - 15], second = words[index2 - 2];
      const sigma0 = rotate(first, 7) ^ rotate(first, 18) ^ first >>> 3;
      const sigma1 = rotate(second, 17) ^ rotate(second, 19) ^ second >>> 10;
      words[index2] = words[index2 - 16] + sigma0 + words[index2 - 7] + sigma1;
    }
    let [a, b, c, d, e, f, g, h] = hash2;
    for (let index2 = 0; index2 < 64; index2++) {
      const upper = rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25), choose = e & f ^ ~e & g;
      const first = h + upper + choose + roundConstants[index2] + words[index2] >>> 0;
      const lower = rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22), majority = a & b ^ a & c ^ b & c;
      h = g;
      g = f;
      f = e;
      e = d + first >>> 0;
      d = c;
      c = b;
      b = a;
      a = first + lower + majority >>> 0;
    }
    const updated = [a, b, c, d, e, f, g, h];
    for (let index2 = 0; index2 < 8; index2++) hash2[index2] += updated[index2];
  };
  const bytes = (value) => {
    total += value.length;
    if (!Number.isSafeInteger(total)) throw new Error("SHA-256 input length is not representable");
    let offset = 0;
    if (used) {
      const count = Math.min(64 - used, value.length);
      pending.set(value.subarray(0, count), used);
      used += count;
      offset = count;
      if (used === 64) {
        block(new DataView(pending.buffer), 0);
        used = 0;
      }
    }
    const view = new DataView(value.buffer, value.byteOffset, value.byteLength);
    for (; offset + 64 <= value.length; offset += 64) block(view, offset);
    if (offset < value.length) {
      pending.set(value.subarray(offset), 0);
      used = value.length - offset;
    }
  };
  let text4 = "", surrogate = "";
  const flush = () => {
    if (!text4) return;
    let value = surrogate + text4;
    text4 = "";
    surrogate = "";
    const last = value.charCodeAt(value.length - 1);
    if (last >= 55296 && last <= 56319) {
      surrogate = value.slice(-1);
      value = value.slice(0, -1);
    }
    if (value) bytes(encoder.encode(value));
  };
  for (const chunk of chunks) {
    if (text4.length + chunk.length > 65536) flush();
    text4 += chunk;
    if (text4.length >= 65536) flush();
  }
  flush();
  if (surrogate) bytes(encoder.encode(surrogate));
  pending.fill(0, used);
  pending[used] = 128;
  if (used >= 56) {
    block(new DataView(pending.buffer), 0);
    pending.fill(0);
  }
  const tail = new DataView(pending.buffer);
  tail.setUint32(56, Math.floor(total / 536870912));
  tail.setUint32(60, total * 8 >>> 0);
  block(tail, 0);
  return Array.from(hash2, (word) => word.toString(16).padStart(8, "0")).join("");
}

// src/shared/json-digest.ts
var normalized = (value, key2) => {
  if (value && (typeof value === "object" || typeof value === "function") && typeof value.toJSON === "function")
    return value.toJSON(key2);
  return value;
};
var omitted = (value) => value === void 0 || typeof value === "function" || typeof value === "symbol";
function* jsonFingerprintChunks(source) {
  const parents = /* @__PURE__ */ new Set(), stack = [{ kind: "value", value: source, key: "" }];
  let chunk = "";
  while (stack.length) {
    const frame = stack.pop();
    if (frame.kind === "array") {
      if (frame.index >= frame.length) {
        parents.delete(frame.value);
        chunk += "]";
      } else {
        if (frame.index) chunk += ",";
        stack.push({ ...frame, index: frame.index + 1 }, { kind: "value", value: frame.value[frame.index], key: String(frame.index), array: true });
      }
    } else if (frame.kind === "object") {
      let name, item;
      while (frame.index < frame.keys.length) {
        const key2 = frame.keys[frame.index++], value = normalized(frame.value[key2], key2);
        if (!omitted(value)) {
          name = key2;
          item = value;
          break;
        }
      }
      if (name === void 0) {
        parents.delete(frame.value);
        chunk += "}";
      } else {
        if (frame.separator) chunk += ",";
        chunk += JSON.stringify(name) + ":";
        frame.separator = true;
        stack.push(frame, { kind: "value", value: item, key: name, ready: true });
      }
    } else {
      const value = frame.ready ? frame.value : normalized(frame.value, frame.key);
      if (omitted(value)) {
        if (frame.array) chunk += "null";
      } else if (!value || typeof value !== "object") chunk += JSON.stringify(value);
      else {
        if (parents.has(value)) throw new TypeError("Converting circular structure to JSON");
        parents.add(value);
        if (Array.isArray(value)) {
          chunk += "[";
          stack.push({ kind: "array", value, index: 0, length: value.length });
        } else {
          chunk += "{";
          const keys5 = Object.keys(Object.fromEntries(Object.keys(value).sort().map((name) => [name, null])));
          stack.push({ kind: "object", value, keys: keys5, index: 0, separator: false });
        }
      }
    }
    while (chunk.length >= 16384) {
      const last = chunk.charCodeAt(16383), width = last >= 55296 && last <= 56319 ? 16383 : 16384;
      yield chunk.slice(0, width);
      chunk = chunk.slice(width);
    }
  }
  if (chunk) yield chunk;
}
function jsonFingerprintEqual(a, b) {
  const left = jsonFingerprintChunks(a), right = jsonFingerprintChunks(b);
  while (true) {
    const x = left.next(), y = right.next();
    if (x.done || y.done) return x.done === y.done;
    if (x.value !== y.value) return false;
  }
}
function cloneJsonValue(source) {
  const parents = /* @__PURE__ */ new Set();
  const copy7 = (input, key2, array = false) => {
    const item = normalized(input, key2), value = item instanceof Number || item instanceof String || item instanceof Boolean ? item.valueOf() : item;
    if (omitted(value)) return array ? null : void 0;
    if (typeof value === "bigint") throw new TypeError("Do not know how to serialize a BigInt");
    if (!value || typeof value !== "object") return typeof value === "number" ? !Number.isFinite(value) ? null : value === 0 ? 0 : value : value;
    if (parents.has(value)) throw new TypeError("Converting circular structure to JSON");
    parents.add(value);
    try {
      if (Array.isArray(value)) {
        const length = value.length, result3 = new Array(length);
        for (let index2 = 0; index2 < length; index2++) {
          const next = copy7(value[index2], String(index2), true);
          if (index2 in Array.prototype) Object.defineProperty(result3, index2, { value: next, enumerable: true, writable: true, configurable: true });
          else result3[index2] = next;
        }
        return result3;
      }
      const result2 = {};
      for (const name of Object.keys(value)) {
        const next = copy7(value[name], name);
        if (next === void 0) continue;
        if (name in Object.prototype) Object.defineProperty(result2, name, { value: next, enumerable: true, writable: true, configurable: true });
        else result2[name] = next;
      }
      return result2;
    } finally {
      parents.delete(value);
    }
  };
  const result = copy7(source, "");
  if (result === void 0) throw new SyntaxError("Value is not JSON");
  return result;
}

// src/shared/json-fingerprint.ts
function jsonFingerprint(value) {
  return JSON.stringify(value, (_key, item) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) return item;
    return Object.fromEntries(Object.keys(item).sort().map((key2) => [key2, item[key2]]));
  });
}

// src/domain/cards/import-source-identity.ts
var PREFIX = "sha256:";
var HASH = /^sha256:[a-f0-9]{64}$/;
var isCompactSourceFingerprint = (value) => typeof value === "string" && HASH.test(value);
function compactSourceFingerprint(fingerprint) {
  return isCompactSourceFingerprint(fingerprint) ? fingerprint : PREFIX + sha256TextChunks([fingerprint]);
}

// src/domain/anchors/source-anchor-fields.ts
var anchorFields = {
  studyRange: true,
  anchorType: true,
  page: true,
  pageY: true,
  scrollRatio: true,
  fragmentText: true,
  line: true,
  ch: true,
  scrollTop: true,
  mdOffset: true,
  mdBefore: true,
  mdAfter: true,
  mdSelection: true,
  pdfLeft: true,
  pdfTop: true,
  pdfZoom: true,
  embeddedPdfPath: true,
  embeddedPdfIndex: true,
  embeddedPdfLine: true,
  canvasX: true,
  canvasY: true,
  canvasZoom: true,
  canvasNodeIds: true,
  canvasFilePaths: true,
  canvasPdfPath: true,
  canvasDocxPath: true,
  canvasPptxPath: true,
  canvasXlsxPath: true,
  canvasImagePath: true,
  canvasMediaPath: true,
  embeddedMediaPath: true,
  embeddedMediaIndex: true,
  embeddedMediaLine: true,
  epubLocation: true,
  epubChapter: true,
  epubPercentage: true,
  epubScrollX: true,
  epubScrollY: true,
  epubStorageKey: true,
  epubStorageValue: true,
  imageX: true,
  imageY: true,
  imageNaturalWidth: true,
  imageNaturalHeight: true,
  docxPage: true,
  docxPageY: true,
  docxScrollX: true,
  docxScrollY: true,
  docxZoom: true,
  docxTextOffset: true,
  docxBefore: true,
  docxAfter: true,
  pptxSlide: true,
  pptxX: true,
  pptxY: true,
  pptxZoom: true,
  xlsxSheetIndex: true,
  xlsxSheetName: true,
  xlsxStartRow: true,
  xlsxStartColumn: true,
  xlsxEndRow: true,
  xlsxEndColumn: true,
  xlsxScrollLeft: true,
  xlsxScrollTop: true,
  xlsxZoom: true,
  excalidrawElementIds: true,
  excalidrawScrollX: true,
  excalidrawScrollY: true,
  excalidrawZoom: true,
  mediaTime: true,
  mediaDuration: true,
  mediaProgress: true,
  mediaKind: true,
  mediaRange: true,
  mediaSourceVersion: true,
  textLine: true,
  textColumn: true,
  textOffset: true,
  textBefore: true,
  textAfter: true,
  textSelection: true,
  textKind: true,
  canvasTextPath: true
};
var SOURCE_REPAIR_ANCHOR_FIELDS = Object.keys(anchorFields);

// src/domain/companion/capacity.ts
var MAX_COMPANION_SESSION_CARDS = 1e3;
var MAX_COMPANION_SNAPSHOT_BYTES = 256 * 1024 * 1024;
var MAX_COMPANION_SNAPSHOT_CHUNK_BYTES = 512 * 1024;
var MAX_COMPANION_CATALOG_PAGE_BYTES = 512 * 1024;
var COMPANION_STUDY_COPY_TTL = 30 * 864e5;
var LEGACY_COMPANION_STUDY_COPY_TTL = 7 * 864e5;

// src/domain/review/external-review.ts
var EXTERNAL_CLOCK_SKEW = 5 * 6e4;

// src/domain/library/tag-key.ts
var tagKey = (value) => value.toLocaleLowerCase();

// src/domain/cards/card-clarification.ts
var CARD_CLARIFICATION_REASONS = [
  { value: "unclear-question", label: "\u041D\u0435\u044F\u0441\u043D\u044B\u0439 \u0432\u043E\u043F\u0440\u043E\u0441" },
  { value: "disputed-answer", label: "\u0421\u043F\u043E\u0440\u043D\u044B\u0439 \u043E\u0442\u0432\u0435\u0442" },
  { value: "too-much-information", label: "\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u043D\u043E\u0433\u043E \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438" },
  { value: "missing-context", label: "\u041D\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430" },
  { value: "other", label: "\u0414\u0440\u0443\u0433\u0430\u044F \u043F\u0440\u0438\u0447\u0438\u043D\u0430" }
];
var MAX_CLARIFICATION_NOTE_LENGTH = 4e3;
function normalizeCardClarification(value) {
  if (value === void 0) return void 0;
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key2) => key2 !== "reason" && key2 !== "note"))
    throw new Error("\u041F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u043E \u043F\u043E\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u043A \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0435.");
  const raw = value;
  if (raw.reason !== void 0 && !CARD_CLARIFICATION_REASONS.some((reason2) => reason2.value === raw.reason))
    throw new Error("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0443\u044E \u043F\u0440\u0438\u0447\u0438\u043D\u0443 \u0443\u0442\u043E\u0447\u043D\u0435\u043D\u0438\u044F.");
  if (raw.note !== void 0 && (typeof raw.note !== "string" || raw.note.length > MAX_CLARIFICATION_NOTE_LENGTH))
    throw new Error(`\u0417\u0430\u043C\u0435\u0442\u043A\u0430: \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 ${MAX_CLARIFICATION_NOTE_LENGTH} \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432.`);
  const reason = raw.reason;
  const note = typeof raw.note === "string" && raw.note.trim() ? raw.note : void 0;
  return reason === void 0 && note === void 0 ? void 0 : { ...reason !== void 0 ? { reason } : {}, ...note !== void 0 ? { note } : {} };
}

// src/domain/review/daily-workload.ts
var DEFAULT_DAILY_WORKLOAD_SETTINGS = Object.freeze({
  enabled: false,
  newLimit: 5,
  reviewLimit: 30,
  pauseNewWithOverdue: false,
  debtPortion: 10
});

// src/domain/planning/study-task.ts
var inputKeys = ["title", "note", "materialId", "plannedDate", "startTime", "durationMinutes", "calendarSync", "recurrence", "repeatDays", "repeatTimes", "autoplanEnabled"];
var taskKeys = [...inputKeys, "id", "calendarGeneration", "completedAt", "createdAt", "updatedAt", "seriesId", "occurrenceDate", "skippedAt"];
function isStudyTaskDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const year = Number(match[1]), month = Number(match[2]), day2 = Number(match[3]);
  if (year < 1 || month < 1 || month > 12 || day2 < 1) return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  return day2 <= [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
}

// src/domain/planning/study-autoplan-plan.ts
function zonedClock(zone) {
  let formatter;
  try {
    formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: zone,
      calendar: "gregory",
      numberingSystem: "latn",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23"
    });
  } catch {
    throw new Error("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u044C \u0447\u0430\u0441\u043E\u0432\u043E\u0439 \u043F\u043E\u044F\u0441 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u043B\u0430\u043D\u0430.");
  }
  const parts = (time3) => {
    const values = formatter.formatToParts(time3);
    return ["year", "month", "day", "hour", "minute", "second"].map((type) => Number(values.find((value) => value.type === type)?.value));
  };
  const utc = (y, m, d, h = 0, n = 0) => {
    const value = /* @__PURE__ */ new Date(0);
    value.setUTCFullYear(y, m - 1, d);
    value.setUTCHours(h, n, 0, 0);
    return value.getTime();
  };
  const cache = /* @__PURE__ */ new Map();
  const instant = (key2, minutes) => {
    const cacheKey = `${key2}/${minutes}`;
    if (cache.has(cacheKey)) return cache.get(cacheKey);
    const [y, m, d] = key2.split("-").map(Number), h = Math.floor(minutes / 60), n = minutes % 60;
    const wall = utc(y, m, d, h, n), matches = [];
    for (const offset of [-2, -1, 0, 1, 2]) {
      const sample = wall + offset * 864e5, shown = parts(sample);
      const difference = utc(shown[0], shown[1], shown[2], shown[3], shown[4]) - sample;
      const candidate = wall - difference, actual = parts(candidate);
      if (actual.slice(0, 5).every((value, index2) => value === [y, m, d, h, n][index2])) matches.push(candidate);
    }
    const result = matches.length ? Math.min(...matches) : void 0;
    cache.set(cacheKey, result);
    return result;
  };
  return { parts, instant };
}

// src/shared/constants.ts
var AUDIO_EXTENSIONS = /* @__PURE__ */ new Set(["mp3", "wav", "m4a", "ogg", "flac", "opus", "aac", "weba"]);
var VIDEO_EXTENSIONS = /* @__PURE__ */ new Set(["mp4", "webm", "mov", "m4v", "ogv", "mkv"]);
var MEDIA_EXTENSIONS = /* @__PURE__ */ new Set([...AUDIO_EXTENSIONS, ...VIDEO_EXTENSIONS]);
var WINDOWS_NOTIFICATION_ICON = `data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#6f52c8"/><path d="M20 42h24l-3-5V28a9 9 0 0 0-18 0v9l-3 5Zm8 5a4 4 0 0 0 8 0" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>')}`;

// src/domain/scheduling/fsrs-card.ts
var serializeFsrsCard = (card) => ({
  due: card.due.getTime(),
  stability: card.stability,
  difficulty: card.difficulty,
  elapsedDays: card.elapsed_days,
  scheduledDays: card.scheduled_days,
  learningSteps: card.learning_steps,
  reps: card.reps,
  lapses: card.lapses,
  state: card.state,
  lastReview: card.last_review?.getTime()
});
var deserializeFsrsCard = (card) => ({
  due: card.due,
  stability: card.stability,
  difficulty: card.difficulty,
  elapsed_days: card.elapsedDays,
  scheduled_days: card.scheduledDays,
  learning_steps: card.learningSteps,
  reps: card.reps,
  lapses: card.lapses,
  state: card.state,
  last_review: card.lastReview ?? null
});

// src/domain/scheduling/fsrs-scheduler.ts
function createInitialFsrsCard(source) {
  const card = createEmptyCard(new Date(source.createdAt));
  card.due = new Date(source.dueAt);
  return card;
}
function nextFsrsCard(source, rating, reviewedAt, parameters) {
  const card = source.fsrsCard ? deserializeFsrsCard(source.fsrsCard) : createInitialFsrsCard(source);
  return serializeFsrsCard(fsrs(parameters).next(card, new Date(reviewedAt), rating).card);
}

// src/domain/planning/study-target.ts
var DAY = 864e5;
var STUDY_TARGET_TRANSITION_MS = 7 * DAY;
var STUDY_TARGET_RETENTION = 0.95;
var fail = () => {
  throw new Error("\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u043A \u0434\u0430\u0442\u0435 \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0435\u043D\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0434\u0430\u0442\u0443, \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0438 \u0447\u0430\u0441\u043E\u0432\u043E\u0439 \u043F\u043E\u044F\u0441.");
};
var object2 = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value);
var time = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && Number.isFinite(new Date(value).getTime());
var exact = (value, required, optional = []) => required.every((key2) => Object.prototype.hasOwnProperty.call(value, key2)) && Object.keys(value).every((key2) => required.includes(key2) || optional.includes(key2));
function studyTargetCivilBoundaryAt(targetDate, timeZone, end) {
  if (!isStudyTaskDate(targetDate)) return fail();
  let formatter;
  try {
    formatter = new Intl.DateTimeFormat("en-US", { timeZone, calendar: "gregory", numberingSystem: "latn", year: "numeric", month: "2-digit", day: "2-digit" });
  } catch {
    return fail();
  }
  const [year, month, day2] = targetDate.split("-").map(Number), next = /* @__PURE__ */ new Date(0);
  next.setUTCFullYear(year, month - 1, day2 + (end ? 1 : 0));
  next.setUTCHours(0, 0, 0, 0);
  const ordinal2 = (at) => {
    const parts = formatter.formatToParts(at), part = (key2) => Number(parts.find((value) => value.type === key2)?.value);
    return part("year") * 1e4 + part("month") * 100 + part("day");
  };
  const expected = year * 1e4 + month * 100 + day2;
  const boundary = next.getUTCFullYear() * 1e4 + (next.getUTCMonth() + 1) * 100 + next.getUTCDate();
  let low = Math.max(0, next.getTime() - 2 * DAY), high = next.getTime() + 2 * DAY;
  if (!time(low) || !time(high) || ordinal2(low) >= boundary || ordinal2(high) < boundary) return fail();
  while (low + 1 < high) {
    const middle = low + Math.floor((high - low) / 2);
    if (ordinal2(middle) < boundary) low = middle;
    else high = middle;
  }
  if ((end ? ordinal2(high - 1) : ordinal2(high)) !== expected || !time(high + STUDY_TARGET_TRANSITION_MS)) return fail();
  return high;
}
function studyTargetExamEndAt(targetDate, timeZone) {
  return studyTargetCivilBoundaryAt(targetDate, timeZone, true);
}
function validateStudyTargetSchedulePolicy(value) {
  if (!object2(value) || !exact(value, ["from", "examEndAt", "transitionEndAt"], ["until", "reviewByAt"]) || !time(value.from) || !time(value.examEndAt) || !time(value.transitionEndAt) || value.transitionEndAt !== value.examEndAt + STUDY_TARGET_TRANSITION_MS || value.reviewByAt !== void 0 && (!time(value.reviewByAt) || value.reviewByAt >= value.examEndAt || value.examEndAt - value.reviewByAt >= 3 * DAY) || value.until !== void 0 && (!time(value.until) || value.until < value.from)) return fail();
  return { from: value.from, ...value.until === void 0 ? {} : { until: value.until }, ...value.reviewByAt === void 0 ? {} : { reviewByAt: value.reviewByAt }, examEndAt: value.examEndAt, transitionEndAt: value.transitionEndAt };
}
function studyTargetRetention(base, policy, at) {
  if (!Number.isFinite(base) || base <= 0 || base >= 1 || !time(at)) return fail();
  if (!policy || at < policy.from || policy.until !== void 0 && at >= policy.until || at >= policy.transitionEndAt) return base;
  const target = Math.max(base, STUDY_TARGET_RETENTION);
  return at < policy.examEndAt ? target : base + (target - base) * (policy.transitionEndAt - at) / STUDY_TARGET_TRANSITION_MS;
}
function applyStudyTargetDue(next, policy, at) {
  return policy && at >= policy.from && (policy.until === void 0 || at < policy.until) && next.state === State.Review && at < policy.examEndAt && policy.reviewByAt !== void 0 && (policy.reviewByAt > at || next.lastReview !== void 0 && next.lastReview < policy.reviewByAt) && next.due > policy.reviewByAt ? { ...next, due: policy.reviewByAt } : next;
}

// src/domain/companion/offline-fsrs.ts
var OFFLINE_FSRS_ENGINE = "ts-fsrs-5.4.1";
var MAX_ENCODING = 8192;
var MAX_TIME = 864e13;
var CLOCK_SKEW = 5 * 6e4;
var check3 = (condition) => {
  if (!condition) throw new Error("Invalid offline FSRS payload");
};
var record = (value) => {
  check3(value !== null && typeof value === "object" && !Array.isArray(value));
  return value;
};
var exactKeys = (value, required, optional = []) => {
  check3(required.every((key2) => Object.prototype.hasOwnProperty.call(value, key2)) && Object.keys(value).every((key2) => required.includes(key2) || optional.includes(key2)));
};
var time2 = (value) => Number.isSafeInteger(value) && Number(value) >= 0 && Number(value) <= MAX_TIME;
var token = (value) => typeof value === "string" && /^[A-Za-z0-9._:-]{1,128}$/.test(value);
function canonical(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    check3(Number.isSafeInteger(value));
    return String(value);
  }
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  const object8 = record(value);
  return "{" + Object.keys(object8).sort().map((key2) => JSON.stringify(key2) + ":" + canonical(object8[key2])).join(",") + "}";
}
function parse(encoded) {
  check3(typeof encoded === "string" && encoded.length >= 2 && encoded.length <= MAX_ENCODING);
  let parsed;
  try {
    parsed = JSON.parse(encoded);
  } catch {
    throw new Error("Invalid offline FSRS payload");
  }
  const object8 = record(parsed);
  check3(canonical(object8) === encoded);
  return object8;
}
var decimal = (value, min = 0, max = 1e12) => {
  check3(typeof value === "string" && value.length <= 32);
  const number = Number(value);
  check3(Number.isFinite(number) && String(number) === value && number >= min && number <= max);
  return number;
};
var nativeDecimal = (value) => {
  check3(typeof value === "number" && Number.isFinite(value) && !Object.is(value, -0));
  return String(value);
};
var stateFields = ["due", "stability", "difficulty", "elapsedDays", "scheduledDays", "learningSteps", "reps", "lapses", "state"];
function encodeOfflineFsrsState(state) {
  const source = record(state);
  exactKeys(source, stateFields, ["lastReview"]);
  const object8 = Object.fromEntries(stateFields.map((key2) => [key2, nativeDecimal(source[key2])]));
  if (source.lastReview !== void 0) object8.lastReview = nativeDecimal(source.lastReview);
  const encoded = canonical(object8);
  decodeOfflineFsrsState(encoded);
  return encoded;
}
function decodeOfflineFsrsState(encoded) {
  const object8 = parse(encoded);
  exactKeys(object8, stateFields, ["lastReview"]);
  const state = Object.fromEntries(stateFields.map((key2) => [key2, decimal(object8[key2], 0, key2 === "due" ? MAX_TIME : 1e12)]));
  check3(time2(state.due) && state.stability <= 1e6 && state.difficulty <= 10 && [0, 1, 2, 3].includes(state.state));
  for (const value of [state.learningSteps, state.reps, state.lapses]) check3(Number.isSafeInteger(value));
  if (object8.lastReview !== void 0) {
    state.lastReview = decimal(object8.lastReview, 0, MAX_TIME);
    check3(time2(state.lastReview));
  }
  return state;
}
var configFields = ["request_retention", "maximum_interval", "w", "enable_fuzz", "enable_short_term", "learning_steps", "relearning_steps"];
function encodedConfig(parameters) {
  const source = record(parameters);
  exactKeys(source, configFields);
  check3(Array.isArray(parameters.w) && Array.isArray(parameters.learning_steps) && Array.isArray(parameters.relearning_steps));
  return {
    request_retention: nativeDecimal(parameters.request_retention),
    maximum_interval: nativeDecimal(parameters.maximum_interval),
    w: parameters.w.map(nativeDecimal),
    enable_fuzz: parameters.enable_fuzz,
    enable_short_term: parameters.enable_short_term,
    learning_steps: [...parameters.learning_steps],
    relearning_steps: [...parameters.relearning_steps]
  };
}
function decodeOfflineFsrsConfig(encoded) {
  const object8 = parse(encoded);
  exactKeys(object8, configFields);
  const steps = (value) => {
    check3(Array.isArray(value) && value.length <= 16 && value.every((step) => typeof step === "string" && step.length <= 32 && /^(?:[1-9]\d{0,8})(?:\.\d+)?[mhd]$/.test(step)));
    return [...value];
  };
  check3(Array.isArray(object8.w) && object8.w.length === 21 && typeof object8.enable_fuzz === "boolean" && typeof object8.enable_short_term === "boolean");
  const config = {
    request_retention: decimal(object8.request_retention, 0, 1),
    maximum_interval: decimal(object8.maximum_interval, 1, 1e9),
    w: object8.w.map((weight) => decimal(weight, -1e6, 1e6)),
    enable_fuzz: object8.enable_fuzz,
    enable_short_term: object8.enable_short_term,
    learning_steps: steps(object8.learning_steps),
    relearning_steps: steps(object8.relearning_steps)
  };
  check3(config.request_retention > 0 && config.request_retention < 1 && Number.isSafeInteger(config.maximum_interval));
  check3(canonical(encodedConfig(fsrs(config).parameters)) === encoded);
  return config;
}
function encodeOfflineSeed(seed) {
  const { studyTarget, ...required } = seed;
  const encoded = canonical({ ...required, ...studyTarget === void 0 ? {} : { studyTarget: validateStudyTargetSchedulePolicy(studyTarget) } });
  decodeOfflineSeed(encoded);
  return encoded;
}
function decodeOfflineSeed(encoded) {
  const object8 = parse(encoded);
  exactKeys(object8, ["version", "engine", "config", "state", "rootRevision", "issuedAt", "expiresAt"], ["studyTarget"]);
  check3(object8.version === 1 && object8.engine === OFFLINE_FSRS_ENGINE && token(object8.rootRevision) && time2(object8.issuedAt) && time2(object8.expiresAt) && object8.expiresAt > object8.issuedAt && object8.expiresAt - object8.issuedAt <= COMPANION_STUDY_COPY_TTL);
  decodeOfflineFsrsConfig(object8.config);
  decodeOfflineFsrsState(object8.state);
  if (object8.studyTarget !== void 0) validateStudyTargetSchedulePolicy(object8.studyTarget);
  return object8;
}
function validateOfflineSeed(encoded) {
  decodeOfflineSeed(encoded);
}
function encodeOfflineStep(step) {
  exactKeys(record(step), ["version", "rootRevision", "index", "before", "after"], ["parentId", "early"]);
  const { parentId, early, ...required } = step, encoded = canonical({ ...required, ...parentId === void 0 ? {} : { parentId }, ...early === void 0 ? {} : { early } });
  decodeOfflineStep(encoded);
  return encoded;
}
function decodeOfflineStep(encoded) {
  const object8 = parse(encoded);
  exactKeys(object8, ["version", "rootRevision", "index", "before", "after"], ["parentId", "early"]);
  check3(object8.version === 1 && token(object8.rootRevision) && Number.isSafeInteger(object8.index) && Number(object8.index) >= 1 && Number(object8.index) <= 1e4);
  check3(object8.index === 1 ? object8.parentId === void 0 : token(object8.parentId));
  const before = decodeOfflineFsrsState(object8.before), after = decodeOfflineFsrsState(object8.after);
  check3(after.reps === before.reps + 1 && after.lastReview !== void 0 && after.state !== State.New && after.due >= after.lastReview && (before.lastReview === void 0 || after.lastReview >= before.lastReview) && after.lapses >= before.lapses && after.lapses <= before.lapses + 1);
  check3(object8.early === void 0 || object8.early === true && Number(object8.index) > 1 && stateIsShortStep(object8.before) && after.lastReview < before.due);
  return object8;
}
function advanceOfflineFsrs(seed, before, rating, occurredAt) {
  const resolved = typeof seed === "string" ? decodeOfflineSeed(seed) : decodeOfflineSeed(encodeOfflineSeed(seed)), state = decodeOfflineFsrsState(before);
  check3([1, 2, 3, 4].includes(rating) && time2(occurredAt) && occurredAt >= resolved.issuedAt - CLOCK_SKEW && occurredAt < resolved.expiresAt && (state.lastReview === void 0 || occurredAt >= state.lastReview));
  const parameters = decodeOfflineFsrsConfig(resolved.config);
  parameters.request_retention = studyTargetRetention(parameters.request_retention, resolved.studyTarget, occurredAt);
  return encodeOfflineFsrsState(applyStudyTargetDue(nextFsrsCard({ createdAt: resolved.issuedAt, dueAt: state.due, fsrsCard: state }, rating, occurredAt, parameters), resolved.studyTarget, occurredAt));
}
function offlineStateDue(state) {
  return decodeOfflineFsrsState(state).due;
}
function stateIsShortStep(state) {
  const card = decodeOfflineFsrsState(state);
  return [State.Learning, State.Relearning].includes(card.state) && card.scheduledDays < 1;
}
function offlineReviewTimeAllowed(step, occurredAt) {
  const before = decodeOfflineFsrsState(step.before);
  return time2(occurredAt) && (before.lastReview === void 0 || occurredAt >= before.lastReview) && (step.early === void 0 ? occurredAt >= before.due : step.early === true && step.index > 1 && stateIsShortStep(step.before) && occurredAt < before.due);
}

// src/domain/companion/study-target.ts
var object3 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var fail2 = () => {
  throw new Error("Invalid companion study target");
};
var fields2 = ["version", "id", "enabled", "targetDate", "timeZone", "examEndAt", "transitionEndAt", "cardIds"];
function validateCompanionStudyTarget(value, cards) {
  if (!object3(value) || Object.keys(value).length !== fields2.length || !fields2.every((key2) => Object.prototype.hasOwnProperty.call(value, key2)) || value.version !== 1 || typeof value.id !== "string" || !/^[a-f0-9]{64}$/.test(value.id) || typeof value.enabled !== "boolean" || typeof value.targetDate !== "string" || !value.targetDate || typeof value.timeZone !== "string" || value.timeZone.length > 100 || !Array.isArray(value.cardIds) || new Set(value.cardIds).size !== value.cardIds.length || !Array.from(value.cardIds).every((id2) => typeof id2 === "string" && /^[a-zA-Z0-9._:-]{1,128}$/.test(id2))) return fail2();
  let end;
  try {
    end = studyTargetExamEndAt(value.targetDate, value.timeZone);
  } catch {
    return fail2();
  }
  if (value.examEndAt !== end || value.transitionEndAt !== end + STUDY_TARGET_TRANSITION_MS) return fail2();
  if (cards) {
    const allowed = new Set(cards.filter((card) => card.mode === "core" && card.eligible).map((card) => card.id));
    if (!value.cardIds.every((id2) => allowed.has(id2))) return fail2();
  }
}

// src/domain/companion/protocol.ts
var MAX_COMPANION_BRIDGE_BYTES = 5e6;
var COMPANION_CLOCK_SKEW = 5 * 6e4;
function companionSnapshotIsCurrent(snapshot, now) {
  return Number.isSafeInteger(now) && now >= 0 && snapshot.generatedAt - now <= COMPANION_CLOCK_SKEW && now < snapshot.expiresAt;
}
var emptyState = () => ({
  version: 1,
  revoked: false,
  pending: [],
  outcomes: [],
  callbacks: [],
  reminders: { mutedUntil: 0, enabled: true, quietUpdates: false }
});
function invalid(condition, message = "invalid companion payload") {
  if (!condition) throw new Error(message);
}
function record2(value) {
  invalid(value !== null && typeof value === "object" && !Array.isArray(value));
}
function keys(value, allowed) {
  invalid(Object.keys(value).every((key2) => allowed.includes(key2)));
}
function token2(value) {
  invalid(typeof value === "string" && /^[a-zA-Z0-9._:-]{1,128}$/.test(value));
}
function text(value, max) {
  invalid(typeof value === "string" && value.length > 0 && value.length <= max);
}
function timestamp(value) {
  invalid(Number.isSafeInteger(value) && value >= 0);
}
function validateSnapshot(value) {
  record2(value);
  keys(value, ["version", "scope", "epoch", "sequence", "generatedAt", "expiresAt", "cards", "earlyShortRepeats", "studyTarget"]);
  invalid(value.earlyShortRepeats === void 0 || value.earlyShortRepeats === true);
  invalid(value.version === 1);
  token2(value.scope);
  token2(value.epoch);
  timestamp(value.sequence);
  invalid(value.sequence > 0);
  timestamp(value.generatedAt);
  timestamp(value.expiresAt);
  invalid(value.expiresAt > value.generatedAt && value.expiresAt - value.generatedAt <= COMPANION_STUDY_COPY_TTL);
  invalid(Array.isArray(value.cards));
  if (value.studyTarget !== void 0) validateCompanionStudyTarget(value.studyTarget, value.cards);
  const ids = /* @__PURE__ */ new Set();
  const materialTitles = /* @__PURE__ */ new Map();
  for (const c of value.cards) {
    record2(c);
    keys(c, ["id", "revision", "materialId", "materialTitle", "mode", "question", "reference", "eligible", "dueAt", "evaluationMode", "acceptedAnswers", "answerMatchMode", "hints", "media", "exercise", "offline"]);
    token2(c.id);
    token2(c.revision);
    token2(c.materialId);
    text(c.materialTitle, 120);
    text(c.question, 1800);
    text(c.reference, 1800);
    invalid(c.mode === "bank" || c.mode === "core");
    invalid(typeof c.eligible === "boolean");
    if (c.dueAt !== void 0) timestamp(c.dueAt);
    if (c.offline !== void 0) {
      const seed = decodeOfflineSeed(c.offline);
      invalid(c.mode === "core" && c.eligible === true && c.dueAt === offlineStateDue(seed.state) && seed.rootRevision === c.revision && seed.issuedAt - value.generatedAt <= COMPANION_CLOCK_SKEW && seed.expiresAt >= value.expiresAt);
    }
    invalid(c.evaluationMode === void 0 || c.evaluationMode === "exact");
    if (c.exercise !== void 0) {
      validateCompanionExercise(c.exercise);
      invalid(c.evaluationMode === "exact" && c.acceptedAnswers === void 0 && c.answerMatchMode === void 0);
      invalid(c.reference === companionExerciseReference(c.exercise) && companionExerciseQuestion(c.exercise, c.question).length <= 1800);
    } else if (c.evaluationMode === "exact") {
      invalid(c.answerMatchMode === void 0 || c.answerMatchMode === "text" || c.answerMatchMode === "literal");
      if (c.acceptedAnswers !== void 0) {
        invalid(Array.isArray(c.acceptedAnswers) && c.acceptedAnswers.length > 0 && c.acceptedAnswers.length <= 12);
        invalid(Array.from(c.acceptedAnswers).every((answer) => typeof answer === "string" && answer.trim().length > 0 && answer.length <= 2e3 && (c.answerMatchMode === "literal" || !!normalizeTestAnswer(answer))));
      } else invalid(c.answerMatchMode === "literal" ? !!c.reference.trim() : c.reference.split(/[\n|]+/).some((answer) => !!normalizeTestAnswer(answer)));
    } else invalid(c.acceptedAnswers === void 0 && c.answerMatchMode === void 0);
    if (c.hints !== void 0) {
      invalid(Array.isArray(c.hints) && c.hints.length <= 10);
      invalid(Array.from(c.hints).every((hint) => typeof hint === "string" && hint.trim().length > 0 && hint.length <= 2e3 && !/!\[|<(?:img|audio|video|iframe|object|embed|svg|picture|canvas)\b/i.test(hint)));
    }
    if (c.media !== void 0) {
      invalid(Array.isArray(c.media) && c.media.length <= 12);
      Array.from(c.media).forEach(validateCompanionMediaAttachment);
    }
    invalid(!ids.has(c.id));
    ids.add(c.id);
    invalid(!materialTitles.has(c.materialId) || materialTitles.get(c.materialId) === c.materialTitle);
    materialTitles.set(c.materialId, c.materialTitle);
  }
}
function validateAttempt(value) {
  record2(value);
  keys(value, ["id", "scope", "epoch", "cardId", "revision", "sequence", "mode", "occurredAt", "rating", "correct", "offline"]);
  for (const key2 of ["id", "scope", "epoch", "cardId", "revision"]) token2(value[key2]);
  timestamp(value.sequence);
  invalid(value.sequence > 0);
  timestamp(value.occurredAt);
  invalid(value.mode === "bank" || value.mode === "core");
  invalid([1, 2, 3, 4].includes(value.rating));
  invalid(typeof value.correct === "boolean");
  if (value.offline !== void 0) {
    const step = decodeOfflineStep(value.offline);
    invalid(value.mode === "core" && value.revision === (step.index === 1 ? step.rootRevision : step.parentId));
  }
}
function validateState(value) {
  record2(value);
  keys(value, ["version", "revoked", "snapshot", "pending", "outcomes", "callbacks", "reminders"]);
  invalid(value.version === 1 && typeof value.revoked === "boolean");
  if (value.snapshot !== void 0) validateSnapshot(value.snapshot);
  invalid(Array.isArray(value.pending));
  value.pending.forEach(validateAttempt);
  invalid(Array.isArray(value.outcomes));
  for (const outcome of value.outcomes) {
    record2(outcome);
    keys(outcome, ["attempt", "status"]);
    validateAttempt(outcome.attempt);
    invalid(["applied", "stale", "epoch-mismatch", "missing", "ineligible", "local-session-active", "expired", "clock-mismatch", "core-adapter-unavailable"].includes(outcome.status));
  }
  const attemptIds = /* @__PURE__ */ new Set();
  for (const a of [...value.pending, ...value.outcomes.map((o) => o.attempt)]) {
    const key2 = attemptKey(a);
    invalid(!attemptIds.has(key2));
    attemptIds.add(key2);
  }
  invalid(Array.isArray(value.callbacks));
  const ids = /* @__PURE__ */ new Set();
  for (const r of value.callbacks) {
    record2(r);
    keys(r, ["id", "command", "result"]);
    token2(r.id);
    text(r.command, 8192);
    text(r.result, 200);
    invalid(!ids.has(r.id));
    ids.add(r.id);
  }
  record2(value.reminders);
  keys(value.reminders, ["mutedUntil", "skippedDay", "enabled", "quietUpdates"]);
  timestamp(value.reminders.mutedUntil);
  invalid(typeof value.reminders.enabled === "boolean" && typeof value.reminders.quietUpdates === "boolean");
  if (value.reminders.skippedDay !== void 0) invalid(typeof value.reminders.skippedDay === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value.reminders.skippedDay));
}
function sameAttempt(a, b) {
  return Object.keys(a).every((key2) => a[key2] === b[key2]) && Object.keys(a).length === Object.keys(b).length;
}
function attemptKey(a) {
  return JSON.stringify([a.scope, a.epoch, a.id]);
}
function queryCards(snapshot, suppressed, options) {
  invalid(companionSnapshotIsCurrent(snapshot, options.now), "snapshot expired or clock moved backwards");
  const size = options.pageSize ?? 4;
  invalid(Number.isInteger(size) && size >= 1 && size <= 20);
  const search = (options.search ?? "").trim().toLocaleLowerCase();
  invalid(search.length <= 200);
  const identity5 = JSON.stringify([snapshot.epoch, snapshot.sequence, search, !!options.dueOnly, size, options.materialId ?? null]);
  let offset = 0;
  if (options.cursor) {
    const cursor = JSON.parse(options.cursor);
    invalid(Array.isArray(cursor) && cursor.length === 2 && cursor[0] === identity5 && Number.isInteger(cursor[1]) && cursor[1] >= 0, "stale cursor");
    offset = cursor[1];
  }
  const suppressedIds = new Set(suppressed.filter((a) => a.scope === snapshot.scope && a.epoch === snapshot.epoch).map((a) => a.cardId));
  const cards = snapshot.cards.filter((c) => c.eligible && (c.offline === void 0 || c.dueAt !== void 0 && c.dueAt <= options.now) && (!options.materialId || c.materialId === options.materialId) && (!search || `${c.question} ${c.materialTitle}`.toLocaleLowerCase().includes(search)) && !suppressedIds.has(c.id));
  const materialIds = [...new Set(cards.map((c) => c.materialId))];
  const materials = options.all ? materialIds : materialIds.slice(offset, offset + size);
  const chosenMaterials = new Set(materials);
  return {
    cards: cards.filter((c) => chosenMaterials.has(c.materialId)),
    materials,
    totalMaterials: materialIds.length,
    nextCursor: !options.all && offset + size < materialIds.length ? JSON.stringify([identity5, offset + size]) : void 0,
    search,
    generatedAt: snapshot.generatedAt,
    expiresAt: snapshot.expiresAt
  };
}

// src/infrastructure/companion/server/shared-runtime.ts
var import_node_crypto13 = require("node:crypto");
var import_promises6 = require("node:fs/promises");
var import_node_path6 = require("node:path");

// src/infrastructure/companion/telegram-api.ts
var import_node_crypto = require("node:crypto");

// src/domain/companion/exercise-feedback.ts
function validateCompanionExerciseFeedback(feedback2, exercise) {
  record2(feedback2);
  if (exercise !== void 0) validateCompanionExercise(exercise);
  if (feedback2.kind === "choice") {
    keys(feedback2, ["kind", "selectedOptionIndexes"]);
    const selected = feedback2.selectedOptionIndexes;
    invalid(Array.isArray(selected) && selected.length <= 12 && Array.from(selected).every((index2, i) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < 12 && (i === 0 || Number(selected[i - 1]) < index2)));
    if (exercise !== void 0) {
      invalid(exercise.kind === "single" || exercise.kind === "multiple");
      invalid(selected.every((index2) => index2 < exercise.options.length) && (exercise.kind !== "single" || selected.length <= 1));
    }
  } else if (feedback2.kind === "matching" || feedback2.kind === "ordering") {
    const matching = feedback2.kind === "matching";
    keys(feedback2, ["kind", matching ? "matches" : "order"]);
    if (exercise !== void 0) invalid(matching ? exercise.kind === "matching" : exercise.kind === "ordering");
    validateCompanionPermutation(matching ? feedback2.matches : feedback2.order, exercise?.kind === "matching" ? exercise.pairs.length : exercise?.kind === "ordering" ? exercise.orderItems.length : void 0);
  } else {
    keys(feedback2, ["kind", "matchedBlanks"]);
    invalid(feedback2.kind === "cloze" && Array.isArray(feedback2.matchedBlanks) && feedback2.matchedBlanks.length >= 1 && feedback2.matchedBlanks.length <= 12 && Array.from(feedback2.matchedBlanks).every((value) => typeof value === "boolean"));
    if (exercise !== void 0) invalid(exercise.kind === "cloze" && feedback2.matchedBlanks.length === extractClozeAnswers(exercise.clozeTemplate).length);
  }
}
function createCompanionExerciseFeedback(exercise, response) {
  const value = response;
  record2(value);
  keys(value, ["selectedOptionIndexes", "clozeAnswers", "matches", "order"]);
  evaluateCompanionExercise(exercise, response);
  let feedback2;
  if (exercise.kind === "cloze") {
    const expected = extractClozeAnswers(exercise.clozeTemplate), answers = response.clozeAnswers ?? [];
    invalid(answers.length === expected.length, "cloze response count differs");
    feedback2 = { kind: "cloze", matchedBlanks: expected.map((answer, index2) => isExactTestAnswerCorrect(answers[index2], answer, exercise.answerMatchMode)) };
  } else if (exercise.kind === "matching") {
    feedback2 = { kind: "matching", matches: [...response.matches] };
  } else if (exercise.kind === "ordering") {
    feedback2 = { kind: "ordering", order: [...response.order] };
  } else {
    invalid((response.clozeAnswers?.length ?? 0) === 0, "choice response contains cloze answers");
    const selectedOptionIndexes = [...response.selectedOptionIndexes ?? []].sort((a, b) => a - b);
    invalid(new Set(selectedOptionIndexes).size === selectedOptionIndexes.length, "duplicate selected option");
    feedback2 = { kind: "choice", selectedOptionIndexes };
  }
  validateCompanionExerciseFeedback(feedback2, exercise);
  return feedback2;
}
function feedbackMatchesAnswer(exercise, feedback2) {
  validateCompanionExerciseFeedback(feedback2, exercise);
  return feedback2.kind === "choice" ? evaluateCompanionExercise(exercise, { selectedOptionIndexes: feedback2.selectedOptionIndexes }) : feedback2.kind === "matching" ? evaluateCompanionExercise(exercise, { matches: feedback2.matches }) : feedback2.kind === "ordering" ? evaluateCompanionExercise(exercise, { order: feedback2.order }) : feedback2.matchedBlanks.every(Boolean);
}

// src/features/companion/presentation.ts
var questionControls = ["\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442", "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438", "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441"];
var leadingChoiceMark = /^[✓✔☐☑✅❌]/u;
function choiceButtonLayout(exercise) {
  const options = exercise.options, lengths = options.map((option) => Array.from(option).length);
  const textOptions = new Set(options.map((option) => option.trim())).size === options.length && options.every((option, index2) => option.trim().length > 0 && !/[\r\n\u2028\u2029]/u.test(option) && lengths[index2] <= 36 && !questionControls.includes(option.trim()) && !leadingChoiceMark.test(option.trimStart()));
  const longest = Math.max(...lengths);
  return {
    textOptions,
    columns: textOptions ? longest <= 8 ? 3 : longest <= 18 ? 2 : 1 : 3,
    labels: options.map((option, index2) => textOptions ? option : String(index2 + 1))
  };
}
function groupCompanionButtons(buttons, map) {
  const rows = [];
  for (let index2 = 0; index2 < buttons.length; index2++) {
    const button = buttons[index2], value = map(button);
    if (index2 > 0 && button.row !== void 0 && button.row === buttons[index2 - 1].row) rows[rows.length - 1].push(value);
    else rows.push([value]);
  }
  return rows;
}
var GRADE_LABELS = ["\u0415\u0449\u0451 \u0440\u0430\u0437", "\u0422\u0440\u0443\u0434\u043D\u043E", "\u0425\u043E\u0440\u043E\u0448\u043E", "\u041B\u0435\u0433\u043A\u043E"];
var GRADE_PROMPT = "\u041D\u0430\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043B\u0435\u0433\u043A\u043E \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u0441\u043F\u043E\u043C\u043D\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442?";
function gradePanelText(rating, stage = "selected", answerText) {
  const suffix = {
    selected: "",
    changing: "\n\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0440\u0443\u0433\u0443\u044E \u043E\u0446\u0435\u043D\u043A\u0443:",
    sent: "\n\u041F\u0435\u0440\u0435\u0434\u0430\u0447\u0430 \u0432 Obsidian \u043D\u0430\u0447\u0430\u0442\u0430.",
    applied: "\n\u2713 \u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u0432 Obsidian.",
    rejected: "\nObsidian \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043B \u043E\u0446\u0435\u043D\u043A\u0443. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u0437\u0430\u043D\u043E\u0432\u043E \u0447\u0435\u0440\u0435\u0437 /go.",
    correcting: "\n\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043E\u0436\u0438\u0434\u0430\u0435\u0442 Obsidian.",
    "correction-rejected": "\n\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u043D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u043E: \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0430\u0441\u044C \u0438\u043B\u0438 \u0431\u044B\u043B\u0430 \u043F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0430."
  }[stage];
  const footer2 = `\u0412\u0430\u0448\u0430 \u043E\u0446\u0435\u043D\u043A\u0430: ${GRADE_LABELS[rating - 1]}${suffix}`;
  if (answerText === void 0) return footer2;
  const combined = combinedGradeText(answerText, footer2);
  invalid(combined !== void 0);
  return combined;
}
var gradeStages = ["selected", "changing", "sent", "applied", "rejected", "correcting", "correction-rejected"];
var maxGradeFooterLength = Math.max(GRADE_PROMPT.length, ...[1, 2, 3, 4].flatMap((rating) => gradeStages.map((stage) => gradePanelText(rating, stage).length)));
function combinedGradeText(answerText, footer2) {
  return answerText.length > 0 && answerText.length + 2 + Math.max(maxGradeFooterLength, footer2.length) <= 4096 ? `${answerText}

${footer2}` : void 0;
}
function validateGradePanelEdit(text4, replyMarkup, answerText) {
  invalid(answerText === void 0 || typeof answerText === "string" && combinedGradeText(answerText, GRADE_PROMPT) !== void 0);
  invalid([1, 2, 3, 4].some((rating) => gradeStages.some((stage) => gradePanelText(rating, stage) === text4 || answerText !== void 0 && gradePanelText(rating, stage, answerText) === text4)));
  record2(replyMarkup);
  keys(replyMarkup, ["inline_keyboard"]);
  invalid(Array.isArray(replyMarkup.inline_keyboard) && replyMarkup.inline_keyboard.length <= 4);
  for (const row of replyMarkup.inline_keyboard) {
    invalid(Array.isArray(row) && row.length === 1);
    record2(row[0]);
    keys(row[0], ["text", "callback_data"]);
    invalid([...GRADE_LABELS, "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0446\u0435\u043D\u043A\u0443"].includes(row[0].text) && typeof row[0].callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(row[0].callback_data));
  }
}
var sessionStatusText = { active: "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0435\u043C.", paused: "\u041D\u0430 \u043F\u0430\u0443\u0437\u0435.", finished: "\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E." };
function studySessionText(completed, total, status, deferredCount = 0, progress = {}) {
  invalid(Number.isSafeInteger(completed) && Number.isSafeInteger(total) && completed >= 0 && completed <= total && total <= MAX_COMPANION_SESSION_CARDS && Number.isSafeInteger(deferredCount) && deferredCount >= 0 && deferredCount <= total && ["active", "paused", "finished"].includes(status));
  record2(progress);
  keys(progress, ["answers", "waitUntil", "timeZone"]);
  invalid(progress.answers === void 0 || Number.isSafeInteger(progress.answers) && progress.answers >= completed && progress.answers <= 1e3);
  invalid(progress.timeZone === void 0 || typeof progress.timeZone === "string");
  const formatter = new Intl.DateTimeFormat("ru-RU", { timeZone: progress.timeZone ?? "UTC", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
  let waiting = "";
  if (progress.waitUntil !== void 0) {
    timestamp(progress.waitUntil);
    invalid(Number.isFinite(new Date(progress.waitUntil).getTime()));
    waiting = `
\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u043F\u043E\u0432\u0442\u043E\u0440: ${formatter.format(new Date(progress.waitUntil))}`;
  }
  return `\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \xB7 ${completed} \u0438\u0437 ${total}
${sessionStatusText[status]}${progress.answers !== void 0 && progress.answers > completed ? `
\u041E\u0442\u0432\u0435\u0442\u043E\u0432: ${progress.answers}.` : ""}${deferredCount ? `
\u041F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E: ${deferredCount}.` : ""}${waiting}`;
}
function validateSessionPanelEdit(text4, replyMarkup) {
  invalid(typeof text4 === "string");
  const match = /^Занятие · (0|[1-9]\d{0,3}) из (0|[1-9]\d{0,3})\n(Продолжаем\.|На паузе\.|Завершено\.)(?:\nОтветов: ([1-9]\d{0,3})\.)?(?:\nПропущено: ([1-9]\d{0,3})\.)?(?:\nСледующий повтор: ([01]\d|2[0-3]):([0-5]\d))?$/.exec(text4);
  invalid(match && Number(match[1]) <= Number(match[2]) && Number(match[2]) <= MAX_COMPANION_SESSION_CARDS && (match[4] === void 0 || Number(match[4]) > Number(match[1]) && Number(match[4]) <= 1e3) && Number(match[5] ?? 0) <= Number(match[2]));
  record2(replyMarkup);
  keys(replyMarkup, ["inline_keyboard"]);
  invalid(Array.isArray(replyMarkup.inline_keyboard) && replyMarkup.inline_keyboard.length <= 4);
  for (const row of replyMarkup.inline_keyboard) {
    invalid(Array.isArray(row) && row.length === 1);
    record2(row[0]);
    keys(row[0], ["text", "callback_data"]);
    invalid(typeof row[0].text === "string" && ["\u0418\u0441\u0442\u043E\u0440\u0438\u044F", "\u041F\u0430\u0443\u0437\u0430", "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C", "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C", "\u041D\u043E\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435"].includes(row[0].text) && typeof row[0].callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(row[0].callback_data));
  }
}
function hintPanelView(hints, count, index2, collapsed) {
  invalid(Array.isArray(hints) && hints.length > 0 && hints.length <= 10 && Array.from(hints).every((hint) => typeof hint === "string" && hint.trim().length > 0 && hint.length <= 2e3));
  invalid(Number.isSafeInteger(count) && count >= 1 && count <= hints.length && Number.isSafeInteger(index2) && index2 >= 0 && index2 < count && typeof collapsed === "boolean");
  const expanded = `\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438 \xB7 ${count} \u0438\u0437 ${hints.length}

${hints.slice(0, count).map((hint, i) => `${i + 1}. ${hint}`).join("\n\n")}`;
  const paged = expanded.length > 4096;
  return { text: collapsed ? `\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438 \xB7 \u043E\u0442\u043A\u0440\u044B\u0442\u043E ${count} \u0438\u0437 ${hints.length}` : paged ? `\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430 ${index2 + 1} \u0438\u0437 ${hints.length}

${hints[index2]}` : expanded, paged };
}
function validateHintPanelEdit(text4, replyMarkup) {
  invalid(typeof text4 === "string" && text4.length <= 4096);
  const collapsed = /^Подсказки · открыто ([1-9]|10) из ([1-9]|10)$/.exec(text4);
  const expanded = /^(?:Подсказки · |Подсказка )([1-9]|10) из ([1-9]|10)\n\n([\s\S]+)$/.exec(text4);
  const match = collapsed ?? expanded;
  invalid(match && Number(match[1]) <= Number(match[2]) && (collapsed || expanded[3].trim().length > 0));
  record2(replyMarkup);
  keys(replyMarkup, ["inline_keyboard"]);
  invalid(Array.isArray(replyMarkup.inline_keyboard) && replyMarkup.inline_keyboard.length <= (collapsed ? 1 : 4));
  const labels = collapsed ? ["\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438"] : ["\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", "\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438"];
  const used = /* @__PURE__ */ new Set();
  for (const row of replyMarkup.inline_keyboard) {
    invalid(Array.isArray(row) && row.length === 1);
    record2(row[0]);
    keys(row[0], ["text", "callback_data"]);
    invalid(typeof row[0].text === "string" && labels.includes(row[0].text) && !used.has(row[0].text) && typeof row[0].callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(row[0].callback_data));
    used.add(row[0].text);
  }
}
function validateCompanionSpoilers(text4, entities) {
  invalid(Array.isArray(entities) && entities.length === 1);
  const splitsPair = (position) => position > 0 && position < text4.length && text4.charCodeAt(position - 1) >= 55296 && text4.charCodeAt(position - 1) <= 56319 && text4.charCodeAt(position) >= 56320 && text4.charCodeAt(position) <= 57343;
  for (const entity of entities) {
    record2(entity);
    keys(entity, ["type", "offset", "length"]);
    invalid(entity.type === "spoiler" && Number.isSafeInteger(entity.offset) && Number(entity.offset) >= 0 && Number.isSafeInteger(entity.length) && Number(entity.length) > 0);
    const start = Number(entity.offset), end = start + Number(entity.length);
    invalid(end <= text4.length && !splitsPair(start) && !splitsPair(end) && text4.slice(start, end).trim().length > 0);
  }
}
function renderCompanionStatus(summary) {
  record2(summary);
  keys(summary, ["now", "lastContactAt", "snapshot", "pending", "applied", "rejected", "pendingCorrections"]);
  timestamp(summary.now);
  invalid(Number.isSafeInteger(summary.pending) && summary.pending >= 0);
  for (const count of [summary.applied, summary.rejected]) invalid(Number.isSafeInteger(count) && count >= 0);
  if (summary.pendingCorrections !== void 0) invalid(Number.isSafeInteger(summary.pendingCorrections) && summary.pendingCorrections >= 0);
  invalid(Number.isSafeInteger(summary.applied + summary.rejected));
  if (summary.lastContactAt !== void 0) timestamp(summary.lastContactAt);
  if (summary.snapshot !== void 0) {
    record2(summary.snapshot);
    keys(summary.snapshot, ["generatedAt", "expiresAt"]);
    timestamp(summary.snapshot.generatedAt);
    timestamp(summary.snapshot.expiresAt);
    invalid(summary.snapshot.expiresAt > summary.snapshot.generatedAt && summary.snapshot.expiresAt - summary.snapshot.generatedAt <= COMPANION_STUDY_COPY_TTL);
  }
  const duration = (milliseconds) => {
    const minutes = Math.floor(milliseconds / 6e4), hours = Math.floor(minutes / 60), days = Math.floor(hours / 24);
    if (minutes < 1) return "\u043C\u0435\u043D\u044C\u0448\u0435 \u043C\u0438\u043D\u0443\u0442\u044B";
    if (hours < 1) return `${minutes} \u043C\u0438\u043D`;
    if (days < 1) return `${hours} \u0447${minutes % 60 ? ` ${minutes % 60} \u043C\u0438\u043D` : ""}`;
    return `${days} \u0434\u043D${hours % 24 ? ` ${hours % 24} \u0447` : ""}`;
  };
  const contactAge = Math.max(0, summary.now - (summary.lastContactAt ?? 0));
  const contact = !summary.lastContactAt ? "\u0435\u0449\u0451 \u043D\u0435 \u0431\u044B\u043B\u043E" : summary.lastContactAt - summary.now > COMPANION_CLOCK_SKEW ? "\u0432\u0440\u0435\u043C\u044F \u043E\u0431\u043C\u0435\u043D\u0430 \u043F\u043E\u0437\u0436\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0447\u0430\u0441\u044B \u0441\u0435\u0440\u0432\u0435\u0440\u0430" : contactAge < 6e4 ? "\u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E" : `${duration(contactAge)} \u043D\u0430\u0437\u0430\u0434`;
  const offline = !summary.snapshot ? "\u0435\u0449\u0451 \u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u044B" : summary.snapshot.generatedAt - summary.now > COMPANION_CLOCK_SKEW ? "\u043E\u0442\u043C\u0435\u0447\u0435\u043D\u044B \u0431\u0443\u0434\u0443\u0449\u0438\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0447\u0430\u0441\u044B \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432" : summary.now >= summary.snapshot.expiresAt ? "\u0441\u0440\u043E\u043A \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u0451\u043A; \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0439\u0442\u0435 Obsidian" : `\u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u0435\u0449\u0451 ${duration(summary.snapshot.expiresAt - summary.now)}`;
  return {
    text: `\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0441 Obsidian
\u041E\u0436\u0438\u0434\u0430\u044E\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F: ${summary.pending}${summary.pendingCorrections ? `
\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u043E\u0446\u0435\u043D\u043A\u0438 \u043E\u0436\u0438\u0434\u0430\u044E\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F: ${summary.pendingCorrections}` : ""}
\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E \u0432 Obsidian: ${summary.applied}
\u041D\u0435 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u043E: ${summary.rejected}

\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u043E\u0431\u043C\u0435\u043D \u0441 Obsidian: ${contact}.
\u041E\u0444\u043B\u0430\u0439\u043D-\u0434\u0430\u043D\u043D\u044B\u0435: ${offline}.`,
    buttons: summary.applied + summary.rejected > 0 ? [{ text: "\u0422\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438", action: { kind: "status", details: true } }] : []
  };
}
function validateQuestionPanelEdit(text4, replyMarkup) {
  invalid(typeof text4 === "string" && text4.trim().length > 0 && text4.length <= 4096);
  record2(replyMarkup);
  keys(replyMarkup, ["inline_keyboard", "force_reply"]);
  invalid(replyMarkup.force_reply === void 0 || replyMarkup.force_reply === true);
  invalid(Array.isArray(replyMarkup.inline_keyboard) && replyMarkup.inline_keyboard.length > 0 && replyMarkup.inline_keyboard.length <= 16);
  const labels = /* @__PURE__ */ new Set();
  let count = 0;
  for (const row of replyMarkup.inline_keyboard) {
    invalid(Array.isArray(row) && row.length >= 1 && row.length <= 3);
    for (const button of row) {
      record2(button);
      keys(button, ["text", "callback_data", "style"]);
      const label2 = button.text;
      invalid(typeof label2 === "string" && label2.trim().length > 0 && label2.length <= 120 && !/[\r\n\u2028\u2029]/u.test(label2) && typeof button.callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(button.callback_data));
      const control = questionControls.includes(label2), selected = label2.startsWith("\u2713 "), checked = label2.startsWith("\u2611 "), checkbox = checked || label2.startsWith("\u2610 ");
      const legacy = /^[☐☑] (?:[1-9]|1[0-2])$/.test(label2);
      invalid(button.style === void 0 || button.style === "primary" && (selected || checked));
      invalid(!(selected || checked && !legacy) || button.style === "primary");
      const base = (selected || checkbox ? label2.slice(2) : label2).trim();
      invalid(base.length > 0 && !labels.has(base) && (!control || row.length === 1 && button.style === void 0) && (control || !questionControls.includes(base) && !leadingChoiceMark.test(base)));
      labels.add(base);
      count++;
    }
  }
  invalid(count <= 16 && labels.has("\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441"));
}
function renderMaterials(snapshot, page2, showGuidance = true) {
  const materialTitles = new Map(snapshot.cards.map((card) => [card.materialId, card.materialTitle]));
  return {
    text: `\u041F\u043E\u0440\u0430 \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0442\u044C
${page2.totalMaterials ? "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B:" : "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u0445 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u0430\u0445."}${showGuidance ? "\n\u041E\u0444\u043B\u0430\u0439\u043D: \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0441\u044F \u043F\u0440\u0438 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0441 Obsidian." : ""}`,
    buttons: [
      ...page2.materials.map((id2) => ({ text: materialTitles.get(id2), action: { kind: "material", materialId: id2, sequence: snapshot.sequence, scope: snapshot.scope, epoch: snapshot.epoch } })),
      ...page2.nextCursor ? [{ text: "\u0415\u0449\u0451 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B", action: { kind: "more", cursor: page2.nextCursor, search: page2.search, sequence: snapshot.sequence, scope: snapshot.scope, epoch: snapshot.epoch } }] : [],
      { text: "\u0412\u0441\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B", action: { kind: "all", sequence: snapshot.sequence, scope: snapshot.scope, epoch: snapshot.epoch } },
      { text: "\u041F\u043E\u0438\u0441\u043A", action: { kind: "search", sequence: snapshot.sequence, scope: snapshot.scope, epoch: snapshot.epoch } }
    ]
  };
}
function exerciseFeedbackText(exercise, feedback2) {
  validateCompanionExerciseFeedback(feedback2, exercise);
  if (exercise.kind === "cloze") {
    invalid(feedback2.kind === "cloze");
    const answers = extractClozeAnswers(exercise.clozeTemplate);
    return feedback2.matchedBlanks.map((matched, index2) => `${matched ? "\u2705" : "\u274C"} \u041F\u0440\u043E\u043F\u0443\u0441\u043A ${index2 + 1} \u2014 ${answers[index2]}`).join("\n");
  }
  if (exercise.kind === "matching") {
    invalid(feedback2.kind === "matching");
    return feedback2.matches.map((right, index2) => `${right === index2 ? "\u2705" : "\u274C"} ${exercise.pairs[index2].left} \u2192 ${exercise.pairs[right].right}${right === index2 ? "" : `
\u0412\u0435\u0440\u043D\u043E: ${exercise.pairs[index2].right}`}`).join("\n\n");
  }
  if (exercise.kind === "ordering") {
    invalid(feedback2.kind === "ordering");
    return feedback2.order.map((item, index2) => `${item === index2 ? "\u2705" : "\u274C"} ${index2 + 1}. ${exercise.orderItems[item]}${item === index2 ? "" : `
\u0412\u0435\u0440\u043D\u043E: ${exercise.orderItems[index2]}`}`).join("\n\n");
  }
  invalid(feedback2.kind === "choice");
  const selected = new Set(feedback2.selectedOptionIndexes), correct = new Set(exercise.correctOptionIndexes);
  const selectedCorrect = [], extra = [], missed = [];
  exercise.options.forEach((option, index2) => {
    const label2 = `${index2 + 1}. ${option}`;
    if (selected.has(index2)) (correct.has(index2) ? selectedCorrect : extra).push(label2);
    else if (correct.has(index2)) missed.push(label2);
  });
  return [
    !selected.size ? "\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043E." : "",
    selectedCorrect.length ? `\u2705 \u0412\u044B\u0431\u0440\u0430\u043D\u043E \u0432\u0435\u0440\u043D\u043E:
${selectedCorrect.join("\n")}` : "",
    extra.length ? `\u274C \u041B\u0438\u0448\u043D\u0438\u0435 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B:
${extra.join("\n")}` : "",
    missed.length ? `\u26A0\uFE0F \u041F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u044B \u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0430\u0440\u0438\u0430\u043D\u0442\u044B:
${missed.join("\n")}` : ""
  ].filter(Boolean).join("\n\n");
}
function renderCard(card, snapshot, reveal = false, answerMatch, showGuidance = true, selectedOptionIndexes = [], legacyChoices = false, checkboxChoices = true, exerciseFeedback) {
  const exercise = card.exercise, exact2 = card.evaluationMode === "exact" || exercise !== void 0;
  if (exerciseFeedback !== void 0) {
    invalid(exercise, "exercise feedback requires an exercise");
    const matched = feedbackMatchesAnswer(exercise, exerciseFeedback);
    invalid(answerMatch === void 0 || answerMatch === matched, "exercise feedback differs from answer result");
  }
  const binding2 = { cardId: card.id, revision: card.revision, sequence: snapshot.sequence, scope: snapshot.scope, epoch: snapshot.epoch };
  const choice = exercise && (exercise.kind === "single" || exercise.kind === "multiple") ? exercise : void 0;
  invalid(Array.isArray(selectedOptionIndexes) && new Set(selectedOptionIndexes).size === selectedOptionIndexes.length && selectedOptionIndexes.every((index2) => choice && Number.isSafeInteger(index2) && index2 >= 0 && index2 < choice.options.length));
  if (!reveal && (exercise?.kind === "matching" || exercise?.kind === "ordering")) return {
    text: `${card.question}

\u042D\u0442\u043E\u0442 \u0444\u043E\u0440\u043C\u0430\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u0432 \u043C\u0438\u043D\u0438-\u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435 \u043A\u043E\u043C\u0430\u043D\u0434\u043E\u0439 /app.`,
    buttons: []
  };
  const layout = choice ? choiceButtonLayout(choice) : void 0;
  const question = exercise && (!choice || reveal || legacyChoices || !layout.textOptions) ? companionExerciseQuestion(exercise, card.question) : card.question;
  const comparison = reveal && exact2 && answerMatch !== void 0 ? `${exercise ? answerMatch ? "\u2705 \u041E\u0442\u0432\u0435\u0442 \u0432\u0435\u0440\u043D\u044B\u0439." : "\u274C \u041E\u0442\u0432\u0435\u0442 \u043D\u0435\u0432\u0435\u0440\u043D\u044B\u0439." : answerMatch ? "\u2705 \u041E\u0442\u0432\u0435\u0442 \u0441\u043E\u0432\u043F\u0430\u043B." : "\u274C \u041E\u0442\u0432\u0435\u0442 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u043B."}

` : "";
  const clozeInstruction = !reveal && exercise?.kind === "cloze" ? companionExerciseBlankCount(exercise) === 1 ? "\n\n\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043D\u044B\u0439 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442 \u0432 \u043E\u0442\u0432\u0435\u0442 \u043D\u0430 \u044D\u0442\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435." : "\n\n\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u043F\u043E \u043F\u043E\u0440\u044F\u0434\u043A\u0443: \u043A\u0430\u0436\u0434\u044B\u0439 \u043F\u0440\u043E\u043F\u0443\u0441\u043A \u0441 \u043D\u043E\u0432\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438, \u0431\u0435\u0437 \u043D\u043E\u043C\u0435\u0440\u043E\u0432." : "";
  const instruction = clozeInstruction || (!exercise && exact2 && showGuidance ? "\n\n\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043E\u0442\u0432\u0435\u0442, \u043E\u0442\u0432\u0435\u0442\u0438\u0432 \u043D\u0430 \u044D\u0442\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 Telegram. \u041C\u043E\u0436\u043D\u043E \u0442\u0430\u043A\u0436\u0435 \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442." : "");
  const needsReply = !reveal && (exercise?.kind === "cloze" || !exercise && exact2);
  const options = choice ? choice.options.map((_, index2) => {
    const selected = selectedOptionIndexes.includes(index2), label2 = legacyChoices ? String(index2 + 1) : layout.labels[index2];
    const mark = choice.kind !== "multiple" ? "" : legacyChoices || checkboxChoices ? `${selected ? "\u2611" : "\u2610"} ` : selected ? "\u2713 " : "";
    return {
      text: mark + label2,
      ...!legacyChoices ? { row: Math.floor(index2 / layout.columns), ...choice.kind === "multiple" && selected ? { style: "primary" } : {} } : {},
      action: { kind: choice.kind === "single" ? "select-option" : "toggle-option", index: index2, ...binding2 }
    };
  }) : [];
  const guidance = card.mode === "core" && showGuidance ? "\nCore: \u043E\u0446\u0435\u043D\u043A\u0430 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E\u0441\u043B\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F Obsidian." : "";
  let text4 = `${comparison}${question}${reveal ? `

\u041E\u0442\u0432\u0435\u0442 \u0434\u043B\u044F \u0441\u0430\u043C\u043E\u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438:
${card.reference}` : instruction}${guidance}`;
  if (reveal && answerMatch !== void 0 && exercise && exerciseFeedback !== void 0) {
    const detailed = `${comparison}${choice ? card.question : question}

${exerciseFeedbackText(exercise, exerciseFeedback)}${guidance}`;
    if (detailed.length <= 4096) text4 = detailed;
  }
  return {
    text: text4,
    ...needsReply ? { answerAction: { kind: "answer", ...binding2 } } : {},
    buttons: reveal ? (answerMatch === true ? [2, 3, 4] : [1, 2, 3, 4]).map((rating) => ({
      text: GRADE_LABELS[rating - 1],
      action: {
        kind: "review",
        scope: snapshot.scope,
        epoch: snapshot.epoch,
        cardId: card.id,
        revision: card.revision,
        sequence: snapshot.sequence,
        rating,
        correct: rating !== 1,
        ...exact2 && answerMatch !== void 0 ? { answerMatch } : {}
      }
    })) : [
      ...options,
      ...choice?.kind === "multiple" && selectedOptionIndexes.length ? [{ text: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442", action: { kind: "submit-options", ...binding2 } }] : [],
      { text: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442", action: { kind: "reveal", ...binding2 } },
      ...card.hints?.length ? [{ text: "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", action: { kind: "hint", index: 0, ...binding2 } }] : [],
      { text: "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441", action: { kind: "skip-card", ...binding2 } }
    ]
  };
}

// src/features/companion/native-poll.ts
function validNativePollId(value) {
  return typeof value === "string" && value.length > 0 && value.length <= 128 && !/[\u0000-\u001f\u007f-\u009f]/u.test(value);
}
function boundedText2(value, max) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= max;
}
function nativePollView(card) {
  const exercise = card.exercise;
  if (!exercise || exercise.kind !== "single" && exercise.kind !== "multiple" || !boundedText2(card.question, 300)) return;
  try {
    validateCompanionExercise(exercise);
  } catch {
    return;
  }
  if (!exercise.options.every((option) => boundedText2(option, 100)) || new Set(exercise.options.map((option) => option.trim())).size !== exercise.options.length) return;
  return {
    question: card.question,
    options: exercise.options.map((text4) => ({ text: text4 })),
    type: "regular",
    is_anonymous: false,
    allows_multiple_answers: exercise.kind === "multiple",
    allows_revoting: false,
    shuffle_options: false,
    allow_adding_options: false,
    hide_results_until_closes: true
  };
}
function validateNativePollPayload(value) {
  record2(value);
  keys(value, ["chat_id", "question", "options", "type", "is_anonymous", "allows_multiple_answers", "allows_revoting", "shuffle_options", "allow_adding_options", "hide_results_until_closes", "disable_notification", "close_date", "reply_markup"]);
  invalid(Number.isSafeInteger(value.chat_id) && Number(value.chat_id) > 0 && typeof value.disable_notification === "boolean");
  invalid(value.close_date === void 0 || Number.isSafeInteger(value.close_date) && Number(value.close_date) > 0);
  invalid(boundedText2(value.question, 300) && Array.isArray(value.options) && value.options.length >= 1 && value.options.length <= 12);
  for (const option of value.options) {
    record2(option);
    keys(option, ["text"]);
    invalid(boundedText2(option.text, 100));
  }
  invalid(value.type === "regular" && value.is_anonymous === false && typeof value.allows_multiple_answers === "boolean" && value.allows_revoting === false && value.shuffle_options === false && value.allow_adding_options === false && value.hide_results_until_closes === true);
  if (value.reply_markup !== void 0) {
    record2(value.reply_markup);
    keys(value.reply_markup, ["inline_keyboard"]);
    invalid(Array.isArray(value.reply_markup.inline_keyboard) && value.reply_markup.inline_keyboard.length <= 3);
    const used = /* @__PURE__ */ new Set();
    for (const row of value.reply_markup.inline_keyboard) {
      invalid(Array.isArray(row) && row.length === 1);
      record2(row[0]);
      keys(row[0], ["text", "callback_data"]);
      invalid(typeof row[0].text === "string" && ["\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438", "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441"].includes(row[0].text) && !used.has(row[0].text) && typeof row[0].callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(row[0].callback_data));
      used.add(row[0].text);
    }
  }
}

// src/infrastructure/companion/telegram-api.ts
function verifyPrivateTelegramUpdate(raw, secretHeader, config) {
  invalid(config.enabled === true, "Telegram transport disabled");
  invalid(raw.length <= 65536 && secretHeader.length <= 256 && config.webhookSecret.length >= 32, "unauthorized Telegram update");
  const supplied = Buffer.from(secretHeader), expected = Buffer.from(config.webhookSecret);
  invalid(supplied.length === expected.length && (0, import_node_crypto.timingSafeEqual)(supplied, expected), "unauthorized Telegram update");
  const update = JSON.parse(raw);
  record2(update);
  invalid(Number.isSafeInteger(update.update_id) && Number(update.update_id) >= 0);
  invalid([update.message, update.callback_query, update.poll_answer].filter((value) => value !== void 0).length === 1, "ambiguous Telegram update");
  if (update.poll_answer !== void 0) {
    const answer = update.poll_answer;
    record2(answer);
    record2(answer.user);
    invalid(answer.voter_chat === void 0 && Number.isSafeInteger(answer.user.id) && Number(answer.user.id) > 0 && answer.user.id === config.userId && answer.user.is_bot !== true, "unauthorized Telegram principal");
    invalid(validNativePollId(answer.poll_id) && Array.isArray(answer.option_ids) && answer.option_ids.length <= 12 && Array.from(answer.option_ids).every((option) => Number.isSafeInteger(option) && Number(option) >= 0 && Number(option) < 12) && new Set(answer.option_ids).size === answer.option_ids.length, "invalid Telegram poll answer");
    return { updateId: update.update_id, pollId: answer.poll_id, optionIds: [...answer.option_ids].sort((a, b) => a - b) };
  }
  let callback;
  if (update.callback_query !== void 0) {
    record2(update.callback_query);
    callback = update.callback_query;
  }
  const message = callback ? callback.message : update.message;
  record2(message);
  record2(message.chat);
  const from = callback ? callback.from : message.from;
  record2(from);
  invalid(message.chat.type === "private" && message.chat.id === config.chatId && from.id === config.userId && from.is_bot !== true, "unauthorized Telegram principal");
  if (callback) {
    invalid(typeof callback.id === "string" && callback.id.length <= 128 && typeof callback.data === "string" && /^[a-zA-Z0-9_-]{1,64}$/.test(callback.data));
    return { updateId: update.update_id, callbackId: callback.id, handle: callback.data };
  }
  invalid(typeof message.text === "string" && message.text.length <= 4096);
  let replyToMessageId;
  if (message.reply_to_message !== void 0) {
    record2(message.reply_to_message);
    invalid(Number.isSafeInteger(message.reply_to_message.message_id) && Number(message.reply_to_message.message_id) > 0);
    replyToMessageId = message.reply_to_message.message_id;
  }
  return { updateId: update.update_id, text: message.text, ...replyToMessageId === void 0 ? {} : { replyToMessageId } };
}

// src/infrastructure/companion/server/runtime.ts
var import_node_crypto8 = require("node:crypto");

// src/infrastructure/companion/server/large-payload.ts
var import_node_crypto2 = require("node:crypto");
var IDLE_TTL = 5 * 6e4;
var MAX_LIFETIME = 90 * 6e4;
var stagedBytes = 0;
var LargePayloadAssembler = class {
  upload;
  clear() {
    if (!this.upload) return;
    clearTimeout(this.upload.timer);
    stagedBytes -= this.upload.received;
    this.upload = void 0;
  }
  touch(now) {
    const upload = this.upload;
    upload.touched = now;
    clearTimeout(upload.timer);
    upload.timer = setTimeout(() => this.clear(), IDLE_TTL);
    upload.timer.unref?.();
  }
  accept(value, now) {
    record2(value);
    if (this.upload && (now - this.upload.touched >= IDLE_TTL || now - this.upload.startedAt >= MAX_LIFETIME)) this.clear();
    if (value.operation === "large-payload-begin") {
      keys(value, ["operation", "bytes", "sha256"]);
      invalid(Number.isSafeInteger(value.bytes) && Number(value.bytes) > 0 && Number(value.bytes) <= MAX_COMPANION_SNAPSHOT_BYTES);
      invalid(typeof value.sha256 === "string" && /^[a-f0-9]{64}$/.test(value.sha256));
      this.clear();
      this.upload = { id: (0, import_node_crypto2.randomUUID)(), bytes: Number(value.bytes), hash: value.sha256, parts: [], received: 0, startedAt: now, touched: now };
      this.touch(now);
      return { response: { id: this.upload.id, offset: 0 } };
    }
    token2(value.id);
    const upload = this.upload;
    invalid(upload && upload.id === value.id, "upload expired; start a new transfer");
    if (value.operation === "large-payload-chunk") {
      keys(value, ["operation", "id", "offset", "data"]);
      invalid(Number.isSafeInteger(value.offset) && Number(value.offset) >= 0);
      invalid(typeof value.data === "string" && value.data.length > 0 && value.data.length <= Math.ceil(MAX_COMPANION_SNAPSHOT_CHUNK_BYTES / 3) * 4);
      const bytes2 = Buffer.from(value.data, "base64");
      invalid(bytes2.length > 0 && bytes2.length <= MAX_COMPANION_SNAPSHOT_CHUNK_BYTES && bytes2.toString("base64") === value.data);
      if (value.offset !== upload.received) {
        let offset = 0;
        const previous = upload.parts.find((part) => {
          const start = offset;
          offset += part.length;
          return start === value.offset;
        });
        invalid(previous?.equals(bytes2), "upload offset differs");
      } else {
        invalid(upload.received + bytes2.length <= upload.bytes && stagedBytes + bytes2.length <= MAX_COMPANION_SNAPSHOT_BYTES * 2, "upload capacity exceeded");
        upload.parts.push(bytes2);
        upload.received += bytes2.length;
        stagedBytes += bytes2.length;
      }
      this.touch(now);
      return { response: { id: upload.id, offset: upload.received } };
    }
    keys(value, ["operation", "id"]);
    invalid(value.operation === "large-payload-commit" && upload.received === upload.bytes);
    const bytes = Buffer.concat(upload.parts, upload.bytes);
    invalid((0, import_node_crypto2.createHash)("sha256").update(bytes).digest("hex") === upload.hash, "upload hash differs");
    this.clear();
    const payload = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
    record2(payload);
    invalid(payload.operation === "study-context" || payload.operation === "study-plan" || payload.operation === void 0 && payload.snapshot !== void 0, "unsupported large payload");
    return { payload, startedAt: upload.startedAt };
  }
};

// src/infrastructure/companion/server/catalog-page-storage.ts
var import_node_crypto5 = require("node:crypto");
var import_node_fs = require("node:fs");
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");
var import_node_zlib = require("node:zlib");

// src/infrastructure/companion/catalog-pages.ts
var import_node_crypto3 = require("node:crypto");

// src/domain/companion/study-context.ts
var COMPANION_KNOWLEDGE_STATES = ["new", "learning", "needs-attention", "weak", "stable", "strong"];
var object4 = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var only = (value, names) => Object.keys(value).every((key2) => names.includes(key2));
var integer = (value, low, high) => typeof value === "number" && Number.isSafeInteger(value) && value >= low && value <= high;
var label = (value) => typeof value === "string" && value.trim().length > 0 && value.length <= 200 && !/[\u0000-\u001f\u007f-\u009f]/.test(value);
var topicLabel = (value) => typeof value === "string" && value.trim().length > 0 && value.length <= 1024 && !/[\u0000-\u001f\u007f-\u009f]/.test(value);
var invalid2 = () => {
  throw new Error("Invalid companion study context");
};
function validateCompanionStudyContext(value) {
  if (!object4(value) || !only(value, ["version", "sourceConsent", "defaults", "cards"]) || value.version !== 1 || typeof value.sourceConsent !== "boolean" || !object4(value.defaults) || !only(value.defaults, ["core", "bank"]) || !Array.isArray(value.cards)) return invalid2();
  for (const mode of ["core", "bank"]) {
    const limits = value.defaults[mode];
    if (!object4(limits) || !only(limits, ["cardLimit", "timeLimitMinutes"]) || !integer(limits.cardLimit, 1, 1e3) || !integer(limits.timeLimitMinutes, 1, 180)) return invalid2();
  }
  const ids = /* @__PURE__ */ new Set();
  for (const row of value.cards) {
    if (!object4(row) || !only(row, ["id", "kind", "group", "sections", "source", "topics", "tags", "knowledgeState", "selfCheckCriteria"]) || typeof row.id !== "string" || row.id.length < 1 || row.id.length > 128 || /[^a-zA-Z0-9._:-]/.test(row.id) || ids.has(row.id) || !["free", "single", "multiple", "cloze", "matching", "ordering"].includes(String(row.kind)) || row.group !== void 0 && !label(row.group) || row.sections !== void 0 && (!Array.isArray(row.sections) || row.sections.length > 100 || !row.sections.every(label) || new Set(row.sections).size !== row.sections.length) || row.topics !== void 0 && (!Array.isArray(row.topics) || row.topics.length > 100 || !row.topics.every(topicLabel) || new Set(row.topics).size !== row.topics.length) || row.tags !== void 0 && (!Array.isArray(row.tags) || row.tags.length > 100 || !row.tags.every(label) || new Set(row.tags.map(tagKey)).size !== row.tags.length) || row.knowledgeState !== void 0 && !COMPANION_KNOWLEDGE_STATES.includes(row.knowledgeState) || row.selfCheckCriteria !== void 0 && (row.kind !== "free" || !Array.isArray(row.selfCheckCriteria) || row.selfCheckCriteria.length > MAX_SELF_CHECK_CRITERIA || !row.selfCheckCriteria.every((value2) => typeof value2 === "string" && value2.trim().length > 0 && value2.length <= MAX_SELF_CHECK_CRITERION_LENGTH && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/.test(value2)))) return invalid2();
    ids.add(row.id);
    if (row.source !== void 0) {
      const source = row.source;
      if (!value.sourceConsent || !object4(source) || !only(source, ["excerpt", "page", "timeSeconds"]) || !Object.keys(source).length || source.excerpt !== void 0 && (typeof source.excerpt !== "string" || !source.excerpt.trim() || source.excerpt.length > 2e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/.test(source.excerpt)) || source.page !== void 0 && !integer(source.page, 1, 1e6) || source.timeSeconds !== void 0 && !integer(source.timeSeconds, 0, 31536e3)) return invalid2();
    }
  }
}

// src/infrastructure/companion/catalog-pages.ts
var CATALOG_PAGE_BYTES = 512 * 1024;
var CATALOG_REFERENCE_BATCH = 256;
var CATALOG_UPLOAD_BATCH = 32;
var PAGE_OVERHEAD = 1024;
function fail3(condition, message = "invalid catalog page") {
  if (!condition) throw new Error(message);
}
var record3 = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var only2 = (value, fields4) => Object.keys(value).every((key2) => fields4.includes(key2));
function finishSteps(steps) {
  let step = steps.next();
  while (!step.done) step = steps.next();
  return step.value;
}
var catalogPageHash = (raw) => (0, import_node_crypto3.createHash)("sha256").update(raw).digest("hex");
function catalogRootRevision(root) {
  return catalogPageHash(Buffer.from(jsonFingerprint(root)));
}
function validateCatalogReference(value) {
  fail3(record3(value) && only2(value, ["sha256", "bytes", "count"]) && typeof value.sha256 === "string" && /^[a-f0-9]{64}$/.test(value.sha256) && Number.isSafeInteger(value.bytes) && Number(value.bytes) > 0 && Number(value.bytes) <= CATALOG_PAGE_BYTES && Number.isSafeInteger(value.count) && Number(value.count) >= 0);
}
function countReferences(children) {
  const count = children.reduce((sum, ref) => sum + ref.count, 0);
  fail3(Number.isSafeInteger(count));
  return count;
}
function decodeCatalogPage(reference3, bytes) {
  validateCatalogReference(reference3);
  fail3(bytes.length === reference3.bytes && catalogPageHash(bytes) === reference3.sha256, "catalog page checksum differs");
  const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  fail3(record3(value) && value.version === 1);
  if (value.kind === "records" || value.kind === "list") {
    fail3(only2(value, ["version", "kind", "values"]) && Array.isArray(value.values) && value.values.length === reference3.count);
  } else if (value.kind === "index") {
    fail3(only2(value, ["version", "kind", "children"]) && Array.isArray(value.children) && value.children.length <= CATALOG_REFERENCE_BATCH);
    value.children.forEach(validateCatalogReference);
    fail3(countReferences(value.children) === reference3.count);
  } else if (value.kind === "array") {
    fail3(only2(value, ["version", "kind", "parts"]) && Array.isArray(value.parts) && value.parts.length <= CATALOG_REFERENCE_BATCH);
    let count = 0;
    for (const part of value.parts) {
      fail3(record3(part) && only2(part, ["reference", "spread"]) && typeof part.spread === "boolean");
      validateCatalogReference(part.reference);
      count += part.spread ? part.reference.count : 1;
    }
    fail3(Number.isSafeInteger(count) && count === reference3.count);
  } else if (value.kind === "json") {
    fail3(only2(value, ["version", "kind", "value"]) && Object.prototype.hasOwnProperty.call(value, "value") && reference3.count === 1);
  } else if (value.kind === "object") {
    fail3(only2(value, ["version", "kind", "members"]) && Array.isArray(value.members) && value.members.length <= CATALOG_REFERENCE_BATCH && reference3.count === 1);
    const names = /* @__PURE__ */ new Set();
    for (const member of value.members) {
      fail3(record3(member) && only2(member, ["name", "reference"]) && typeof member.name === "string" && !names.has(member.name));
      names.add(member.name);
      validateCatalogReference(member.reference);
    }
  } else fail3(false);
  return value;
}
function validateCatalogRoot(value) {
  fail3(record3(value) && only2(value, ["version", "snapshot", "context", "consentIds", "materialConsentIds", "timeZone", "attachmentConsent", "offlineConsent"]) && value.version === 1 && typeof value.timeZone === "string" && value.timeZone.length > 0 && value.timeZone.length <= 100);
  const collection = (v) => {
    fail3(record3(v) && only2(v, ["records", "order", "count"]) && Number.isSafeInteger(v.count) && Number(v.count) >= 0);
    validateCatalogReference(v.records);
    validateCatalogReference(v.order);
    fail3(v.records.count === v.count && v.order.count === v.count);
  };
  fail3(record3(value.snapshot) && only2(value.snapshot, ["header", "cards", "targetCardIds"]) && record3(value.snapshot.header));
  fail3(!("cards" in value.snapshot.header));
  collection(value.snapshot.cards);
  if (value.snapshot.targetCardIds !== void 0) validateCatalogReference(value.snapshot.targetCardIds);
  if (value.context !== void 0) {
    fail3(record3(value.context) && only2(value.context, ["header", "cards"]) && record3(value.context.header) && !("cards" in value.context.header));
    collection(value.context.cards);
  }
  validateCatalogReference(value.consentIds);
  if (value.materialConsentIds !== void 0) validateCatalogReference(value.materialConsentIds);
  for (const flag of [value.attachmentConsent, value.offlineConsent]) fail3(flag === void 0 || typeof flag === "boolean");
  fail3(Buffer.byteLength(jsonFingerprint(value)) <= CATALOG_PAGE_BYTES, "catalog root too large");
}
var CatalogPageBuilder = class {
  pages = /* @__PURE__ */ new Map();
  add(factory, count) {
    const encode = () => Buffer.from(jsonFingerprint(factory()));
    const bytes = encode();
    fail3(bytes.length <= CATALOG_PAGE_BYTES, "catalog record exceeds page limit");
    const reference3 = { sha256: catalogPageHash(bytes), bytes: bytes.length, count };
    validateCatalogReference(reference3);
    if (!this.pages.has(reference3.sha256)) this.pages.set(reference3.sha256, { reference: reference3, bytes: () => {
      const current = encode();
      fail3(current.length === reference3.bytes && catalogPageHash(current) === reference3.sha256, "catalog changed during transfer");
      return current;
    } });
    return reference3;
  }
  tree(children) {
    if (!children.length) return this.add(() => ({ version: 1, kind: "list", values: [] }), 0);
    while (children.length > CATALOG_REFERENCE_BATCH) {
      const next = [];
      for (let offset = 0; offset < children.length; offset += CATALOG_REFERENCE_BATCH) {
        const group = children.slice(offset, offset + CATALOG_REFERENCE_BATCH);
        next.push(this.add(() => ({ version: 1, kind: "index", children: group }), countReferences(group)));
      }
      children = next;
    }
    return children.length === 1 ? children[0] : this.add(() => ({ version: 1, kind: "index", children }), countReferences(children));
  }
  list(values, kind2 = "list") {
    return finishSteps(this.listSteps(values, kind2));
  }
  *listSteps(values, kind2 = "list") {
    const pages = [];
    let group = [], bytes = PAGE_OVERHEAD, visited = 0;
    const flush = () => {
      const records = group;
      pages.push(this.add(() => ({ version: 1, kind: kind2, values: records }), records.length));
      group = [];
      bytes = PAGE_OVERHEAD;
    };
    for (const value of values) {
      const length = boundedJsonBytes(value, CATALOG_PAGE_BYTES - PAGE_OVERHEAD);
      fail3(length !== void 0, "catalog record exceeds page limit");
      if (group.length && bytes + length + 1 > CATALOG_PAGE_BYTES) {
        flush();
        yield;
      }
      group.push(value);
      bytes += length + 1;
      if (++visited % 256 === 0) yield;
    }
    if (group.length || !pages.length) {
      flush();
      yield;
    }
    return this.tree(pages);
  }
  collection(values) {
    return finishSteps(this.collectionSteps(values));
  }
  *collectionSteps(values) {
    const buckets = /* @__PURE__ */ new Map(), ids = [], seen = /* @__PURE__ */ new Set();
    let visited = 0;
    for (const value of values) {
      fail3(typeof value.id === "string" && !seen.has(value.id), "duplicate catalog record");
      seen.add(value.id);
      ids.push(value.id);
      const bucket = (0, import_node_crypto3.createHash)("sha256").update(value.id).digest()[0], rows = buckets.get(bucket) ?? [];
      rows.push(value);
      buckets.set(bucket, rows);
      if (++visited % 256 === 0) yield;
    }
    const refs = [];
    for (const [, rows] of [...buckets].sort(([a], [b]) => a - b))
      refs.push(yield* this.listSteps(rows.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0), "records"));
    const records = refs.length ? this.tree(refs) : yield* this.listSteps([], "records"), order = yield* this.listSteps(ids);
    return { records, order, count: values.length };
  }
  value(value) {
    if (boundedJsonBytes(value, CATALOG_PAGE_BYTES - PAGE_OVERHEAD) !== void 0) return this.add(() => ({ version: 1, kind: "json", value }), 1);
    if (Array.isArray(value)) {
      let parts = [];
      let group = [], bytes = PAGE_OVERHEAD;
      const flush = () => {
        if (!group.length) return;
        const values = group;
        parts.push({ reference: this.add(() => ({ version: 1, kind: "list", values }), values.length), spread: true });
        group = [];
        bytes = PAGE_OVERHEAD;
      };
      for (const item of value) {
        const length = boundedJsonBytes(item, CATALOG_PAGE_BYTES - PAGE_OVERHEAD);
        if (length === void 0) {
          flush();
          parts.push({ reference: this.value(item), spread: false });
        } else {
          if (group.length && bytes + length + 1 > CATALOG_PAGE_BYTES) flush();
          group.push(item);
          bytes += length + 1;
        }
      }
      flush();
      const count = (rows) => rows.reduce((sum, row) => sum + (row.spread ? row.reference.count : 1), 0);
      while (parts.length > CATALOG_REFERENCE_BATCH) {
        const next = [];
        for (let offset = 0; offset < parts.length; offset += CATALOG_REFERENCE_BATCH) {
          const group2 = parts.slice(offset, offset + CATALOG_REFERENCE_BATCH);
          next.push({ reference: this.add(() => ({ version: 1, kind: "array", parts: group2 }), count(group2)), spread: true });
        }
        parts = next;
      }
      return this.add(() => ({ version: 1, kind: "array", parts }), value.length);
    }
    fail3(record3(value), "JSON scalar exceeds page limit");
    const members = Object.keys(value).filter((name) => value[name] !== void 0).sort().map((name) => ({ name, reference: this.value(value[name]) }));
    fail3(members.length <= CATALOG_REFERENCE_BATCH, "JSON object has too many fields");
    return this.add(() => ({ version: 1, kind: "object", members }), 1);
  }
};
function boundedJsonBytes(value, maximum) {
  let bytes = 0;
  const ancestors = /* @__PURE__ */ new Set();
  const add = (length) => {
    bytes += length;
    return bytes <= maximum;
  };
  const visit = (item) => {
    if (!item || typeof item !== "object") {
      if (typeof item === "string" && item.length > maximum) return false;
      const text4 = JSON.stringify(item);
      return text4 !== void 0 && add(Buffer.byteLength(text4));
    }
    if (ancestors.has(item)) throw new Error("cyclic catalog value");
    ancestors.add(item);
    let ok = add(2);
    if (Array.isArray(item)) {
      for (let index2 = 0; ok && index2 < item.length; index2++) ok = (!index2 || add(1)) && visit(item[index2] === void 0 ? null : item[index2]);
    } else {
      let index2 = 0;
      for (const name of Object.keys(item)) {
        const child = item[name];
        if (child === void 0) continue;
        ok = (!index2++ || add(1)) && add(Buffer.byteLength(JSON.stringify(name)) + 1) && visit(child);
        if (!ok) break;
      }
    }
    ancestors.delete(item);
    return ok;
  };
  return visit(value) ? bytes : void 0;
}
function* catalogBuildSteps(input) {
  const builder = new CatalogPageBuilder(), { cards, studyTarget, ...header } = input.snapshot;
  const snapshotCards = yield* builder.collectionSteps(cards), consentIds = yield* builder.listSteps(input.consentIds);
  const root = { version: 1, snapshot: { header, cards: snapshotCards }, consentIds, timeZone: input.timeZone };
  if (studyTarget) {
    const { cardIds, ...target } = studyTarget;
    root.snapshot.header.studyTarget = target;
    root.snapshot.targetCardIds = yield* builder.listSteps(cardIds);
  }
  if (input.context) {
    const { cards: cards2, ...header2 } = input.context;
    root.context = { header: header2, cards: yield* builder.collectionSteps(cards2) };
  }
  if (input.materialConsentIds !== void 0) root.materialConsentIds = yield* builder.listSteps(input.materialConsentIds);
  if (input.attachmentConsent !== void 0) root.attachmentConsent = input.attachmentConsent;
  if (input.offlineConsent !== void 0) root.offlineConsent = input.offlineConsent;
  validateCatalogRoot(root);
  return { root, revision: catalogRootRevision(root), pages: builder.pages };
}
function buildCatalogPages(input) {
  validateSnapshot(input.snapshot);
  if (input.context) validateCompanionStudyContext(input.context);
  return finishSteps(catalogBuildSteps(input));
}
async function page(reference3, storage, ancestors) {
  fail3(ancestors.size < 64 && !ancestors.has(reference3.sha256), "invalid catalog page depth or cycle");
  const next = new Set(ancestors);
  next.add(reference3.sha256);
  return { page: decodeCatalogPage(reference3, await storage.read(reference3)), ancestors: next };
}
async function readCatalogList(reference3, storage, kind2 = "list", ancestors = /* @__PURE__ */ new Set(), seen = /* @__PURE__ */ new Set()) {
  fail3(!seen.has(reference3.sha256), "repeated catalog collection page");
  seen.add(reference3.sha256);
  const current = await page(reference3, storage, ancestors);
  if (current.page.kind === kind2) return current.page.values;
  fail3(current.page.kind === "index", "catalog page kind differs");
  const values = [];
  for (const child of current.page.children) for (const value of await readCatalogList(child, storage, kind2, current.ancestors, seen)) values.push(value);
  fail3(values.length === reference3.count);
  return values;
}
async function readCollection(collection, storage) {
  const records = await readCatalogList(collection.records, storage, "records"), order = await readCatalogList(collection.order, storage), byId = /* @__PURE__ */ new Map();
  for (const row of records) {
    fail3(record3(row) && typeof row.id === "string" && !byId.has(row.id));
    byId.set(row.id, row);
  }
  const seen = /* @__PURE__ */ new Set(), result = order.map((id2) => {
    fail3(typeof id2 === "string" && !seen.has(id2) && byId.has(id2));
    seen.add(id2);
    return byId.get(id2);
  });
  fail3(seen.size === byId.size && result.length === collection.count);
  return result;
}
async function readCatalogRoot(root, storage) {
  validateCatalogRoot(root);
  const snapshot = { ...root.snapshot.header, cards: await readCollection(root.snapshot.cards, storage) };
  if (root.snapshot.header.studyTarget) {
    fail3(root.snapshot.targetCardIds);
    snapshot.studyTarget = { ...root.snapshot.header.studyTarget, cardIds: await readCatalogList(root.snapshot.targetCardIds, storage) };
  } else fail3(root.snapshot.targetCardIds === void 0);
  const result = { snapshot, consentIds: await readCatalogList(root.consentIds, storage), timeZone: root.timeZone };
  if (root.context) result.context = { ...root.context.header, cards: await readCollection(root.context.cards, storage) };
  if (root.materialConsentIds) result.materialConsentIds = await readCatalogList(root.materialConsentIds, storage);
  if (root.attachmentConsent !== void 0) result.attachmentConsent = root.attachmentConsent;
  if (root.offlineConsent !== void 0) result.offlineConsent = root.offlineConsent;
  return result;
}
async function readPagedJson(reference3, storage, ancestors = /* @__PURE__ */ new Set()) {
  const current = await page(reference3, storage, ancestors), value = current.page;
  if (value.kind === "json") return value.value;
  if (value.kind === "list") return value.values;
  if (value.kind === "object") {
    const result2 = /* @__PURE__ */ Object.create(null);
    for (const member of value.members) Object.defineProperty(result2, member.name, { value: await readPagedJson(member.reference, storage, current.ancestors), enumerable: true, writable: true, configurable: true });
    return result2;
  }
  fail3(value.kind === "array", "invalid paged JSON tree");
  const result = [];
  for (const part of value.parts) {
    const item = await readPagedJson(part.reference, storage, current.ancestors);
    if (part.spread) {
      fail3(Array.isArray(item));
      for (const row of item) result.push(row);
    } else result.push(item);
  }
  fail3(result.length === reference3.count);
  return result;
}

// src/infrastructure/companion/server/immutable-content.ts
var import_node_crypto4 = require("node:crypto");
var snapshots = /* @__PURE__ */ new WeakSet();
var contexts = /* @__PURE__ */ new WeakSet();
var cardIndexes = /* @__PURE__ */ new WeakMap();
var metadataIndexes = /* @__PURE__ */ new WeakMap();
var contextTokens = /* @__PURE__ */ new WeakMap();
var rootSeeds = /* @__PURE__ */ new WeakMap();
function freeze(value) {
  if (!value || typeof value !== "object") return;
  for (const child of Object.values(value)) freeze(child);
  if (!Object.isFrozen(value)) Object.freeze(value);
}
function validateImmutableSnapshot(value) {
  if (value && typeof value === "object" && snapshots.has(value)) return;
  validateSnapshot(value);
  freeze(value);
  snapshots.add(value);
}
function validateImmutableStudyContext(value) {
  if (value && typeof value === "object" && contexts.has(value)) return;
  validateCompanionStudyContext(value);
  freeze(value);
  contexts.add(value);
}
function snapshotCardMap(value) {
  if (!snapshots.has(value)) return new Map(value.cards.map((card) => [card.id, card]));
  let index2 = cardIndexes.get(value);
  if (!index2) {
    index2 = new Map(value.cards.map((card) => [card.id, card]));
    cardIndexes.set(value, index2);
  }
  return index2;
}
function studyContextCardMap(value) {
  if (!contexts.has(value)) return new Map(value.cards.map((card) => [card.id, card]));
  let index2 = metadataIndexes.get(value);
  if (!index2) {
    index2 = new Map(value.cards.map((card) => [card.id, card]));
    metadataIndexes.set(value, index2);
  }
  return index2;
}
function studyContextToken(value) {
  const old = contexts.has(value) && contextTokens.get(value);
  if (old) return old;
  const digest5 = (0, import_node_crypto4.createHash)("sha256");
  let pending = "";
  for (const chunk of jsonFingerprintChunks(value)) {
    if (pending.length + chunk.length > 65536 && pending) {
      digest5.update(pending);
      pending = "";
    }
    if (chunk.length > 65536) digest5.update(chunk);
    else pending += chunk;
  }
  if (pending) digest5.update(pending);
  const token5 = digest5.digest("hex");
  if (contexts.has(value)) contextTokens.set(value, token5);
  return token5;
}
function snapshotOfflineSeed(snapshot, id2) {
  const card = snapshotCardMap(snapshot).get(id2);
  if (!card?.offline) return;
  if (!snapshots.has(snapshot)) return decodeOfflineSeed(card.offline);
  let seeds = rootSeeds.get(snapshot);
  if (!seeds) {
    seeds = /* @__PURE__ */ new Map();
    rootSeeds.set(snapshot, seeds);
  }
  let seed = seeds.get(id2);
  if (!seed) {
    seed = decodeOfflineSeed(card.offline);
    freeze(seed);
    seeds.set(id2, seed);
  }
  return seed;
}
function mutableServerState(state) {
  const { studyContext: _context, domain, ...mutable } = state, { snapshot: _snapshot, ...mutableDomain } = domain;
  return { ...mutable, domain: mutableDomain };
}
function cloneServerState(state) {
  if (state.domain.snapshot) validateImmutableSnapshot(state.domain.snapshot);
  if (state.studyContext) validateImmutableStudyContext(state.studyContext);
  const copy7 = cloneJsonValue(mutableServerState(state));
  if (state.domain.snapshot) copy7.domain.snapshot = state.domain.snapshot;
  if (state.studyContext) copy7.studyContext = state.studyContext;
  return copy7;
}

// src/infrastructure/companion/server/catalog-page-storage.ts
var publications = /* @__PURE__ */ new WeakMap();
function verifiedCatalogPublication(storage, snapshot, context, root) {
  const value = publications.get(snapshot);
  return value?.storage === storage && value.context === context && root && jsonFingerprintEqual(value.root, root) ? value : void 0;
}
function freezeRoot(value) {
  if (value && typeof value === "object") {
    for (const child of Object.values(value)) freezeRoot(child);
    Object.freeze(value);
  }
}
function privateFile(info) {
  invalid(info.isFile() && !info.isSymbolicLink() && Number(info.nlink) === 1 && (process.platform === "win32" || (Number(info.mode) & 63) === 0), "private catalog page required");
}
var identity = (info) => [
  info.dev,
  info.ino,
  info.size,
  info.mode,
  info.nlink,
  "mtimeNs" in info ? info.mtimeNs : info.mtimeMs,
  "ctimeNs" in info ? info.ctimeNs : info.ctimeMs
].map(String).join(":");
async function syncDirectory(path) {
  if (process.platform === "win32") return;
  const file = await (0, import_promises.open)(path, "r");
  try {
    await file.sync();
  } finally {
    await file.close();
  }
}
var DesktopCatalogPageStorage = class {
  directory;
  directoryIdentity;
  pendingDirectorySync = true;
  verified = /* @__PURE__ */ new Map();
  identities = /* @__PURE__ */ new WeakMap();
  captures = /* @__PURE__ */ new Set();
  constructor(journalPath) {
    this.directory = `${journalPath}.pages`;
  }
  async directoryReady(create) {
    let created = false;
    if (create) await (0, import_promises.mkdir)(this.directory, { mode: 448 }).then(() => {
      created = true;
    }).catch((error) => {
      if (error.code !== "EEXIST") throw error;
    });
    const info = await (0, import_promises.lstat)(this.directory, { bigint: true });
    invalid(info.isDirectory() && !info.isSymbolicLink() && (process.platform === "win32" || (Number(info.mode) & 63) === 0), "private catalog directory required");
    const current = [info.dev, info.ino].map(String).join(":");
    if (create && (created || this.directoryIdentity !== current)) {
      this.pendingDirectorySync = true;
      await syncDirectory((0, import_node_path.dirname)(this.directory));
      this.directoryIdentity = current;
    }
  }
  path(reference3) {
    validateCatalogReference(reference3);
    return (0, import_node_path.join)(this.directory, reference3.sha256 + ".json");
  }
  async read(reference3) {
    await this.directoryReady(false);
    const path = this.path(reference3), named = await (0, import_promises.lstat)(path, { bigint: true });
    privateFile(named);
    invalid(Number(named.size) === reference3.bytes, "catalog page size differs");
    const file = await (0, import_promises.open)(path, import_node_fs.constants.O_RDONLY | (import_node_fs.constants.O_NOFOLLOW ?? 0));
    let bytes;
    try {
      const before = await file.stat({ bigint: true });
      privateFile(before);
      invalid(identity(before) === identity(named));
      const buffer = Buffer.allocUnsafe(reference3.bytes + 1);
      let offset = 0;
      while (offset < buffer.length) {
        const result = await file.read(buffer, offset, buffer.length - offset, offset);
        if (!result.bytesRead) break;
        offset += result.bytesRead;
      }
      const after = await file.stat({ bigint: true }), current = await (0, import_promises.lstat)(path, { bigint: true });
      privateFile(after);
      privateFile(current);
      invalid(identity(before) === identity(after) && identity(after) === identity(current) && offset === reference3.bytes, "catalog page changed while reading");
      bytes = buffer.subarray(0, offset);
      decodeCatalogPage(reference3, bytes);
      this.remember(reference3, after);
    } finally {
      await file.close();
    }
    return bytes;
  }
  remember(reference3, info) {
    const copy7 = { ...reference3 }, current = identity(info);
    this.identities.set(reference3, current);
    this.identities.set(copy7, current);
    this.verified.delete(reference3.sha256);
    this.verified.set(reference3.sha256, { reference: copy7, identity: current });
    if (this.verified.size > 4096) this.verified.delete(this.verified.keys().next().value);
    for (const capture of this.captures) capture.set(reference3.sha256, copy7);
  }
  async capture(operation) {
    const references = /* @__PURE__ */ new Map();
    this.captures.add(references);
    try {
      return { value: await operation(), references: [...references.values()] };
    } finally {
      this.captures.delete(references);
    }
  }
  async assertUnchanged(references) {
    await this.directoryReady(false);
    for (const reference3 of references) {
      const prior = this.verified.get(reference3.sha256), expected = this.identities.get(reference3) ?? (prior?.reference.bytes === reference3.bytes && prior.reference.count === reference3.count ? prior.identity : void 0);
      const current = await (0, import_promises.lstat)(this.path(reference3), { bigint: true });
      privateFile(current);
      invalid(expected && expected === identity(current), "catalog page changed before publication");
      for (const capture of this.captures) {
        const copy7 = { ...reference3 };
        this.identities.set(copy7, expected);
        capture.set(reference3.sha256, copy7);
      }
    }
  }
  async flush() {
    await this.directoryReady(true);
    if (this.pendingDirectorySync) {
      await syncDirectory(this.directory);
      this.pendingDirectorySync = false;
    }
  }
  async has(reference3) {
    try {
      await this.read(reference3);
      return true;
    } catch (error) {
      if (error.code === "ENOENT") return false;
      throw error;
    }
  }
  async put(reference3, bytes) {
    await this.putBatch([{ reference: reference3, bytes }]);
  }
  async putBatch(pages) {
    for (const { reference: reference3, bytes } of pages) await this.writePage(reference3, bytes);
    await this.flush();
  }
  async writePage(reference3, bytes) {
    decodeCatalogPage(reference3, bytes);
    await this.directoryReady(true);
    const destination = this.path(reference3);
    if (this.verified.has(reference3.sha256)) {
      await this.assertUnchanged([reference3]);
      return;
    }
    try {
      await (0, import_promises.lstat)(destination);
      await this.read(reference3);
      return;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const temporary = (0, import_node_path.join)(this.directory, `.${(0, import_node_crypto5.randomUUID)()}.tmp`);
    try {
      const file = await (0, import_promises.open)(temporary, "wx", 384);
      try {
        await file.writeFile(bytes);
        await file.sync();
      } finally {
        await file.close();
      }
      try {
        await (0, import_promises.lstat)(destination);
        await this.read(reference3);
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
        this.pendingDirectorySync = true;
        await (0, import_promises.rename)(temporary, destination);
      }
      await this.read(reference3);
    } finally {
      await (0, import_promises.unlink)(temporary).catch((error) => {
        if (error.code !== "ENOENT") throw error;
      });
    }
  }
};
function decodeUploadPage(value, reference3) {
  invalid(value.encoding === void 0 || value.encoding === "gzip");
  invalid(typeof value.data === "string" && value.data.length > 0 && value.data.length <= Math.ceil(CATALOG_PAGE_BYTES / 3) * 4);
  let bytes = Buffer.from(value.data, "base64");
  invalid(bytes.toString("base64") === value.data && bytes.length <= CATALOG_PAGE_BYTES);
  if (value.encoding === "gzip") bytes = (0, import_node_zlib.gunzipSync)(bytes, { maxOutputLength: reference3.bytes });
  invalid(bytes.length === reference3.bytes && (0, import_node_crypto5.createHash)("sha256").update(bytes).digest("hex") === reference3.sha256);
  return bytes;
}
var idleTtl = 5 * 6e4;
var maxLifetime = 90 * 6e4;
var CatalogPageTransfer = class {
  constructor(storage) {
    this.storage = storage;
  }
  upload;
  async accept(value, now, activeRevision, activeSequence) {
    if (this.upload && (now - this.upload.touchedAt >= idleTtl || now - this.upload.startedAt >= maxLifetime)) this.upload = void 0;
    if (value.operation === "catalog-pages-begin") {
      keys(value, ["operation", "root", "baseRevision"]);
      validateCatalogRoot(value.root);
      invalid(value.baseRevision === null || typeof value.baseRevision === "string" && /^[a-f0-9]{64}$/.test(value.baseRevision));
      const revision = catalogRootRevision(value.root);
      invalid(value.baseRevision === activeRevision || revision === activeRevision, "catalog base changed; start a new transfer");
      if (!this.upload || this.upload.revision !== revision || this.upload.baseRevision !== activeRevision)
        this.upload = { id: (0, import_node_crypto5.randomUUID)(), root: cloneJsonValue(value.root), revision, baseRevision: activeRevision, startedAt: now, touchedAt: now };
      this.upload.touchedAt = now;
      return { response: { id: this.upload.id, revision } };
    }
    if (value.operation === "catalog-pages-commit") {
      keys(value, ["operation", "id", "revision"]);
      token2(value.id);
      invalid(typeof value.revision === "string" && /^[a-f0-9]{64}$/.test(value.revision));
      if (value.revision === activeRevision) {
        invalid(Number.isSafeInteger(activeSequence) && Number(activeSequence) > 0);
        return { response: { sequence: activeSequence, revision: activeRevision } };
      }
    }
    token2(value.id);
    const upload = this.upload;
    invalid(upload && upload.id === value.id, "catalog upload expired; start a new transfer");
    invalid(activeRevision === upload.baseRevision, "catalog base changed; start a new transfer");
    upload.touchedAt = now;
    if (value.operation === "catalog-pages-missing") {
      keys(value, ["operation", "id", "references"]);
      invalid(Array.isArray(value.references) && value.references.length <= CATALOG_REFERENCE_BATCH);
      const missing3 = [], seen = /* @__PURE__ */ new Set();
      for (const reference3 of value.references) {
        validateCatalogReference(reference3);
        invalid(!seen.has(reference3.sha256), "duplicate catalog reference");
        seen.add(reference3.sha256);
        if (!await this.storage.has(reference3)) missing3.push(reference3.sha256);
      }
      return { response: { missing: missing3 } };
    }
    if (value.operation === "catalog-pages-put") {
      keys(value, ["operation", "id", "reference", "data", "encoding"]);
      validateCatalogReference(value.reference);
      await this.storage.put(value.reference, decodeUploadPage(value, value.reference));
      return { response: { sha256: value.reference.sha256 } };
    }
    if (value.operation === "catalog-pages-put-batch") {
      keys(value, ["operation", "id", "pages"]);
      invalid(Array.isArray(value.pages) && value.pages.length > 0 && value.pages.length <= CATALOG_UPLOAD_BATCH);
      const hashes = /* @__PURE__ */ new Set();
      let totalBytes = 0;
      const pages = value.pages.map((page2) => {
        record2(page2);
        keys(page2, ["reference", "data", "encoding"]);
        validateCatalogReference(page2.reference);
        totalBytes += page2.reference.bytes;
        invalid(totalBytes <= CATALOG_PAGE_BYTES && !hashes.has(page2.reference.sha256), "invalid catalog page batch");
        hashes.add(page2.reference.sha256);
        const bytes = decodeUploadPage(page2, page2.reference);
        decodeCatalogPage(page2.reference, bytes);
        return { reference: page2.reference, bytes };
      });
      await this.storage.putBatch(pages);
      return { response: { hashes: [...hashes] } };
    }
    invalid(value.operation === "catalog-pages-commit" && value.revision === upload.revision);
    const references = /* @__PURE__ */ new Map();
    const payload = await readCatalogRoot(upload.root, { read: async (reference3) => {
      const bytes = await this.storage.read(reference3);
      references.set(reference3.sha256, reference3);
      return bytes;
    } });
    validateImmutableSnapshot(payload.snapshot);
    if (payload.context) validateImmutableStudyContext(payload.context);
    await this.storage.flush?.();
    freezeRoot(upload.root);
    publications.set(payload.snapshot, Object.freeze({
      storage: this.storage,
      root: upload.root,
      context: payload.context,
      references: Object.freeze([...references.values()].map((reference3) => Object.freeze(reference3)))
    }));
    return { payload, root: upload.root, revision: upload.revision, baseRevision: upload.baseRevision, startedAt: upload.startedAt };
  }
};

// src/domain/companion/card-reports.ts
var COMPANION_CARD_REPORT_TTL = 7 * 864e5;
function companionCardReportContentHash(card) {
  return compactSourceFingerprint(jsonFingerprint([
    card.question,
    card.reference,
    card.exercise ?? null,
    card.evaluationMode ?? null,
    card.acceptedAnswers ?? null,
    card.answerMatchMode ?? null
  ])).slice(7);
}
function validateCompanionCardReport(value) {
  record2(value);
  keys(value, ["id", "scope", "epoch", "cardId", "materialId", "contentHash", "requestedAt", "reason", "note"]);
  for (const field of ["id", "scope", "epoch", "cardId", "materialId"]) token2(value[field]);
  timestamp(value.requestedAt);
  invalid(typeof value.contentHash === "string" && /^[a-f0-9]{64}$/.test(value.contentHash));
  normalizeCardClarification({ ...value.reason === void 0 ? {} : { reason: value.reason }, ...value.note === void 0 ? {} : { note: value.note } });
}
function sameCompanionCardReport(a, b) {
  return jsonFingerprint(a) === jsonFingerprint(b);
}
function validateCompanionCardReportReceipt(value, expected) {
  record2(value);
  keys(value, ["report", "status"]);
  validateCompanionCardReport(value.report);
  invalid(!expected || sameCompanionCardReport(value.report, expected));
  invalid(["applied", "conflict", "missing", "revoked", "expired"].includes(String(value.status)));
}

// src/domain/companion/corrections.ts
function validateCompanionGradeCorrection(value) {
  record2(value);
  keys(value, ["id", "scope", "epoch", "attemptId", "cardId", "revision", "expectedReviewEventId", "rating", "correct", "requestedAt"]);
  for (const field of ["id", "scope", "epoch", "attemptId", "cardId", "revision", "expectedReviewEventId"]) token2(value[field]);
  timestamp(value.requestedAt);
  invalid([1, 2, 3, 4].includes(value.rating) && value.correct === (value.rating !== 1));
}
function sameCompanionGradeCorrection(a, b) {
  return Object.keys(a).length === Object.keys(b).length && Object.keys(a).every((key2) => a[key2] === b[key2]);
}
function validateCompanionGradeCorrectionReceipt(value, expected) {
  record2(value);
  keys(value, ["correction", "status", "reviewEventId", "nextDueAt"]);
  validateCompanionGradeCorrection(value.correction);
  invalid(!expected || sameCompanionGradeCorrection(value.correction, expected), "Correction receipt differs from request");
  invalid(typeof value.status === "string" && ["applied", "stale", "missing", "epoch-mismatch", "ineligible", "local-session-active", "expired", "clock-mismatch"].includes(value.status));
  if (value.status === "applied") {
    token2(value.reviewEventId);
    timestamp(value.nextDueAt);
  } else invalid(value.reviewEventId === void 0 && value.nextDueAt === void 0);
}

// src/domain/companion/study-plan-actions.ts
var COMPANION_PLAN_ACTION_TTL = 7 * 864e5;
var isCompanionPlanHash = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
function validateCompanionPlanActionOptions(value) {
  record2(value);
  keys(value, ["revision", "date", "time", "durationMinutes", "canMoveDate"]);
  invalid(isCompanionPlanHash(value.revision) && typeof value.date === "string" && isStudyTaskDate(value.date) && typeof value.time === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(value.time) && Number.isSafeInteger(value.durationMinutes) && Number(value.durationMinutes) >= 1 && Number(value.durationMinutes) <= 1440 && typeof value.canMoveDate === "boolean");
}
function validateCompanionPlanCommand(value) {
  record2(value);
  keys(value, ["id", "scope", "epoch", "entryId", "revision", "action", "requestedAt", "date", "time", "durationMinutes"]);
  token2(value.id);
  token2(value.scope);
  token2(value.epoch);
  timestamp(value.requestedAt);
  invalid(isCompanionPlanHash(value.entryId) && isCompanionPlanHash(value.revision) && ["complete", "reopen", "reschedule"].includes(String(value.action)));
  if (value.action === "reschedule") {
    invalid(typeof value.date === "string" && isStudyTaskDate(value.date) && typeof value.time === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(value.time) && Number.isSafeInteger(value.durationMinutes) && Number(value.durationMinutes) >= 1 && Number(value.durationMinutes) <= 1440);
  } else invalid(value.date === void 0 && value.time === void 0 && value.durationMinutes === void 0);
}
var sameCompanionPlanCommand = (a, b) => jsonFingerprint(a) === jsonFingerprint(b);
function validateCompanionPlanCommandReceipt(value, expected) {
  record2(value);
  keys(value, ["command", "status"]);
  validateCompanionPlanCommand(value.command);
  invalid(!expected || sameCompanionPlanCommand(value.command, expected));
  invalid(["applied", "conflict", "missing", "revoked", "expired"].includes(String(value.status)));
}

// src/domain/companion/study-plan.ts
var minute = 6e4;
var day = 864e5;
var COMPANION_STUDY_PLAN_TTL = 7 * day;
var record4 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var timestamp2 = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && Number.isFinite(new Date(value).getTime());
var token3 = (value) => typeof value === "string" && value.length >= 1 && value.length <= 128 && !/[^a-zA-Z0-9._:-]/.test(value);
var keys2 = (value, allowed) => Object.keys(value).every((key2) => allowed.includes(key2));
var text2 = (value) => typeof value === "string" && value.trim().length > 0 && value.length <= 200 && !/[\u0000-\u001f\u007f-\u009f]/.test(value);
var invalid3 = () => {
  throw new Error("Invalid companion study plan");
};
var validZone = (value) => {
  if (typeof value !== "string" || !value || value.length > 100 || /^[+-]/.test(value)) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: value }).format(0);
    return true;
  } catch {
    return false;
  }
};
function validateCompanionStudyPlan(value) {
  if (!record4(value) || !keys2(value, ["version", "enabled", "timeZone", "generatedAt", "expiresAt", "entries", "overview"]) || value.version !== 1 || typeof value.enabled !== "boolean" || !validZone(value.timeZone) || !timestamp2(value.generatedAt) || !timestamp2(value.expiresAt) || value.expiresAt <= value.generatedAt || value.expiresAt - value.generatedAt > COMPANION_STUDY_PLAN_TTL || !Array.isArray(value.entries) || !value.enabled && value.entries.length) return invalid3();
  if (value.overview !== void 0 && !Array.isArray(value.overview)) return invalid3();
  for (const [index2, rows] of [value.entries, value.overview ?? []].entries()) {
    const ids = /* @__PURE__ */ new Set();
    for (const entry of rows) {
      if (!record4(entry) || !keys2(entry, ["id", "title", "startAt", "notifyAt", "materialIds", "mode", "action", ...index2 ? ["completed", "skipped", "calendar"] : []]) || typeof entry.id !== "string" || entry.id.length !== 64 || !/^[a-f0-9]{64}$/.test(entry.id) || ids.has(entry.id) || !text2(entry.title) || !timestamp2(entry.startAt) || !timestamp2(entry.notifyAt) || entry.notifyAt > entry.startAt || entry.startAt - entry.notifyAt > 1440 * minute || entry.startAt >= value.expiresAt || !Array.isArray(entry.materialIds) || entry.materialIds.length > 100 || !Array.from(entry.materialIds).every(token3) || new Set(entry.materialIds).size !== entry.materialIds.length || entry.mode !== void 0 && entry.mode !== "core" && entry.mode !== "bank" || !entry.materialIds.length && entry.mode !== "core" || index2 && (entry.completed !== void 0 && typeof entry.completed !== "boolean" || entry.skipped !== void 0 && typeof entry.skipped !== "boolean")) return invalid3();
      ids.add(entry.id);
      if (entry.action !== void 0) validateCompanionPlanActionOptions(entry.action);
      if (entry.calendar !== void 0) {
        if (!entry.action || !record4(entry.calendar) || !keys2(entry.calendar, ["state", "checkedAt"]) || !["waiting", "synced", "disabled", "not-routed", "error", "conflict"].includes(String(entry.calendar.state)) || entry.calendar.checkedAt !== void 0 && (!timestamp2(entry.calendar.checkedAt) || entry.calendar.checkedAt > value.generatedAt + 3e5) || ["synced", "conflict"].includes(String(entry.calendar.state)) && entry.calendar.checkedAt === void 0) return invalid3();
      }
    }
  }
}

// src/domain/companion/study-plan-link.ts
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
function parseStudyPlanStartParameter(parameter) {
  if (!/^p_[A-Za-z0-9_-]{43}$/.test(parameter)) return void 0;
  let bits = 0, value = 0, hex = "";
  for (const character of parameter.slice(2)) {
    value = value << 6 | alphabet.indexOf(character);
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      hex += (value >>> bits & 255).toString(16).padStart(2, "0");
    }
  }
  if (value & (1 << bits) - 1) return void 0;
  return hex.length === 64 ? hex : void 0;
}

// src/features/companion/rich-checkbox-demo.ts
var RICH_CHECKBOX_DEMO_QUESTION = "\u0412\u044B\u0431\u0435\u0440\u0438 \u0432\u0441\u0435 \u0447\u0451\u0442\u043D\u044B\u0435 \u0447\u0438\u0441\u043B\u0430.";
var RICH_CHECKBOX_DEMO_OPTIONS = ["2", "3", "4", "6"];
var footer = "\u041F\u0440\u043E\u0431\u043D\u044B\u0439 \u0438\u043D\u0442\u0435\u0440\u0444\u0435\u0439\u0441 \xB7 \u0431\u0435\u0437 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0438 FSRS.";
var feedback = (selected) => selected.length === 3 && selected[0] === 0 && selected[1] === 2 && selected[2] === 3 ? "\u2705 \u0412\u0435\u0440\u043D\u043E: 2, 4 \u0438 6." : "\u274C \u041D\u0435 \u0441\u043E\u0432\u0441\u0435\u043C. \u0427\u0451\u0442\u043D\u044B\u0435 \u0447\u0438\u0441\u043B\u0430: 2, 4 \u0438 6.";
function handle(value) {
  invalid(typeof value === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(value));
}
function validateState2(value) {
  record2(value);
  keys(value, ["selectedOptionIndexes", "toggleHandles", "checkHandle", "resetHandle", "checked"]);
  invalid(Array.isArray(value.selectedOptionIndexes) && value.selectedOptionIndexes.length <= 4 && Array.from(value.selectedOptionIndexes).every((index2, i) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < 4 && (i === 0 || value.selectedOptionIndexes[i - 1] < index2)));
  invalid(Array.isArray(value.toggleHandles) && value.toggleHandles.length === 4 && typeof value.checked === "boolean");
  for (const id2 of [...value.toggleHandles, value.checkHandle, value.resetHandle]) handle(id2);
  invalid((/* @__PURE__ */ new Set([...value.toggleHandles, value.checkHandle, value.resetHandle])).size === 6);
}
function richCheckboxDemoView(state) {
  validateState2(state);
  return { blocks: [
    { type: "paragraph", text: RICH_CHECKBOX_DEMO_QUESTION },
    { type: "list", items: RICH_CHECKBOX_DEMO_OPTIONS.map((text4, index2) => ({
      has_checkbox: true,
      ...state.selectedOptionIndexes.includes(index2) ? { is_checked: true } : {},
      blocks: [{ type: "paragraph", text: { type: "button", button: { text: text4, style: "link", callback_data: state.toggleHandles[index2] } } }]
    })) },
    ...state.checked ? [{ type: "paragraph", text: feedback(state.selectedOptionIndexes) }] : [],
    { type: "buttons", align: "left", buttons: [
      { text: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442", style: "primary", callback_data: state.checkHandle },
      { text: "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440", style: "link", callback_data: state.resetHandle }
    ] },
    { type: "footer", text: footer }
  ], skip_entity_detection: true };
}
function parseMessage(value) {
  record2(value);
  keys(value, ["blocks", "skip_entity_detection"]);
  invalid(value.skip_entity_detection === true && Array.isArray(value.blocks) && (value.blocks.length === 4 || value.blocks.length === 5));
  const blocks = value.blocks;
  const paragraph = (block) => {
    record2(block);
    keys(block, ["type", "text"]);
    invalid(block.type === "paragraph");
    return block;
  };
  invalid(paragraph(blocks[0]).text === RICH_CHECKBOX_DEMO_QUESTION);
  const list = blocks[1];
  record2(list);
  keys(list, ["type", "items"]);
  invalid(list.type === "list" && Array.isArray(list.items) && list.items.length === 4);
  const selectedOptionIndexes = [], toggles = [];
  for (let index2 = 0; index2 < 4; index2++) {
    const item = list.items[index2];
    record2(item);
    keys(item, ["blocks", "has_checkbox", "is_checked"]);
    invalid(item.has_checkbox === true && (item.is_checked === void 0 || item.is_checked === true) && Array.isArray(item.blocks) && item.blocks.length === 1);
    if (item.is_checked === true) selectedOptionIndexes.push(index2);
    const richText = paragraph(item.blocks[0]).text;
    record2(richText);
    keys(richText, ["type", "button"]);
    invalid(richText.type === "button");
    record2(richText.button);
    keys(richText.button, ["text", "style", "callback_data"]);
    invalid(richText.button.text === RICH_CHECKBOX_DEMO_OPTIONS[index2] && richText.button.style === "link");
    handle(richText.button.callback_data);
    toggles.push(richText.button.callback_data);
  }
  const checked = blocks.length === 5;
  if (checked) invalid(paragraph(blocks[2]).text === feedback(selectedOptionIndexes));
  const controls = blocks[blocks.length - 2];
  record2(controls);
  keys(controls, ["type", "align", "buttons"]);
  invalid(controls.type === "buttons" && controls.align === "left" && Array.isArray(controls.buttons) && controls.buttons.length === 2);
  for (let index2 = 0; index2 < 2; index2++) {
    const button = controls.buttons[index2];
    record2(button);
    keys(button, ["text", "style", "callback_data"]);
    invalid(button.text === (index2 === 0 ? "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442" : "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440") && button.style === (index2 === 0 ? "primary" : "link"));
    handle(button.callback_data);
  }
  const note = blocks[blocks.length - 1];
  record2(note);
  keys(note, ["type", "text"]);
  invalid(note.type === "footer" && note.text === footer);
  const state = {
    selectedOptionIndexes,
    checked,
    toggleHandles: toggles,
    checkHandle: controls.buttons[0].callback_data,
    resetHandle: controls.buttons[1].callback_data
  };
  validateState2(state);
  return state;
}
function validateRichCheckboxDemoMessage(value) {
  parseMessage(value);
}
function readRichCheckboxDemoMessage(value) {
  return parseMessage(value);
}
function richCheckboxDemoCallbacks(value) {
  const { toggleHandles, checkHandle, resetHandle } = parseMessage(value);
  return { toggleHandles, checkHandle, resetHandle };
}
function validateRichCheckboxDemoPayload(value, editing = false) {
  record2(value);
  keys(value, editing ? ["chat_id", "message_id", "rich_message"] : ["chat_id", "rich_message", "disable_notification"]);
  invalid(Number.isSafeInteger(value.chat_id) && Number(value.chat_id) > 0);
  if (editing) invalid(Number.isSafeInteger(value.message_id) && Number(value.message_id) > 0);
  else invalid(value.disable_notification === true);
  validateRichCheckboxDemoMessage(value.rich_message);
}

// src/domain/review/answer-history.ts
var MAX_ANSWER_HISTORY_TEXT_LENGTH = 3e4;
var MAX_ANSWER_HISTORY_CONTEXT_LENGTH = 3e4;
var fields3 = ["attemptId", "cardId", "mode", "occurredAt", "kind", "question", "reference", "answerMatch", "answer", "answerMatchMode", "criteria", "checkedCriteria"];
var kinds = ["exact", "self", "single", "multiple", "cloze", "matching", "ordering"];
var fail4 = () => {
  throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u043E\u0442\u0432\u0435\u0442\u043E\u0432.");
};
var check4 = (value) => {
  if (!value) fail4();
};
var object5 = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
var own = (value, key2) => Object.prototype.hasOwnProperty.call(value, key2);
var dense = (value) => Array.from({ length: value.length }, (_, index2) => own(value, String(index2))).every(Boolean);
var token4 = (value) => typeof value === "string" && /^[a-zA-Z0-9._:-]{1,128}$/.test(value);
var text3 = (value, max) => typeof value === "string" && value.length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/.test(value);
var timestamp3 = (value) => Number.isSafeInteger(value) && Number(value) >= 0;
function validateAnswerHistoryEvidence(value) {
  check4(object5(value) && Object.keys(value).every((key2) => fields3.includes(key2)));
  const evidence = value;
  for (const key2 of ["attemptId", "cardId", "mode", "occurredAt", "kind", "question", "reference", "answerMatch"]) check4(own(evidence, key2));
  check4(token4(evidence.attemptId) && token4(evidence.cardId) && ["core", "bank"].includes(evidence.mode) && timestamp3(evidence.occurredAt));
  check4(kinds.includes(evidence.kind) && text3(evidence.question, MAX_ANSWER_HISTORY_CONTEXT_LENGTH) && !!evidence.question.trim() && text3(evidence.reference, MAX_ANSWER_HISTORY_CONTEXT_LENGTH));
  check4(evidence.answerMatch === true || evidence.answerMatch === false || evidence.answerMatch === null);
  if (evidence.kind === "self") check4(evidence.answerMatch === null);
  else check4(evidence.criteria === void 0 && evidence.checkedCriteria === void 0);
  if (evidence.kind === "self" || evidence.answerMatch === false) check4(own(evidence, "answer") && text3(evidence.answer, MAX_ANSWER_HISTORY_TEXT_LENGTH));
  else if (evidence.answerMatch === true) check4(!own(evidence, "answer"));
  else if (own(evidence, "answer")) check4(text3(evidence.answer, MAX_ANSWER_HISTORY_TEXT_LENGTH));
  if (evidence.answerMatchMode !== void 0) check4(["exact", "cloze"].includes(evidence.kind) && ["text", "literal"].includes(evidence.answerMatchMode));
  if (evidence.criteria !== void 0) check4(Array.isArray(evidence.criteria) && dense(evidence.criteria) && evidence.criteria.length <= MAX_SELF_CHECK_CRITERIA && evidence.criteria.every((row) => text3(row, MAX_SELF_CHECK_CRITERION_LENGTH) && !!row.trim()));
  if (evidence.checkedCriteria !== void 0) {
    const values = evidence.checkedCriteria, count = evidence.criteria?.length ?? 0;
    check4(Array.isArray(values) && dense(values) && values.length <= count && values.every((index2, position) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < count && (position === 0 || values[position - 1] < index2)));
  }
  if (evidence.kind === "self" && !evidence.answer.trim()) check4(Boolean(evidence.checkedCriteria?.length));
}
function createAnswerHistoryEvidence(input) {
  check4(object5(input) && Object.keys(input).every((key2) => fields3.includes(key2)));
  const value = { ...input };
  if (value.kind !== "self" && (value.answerMatch === true || value.answerMatch === null && value.answer === void 0)) delete value.answer;
  if (input.criteria !== void 0) value.criteria = [...input.criteria];
  if (input.checkedCriteria !== void 0) value.checkedCriteria = [...input.checkedCriteria];
  validateAnswerHistoryEvidence(value);
  return value;
}
function sameAnswerHistoryEvidence(left, right) {
  return jsonFingerprint(left) === jsonFingerprint(right);
}
function answerHistoryReferenceId(evidence) {
  check4(text3(evidence.question, MAX_ANSWER_HISTORY_CONTEXT_LENGTH) && !!evidence.question.trim() && text3(evidence.reference, MAX_ANSWER_HISTORY_CONTEXT_LENGTH));
  if (evidence.criteria !== void 0) check4(Array.isArray(evidence.criteria) && dense(evidence.criteria) && evidence.criteria.length <= MAX_SELF_CHECK_CRITERIA && evidence.criteria.every((row) => text3(row, MAX_SELF_CHECK_CRITERION_LENGTH) && !!row.trim()));
  return compactSourceFingerprint(jsonFingerprint({ question: evidence.question, reference: evidence.reference, ...evidence.criteria === void 0 ? {} : { criteria: evidence.criteria } }));
}
function normalizeRecurringAnswer(answer, matchMode = "text") {
  check4(text3(answer, MAX_ANSWER_HISTORY_TEXT_LENGTH) && ["text", "literal"].includes(matchMode));
  return matchMode === "literal" ? answer : answer.normalize("NFKC").replace(/\s+/gu, " ").trim();
}
function aggregateWrongAnswerEvidence(evidences) {
  const seen = /* @__PURE__ */ new Map(), patterns = /* @__PURE__ */ new Map();
  for (const evidence of evidences) {
    validateAnswerHistoryEvidence(evidence);
    const identity5 = jsonFingerprint([evidence.mode, evidence.cardId, evidence.attemptId]), prior = seen.get(identity5);
    if (prior) {
      check4(sameAnswerHistoryEvidence(prior, evidence));
      continue;
    }
    seen.set(identity5, evidence);
    if (evidence.answerMatch !== false) continue;
    const referenceId = answerHistoryReferenceId(evidence), normalizedAnswer = normalizeRecurringAnswer(evidence.answer, evidence.answerMatchMode);
    const key2 = jsonFingerprint([evidence.cardId, evidence.kind, referenceId, evidence.answerMatchMode ?? "text", normalizedAnswer]), pattern = patterns.get(key2);
    if (pattern) {
      pattern.count++;
      pattern.firstOccurredAt = Math.min(pattern.firstOccurredAt, evidence.occurredAt);
      if (evidence.occurredAt >= pattern.lastOccurredAt) {
        pattern.lastOccurredAt = evidence.occurredAt;
        pattern.answer = evidence.answer;
      }
    } else patterns.set(key2, {
      cardId: evidence.cardId,
      kind: evidence.kind,
      referenceId,
      question: evidence.question,
      reference: evidence.reference,
      answer: evidence.answer,
      normalizedAnswer,
      count: 1,
      firstOccurredAt: evidence.occurredAt,
      lastOccurredAt: evidence.occurredAt
    });
  }
  return [...patterns.values()].sort((a, b) => b.count - a.count || b.lastOccurredAt - a.lastOccurredAt || a.cardId.localeCompare(b.cardId) || a.normalizedAnswer.localeCompare(b.normalizedAnswer));
}

// src/domain/companion/answer-history.ts
function validateCompanionAnswerHistory(value) {
  record2(value);
  keys(value, ["attempt", "evidence"]);
  validateAttempt(value.attempt);
  validateAnswerHistoryEvidence(value.evidence);
  const attempt = value.attempt, evidence = value.evidence;
  invalid(
    attempt.id === evidence.attemptId && attempt.cardId === evidence.cardId && attempt.mode === evidence.mode && attempt.occurredAt === evidence.occurredAt,
    "Answer evidence differs from its grade identity"
  );
}
function sameCompanionAnswerHistory(a, b) {
  return sameAttempt(a.attempt, b.attempt) && sameAnswerHistoryEvidence(a.evidence, b.evidence);
}
function validateCompanionAnswerHistoryReceipt(value, expected) {
  record2(value);
  keys(value, ["record", "status"]);
  validateCompanionAnswerHistory(value.record);
  invalid(!expected || sameCompanionAnswerHistory(value.record, expected));
  invalid(["applied", "conflict", "missing", "revoked", "expired"].includes(String(value.status)));
}

// src/infrastructure/companion/server/bridge-contract.ts
var import_crypto = require("crypto");

// src/domain/companion/written-recall.ts
var MAX_COMPANION_WRITTEN_ANSWER_LENGTH = 4e3;
function validateCompanionWrittenAnswer(value) {
  invalid(typeof value === "string" && value.length <= MAX_COMPANION_WRITTEN_ANSWER_LENGTH && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/.test(value));
}
function validateCompanionSelfCheckCriteria(value) {
  invalid(Array.isArray(value) && value.length <= MAX_SELF_CHECK_CRITERIA && value.every((row) => typeof row === "string" && !!row.trim() && row.length <= MAX_SELF_CHECK_CRITERION_LENGTH && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/.test(row)));
}
function validateCompanionCheckedCriteria(value, count = MAX_SELF_CHECK_CRITERIA) {
  invalid(Array.isArray(value) && value.length <= count && value.every((index2, position, rows) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < count && (position === 0 || rows[position - 1] < index2)));
}
function validateCompanionWrittenRecall(value) {
  record2(value);
  keys(value, ["attempt", "answer", "question", "reference", "criteria", "checkedCriteria"]);
  validateAttempt(value.attempt);
  validateCompanionWrittenAnswer(value.answer);
  for (const field of [value.question, value.reference]) invalid(typeof field === "string" && field.length > 0 && field.length <= 1800);
  if (value.criteria !== void 0) validateCompanionSelfCheckCriteria(value.criteria);
  if (value.checkedCriteria !== void 0) validateCompanionCheckedCriteria(value.checkedCriteria, value.criteria?.length ?? 0);
}
function sameCompanionWrittenRecall(a, b) {
  return jsonFingerprint(a) === jsonFingerprint(b);
}
function validateCompanionWrittenRecallReceipt(value, expected) {
  record2(value);
  keys(value, ["recall", "status"]);
  validateCompanionWrittenRecall(value.recall);
  invalid(!expected || sameCompanionWrittenRecall(value.recall, expected));
  invalid(["applied", "conflict", "missing", "revoked", "expired"].includes(String(value.status)));
}

// src/infrastructure/companion/server/bridge-contract.ts
function canonical2(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
  if (typeof value === "number") {
    invalid(Number.isSafeInteger(value));
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonical2).join(",")}]`;
  record2(value);
  return `{${Object.keys(value).sort().map((k) => `${JSON.stringify(k)}:${canonical2(value[k])}`).join(",")}}`;
}
var digest = (value) => (0, import_crypto.createHash)("sha256").update(canonical2(value)).digest("hex");
var sign = (secret, value) => (0, import_crypto.createHmac)("sha256", secret).update(canonical2(value)).digest("hex");
function equal(a, b) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && (0, import_crypto.timingSafeEqual)(x, y);
}
function pendingCapability(secret, enrollment, attempt) {
  return sign(secret, { purpose: "ack-v1", enrollment, attempt });
}
function correctionCapability(secret, enrollment, correction) {
  return sign(secret, { purpose: "grade-correction-v1", enrollment, correction });
}
function planCommandCapability(secret, enrollment, command) {
  return sign(secret, { purpose: "plan-command-v1", enrollment, command });
}
function verifyPlanCommandCapability(secret, binding2, command, capability) {
  try {
    validateCompanionPlanCommand(command);
    return command.scope === binding2.scope && command.epoch === binding2.epoch && typeof capability === "string" && /^[a-f0-9]{64}$/.test(capability) && equal(capability, planCommandCapability(secret, binding2.enrollment, command));
  } catch {
    return false;
  }
}
function cardReportCapability(secret, enrollment, report) {
  return sign(secret, { purpose: "card-report-v1", enrollment, report });
}
function verifyCardReportCapability(secret, binding2, report, capability) {
  try {
    validateCompanionCardReport(report);
    return report.scope === binding2.scope && report.epoch === binding2.epoch && typeof capability === "string" && /^[a-f0-9]{64}$/.test(capability) && equal(capability, cardReportCapability(secret, binding2.enrollment, report));
  } catch {
    return false;
  }
}
function writtenRecallCapability(secret, enrollment, recall) {
  return sign(secret, { purpose: "written-recall-v1", enrollment, recall });
}
function answerHistoryCapability(secret, enrollment, value) {
  return sign(secret, { purpose: "answer-history-v1", enrollment, record: value });
}
function verifyAnswerHistoryCapability(secret, binding2, value, capability) {
  try {
    validateCompanionAnswerHistory(value);
    return value.attempt.scope === binding2.scope && value.attempt.epoch === binding2.epoch && typeof capability === "string" && equal(capability, answerHistoryCapability(secret, binding2.enrollment, value));
  } catch {
    return false;
  }
}
function verifyWrittenRecallCapability(secret, binding2, recall, capability) {
  try {
    validateCompanionWrittenRecall(recall);
    return recall.attempt.scope === binding2.scope && recall.attempt.epoch === binding2.epoch && typeof capability === "string" && /^[a-f0-9]{64}$/.test(capability) && equal(capability, writtenRecallCapability(secret, binding2.enrollment, recall));
  } catch {
    return false;
  }
}

// src/infrastructure/companion/server/answer-history.ts
var copy = cloneJsonValue;
function unpack(state, row, references) {
  const reference3 = references ? references.get(row.evidence.referenceId) : state.answerHistoryReferences?.find((item) => item.id === row.evidence.referenceId);
  invalid(reference3, "Answer history reference missing");
  const { referenceId: _id, ...evidence } = row.evidence, { id: _refId, ...context } = reference3;
  return { attempt: copy(row.attempt), evidence: { ...copy(evidence), ...copy(context) } };
}
function answerHistoryForAttempt(state, id2) {
  const row = state.answerHistory?.find((item) => item.attempt.id === id2);
  return row && unpack(state, row);
}
function answerHistoryRecords(state, attemptIds) {
  if (attemptIds?.size === 0) return [];
  const rows = (state.answerHistory ?? []).filter((row) => !attemptIds || attemptIds.has(row.attempt.id));
  const references = new Map((state.answerHistoryReferences ?? []).map((row) => [row.id, row]));
  return rows.map((row) => unpack(state, row, references));
}
function pendingAnswerHistory(state, maximum = Number.MAX_SAFE_INTEGER) {
  invalid(Number.isSafeInteger(maximum) && maximum > 0);
  const acked = new Set(state.answerHistoryReceipts?.map((row) => row.attemptId));
  const references = new Map((state.answerHistoryReferences ?? []).map((row) => [row.id, row]));
  const result = [];
  for (const row of state.answerHistory ?? []) if (!acked.has(row.attempt.id)) {
    result.push(unpack(state, row, references));
    if (result.length >= maximum) break;
  }
  return result;
}
function enqueueAnswerHistory(state, value) {
  validateCompanionAnswerHistory(value);
  const prior = answerHistoryForAttempt(state, value.attempt.id);
  if (prior) {
    invalid(sameCompanionAnswerHistory(prior, value), "Answer history ID collision");
    return;
  }
  const { question, reference: reference3, criteria, ...evidence } = value.evidence;
  const context = { question, reference: reference3, ...criteria === void 0 ? {} : { criteria: [...criteria] } }, id2 = digest(context);
  if (!(state.answerHistoryReferences ?? []).some((row) => row.id === id2)) (state.answerHistoryReferences ??= []).push({ id: id2, ...context });
  (state.answerHistory ??= []).push({ attempt: copy(value.attempt), evidence: { ...copy(evidence), referenceId: id2 } });
}
function acknowledgeAnswerHistory(state, value, receipt) {
  validateCompanionAnswerHistoryReceipt(receipt, value);
  const saved = answerHistoryForAttempt(state, value.attempt.id);
  invalid(saved && sameCompanionAnswerHistory(saved, value), "Unknown answer history record");
  const prior = state.answerHistoryReceipts?.find((row) => row.attemptId === value.attempt.id);
  if (prior) {
    invalid(prior.status === receipt.status, "Answer history receipt collision");
    return;
  }
  (state.answerHistoryReceipts ??= []).push({ attemptId: value.attempt.id, status: receipt.status });
}
function replacePendingAnswerHistoryAttempt(state, previousId, replacement) {
  const row = state.answerHistory?.find((item) => item.attempt.id === previousId);
  if (!row) return;
  invalid(!state.answerHistoryReceipts?.some((item) => item.attemptId === previousId), "Acknowledged answer history is immutable");
  row.attempt = copy(replacement);
  row.evidence.attemptId = replacement.id;
}
function validateAnswerHistoryState(state, attempts2) {
  for (const rows of [state.answerHistory, state.answerHistoryReferences, state.answerHistoryReceipts])
    invalid(rows === void 0 || Array.isArray(rows));
  const ids = /* @__PURE__ */ new Set(), references = /* @__PURE__ */ new Map(), known = new Map(attempts2.map((row) => [row.id, row]));
  for (const context of state.answerHistoryReferences ?? []) {
    record2(context);
    keys(context, ["id", "question", "reference", "criteria"]);
    const { id: id2, ...value } = context;
    invalid(typeof id2 === "string" && id2 === digest(value) && !references.has(id2));
    references.set(id2, context);
  }
  for (const row of state.answerHistory ?? []) {
    record2(row);
    keys(row, ["attempt", "evidence"]);
    const value = unpack(state, row, references);
    validateCompanionAnswerHistory(value);
    invalid(!ids.has(value.attempt.id) && known.has(value.attempt.id) && sameAttempt(known.get(value.attempt.id), value.attempt));
    ids.add(value.attempt.id);
  }
  const receipts = /* @__PURE__ */ new Set();
  for (const receipt of state.answerHistoryReceipts ?? []) {
    record2(receipt);
    keys(receipt, ["attemptId", "status"]);
    token2(receipt.attemptId);
    invalid(ids.has(receipt.attemptId) && !receipts.has(receipt.attemptId));
    invalid(["applied", "conflict", "missing", "revoked", "expired"].includes(receipt.status));
    receipts.add(receipt.attemptId);
  }
}

// src/infrastructure/companion/server/card-reports.ts
var copy2 = (value) => JSON.parse(JSON.stringify(value));
function validateCompanionCardReportState(state) {
  invalid((state.cardReports === void 0 || Array.isArray(state.cardReports)) && (state.cardReportReceipts === void 0 || Array.isArray(state.cardReportReceipts)));
  const ids = /* @__PURE__ */ new Set();
  for (const row of state.cardReports ?? []) {
    validateCompanionCardReport(row);
    invalid(!ids.has(row.id));
    ids.add(row.id);
  }
  for (const row of state.cardReportReceipts ?? []) {
    validateCompanionCardReportReceipt(row);
    invalid(!ids.has(row.report.id));
    ids.add(row.report.id);
  }
}
function enqueueCompanionCardReport(state, report, card, now) {
  validateCompanionCardReport(report);
  validateCompanionCardReportState(state);
  const prior = state.cardReports?.find((row) => row.id === report.id) ?? state.cardReportReceipts?.find((row) => row.report.id === report.id)?.report;
  if (prior) {
    invalid(sameCompanionCardReport(prior, report), "card report ID collision");
    return;
  }
  invalid(report.cardId === card.id && report.materialId === card.materialId && report.contentHash === companionCardReportContentHash(card) && report.requestedAt <= now + 3e5 && now - report.requestedAt <= COMPANION_CARD_REPORT_TTL, "stale card report");
  invalid(!state.cardReports?.some((row) => row.cardId === card.id), "card report pending");
  (state.cardReports ??= []).push(copy2(report));
}
function acknowledgeCompanionCardReport(state, report, receipt) {
  validateCompanionCardReportReceipt(receipt, report);
  validateCompanionCardReportState(state);
  const previous = state.cardReportReceipts?.find((row) => row.report.id === report.id);
  if (previous) {
    invalid(previous.status === receipt.status && sameCompanionCardReport(previous.report, report), "card report receipt collision");
    return;
  }
  const pending = state.cardReports?.find((row) => row.id === report.id);
  invalid(pending && sameCompanionCardReport(pending, report), "unknown card report");
  state.cardReports = state.cardReports.filter((row) => row.id !== report.id);
  (state.cardReportReceipts ??= []).push(copy2(receipt));
}
function companionCardReportViews(state, cards) {
  if (!state.cardReportReceipts?.length && !state.cardReports?.length) return [];
  const available = new Map(cards.map((card) => [card.id, card])), hashes = /* @__PURE__ */ new Map();
  return [...state.cardReportReceipts ?? [], ...(state.cardReports ?? []).map((report) => ({ report, status: "pending" }))].filter(({ report }) => {
    const card = available.get(report.cardId);
    if (!card) return false;
    let hash2 = hashes.get(card.id);
    if (hash2 === void 0) {
      hash2 = companionCardReportContentHash(card);
      hashes.set(card.id, hash2);
    }
    return report.contentHash === hash2;
  }).sort((a, b) => a.report.requestedAt - b.report.requestedAt).slice(-100).map(({ report, status }) => ({ id: report.id, cardId: report.cardId, status, requestedAt: report.requestedAt }));
}

// src/infrastructure/companion/server/metrics.ts
var metrics = ["journal.validate", "journal.write", "telegram.api", "telegram.upload", "media.read", "media.hash", "transport.wait", "runtime.commit", "runtime.queue", "runtime.callback_queue", "media.cache.hit", "media.cache.miss", "media.cache.invalid", "miniapp.view", "miniapp.view-conflict"];
var bounds = [1, 5, 10, 25, 50, 100, 250, 500, 1e3, 3e3, 1e4, 3e4, 6e4, Number.POSITIVE_INFINITY];
var CompanionPerformance = class {
  rows = /* @__PURE__ */ new Map();
  observe = (metric, elapsedMs) => {
    if (!metrics.includes(metric) || !Number.isFinite(elapsedMs) || elapsedMs < 0) return;
    const row = this.rows.get(metric) ?? { count: 0, totalMs: 0, maxMs: 0, buckets: bounds.map(() => 0) };
    if (row.count >= Number.MAX_SAFE_INTEGER) return;
    row.count++;
    row.totalMs = Math.min(Number.MAX_SAFE_INTEGER, row.totalMs + elapsedMs);
    row.maxMs = Math.max(row.maxMs, elapsedMs);
    row.buckets[bounds.findIndex((bound) => elapsedMs <= bound)]++;
    this.rows.set(metric, row);
  };
  snapshot(reset = false) {
    const result = {};
    for (const [metric, row] of this.rows) {
      const percentile = (fraction) => {
        let count = 0;
        for (let i = 0; i < row.buckets.length; i++) {
          count += row.buckets[i];
          if (count >= Math.ceil(row.count * fraction)) return Math.min(bounds[i], row.maxMs);
        }
        return row.maxMs;
      };
      result[metric] = { count: row.count, totalMs: Math.round(row.totalMs), maxMs: Math.ceil(row.maxMs), p50Ms: Math.ceil(percentile(0.5)), p95Ms: Math.ceil(percentile(0.95)) };
    }
    if (reset) this.rows.clear();
    return result;
  }
};
function recordPerformance(observer, metric, elapsedMs) {
  try {
    observer?.(metric, elapsedMs);
  } catch {
  }
}

// src/infrastructure/companion/server/miniapp-study.ts
var import_node_crypto7 = require("node:crypto");

// src/infrastructure/companion/server/miniapp-auth.ts
var import_node_crypto6 = require("node:crypto");
var MINIAPP_INIT_DATA_MAX_AGE_MS = 5 * 6e4;
var MINIAPP_SESSION_TTL_MS = 90 * 6e4;
var MINIAPP_FINISH_GRACE_MS = 5 * 6e4;
var futureToleranceMs = 3e4;
var maxInitDataBytes = 16384;
var positiveId = (value) => Number.isSafeInteger(value) && Number(value) > 0;
function verifyMiniAppInitData(raw, botToken, now = Date.now()) {
  try {
    timestamp(now);
    invalid(typeof botToken === "string" && /^\d+:[A-Za-z0-9_-]{20,256}$/.test(botToken));
    invalid(typeof raw === "string" && raw.length > 0 && raw.length <= maxInitDataBytes && Buffer.byteLength(raw, "utf8") <= maxInitDataBytes);
    const fields4 = /* @__PURE__ */ new Map();
    for (const part of raw.split("&")) {
      const equals = part.indexOf("=");
      invalid(equals > 0);
      const decode = (value2) => decodeURIComponent(value2.replace(/\+/g, " "));
      const key2 = decode(part.slice(0, equals)), value = decode(part.slice(equals + 1));
      invalid(/^[a-z_]{1,64}$/.test(key2) && !fields4.has(key2) && !/[\u0000-\u001f\u007f]/u.test(value));
      fields4.set(key2, value);
    }
    const hash2 = fields4.get("hash");
    invalid(typeof hash2 === "string" && /^[a-f0-9]{64}$/.test(hash2));
    fields4.delete("hash");
    const dataCheckString = [...fields4].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key2, value]) => `${key2}=${value}`).join("\n");
    const secret = (0, import_node_crypto6.createHmac)("sha256", "WebAppData").update(botToken).digest();
    const expected = (0, import_node_crypto6.createHmac)("sha256", secret).update(dataCheckString).digest();
    invalid((0, import_node_crypto6.timingSafeEqual)(expected, Buffer.from(hash2, "hex")));
    const authDate = fields4.get("auth_date");
    invalid(typeof authDate === "string" && /^[1-9]\d{0,12}$/.test(authDate));
    const authenticatedAt = Number(authDate) * 1e3;
    invalid(Number.isSafeInteger(authenticatedAt) && authenticatedAt <= now + futureToleranceMs && now - authenticatedAt <= MINIAPP_INIT_DATA_MAX_AGE_MS);
    const user = JSON.parse(fields4.get("user") ?? "null");
    record2(user);
    invalid(positiveId(user.id) && (user.is_bot === void 0 || user.is_bot === false));
    const chatType = fields4.get("chat_type");
    invalid(chatType === void 0 || chatType === "private" || chatType === "sender");
    const chatRaw = fields4.get("chat");
    if (chatRaw !== void 0) {
      const chat = JSON.parse(chatRaw);
      record2(chat);
      invalid(chat.type === "private" && chat.id === user.id);
    }
    return { userId: user.id, chatId: user.id, authDate: authenticatedAt };
  } catch {
    throw new Error("Mini App authorization rejected");
  }
}
function validateBinding(value) {
  record2(value);
  keys(value, ["enrollment", "userId", "epoch"]);
  invalid(typeof value.enrollment === "string" && /^[a-f0-9]{48}$/.test(value.enrollment) && positiveId(value.userId));
  token2(value.epoch);
}
var MiniAppSessions = class {
  rows = /* @__PURE__ */ new Map();
  users = /* @__PURE__ */ new Map();
  timeFloor = 0;
  advance(now) {
    timestamp(now);
    invalid(now >= this.timeFloor, "Mini App session clock rollback");
    this.timeFloor = now;
  }
  remove(token5) {
    const row = this.rows.get(token5);
    if (!row) return;
    this.rows.delete(token5);
    const user = this.users.get(row.userId);
    user?.delete(token5);
    if (!user?.size) this.users.delete(row.userId);
  }
  prune(now) {
    for (const [token5, row] of this.rows) if (row.expiresAt <= now) this.remove(token5);
  }
  active(token5, now) {
    if (typeof token5 !== "string" || !/^[a-f0-9]{64}$/.test(token5)) return;
    try {
      this.advance(now);
    } catch {
      return;
    }
    const row = this.rows.get(token5);
    if (row && row.expiresAt <= now) {
      this.remove(token5);
      return;
    }
    return row;
  }
  issue(binding2, now = Date.now(), previousToken) {
    validateBinding(binding2);
    this.advance(now);
    this.prune(now);
    const previous = previousToken === void 0 ? void 0 : this.rows.get(previousToken);
    invalid(previousToken === void 0 || previous?.userId === binding2.userId, "Mini App unauthorized");
    invalid(Number.isSafeInteger(now + MINIAPP_SESSION_TTL_MS));
    const user = this.users.get(binding2.userId), replace = (user?.size ?? 0) >= 3;
    invalid(this.rows.size < 1e4 || replace, "Mini App session capacity reached");
    let token5 = (0, import_node_crypto6.randomBytes)(32).toString("hex");
    while (this.rows.has(token5)) token5 = (0, import_node_crypto6.randomBytes)(32).toString("hex");
    if (replace) this.remove([...user].find((candidate) => candidate !== previousToken));
    const expiresAt = Math.min(now + MINIAPP_SESSION_TTL_MS, previous?.expiresAt ?? Infinity);
    this.rows.set(token5, { ...binding2, expiresAt, hardExpiresAt: expiresAt });
    const tokens = this.users.get(binding2.userId) ?? /* @__PURE__ */ new Set();
    tokens.add(token5);
    this.users.set(binding2.userId, tokens);
    return { token: token5, expiresAt };
  }
  get(token5, now = Date.now()) {
    const row = this.active(token5, now);
    return row ? { enrollment: row.enrollment, userId: row.userId, epoch: row.epoch } : void 0;
  }
  expiresAt(token5, now = Date.now()) {
    return this.active(token5, now)?.expiresAt;
  }
  /** The current lesson can reshape its lease, never revive or outlive the issued credential. */
  setExpiry(token5, expiresAt, now = Date.now()) {
    if (expiresAt !== void 0) timestamp(expiresAt);
    const row = this.active(token5, now);
    if (!row) return;
    row.expiresAt = Math.min(expiresAt ?? row.hardExpiresAt, row.hardExpiresAt);
    return row.expiresAt;
  }
  revoke(token5) {
    this.remove(token5);
  }
  revokeEnrollment(enrollment) {
    for (const [token5, row] of this.rows) if (row.enrollment === enrollment) this.remove(token5);
  }
};

// src/infrastructure/companion/server/offline-session.ts
var clone = (value) => JSON.parse(JSON.stringify(value));
function stable(value) {
  if (Array.isArray(value)) return "[" + value.map(stable).join(",") + "]";
  if (value !== null && typeof value === "object") return "{" + Object.entries(value).filter(([, item]) => item !== void 0).sort(([a], [b]) => a.localeCompare(b)).map(([key2, item]) => JSON.stringify(key2) + ":" + stable(item)).join(",") + "}";
  return JSON.stringify(value);
}
function authored(card) {
  return stable(Object.fromEntries(Object.entries(card).filter(([key2]) => !["offline", "revision", "dueAt", "eligible"].includes(key2))));
}
var newHead = (card) => ({ cardId: card.id, seed: card.offline, state: decodeOfflineSeed(card.offline).state, index: 0, baseCard: clone(card) });
function ensureOfflineHead(heads, snapshot, id2) {
  const existing = heads.find((row) => row.cardId === id2);
  if (existing) return existing;
  const card = snapshotCardMap(snapshot).get(id2);
  if (!card?.offline) return;
  const head = newHead(card);
  heads.push(head);
  return head;
}
function projectOfflineCard(head) {
  return { ...clone(head.baseCard), offline: head.seed, revision: head.lastAttemptId ?? decodeOfflineSeed(head.seed).rootRevision, dueAt: offlineStateDue(head.state) };
}
function reconcileOfflineHeads(previous, next, now, pending = [], sparse = false) {
  const previousById = new Map(previous.map((head) => [head.cardId, head])), pendingById = new Map(pending.map((row) => [row.id, row]));
  return next.cards.filter((card) => card.offline !== void 0 && (!sparse || previousById.has(card.id))).map((card) => {
    const current = decodeOfflineSeed(card.offline), old = previousById.get(card.id);
    if (old) {
      const original = decodeOfflineSeed(old.seed), live = original.expiresAt > now && original.issuedAt - now <= COMPANION_CLOCK_SKEW;
      if (authored(old.baseCard) === authored(card) && original.config === current.config) {
        if (old.seed !== card.offline && current.state !== old.state) {
          let parent = old.lastAttemptId, after = old.state, index2 = old.index;
          while (parent !== void 0) {
            const found = pendingById.get(parent), attempt = found?.cardId === old.cardId && found.offline ? found : void 0;
            if (!attempt?.offline) break;
            const step = decodeOfflineStep(attempt.offline);
            if (step.rootRevision !== original.rootRevision || step.index !== index2 || step.after !== after) break;
            invalid(step.before !== current.state, "Offline queue changed; synchronize pending attempts before replacing baseline");
            parent = step.parentId;
            after = step.before;
            index2--;
          }
        }
        const sameLifetime = original.expiresAt - original.issuedAt > LEGACY_COMPANION_STUDY_COPY_TTL === current.expiresAt - current.issuedAt > LEGACY_COMPANION_STUDY_COPY_TTL;
        if (live && (old.seed === card.offline || sameLifetime && current.state === old.state)) return clone(old);
      }
    }
    return newHead(card);
  });
}
function validateOfflineHeads(heads, snapshot, attempts2) {
  if (heads === void 0) return;
  invalid(Array.isArray(heads) && (snapshot !== void 0 || heads.length === 0));
  const ids = /* @__PURE__ */ new Set(), cards = snapshot && snapshotCardMap(snapshot), byAttempt = new Map(attempts2.map((row) => [row.id, row]));
  for (const value of heads) {
    record2(value);
    keys(value, ["cardId", "seed", "state", "index", "lastAttemptId", "baseCard"]);
    token2(value.cardId);
    invalid(!ids.has(value.cardId));
    ids.add(value.cardId);
    validateOfflineSeed(value.seed);
    const seed = decodeOfflineSeed(value.seed);
    offlineStateDue(value.state);
    invalid(Number.isSafeInteger(value.index) && Number(value.index) >= 0 && Number(value.index) <= 1e4 && (value.index === 0 ? value.lastAttemptId === void 0 : typeof value.lastAttemptId === "string"));
    if (value.lastAttemptId !== void 0) token2(value.lastAttemptId);
    record2(value.baseCard);
    const base = value.baseCard;
    invalid(base.id === value.cardId && base.offline === value.seed);
    validateSnapshot({
      version: 1,
      scope: snapshot.scope,
      epoch: snapshot.epoch,
      sequence: snapshot.sequence,
      generatedAt: seed.issuedAt,
      expiresAt: seed.expiresAt,
      cards: [base]
    });
    const current = cards.get(value.cardId);
    invalid(current?.offline !== void 0 && authored(base) === authored(current) && decodeOfflineSeed(current.offline).config === seed.config, "offline source differs");
    const chain = [];
    let cursor = value.lastAttemptId;
    for (let index2 = Number(value.index); index2 > 0; index2--) {
      const found = byAttempt.get(cursor), attempt = found?.scope === snapshot.scope && found.epoch === snapshot.epoch && found.cardId === value.cardId ? found : void 0;
      invalid(attempt?.offline !== void 0, "offline parent missing");
      const step = decodeOfflineStep(attempt.offline);
      invalid(step.rootRevision === seed.rootRevision && step.index === index2, "offline branch differs");
      chain.unshift(attempt);
      cursor = step.parentId;
    }
    invalid(cursor === void 0, "offline branch differs");
    let state = seed.state, parent;
    const ancestors = /* @__PURE__ */ new Set([state]);
    for (let index2 = 0; index2 < chain.length; index2++) {
      const attempt = chain[index2];
      validateAttempt(attempt);
      const step = decodeOfflineStep(attempt.offline);
      invalid(attempt.scope === snapshot.scope && attempt.epoch === snapshot.epoch && step.index === index2 + 1 && step.parentId === parent && step.before === state && attempt.revision === (parent ?? seed.rootRevision) && offlineReviewTimeAllowed(step, attempt.occurredAt), "offline chain differs");
      invalid(step.after === advanceOfflineFsrs(seed, state, attempt.correct ? attempt.rating : 1, attempt.occurredAt), "offline schedule differs");
      state = step.after;
      parent = attempt.id;
      ancestors.add(state);
    }
    invalid(state === value.state && parent === value.lastAttemptId && ancestors.has(decodeOfflineSeed(current.offline).state), "offline head differs");
  }
}
function validateSessionFrame(value, snapshot) {
  record2(value);
  const card = value, normal = { ...value };
  delete normal.offline;
  validateSnapshot({ ...snapshot, cards: [normal] });
  const base = snapshotCardMap(snapshot).get(card.id);
  invalid(base, "session card missing");
  if (card.offline === void 0) {
    invalid(stable(card) === stable(base), "session card differs");
    return;
  }
  const seed = decodeOfflineSeed(card.offline);
  invalid(base.offline === card.offline && base.revision === seed.rootRevision && card.mode === "core" && card.eligible && card.dueAt !== void 0 && authored(card) === authored(base), "offline session card differs");
}

// src/infrastructure/companion/server/written-recall.ts
var copy3 = (value) => JSON.parse(JSON.stringify(value));
function writtenRecallForAttempt(state, id2) {
  return state.writtenRecalls?.find((row) => row.attempt.id === id2) ?? state.writtenRecallReceipts?.find((row) => row.recall.attempt.id === id2)?.recall;
}
function validateCompanionWrittenRecallState(state, attempts2) {
  invalid((state.writtenRecalls === void 0 || Array.isArray(state.writtenRecalls)) && (state.writtenRecallReceipts === void 0 || Array.isArray(state.writtenRecallReceipts)));
  const ids = /* @__PURE__ */ new Set();
  const known = new Map(attempts2.map((attempt) => [attempt.id, attempt]));
  const verifyAttempt = (row) => {
    invalid(!ids.has(row.attempt.id));
    ids.add(row.attempt.id);
    const attempt = known.get(row.attempt.id);
    invalid(attempt && sameAttempt(attempt, row.attempt), "written recall attempt differs");
  };
  for (const row of state.writtenRecalls ?? []) {
    validateCompanionWrittenRecall(row);
    verifyAttempt(row);
  }
  for (const row of state.writtenRecallReceipts ?? []) {
    validateCompanionWrittenRecallReceipt(row);
    verifyAttempt(row.recall);
  }
}
function enqueueCompanionWrittenRecall(state, recall) {
  validateCompanionWrittenRecall(recall);
  const prior = writtenRecallForAttempt(state, recall.attempt.id);
  if (prior) {
    invalid(sameCompanionWrittenRecall(prior, recall), "written recall ID collision");
    return;
  }
  (state.writtenRecalls ??= []).push(copy3(recall));
}
function acknowledgeCompanionWrittenRecall(state, recall, receipt) {
  validateCompanionWrittenRecallReceipt(receipt, recall);
  const previous = state.writtenRecallReceipts?.find((row) => row.recall.attempt.id === recall.attempt.id);
  if (previous) {
    invalid(previous.status === receipt.status && sameCompanionWrittenRecall(previous.recall, recall), "written recall receipt collision");
    return;
  }
  const pending = state.writtenRecalls?.find((row) => row.attempt.id === recall.attempt.id);
  invalid(pending && sameCompanionWrittenRecall(pending, recall), "unknown written recall");
  state.writtenRecalls = state.writtenRecalls.filter((row) => row.attempt.id !== recall.attempt.id);
  (state.writtenRecallReceipts ??= []).push(copy3(receipt));
}

// src/infrastructure/companion/server/miniapp-study.ts
var copy4 = (value) => JSON.parse(JSON.stringify(value));
var opaque = () => (0, import_node_crypto7.randomBytes)(24).toString("base64url");
var ratings = [1, 2, 3, 4];
var MINIAPP_STUDY_IDLE_MS = 30 * 6e4;
var idleExpiresAt = (app) => (app.lastActivityAt ?? app.startedAt ?? app.session.snapshot.generatedAt) + MINIAPP_STUDY_IDLE_MS;
var attempts = (s) => [...s.domain.pending, ...s.domain.outcomes.map((row) => row.attempt)];
var authored2 = (card) => canonical2(Object.fromEntries(Object.entries(card).filter(([key2]) => !["revision", "dueAt", "offline", "eligible"].includes(key2))));
var cardSourceMatches = (s, card) => {
  const source = s.domain.snapshot && snapshotCardMap(s.domain.snapshot).get(card.id);
  if (source) return source.eligible && (source === card || authored2(source) === authored2(card)) && (card.offline !== void 0 || source.revision === card.revision);
  return !!s.miniApp?.session.results.some((row) => row.card?.id === card.id && row.card.revision === card.revision && authored2(row.card) === authored2(card));
};
var cardSourceAllowed = (s, card, now, permitted) => {
  return !s.domain.revoked && !!s.domain.snapshot && companionSnapshotIsCurrent(s.domain.snapshot, now) && cardSourceMatches(s, card) && (permitted ? permitted.has(card.materialId) : s.materialConsentIds?.includes(card.materialId) ?? false) && (s.attachmentConsent !== false || !card.hints?.length && !card.media?.length) && (!card.offline || s.offlineConsent === true && now < (snapshotCardMap(s.domain.snapshot).get(card.id)?.offline === card.offline ? snapshotOfflineSeed(s.domain.snapshot, card.id) : decodeOfflineSeed(card.offline)).expiresAt);
};
var cardIsDue = (card, now) => card.mode !== "core" || card.dueAt === void 0 || card.dueAt <= now;
function miniAppSessionAllowed(s, now) {
  const app = s.miniApp;
  return !!app && (!app.earlyRepeat || s.domain.snapshot?.earlyShortRepeats === true) && now < app.session.snapshot.expiresAt && app.session.snapshot.cards.every((card) => cardSourceAllowed(s, card, now));
}
function miniAppViewToken(s) {
  const app = s.miniApp, snapshot = s.domain.snapshot;
  const head = app?.session.current?.offline ? s.offlineHeads?.find((row) => row.cardId === app.session.current.id) : void 0;
  const source = app && ["active", "paused"].includes(app.session.status) ? {
    cards: app.session.snapshot.cards.map((card) => [card.id, cardSourceMatches(s, card)]),
    currentOffline: head ? [head.seed, head.state, head.lastAttemptId ?? null] : null
  } : {
    sequence: snapshot?.sequence,
    filters: s.studyContext ? studyContextToken(s.studyContext) : null,
    ...snapshot?.studyTarget ? { studyTarget: snapshot.studyTarget } : {}
  };
  return digest({
    snapshot: snapshot ? [snapshot.scope, snapshot.epoch, source] : null,
    app: app ? [app.session.id, app.revision] : null,
    revoked: s.domain.revoked,
    chat: s.studySession && s.studySession.status !== "finished" ? [
      s.studySession.id,
      s.studySession.status,
      s.studySession.current?.id ?? null,
      s.studySession.waitUntil ?? null,
      s.studySession.results.map((row) => row.attemptId)
    ] : null,
    consent: [s.materialConsentIds ?? null, s.attachmentConsent ?? null, s.offlineConsent ?? null, snapshot?.earlyShortRepeats ?? null],
    retention: [s.retainAnswers ?? null, s.retainAnswersChangedAt ?? 0]
  });
}
function validateStartSelection(request) {
  if (request.topicRecallCardId !== void 0) {
    token2(request.topicRecallCardId);
    invalid(request.mode === "bank" && request.retryWeak === void 0 && request.allMaterials === void 0 && (request.materialId !== void 0 || Array.isArray(request.materialIds) && request.materialIds.length === 1), "Choose one material for topic recall");
  }
  if (request.retryWeak !== void 0) {
    invalid(request.retryWeak === true && request.mode === "bank" && [request.materialId, request.materialIds, request.allMaterials].every((value) => value === void 0), "Weak retry must stay inside the previous Bank session");
    return;
  }
  invalid([request.materialId, request.materialIds, request.allMaterials].filter((value) => value !== void 0).length === 1, "Choose materials or explicitly choose all materials");
  if (request.materialId !== void 0) token2(request.materialId);
  if (request.materialIds !== void 0) {
    invalid(Array.isArray(request.materialIds) && request.materialIds.length > 0 && new Set(request.materialIds).size === request.materialIds.length);
    request.materialIds.forEach(token2);
  }
  if (request.allMaterials !== void 0) invalid(request.allMaterials === true);
}
function validateSessionOptions(value, maximumMinutes = 180) {
  for (const [limit, max] of [[value.cardLimit, 1e3], [value.timeLimitMinutes, maximumMinutes]]) invalid(limit === void 0 || Number.isSafeInteger(limit) && Number(limit) >= 1 && Number(limit) <= Number(max));
  invalid(value.shuffle === void 0 || typeof value.shuffle === "boolean");
  for (const label2 of [value.learningGroup, value.section, value.tag]) invalid(label2 === void 0 || typeof label2 === "string" && !!label2.trim() && label2.length <= 200 && !/[\u0000-\u001f\u007f-\u009f]/.test(label2));
  invalid(value.topic === void 0 || typeof value.topic === "string" && !!value.topic.trim() && value.topic.length <= 1024 && !/[\u0000-\u001f\u007f-\u009f]/.test(value.topic));
  invalid(value.questionKind === void 0 || ["free", "single", "multiple", "cloze", "matching", "ordering"].includes(String(value.questionKind)));
  invalid(value.knowledgeState === void 0 || COMPANION_KNOWLEDGE_STATES.includes(value.knowledgeState));
}
function arrangeCard(card) {
  const exercise = card.exercise;
  if (!exercise || exercise.kind !== "matching" && exercise.kind !== "ordering") return;
  const positions2 = Array.from({ length: exercise.kind === "matching" ? exercise.pairs.length : exercise.orderItems.length }, (_, index2) => index2);
  for (let index2 = positions2.length - 1; index2 > 0; index2--) {
    const target = (0, import_node_crypto7.randomInt)(index2 + 1);
    [positions2[index2], positions2[target]] = [positions2[target], positions2[index2]];
  }
  if (positions2.every((value, index2) => value === index2)) positions2.push(positions2.shift());
  return { kind: exercise.kind, positions: positions2 };
}
function validateMiniAppRequest(value) {
  record2(value);
  if (value.kind === "view" || value.kind === "today") {
    keys(value, ["kind", "answerHistoryVersion"]);
    invalid(value.answerHistoryVersion === void 0 || value.answerHistoryVersion === 1);
    return;
  }
  if (value.kind === "report-card") {
    keys(value, ["kind", "requestId", "viewToken", "reason", "note"]);
    token2(value.requestId);
    invalid(typeof value.viewToken === "string" && /^[a-f0-9]{64}$/.test(value.viewToken));
    normalizeCardClarification({ ...value.reason === void 0 ? {} : { reason: value.reason }, ...value.note === void 0 ? {} : { note: value.note } });
    return;
  }
  if (value.kind === "plan") {
    keys(value, ["kind", "id", "answerHistoryVersion"]);
    invalid(value.answerHistoryVersion === void 0 || value.answerHistoryVersion === 1);
    invalid(typeof value.id === "string" && value.id.length === 64 && /^[a-f0-9]{64}$/.test(value.id));
    return;
  }
  if (value.kind === "plan-action") {
    keys(value, ["kind", "requestId", "viewToken", "id", "revision", "action", "date", "time", "durationMinutes"]);
    invalid(typeof value.viewToken === "string" && /^[a-f0-9]{64}$/.test(value.viewToken));
    const { kind: _kind, requestId, viewToken: _viewToken, id: id2, ...fields5 } = value;
    validateCompanionPlanCommand({ ...fields5, id: requestId, entryId: id2, scope: "request", epoch: "request", requestedAt: 0 });
    return;
  }
  if (value.kind === "finish-chat") {
    keys(value, ["kind", "requestId", "viewToken", "chatSessionId"]);
    token2(value.requestId);
    token2(value.chatSessionId);
    invalid(typeof value.viewToken === "string" && /^[a-f0-9]{64}$/.test(value.viewToken));
    return;
  }
  invalid(["start", "hint", "check", "reveal", "self-recall", "grade", "next", "skip", "finish", "change-grade", "pause", "resume", "answer-retention"].includes(String(value.kind)));
  const fields4 = value.kind === "start" ? ["materialId", "materialIds", "allMaterials", "shuffle", "mode", "cardLimit", "timeLimitMinutes", "retryWeak", "learningGroup", "questionKind", "section", "topic", "tag", "knowledgeState", "topicRecallCardId", "planId"] : value.kind === "check" ? ["response"] : value.kind === "self-recall" ? ["text"] : value.kind === "grade" ? ["rating", "advance", "checkedCriteria", "text", "response"] : value.kind === "next" ? ["early"] : value.kind === "change-grade" ? ["rating", "attemptId"] : value.kind === "answer-retention" ? ["enabled"] : [];
  keys(value, ["kind", "requestId", "viewToken", ...fields4]);
  token2(value.requestId);
  invalid(typeof value.viewToken === "string" && /^[a-f0-9]{64}$/.test(value.viewToken));
  if (value.kind === "start") {
    validateStartSelection(value);
    validateSessionOptions(value, 90);
  }
  if (value.planId !== void 0) invalid(typeof value.planId === "string" && /^[a-f0-9]{64}$/.test(value.planId));
  if (value.shuffle !== void 0) invalid(typeof value.shuffle === "boolean");
  if (value.mode !== void 0) invalid(value.mode === "core" || value.mode === "bank");
  if (value.advance !== void 0) invalid(typeof value.advance === "boolean");
  if (value.early !== void 0) invalid(value.early === true);
  if (value.kind === "answer-retention") invalid(typeof value.enabled === "boolean");
  if (value.kind === "grade" || value.kind === "change-grade") invalid(ratings.includes(value.rating));
  if (value.kind === "change-grade") token2(value.attemptId);
  if ((value.kind === "self-recall" || value.kind === "grade") && value.text !== void 0) validateCompanionWrittenAnswer(value.text);
  if (value.kind === "grade" && value.checkedCriteria !== void 0) validateCompanionCheckedCriteria(value.checkedCriteria);
  if (value.kind === "check" || value.kind === "grade" && value.response !== void 0) {
    record2(value.response);
    keys(value.response, ["text", "selectedOptionIndexes", "clozeAnswers", "matches", "order"]);
    const r = value.response;
    if (r.text !== void 0) invalid(typeof r.text === "string" && r.text.length <= 2e3);
    if (r.selectedOptionIndexes !== void 0) invalid(Array.isArray(r.selectedOptionIndexes) && (value.kind === "grade" || r.selectedOptionIndexes.length > 0) && r.selectedOptionIndexes.length <= 12 && r.selectedOptionIndexes.every((index2, i, rows) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < 12 && (i === 0 || rows[i - 1] < index2)));
    if (r.clozeAnswers !== void 0) invalid(Array.isArray(r.clozeAnswers) && (value.kind === "grade" || r.clozeAnswers.length > 0) && r.clozeAnswers.length <= 12 && r.clozeAnswers.every((answer) => typeof answer === "string" && answer.length <= 2e3));
    for (const [key2, indexes] of [["matches", r.matches], ["order", r.order]]) if (indexes !== void 0) invalid(Array.isArray(indexes) && indexes.length >= 2 && indexes.length <= 12 && indexes.every((index2) => Number.isSafeInteger(index2) && index2 >= (value.kind === "grade" && key2 === "matches" ? -1 : 0) && index2 < indexes.length) && (value.kind === "grade" && key2 === "matches" || new Set(indexes).size === indexes.length));
  }
}
function validateMiniAppState(s) {
  if (s.miniAppReceipts !== void 0) {
    invalid(Array.isArray(s.miniAppReceipts) && new Set(s.miniAppReceipts.map((row) => row.id)).size === s.miniAppReceipts.length);
    for (const row of s.miniAppReceipts) {
      record2(row);
      keys(row, ["id", "hash"]);
      token2(row.id);
      invalid(typeof row.hash === "string" && /^[a-f0-9]{64}$/.test(row.hash));
    }
  }
  if (!s.miniApp) return;
  const app = s.miniApp;
  record2(app);
  keys(app, ["session", "revision", "revealed", "hintCount", "answerMatch", "feedback", "currentAttemptId", "selfRecall", "retainedAnswer", "answerDigest", "earlyRepeat", "arrangement", "startedAt", "lastActivityAt", "deadlineAt", "pausedAt", "pausedDurationMs", "finishedAt", "finishReason", "skipCount", "options"]);
  if (app.retainedAnswer !== void 0) invalid(s.retainAnswers === true && typeof app.retainedAnswer === "string" && app.retainedAnswer.length <= 3e4 && app.answerMatch === false && app.answerDigest === digest({ answer: app.retainedAnswer }));
  if (app.answerDigest !== void 0) invalid(typeof app.answerDigest === "string" && /^[a-f0-9]{64}$/.test(app.answerDigest) && app.revealed);
  if (app.startedAt !== void 0) timestamp(app.startedAt);
  if (app.lastActivityAt !== void 0) {
    timestamp(app.lastActivityAt);
    invalid(app.startedAt !== void 0 && app.lastActivityAt >= app.startedAt && (app.finishedAt === void 0 || app.lastActivityAt <= app.finishedAt));
  }
  if (app.pausedDurationMs !== void 0) invalid(Number.isSafeInteger(app.pausedDurationMs) && app.pausedDurationMs >= 0 && app.startedAt !== void 0);
  if (app.pausedAt !== void 0) {
    timestamp(app.pausedAt);
    invalid(app.startedAt !== void 0 && app.pausedAt >= app.startedAt && app.session.status === "paused");
  }
  invalid(app.session.status !== "paused" || app.pausedAt !== void 0);
  if (app.options !== void 0) {
    record2(app.options);
    keys(app.options, ["cardLimit", "timeLimitMinutes", "shuffle", "learningGroup", "questionKind", "section", "topic", "tag", "knowledgeState"]);
    validateSessionOptions(app.options);
    invalid(app.startedAt !== void 0);
  }
  if (app.deadlineAt !== void 0) {
    timestamp(app.deadlineAt);
    invalid(app.startedAt !== void 0 && app.options?.timeLimitMinutes !== void 0 && app.deadlineAt === app.startedAt + app.options.timeLimitMinutes * 6e4 + (app.pausedDurationMs ?? 0));
  }
  invalid(app.options?.timeLimitMinutes === void 0 || app.deadlineAt !== void 0);
  if (app.finishedAt !== void 0) {
    timestamp(app.finishedAt);
    invalid(app.startedAt !== void 0 && app.finishedAt >= app.startedAt && app.session.status === "finished");
  }
  invalid(app.finishReason === void 0 || app.finishedAt !== void 0 && ["completed", "time-limit", "manual", "inactive", "expired"].includes(app.finishReason));
  if (app.skipCount !== void 0) invalid(Number.isSafeInteger(app.skipCount) && app.skipCount >= (app.session.deferred?.length ?? 0));
  timestamp(app.revision);
  invalid(typeof app.revealed === "boolean" && Number.isSafeInteger(app.hintCount) && app.hintCount >= 0 && app.hintCount <= 10);
  invalid(app.answerMatch === void 0 || typeof app.answerMatch === "boolean");
  const session = app.session;
  record2(session);
  keys(session, ["id", "snapshot", "status", "results", "skipped", "deferred", "current", "frames", "waitUntil", "mode"]);
  token2(session.id);
  validateSnapshot(session.snapshot);
  invalid(session.snapshot.cards.length <= 1e3, "session card limit");
  invalid(session.snapshot.scope === s.domain.snapshot?.scope && session.snapshot.epoch === s.domain.snapshot?.epoch);
  invalid(session.mode === void 0 || (session.mode === "core" || session.mode === "bank") && session.snapshot.cards.every((card) => card.mode === session.mode));
  invalid(["active", "paused", "finished"].includes(session.status) && Array.isArray(session.results) && session.results.length <= 1e3 && Array.isArray(session.skipped));
  invalid(session.deferred === void 0 || Array.isArray(session.deferred));
  invalid(app.options?.cardLimit === void 0 || session.snapshot.cards.length <= app.options.cardLimit);
  invalid(new Set(session.results.map((row) => row.attemptId)).size === session.results.length && (/* @__PURE__ */ new Set([...session.skipped, ...session.deferred ?? []])).size === session.skipped.length + (session.deferred?.length ?? 0));
  const history = attempts(s);
  const ancestors = [...history, ...(s.supersededOfflineReviews ?? []).map((row) => row.attempt)];
  const validateFrame = (card) => {
    validateSessionFrame(card, session.snapshot);
    if (!card.offline) return;
    const seed = decodeOfflineSeed(card.offline), parent = ancestors.find((row) => row.id === card.revision && row.cardId === card.id && row.offline);
    const previous = parent?.offline && decodeOfflineStep(parent.offline);
    const state = card.revision === seed.rootRevision ? seed.state : previous && previous.rootRevision === seed.rootRevision ? previous.after : void 0;
    invalid(state && card.dueAt === offlineStateDue(state), "Mini App offline occurrence differs");
    return state;
  };
  invalid(new Set(session.results.filter((row) => !row.card?.offline).map((row) => row.cardId)).size === session.results.filter((row) => !row.card?.offline).length);
  for (const row of session.results) {
    record2(row);
    keys(row, ["cardId", "attemptId", "card"]);
    token2(row.cardId);
    token2(row.attemptId);
    invalid(row.card && row.card.id === row.cardId);
    const before = validateFrame(row.card);
    const attempt = history.find((attempt2) => attempt2.id === row.attemptId && attempt2.cardId === row.cardId && attempt2.revision === row.card.revision);
    invalid(attempt);
    if (row.card.offline) invalid(attempt.offline && decodeOfflineStep(attempt.offline).before === before);
  }
  const currentState = session.current && validateFrame(session.current);
  if (session.current) invalid(app.hintCount <= (session.current.hints?.length ?? 0));
  if (app.earlyRepeat !== void 0) invalid(app.earlyRepeat === true && session.current?.offline && currentState && stateIsShortStep(currentState) && session.current.revision !== decodeOfflineSeed(session.current.offline).rootRevision, "Early repeat needs an in-session short step");
  const exercise = session.current?.exercise;
  if (exercise?.kind === "matching" || exercise?.kind === "ordering") {
    record2(app.arrangement);
    keys(app.arrangement, ["kind", "positions"]);
    const count = exercise.kind === "matching" ? exercise.pairs.length : exercise.orderItems.length, positions2 = app.arrangement.positions;
    invalid(app.arrangement.kind === exercise.kind && Array.isArray(positions2) && positions2.length === count && Array.from(positions2).every((value) => Number.isSafeInteger(value) && value >= 0 && value < count) && new Set(positions2).size === count);
  } else invalid(app.arrangement === void 0);
  if (session.frames !== void 0) {
    invalid(Array.isArray(session.frames) && session.frames.length <= 1001);
    session.frames.forEach(validateFrame);
  }
  for (const id2 of [...session.skipped, ...session.deferred ?? []]) {
    token2(id2);
    invalid(session.snapshot.cards.some((card) => card.id === id2));
  }
  if (session.waitUntil !== void 0) timestamp(session.waitUntil);
  if (app.currentAttemptId !== void 0) {
    token2(app.currentAttemptId);
    invalid(app.revealed && session.current && session.results.some((row) => row.attemptId === app.currentAttemptId && row.cardId === session.current.id && row.card.revision === session.current.revision));
  }
  if (app.selfRecall !== void 0) {
    record2(app.selfRecall);
    keys(app.selfRecall, ["answer", "criteria"]);
    validateCompanionWrittenAnswer(app.selfRecall.answer);
    if (app.selfRecall.criteria !== void 0) validateCompanionSelfCheckCriteria(app.selfRecall.criteria);
    invalid(app.revealed && session.current && !session.current.exercise && session.current.evaluationMode === void 0 && app.answerMatch === void 0);
    if (app.currentAttemptId) {
      const saved = writtenRecallForAttempt(s, app.currentAttemptId);
      invalid(!app.selfRecall.answer.trim() || saved || answerHistoryForAttempt(s, app.currentAttemptId));
      if (saved) invalid(saved.answer === app.selfRecall.answer && canonical2(saved.criteria ?? []) === canonical2(app.selfRecall.criteria ?? []));
    }
  }
  invalid(app.revealed || app.answerMatch === void 0 && app.feedback === void 0 && app.currentAttemptId === void 0);
  if (app.feedback !== void 0) {
    invalid(session.current?.exercise && typeof app.answerMatch === "boolean");
    validateCompanionExerciseFeedback(app.feedback, session.current.exercise);
    invalid(feedbackMatchesAnswer(session.current.exercise, app.feedback) === app.answerMatch);
  }
}
function appendCompanionReview(s, card, id2, rating, correct, now, early = false) {
  const snapshot = s.domain.snapshot;
  invalid(snapshot && companionSnapshotIsCurrent(snapshot, now));
  invalid(!attempts(s).some((row) => row.id === id2));
  const attempt = { id: id2, scope: snapshot.scope, epoch: snapshot.epoch, sequence: snapshot.sequence, cardId: card.id, revision: card.revision, mode: card.mode, occurredAt: now, rating, correct };
  if (card.offline) {
    const head = ensureOfflineHead(s.offlineHeads ??= [], snapshot, card.id);
    invalid(head && s.offlineConsent === true && card.revision === (head.lastAttemptId ?? decodeOfflineSeed(head.seed).rootRevision) && now < decodeOfflineSeed(head.seed).expiresAt);
    const earlyStep = early && card.dueAt > now;
    const after = advanceOfflineFsrs(head.seed, head.state, correct ? rating : 1, now);
    const step = {
      version: 1,
      rootRevision: decodeOfflineSeed(head.seed).rootRevision,
      index: head.index + 1,
      ...head.lastAttemptId ? { parentId: head.lastAttemptId } : {},
      before: head.state,
      after,
      ...earlyStep ? { early: true } : {}
    };
    invalid(offlineReviewTimeAllowed(step, now), "Offline review is not due");
    attempt.offline = encodeOfflineStep(step);
    head.state = after;
    head.index++;
    head.lastAttemptId = attempt.id;
  }
  validateAttempt(attempt);
  s.domain.pending.push(attempt);
  return attempt;
}
function resultAttempt(s, id2) {
  const attempt = attempts(s).find((row) => row.id === id2);
  if (!attempt) return;
  const correction = [...s.gradeCorrections ?? []].reverse().find((row) => row.correction.attemptId === id2 && row.receipt?.status === "applied");
  return correction ? { ...attempt, rating: correction.correction.rating, correct: correction.correction.correct } : attempt;
}
function visibleResult(s, id2) {
  const attempt = resultAttempt(s, id2);
  invalid(attempt);
  const latest = [...s.gradeCorrections ?? []].reverse().find((row) => row.correction.attemptId === id2);
  if (latest && !latest.receipt) return { attempt: { ...attempt, rating: latest.correction.rating, correct: latest.correction.correct }, syncStatus: "correcting" };
  if (latest && latest.receipt?.status !== "applied") return { attempt, syncStatus: "correction-rejected" };
  return { attempt, syncStatus: s.domain.pending.some((row) => row.id === id2) ? s.claimedAttempts?.includes(id2) ? "syncing" : "pending" : s.domain.outcomes.find((row) => row.attempt.id === id2)?.status ?? "missing" };
}
function canChangeGrade(s, id2, now) {
  if (s.miniApp?.session.status === "paused") return false;
  const attempt = resultAttempt(s, id2);
  if (!attempt || s.gradeCorrections?.some((row) => row.correction.attemptId === id2 && !row.receipt)) return false;
  if (attempt.offline && s.offlineHeads?.find((head) => head.cardId === attempt.cardId)?.lastAttemptId !== id2) return false;
  return s.domain.pending.some((row) => row.id === id2) ? !s.claimedAttempts?.includes(id2) : !!s.editableGrades?.some((row) => row.attemptId === id2 && now < row.expiresAt);
}
function weakBankCards(s, effective, now) {
  const session = s.miniApp?.session;
  if (!session || session.status !== "finished" || !session.snapshot.cards.length || session.snapshot.cards.some((card) => card.mode !== "bank")) return [];
  const weak = new Set(session.results.filter((row) => visibleResult(s, row.attemptId).attempt.rating <= 2).map((row) => row.cardId));
  const cards = snapshotCardMap(effective);
  return session.snapshot.cards.flatMap((original) => {
    const current = cards.get(original.id);
    return weak.has(original.id) && current?.mode === "bank" && current.eligible && authored2(current) === authored2(original) && cardSourceAllowed(s, current, now) ? [current] : [];
  });
}
function sessionSummary(s, now) {
  const app = s.miniApp;
  if (app.startedAt === void 0) return;
  const session = app.session, grades = { again: 0, hard: 0, good: 0, easy: 0 }, correctness = { correct: 0, incorrect: 0, unchecked: 0 };
  for (const row of session.results) {
    const rating = visibleResult(s, row.attemptId).attempt.rating;
    grades[["again", "hard", "good", "easy"][rating - 1]]++;
    const checked = s.miniAppAttempts?.find((attempt) => attempt.id === row.attemptId)?.answerMatch;
    correctness[checked === true ? "correct" : checked === false ? "incorrect" : "unchecked"]++;
  }
  return {
    elapsedSeconds: Math.max(0, Math.floor(((app.finishedAt ?? app.pausedAt ?? now) - app.startedAt - (app.pausedDurationMs ?? 0)) / 1e3)),
    completed: new Set(session.results.map((row) => row.cardId)).size,
    total: session.snapshot.cards.length,
    answers: session.results.length,
    skipped: app.skipCount ?? session.deferred?.length ?? 0,
    unavailable: session.skipped.length,
    grades,
    correctness,
    ...app.finishReason ? { reason: app.finishReason } : {}
  };
}
function finishedSessionView(view, s, now) {
  const app = s.miniApp, session = app.session;
  view.status = "finished";
  view.summary = sessionSummary(s, now);
  view.session = {
    id: session.id,
    completed: new Set(session.results.map((row) => row.cardId)).size,
    total: session.snapshot.cards.length,
    answers: session.results.length,
    skipped: (session.deferred?.length ?? 0) + session.skipped.length,
    ...session.mode ? { mode: session.mode } : {}
  };
  return view;
}
function miniAppStudyTargetCards(s, effective, now) {
  const target = s.domain.snapshot?.studyTarget;
  if (!target || !effective || s.domain.revoked || !companionSnapshotIsCurrent(effective, now)) return [];
  const ids = new Set(target.cardIds), permitted = new Set(s.materialConsentIds);
  return effective.cards.filter((card) => ids.has(card.id) && card.mode === "core" && card.eligible && cardSourceAllowed(s, card, now, permitted));
}
function miniAppStudyTargetView(s, effective, suppressed, now) {
  const snapshot = s.domain.snapshot, target = snapshot?.studyTarget;
  if (!snapshot || !target || s.domain.revoked) return;
  const status = !effective || !companionSnapshotIsCurrent(snapshot, now) ? "stale" : !target.enabled ? "disabled" : now < target.examEndAt ? "active" : now < target.transitionEndAt ? "transition" : "completed";
  const cards = miniAppStudyTargetCards(s, effective, now), active = status === "active" || status === "transition";
  const blocked = new Set(suppressed.filter((row) => row.mode === "core").map((row) => row.cardId));
  const nextDueAt = cards.reduce((next, card) => card.dueAt !== void 0 && card.dueAt > now ? Math.min(next ?? card.dueAt, card.dueAt) : next, void 0);
  return {
    id: target.id,
    targetDate: target.targetDate,
    timeZone: target.timeZone,
    status,
    available: active ? cards.filter((card) => cardIsDue(card, now) && !blocked.has(card.id)).length : 0,
    total: cards.length,
    syncedAt: snapshot.generatedAt,
    expiresAt: snapshot.expiresAt,
    ...active && nextDueAt !== void 0 ? { nextDueAt } : {}
  };
}
function miniAppView(s, effective, suppressed, now) {
  const effectiveCards = effective && snapshotCardMap(effective);
  suppressed = suppressed.filter((attempt) => attempt.mode === "core" && effectiveCards?.get(attempt.cardId)?.mode === "core");
  const view = {
    status: "unavailable",
    serverNow: now,
    viewToken: miniAppViewToken(s),
    materials: [],
    history: [],
    answerHistorySupported: true,
    retainAnswers: s.retainAnswers === true,
    retainAnswersChangedAt: s.retainAnswersChangedAt ?? 0
  };
  const studyTarget = miniAppStudyTargetView(s, effective, suppressed, now);
  if (studyTarget) view.studyTarget = studyTarget;
  if (s.domain.revoked || !effective || !companionSnapshotIsCurrent(effective, now)) return s.miniApp?.session.status === "finished" ? finishedSessionView(view, s, now) : view;
  view.sync = { generatedAt: effective.generatedAt, pendingAnswers: s.domain.pending.length };
  view.topicRecallSupported = true;
  if (s.cardReportsEnabled) {
    view.cardReportsSupported = true;
    view.cardReports = companionCardReportViews(s, effective.cards);
  }
  const permittedMaterials = new Set(s.materialConsentIds);
  const available = effective.cards.filter((card2) => cardSourceAllowed(s, card2, now, permittedMaterials) && cardIsDue(card2, now));
  const page2 = queryCards({ ...effective, cards: available }, suppressed, { now, all: true });
  const materialCounts = /* @__PURE__ */ new Map();
  for (const card2 of page2.cards) {
    const key2 = `${card2.materialId}:${card2.mode}`, row = materialCounts.get(key2);
    if (row) row.count++;
    else materialCounts.set(key2, { id: card2.materialId, title: card2.materialTitle, count: 1, mode: card2.mode });
  }
  view.materials = page2.materials.flatMap((id2) => ["core", "bank"].flatMap((mode) => {
    const row = materialCounts.get(`${id2}:${mode}`);
    return row ? [row] : [];
  }));
  if (s.studyContext) view.defaults = copy4(s.studyContext.defaults);
  const includeTopicPrompts = !s.miniApp || s.miniApp.session.status === "finished" || !miniAppSessionAllowed(s, now);
  const sessionAttempts = includeTopicPrompts ? void 0 : new Set(s.miniApp.session.results.map((row) => row.attemptId));
  const historyRecords = new Map(answerHistoryRecords(s, sessionAttempts).map((row) => [row.attempt.id, row]));
  if (includeTopicPrompts) {
    const allowedMaterials = new Set(s.materialConsentIds), materialIds = new Map(effective.cards.map((card2) => [card2.id, card2.materialId]));
    const evidence = [...historyRecords.values()].filter((row) => allowedMaterials.has(materialIds.get(row.evidence.cardId) ?? "")).map((row) => row.evidence);
    view.answerMistakes = aggregateWrongAnswerEvidence(evidence).filter((row) => row.count > 1).slice(0, 10).map((row) => ({
      cardId: row.cardId,
      question: row.question.slice(0, 300),
      answer: row.answer.slice(0, 300),
      count: row.count,
      total: evidence.filter((item) => item.cardId === row.cardId && item.answerMatch !== null && answerHistoryReferenceId(item) === row.referenceId).length
    }));
  }
  const metadataById = s.studyContext && studyContextCardMap(s.studyContext), catalog = /* @__PURE__ */ new Map();
  for (const card2 of page2.cards) {
    const metadata3 = metadataById?.get(card2.id);
    const row = {
      id: card2.id,
      materialId: card2.materialId,
      mode: card2.mode,
      kind: metadata3?.kind ?? card2.exercise?.kind ?? "free",
      ...metadata3?.group ? { group: metadata3.group } : {},
      ...metadata3?.sections ? { sections: [...metadata3.sections] } : {},
      ...metadata3?.topics ? { topics: [...metadata3.topics] } : {},
      ...metadata3?.tags ? { tags: [...metadata3.tags] } : {},
      ...metadata3?.knowledgeState ? { knowledgeState: metadata3.knowledgeState } : {},
      ...includeTopicPrompts && card2.mode === "bank" && !card2.exercise && card2.evaluationMode === void 0 ? { recallPrompt: card2.question } : {}
    };
    const { id: _id, ...group } = row, key2 = page2.cards.length > 1e3 && row.recallPrompt === void 0 ? JSON.stringify(group) : card2.id;
    const previous = catalog.get(key2);
    if (previous) previous.count = (previous.count ?? 1) + 1;
    else catalog.set(key2, row);
  }
  view.catalog = [...catalog.values()];
  if (s.studySession && s.studySession.status !== "finished" && now < s.studySession.snapshot.expiresAt) {
    view.status = "chat-active";
    view.chatSessionId = s.studySession.id;
    return view;
  }
  const app = s.miniApp;
  if (!app) {
    view.status = "materials";
    return view;
  }
  if (!miniAppSessionAllowed(s, now)) return app.session.status === "finished" ? finishedSessionView(view, s, now) : view;
  const session = app.session;
  view.session = {
    id: session.id,
    completed: new Set(session.results.map((row) => row.cardId)).size,
    total: session.snapshot.cards.length,
    answers: session.results.length,
    skipped: (session.deferred?.length ?? 0) + session.skipped.length,
    ...session.waitUntil === void 0 ? {} : { waitUntil: session.waitUntil },
    ...session.mode === void 0 ? {} : { mode: session.mode },
    startedAt: app.startedAt ?? session.snapshot.generatedAt,
    ...app.deadlineAt === void 0 ? {} : { deadlineAt: app.deadlineAt },
    ...session.status === "finished" || session.status === "paused" ? {} : { idleExpiresAt: idleExpiresAt(app) },
    ...app.pausedAt === void 0 ? {} : { pausedAt: app.pausedAt },
    ...app.pausedDurationMs === void 0 ? {} : { pausedDurationMs: app.pausedDurationMs },
    ...app.options?.cardLimit === void 0 ? {} : { cardLimit: app.options.cardLimit },
    ...app.options?.timeLimitMinutes === void 0 ? {} : { timeLimitMinutes: app.options.timeLimitMinutes }
  };
  view.history = session.results.map((row) => {
    const { attempt: a2, syncStatus } = visibleResult(s, row.attemptId), recall = writtenRecallForAttempt(s, a2.id);
    return {
      attemptId: a2.id,
      cardId: row.cardId,
      question: row.card.question,
      rating: a2.rating,
      syncStatus,
      canChangeGrade: canChangeGrade(s, a2.id, now),
      allowedRatings: s.miniAppAttempts?.find((row2) => row2.id === a2.id)?.answerMatch === true ? [2, 3, 4] : [...ratings],
      ...recall ? { recall: { answer: recall.answer, reference: recall.reference, ...recall.criteria === void 0 ? {} : { criteria: [...recall.criteria] }, ...recall.checkedCriteria === void 0 ? {} : { checkedCriteria: [...recall.checkedCriteria] } } } : {},
      ...historyRecords.has(a2.id) ? { answerEvidence: copy4(historyRecords.get(a2.id).evidence) } : {}
    };
  });
  view.summary = sessionSummary(s, now);
  if (session.status === "finished") {
    view.status = "finished";
    if (session.snapshot.cards.every((card2) => card2.mode === "bank")) {
      const weak = weakBankCards(s, effective, now);
      view.weakRetry = { available: weak.length > 0, cardCount: weak.length, materialIds: [...new Set(weak.map((card2) => card2.materialId))] };
    }
    return view;
  }
  const card = session.current;
  if (!card) {
    view.status = app.pausedAt === void 0 ? "waiting" : "paused";
    if (view.status === "waiting") {
      const next = nextSessionCard(s, effective, suppressed, now);
      view.session.waitUntil = next.waitUntil ?? now;
      view.session.canContinueEarly = next.waitUntil !== void 0 && next.waitUntil > now && effective.earlyShortRepeats === true;
    }
    return view;
  }
  view.status = app.pausedAt !== void 0 ? "paused" : app.revealed ? "result" : "question";
  const exercise = card.exercise, a = app.currentAttemptId ? visibleResult(s, app.currentAttemptId).attempt : void 0;
  const positions2 = app.arrangement?.positions;
  const feedback2 = app.feedback?.kind === "matching" ? { kind: "matching", matches: app.feedback.matches.map((index2) => positions2.indexOf(index2)) } : app.feedback?.kind === "ordering" ? { kind: "ordering", order: app.feedback.order.map((index2) => positions2.indexOf(index2)) } : app.feedback;
  view.card = {
    id: card.id,
    revision: card.revision,
    materialTitle: card.materialTitle,
    question: exercise?.kind === "cloze" ? companionExerciseQuestion(exercise, card.question) : card.question,
    kind: exercise?.kind ?? (card.evaluationMode === "exact" ? "exact" : "self"),
    ...exercise?.kind === "single" || exercise?.kind === "multiple" ? { options: [...exercise.options] } : {},
    ...exercise?.kind === "cloze" ? { blankCount: companionExerciseBlankCount(exercise) } : {},
    ...exercise?.kind === "matching" ? { matching: { left: exercise.pairs.map((pair) => pair.left), right: positions2.map((index2) => exercise.pairs[index2].right) } } : {},
    ...exercise?.kind === "ordering" ? { orderItems: positions2.map((index2) => exercise.orderItems[index2]) } : {},
    questionMedia: copy4((card.media ?? []).filter((asset) => asset.side === "question")),
    hints: (card.hints ?? []).slice(0, app.hintCount),
    totalHints: card.hints?.length ?? 0,
    ...app.revealed ? { result: {
      reference: card.reference,
      ...app.answerMatch === void 0 ? {} : { matched: app.answerMatch },
      ...feedback2 ? { feedback: copy4(feedback2) } : {},
      ...app.selfRecall ? {
        ...s.retainAnswers === false ? {} : { recalledText: app.selfRecall.answer },
        ...app.selfRecall.criteria === void 0 ? {} : { selfCheckCriteria: [...app.selfRecall.criteria] },
        ...a && writtenRecallForAttempt(s, a.id)?.checkedCriteria !== void 0 ? { checkedCriteria: [...writtenRecallForAttempt(s, a.id).checkedCriteria] } : {}
      } : {},
      ...exercise?.kind === "cloze" ? { expectedBlanks: extractClozeAnswers(exercise.clozeTemplate) } : {},
      ...exercise?.kind === "single" || exercise?.kind === "multiple" ? { correctOptionIndexes: [...exercise.correctOptionIndexes] } : {},
      ...exercise?.kind === "matching" ? { correctMatches: exercise.pairs.map((_, index2) => positions2.indexOf(index2)) } : {},
      ...exercise?.kind === "ordering" ? { correctOrder: exercise.orderItems.map((_, index2) => positions2.indexOf(index2)) } : {},
      answerMedia: copy4((card.media ?? []).filter((asset) => asset.side === "answer"))
    } } : {},
    allowedRatings: app.revealed ? app.answerMatch === true ? [2, 3, 4] : [...ratings] : [],
    ...a ? { selectedRating: a.rating, attemptId: a.id } : {},
    canChangeGrade: !!a && canChangeGrade(s, a.id, now)
  };
  const source = app.revealed && s.studyContext?.sourceConsent && s.studyContext.cards.find((row) => row.id === card.id)?.source;
  if (source) view.card.source = copy4(source);
  if (a) {
    const next = nextSessionCard(s, effective, suppressed, now);
    view.nextStep = next.card ? next.card.materialId === card.materialId ? { kind: "card" } : { kind: "material", materialTitle: next.card.materialTitle } : { kind: next.waitUntil === void 0 ? "finished" : "waiting" };
  }
  return view;
}
function nextSessionCard(s, effective, suppressed, now, early = false) {
  const session = s.miniApp.session, available = [], skipped = [];
  let waitingCard;
  const byId = snapshotCardMap(effective), heads = new Map((s.offlineHeads ?? []).map((head) => [head.cardId, head]));
  if (s.miniApp.pausedAt === void 0 && s.miniApp.deadlineAt !== void 0 && now >= s.miniApp.deadlineAt) return { skipped };
  for (const original of session.snapshot.cards) {
    const answered = session.results.some((row) => row.cardId === original.id);
    if (!original.offline && answered || session.skipped.includes(original.id) || session.deferred?.includes(original.id)) continue;
    const candidate = byId.get(original.id), card = candidate?.eligible ? candidate : void 0, head = heads.get(original.id);
    if (!card || !cardSourceAllowed(s, card, now) || !original.offline && canonical2(original) !== canonical2(card) || original.offline && (!head || head.seed !== original.offline) || suppressed.some((row) => row.cardId === original.id)) {
      skipped.push(original.id);
      continue;
    }
    if (head && answered && !stateIsShortStep(head.state)) continue;
    if (card.offline && card.dueAt > now) {
      if (answered && head && head.index > 0 && stateIsShortStep(head.state) && (!waitingCard || card.dueAt < waitingCard.dueAt)) waitingCard = card;
      continue;
    }
    available.push(card);
  }
  available.sort((a, b) => Number(!!s.offlineHeads?.some((head) => head.cardId === b.id && head.index > 0 && stateIsShortStep(head.state))) - Number(!!s.offlineHeads?.some((head) => head.cardId === a.id && head.index > 0 && stateIsShortStep(head.state))));
  return session.results.length >= 1e3 ? { skipped } : available.length ? { card: available[0], skipped } : waitingCard ? early ? { card: waitingCard, early: true, skipped } : { waitUntil: waitingCard.dueAt, skipped } : { skipped };
}
function resumeClock(app, now) {
  if (app.pausedAt === void 0) return;
  const duration = Math.max(0, now - app.pausedAt);
  app.pausedDurationMs = (app.pausedDurationMs ?? 0) + duration;
  if (app.deadlineAt !== void 0) app.deadlineAt += duration;
  delete app.pausedAt;
}
function finishSession(app, now, reason) {
  app.startedAt ??= Math.min(now, app.session.snapshot.generatedAt);
  resumeClock(app, now);
  app.session.status = "finished";
  delete app.session.waitUntil;
  if (app.startedAt !== void 0 && app.finishedAt === void 0) {
    app.finishedAt = Math.max(now, app.startedAt);
    app.finishReason = reason;
  }
}
function finishMiniAppSession(s, now, reason = "manual") {
  const app = s.miniApp;
  if (!app || app.session.status === "finished") return false;
  finishSession(app, now, reason);
  app.revision++;
  return true;
}
function expireMiniAppSession(s, now) {
  const app = s.miniApp;
  if (!app || app.session.status === "finished") return false;
  const hardLimit = (app.startedAt ?? app.session.snapshot.generatedAt) + MINIAPP_SESSION_TTL_MS;
  const lessonLimit = app.pausedAt === void 0 && app.deadlineAt !== void 0 ? app.deadlineAt + MINIAPP_FINISH_GRACE_MS : hardLimit;
  const idleLimit = app.pausedAt === void 0 ? idleExpiresAt(app) : Infinity, expiry = Math.min(hardLimit, lessonLimit, idleLimit);
  const allowed = miniAppSessionAllowed(s, now);
  if (allowed && now < expiry) return false;
  let activityAt = Math.max(app.lastActivityAt ?? app.startedAt ?? 0, app.pausedAt ?? 0);
  const resultIds = new Set(app.session.results.map((row) => row.attemptId));
  for (const attempt of attempts(s)) if (resultIds.has(attempt.id)) activityAt = Math.max(activityAt, attempt.occurredAt);
  const endedAt = Math.max(Math.min(now, expiry), activityAt);
  return finishMiniAppSession(s, endedAt, !allowed ? "expired" : expiry === idleLimit ? "inactive" : "time-limit");
}
function finishMiniAppRequest(s, request, now) {
  const hash2 = digest(request), prior = s.miniAppReceipts?.find((row) => row.id === request.requestId);
  if (prior) {
    invalid(prior.hash === hash2, "Mini App request collision");
    return;
  }
  invalid(request.viewToken === miniAppViewToken(s), "stale Mini App view");
  invalid(s.miniApp, "Mini App session unavailable");
  finishMiniAppSession(s, now);
  (s.miniAppReceipts ??= []).push({ id: request.requestId, hash: hash2 });
}
function nextCard(s, effective, suppressed, now, early = false) {
  const app = s.miniApp, session = app.session, next = nextSessionCard(s, effective, suppressed, now, early);
  delete session.current;
  delete session.waitUntil;
  app.revealed = false;
  app.hintCount = 0;
  delete app.answerMatch;
  delete app.feedback;
  delete app.currentAttemptId;
  delete app.arrangement;
  delete app.selfRecall;
  delete app.retainedAnswer;
  delete app.answerDigest;
  delete app.earlyRepeat;
  session.skipped.push(...next.skipped);
  if (next.card) {
    session.current = copy4(next.card);
    if (next.early) app.earlyRepeat = true;
    const arrangement = arrangeCard(next.card);
    if (arrangement) app.arrangement = arrangement;
  } else if (next.waitUntil !== void 0) session.waitUntil = next.waitUntil;
  else finishSession(app, now, app.deadlineAt !== void 0 && now >= app.deadlineAt ? "time-limit" : "completed");
}
function checkedResponse(card, response, arrangement) {
  const exercise = card.exercise;
  if (!exercise) {
    invalid(typeof response.text === "string" && !!response.text.trim() && response.selectedOptionIndexes === void 0 && response.clozeAnswers === void 0 && response.matches === void 0 && response.order === void 0);
    return { response, answer: response.text };
  }
  invalid(response.text === void 0);
  if (exercise.kind === "cloze") {
    invalid(response.selectedOptionIndexes === void 0 && response.matches === void 0 && response.order === void 0 && response.clozeAnswers?.length === companionExerciseBlankCount(exercise) && response.clozeAnswers.every((text4) => !!text4.trim()));
    return { response, answer: response.clozeAnswers.map((answer, index2) => `${index2 + 1}. ${answer}`).join("\n") };
  }
  if (exercise.kind === "single" || exercise.kind === "multiple") {
    invalid(response.clozeAnswers === void 0 && response.matches === void 0 && response.order === void 0 && response.selectedOptionIndexes && (exercise.kind !== "single" || response.selectedOptionIndexes.length === 1));
    evaluateCompanionExercise(exercise, response);
    return { response, answer: response.selectedOptionIndexes.map((index2) => exercise.options[index2]).join("\n") };
  }
  invalid(response.clozeAnswers === void 0 && response.selectedOptionIndexes === void 0 && arrangement && arrangement.kind === exercise.kind);
  if (exercise.kind === "matching") {
    invalid(response.order === void 0 && response.matches?.length === exercise.pairs.length);
    const canonicalResponse2 = { matches: response.matches.map((index2) => arrangement.positions[index2]) };
    evaluateCompanionExercise(exercise, canonicalResponse2);
    return { response: canonicalResponse2, answer: exercise.pairs.map((pair, index2) => `${pair.left} \u2192 ${exercise.pairs[canonicalResponse2.matches[index2]].right}`).join("\n") };
  }
  invalid(response.matches === void 0 && response.order?.length === exercise.orderItems.length);
  const canonicalResponse = { order: response.order.map((index2) => arrangement.positions[index2]) };
  evaluateCompanionExercise(exercise, canonicalResponse);
  return { response: canonicalResponse, answer: canonicalResponse.order.map((index2, position) => `${position + 1}. ${exercise.orderItems[index2]}`).join("\n") };
}
function uncheckedResponseAnswer(card, response, arrangement) {
  const exercise = card.exercise;
  invalid(exercise && response.text === void 0);
  if (exercise.kind === "cloze") {
    invalid(response.selectedOptionIndexes === void 0 && response.matches === void 0 && response.order === void 0 && response.clozeAnswers && (response.clozeAnswers.length === 0 || response.clozeAnswers.length === companionExerciseBlankCount(exercise)));
    return response.clozeAnswers.some((answer) => !!answer.trim()) ? response.clozeAnswers.map((answer, index2) => `${index2 + 1}. ${answer || "\u2014"}`).join("\n") : void 0;
  }
  if (exercise.kind === "single" || exercise.kind === "multiple") {
    invalid(response.clozeAnswers === void 0 && response.matches === void 0 && response.order === void 0 && response.selectedOptionIndexes && response.selectedOptionIndexes.every((index2) => index2 < exercise.options.length) && (exercise.kind !== "single" || response.selectedOptionIndexes.length <= 1));
    return response.selectedOptionIndexes.length ? response.selectedOptionIndexes.map((index2) => exercise.options[index2]).join("\n") : void 0;
  }
  invalid(response.clozeAnswers === void 0 && response.selectedOptionIndexes === void 0 && arrangement && arrangement.kind === exercise.kind);
  if (exercise.kind === "matching") {
    invalid(response.order === void 0 && response.matches?.length === exercise.pairs.length && response.matches.every((index2) => index2 >= -1 && index2 < exercise.pairs.length));
    return response.matches.some((index2) => index2 >= 0) ? exercise.pairs.map((pair, index2) => `${pair.left} \u2192 ${response.matches[index2] < 0 ? "\u2014" : exercise.pairs[arrangement.positions[response.matches[index2]]].right}`).join("\n") : void 0;
  }
  invalid(response.matches === void 0 && response.order?.length === exercise.orderItems.length);
  return response.order.map((index2, position) => `${position + 1}. ${exercise.orderItems[arrangement.positions[index2]]}`).join("\n");
}
function applyMiniAppRequest(s, request, effective, suppressed, now) {
  const effectiveCards = snapshotCardMap(effective);
  suppressed = suppressed.filter((attempt) => attempt.mode === "core" && effectiveCards.get(attempt.cardId)?.mode === "core");
  const hash2 = digest(request), prior = s.miniAppReceipts?.find((row) => row.id === request.requestId);
  if (prior) {
    invalid(prior.hash === hash2, "Mini App request collision");
    return;
  }
  invalid(request.viewToken === miniAppViewToken(s), "stale Mini App view");
  invalid(!s.domain.revoked && companionSnapshotIsCurrent(effective, now));
  invalid(!s.studySession || s.studySession.status === "finished" || now >= s.studySession.snapshot.expiresAt, "Continue or finish the chat session first");
  if (request.kind === "answer-retention") {
    invalid(typeof request.enabled === "boolean");
    s.retainAnswers = request.enabled;
    s.retainAnswersChangedAt = Math.max(now, (s.retainAnswersChangedAt ?? 0) + 1);
    if (!request.enabled && s.miniApp) {
      delete s.miniApp.retainedAnswer;
      if (s.miniApp.selfRecall && !s.miniApp.currentAttemptId) s.miniApp.selfRecall.answer = "";
    }
  } else if (request.kind === "start") {
    validateStartSelection(request);
    validateSessionOptions(request, 90);
    invalid(request.shuffle === void 0 || typeof request.shuffle === "boolean");
    invalid(request.mode === void 0 || request.mode === "core" || request.mode === "bank");
    invalid(!s.miniApp || s.miniApp.session.status === "finished" || !miniAppSessionAllowed(s, now), "Mini App session already active");
    const base = request.retryWeak ? weakBankCards(s, effective, now) : queryCards(effective, suppressed, { now, all: true }).cards;
    const permittedMaterials = new Set(s.materialConsentIds);
    const available = base.filter((card) => cardSourceAllowed(s, card, now, permittedMaterials) && cardIsDue(card, now) && (request.mode === void 0 || card.mode === request.mode));
    const selectedIds = request.materialIds ?? (request.materialId === void 0 ? void 0 : [request.materialId]);
    const materialCards = /* @__PURE__ */ new Map();
    for (const card of available) {
      const rows = materialCards.get(card.materialId) ?? [];
      rows.push(card);
      materialCards.set(card.materialId, rows);
    }
    if (selectedIds) invalid(selectedIds.every((id2) => materialCards.has(id2)), "A selected material is unavailable");
    const cards = (selectedIds ? selectedIds.flatMap((id2) => materialCards.get(id2)) : available).filter((card) => {
      const metadata3 = s.studyContext && studyContextCardMap(s.studyContext).get(card.id);
      return (request.topicRecallCardId === void 0 || card.id === request.topicRecallCardId && card.mode === "bank" && !card.exercise && card.evaluationMode === void 0) && (request.learningGroup === void 0 || metadata3?.group === request.learningGroup) && (request.section === void 0 || metadata3?.sections?.includes(request.section)) && (request.questionKind === void 0 || (metadata3?.kind ?? card.exercise?.kind ?? "free") === request.questionKind) && (request.topic === void 0 || metadata3?.topics?.includes(request.topic)) && (request.tag === void 0 || metadata3?.tags?.some((tag) => tagKey(tag) === tagKey(request.tag))) && (request.knowledgeState === void 0 || metadata3?.knowledgeState === request.knowledgeState);
    });
    invalid(cards.length > 0, "No cards available");
    if (request.shuffle) for (let i = cards.length - 1; i > 0; i--) {
      const j = (0, import_node_crypto7.randomInt)(i + 1);
      [cards[i], cards[j]] = [cards[j], cards[i]];
    }
    const originals = cards.slice(0, request.cardLimit ?? 1e3).map((card) => card.offline ? ensureOfflineHead(s.offlineHeads ??= [], s.domain.snapshot, card.id).baseCard : card);
    const options = Object.fromEntries(["cardLimit", "timeLimitMinutes", "shuffle", "learningGroup", "questionKind", "section", "topic", "tag", "knowledgeState"].filter((key2) => request[key2] !== void 0).map((key2) => [key2, request[key2]]));
    const { studyTarget: _studyTarget, cards: _cards, ...sessionSnapshot } = effective;
    s.miniApp = {
      session: { id: opaque(), snapshot: { ...sessionSnapshot, expiresAt: Math.min(effective.expiresAt, ...originals.map((card) => card.offline ? decodeOfflineSeed(card.offline).expiresAt : effective.expiresAt)), cards: copy4(originals) }, status: "active", results: [], skipped: [], deferred: [], ...request.mode === void 0 ? {} : { mode: request.mode } },
      revision: 0,
      revealed: false,
      hintCount: 0,
      startedAt: now,
      lastActivityAt: now,
      skipCount: 0,
      options,
      ...request.timeLimitMinutes === void 0 ? {} : { deadlineAt: now + request.timeLimitMinutes * 6e4 }
    };
    nextCard(s, effective, suppressed, now);
  } else {
    invalid(miniAppSessionAllowed(s, now), "Mini App session expired or selection changed");
    const app = s.miniApp, session = app.session, card = session.current;
    if (request.kind === "finish") finishSession(app, now, "manual");
    else if (request.kind === "pause") {
      invalid(session.status === "active" && app.startedAt !== void 0 && (app.deadlineAt === void 0 || now < app.deadlineAt));
      app.pausedAt = now;
      session.status = "paused";
    } else if (request.kind === "resume") {
      invalid(session.status === "paused" && app.pausedAt !== void 0);
      resumeClock(app, now);
      session.status = "active";
    } else if (request.kind === "change-grade") {
      invalid(session.status !== "paused");
      replaceMiniAppGrade(s, request.attemptId, request.rating, effective, suppressed, now);
    } else {
      invalid(session.status === "active");
      if (request.kind === "next") {
        invalid(!card || app.currentAttemptId, "Grade or skip the current card first");
        if (request.early) invalid(!card && effective.earlyShortRepeats === true, "Early continue needs a compatible waiting session");
        nextCard(s, effective, suppressed, now, request.early === true);
      } else {
        invalid(card && cardSourceAllowed(s, card, now));
        if (request.kind === "hint") {
          invalid(!app.revealed && app.hintCount < (card.hints?.length ?? 0));
          app.hintCount++;
        } else if (request.kind === "skip") {
          invalid(!app.currentAttemptId);
          const skipped = app.skipCount ?? session.deferred?.length ?? 0;
          (session.deferred ??= []).push(card.id);
          app.skipCount = skipped + 1;
          nextCard(s, effective, suppressed, now);
        } else if (request.kind === "reveal" || request.kind === "self-recall") {
          invalid(!app.revealed);
          if (request.kind === "self-recall") invalid(!card.exercise && card.evaluationMode === void 0, "Written recall needs a self-check card");
          if (!card.exercise && card.evaluationMode === void 0) {
            const criteria = (s.studyContext && studyContextCardMap(s.studyContext).get(card.id))?.selfCheckCriteria;
            const answer = request.kind === "self-recall" ? request.text ?? "" : "";
            app.answerDigest = digest({ answer });
            app.selfRecall = { answer: s.retainAnswers === false ? "" : answer, ...criteria === void 0 ? {} : { criteria: [...criteria] } };
          }
          app.revealed = true;
        } else if (request.kind === "check") {
          invalid(!app.revealed && card.evaluationMode === "exact");
          const response = request.response, checked = checkedResponse(card, response, app.arrangement);
          if (card.exercise) {
            invalid(response.text === void 0);
            let canonicalResponse = response;
            if (card.exercise.kind === "cloze") invalid(response.selectedOptionIndexes === void 0 && response.matches === void 0 && response.order === void 0 && response.clozeAnswers?.length === companionExerciseBlankCount(card.exercise) && response.clozeAnswers.every((text4) => !!text4.trim()));
            else if (card.exercise.kind === "single" || card.exercise.kind === "multiple") invalid(response.clozeAnswers === void 0 && response.matches === void 0 && response.order === void 0 && response.selectedOptionIndexes && (card.exercise.kind !== "single" || response.selectedOptionIndexes.length === 1));
            else {
              invalid(response.clozeAnswers === void 0 && response.selectedOptionIndexes === void 0);
              const arrangement = app.arrangement;
              invalid(arrangement && arrangement.kind === card.exercise.kind);
              if (card.exercise.kind === "matching") {
                invalid(response.order === void 0 && response.matches?.length === card.exercise.pairs.length);
                canonicalResponse = { matches: response.matches.map((index2) => arrangement.positions[index2]) };
              } else {
                invalid(response.matches === void 0 && response.order?.length === card.exercise.orderItems.length);
                canonicalResponse = { order: response.order.map((index2) => arrangement.positions[index2]) };
              }
            }
            app.answerMatch = evaluateCompanionExercise(card.exercise, canonicalResponse);
            app.feedback = createCompanionExerciseFeedback(card.exercise, canonicalResponse);
          } else {
            invalid(typeof response.text === "string" && !!response.text.trim() && response.selectedOptionIndexes === void 0 && response.clozeAnswers === void 0 && response.matches === void 0 && response.order === void 0);
            app.answerMatch = card.acceptedAnswers === void 0 ? isExactTestAnswerCorrect(response.text, card.reference, card.answerMatchMode) : isExplicitTestAnswerCorrect(response.text, card.acceptedAnswers, card.answerMatchMode);
          }
          app.answerDigest = digest({ answer: checked.answer });
          if (s.retainAnswers === true && app.answerMatch === false) app.retainedAnswer = checked.answer;
          app.revealed = true;
        } else if (request.kind === "grade") {
          invalid(app.revealed && !app.currentAttemptId && !(app.answerMatch === true && request.rating === 1));
          invalid(effective.cards.some((row) => row.id === card.id && row.revision === card.revision) && !suppressed.some((row) => row.cardId === card.id));
          invalid(request.checkedCriteria === void 0 || app.selfRecall !== void 0, "Checklist needs a self-check card");
          if (request.checkedCriteria !== void 0) validateCompanionCheckedCriteria(request.checkedCriteria, app.selfRecall?.criteria?.length ?? 0);
          const selfRecall = app.selfRecall, hasWrittenEvidence = s.retainAnswers === void 0 && selfRecall && (!!selfRecall.answer.trim() || !!request.checkedCriteria?.length);
          const attempt = appendCompanionReview(s, card, opaque(), request.rating, request.rating !== 1, now, app.earlyRepeat === true);
          if (hasWrittenEvidence) enqueueCompanionWrittenRecall(s, {
            attempt: copy4(attempt),
            answer: selfRecall.answer,
            question: card.question,
            reference: card.reference,
            ...selfRecall.criteria === void 0 ? {} : { criteria: [...selfRecall.criteria] },
            ...request.checkedCriteria === void 0 ? {} : { checkedCriteria: [...request.checkedCriteria] }
          });
          if (s.retainAnswers === true) {
            let answer = app.retainedAnswer ?? selfRecall?.answer;
            if (request.text !== void 0) {
              invalid(!card.exercise);
              answer = request.text;
            }
            if (request.response !== void 0) {
              invalid(card.exercise);
              answer = app.answerMatch === void 0 ? uncheckedResponseAnswer(card, request.response, app.arrangement) : checkedResponse(card, request.response, app.arrangement).answer;
            }
            if (app.answerDigest !== void 0 && (selfRecall || app.answerMatch === false)) invalid(typeof answer === "string" && digest({ answer }) === app.answerDigest, "Original answer differs from the checked response");
            if (!selfRecall || !!answer?.trim() || !!request.checkedCriteria?.length) {
              const evidence = createAnswerHistoryEvidence({
                attemptId: attempt.id,
                cardId: card.id,
                mode: card.mode,
                occurredAt: now,
                kind: card.exercise?.kind ?? (card.evaluationMode === "exact" ? "exact" : "self"),
                question: card.question,
                reference: card.reference,
                answerMatch: app.answerMatch ?? null,
                ...answer === void 0 ? {} : { answer },
                ...card.answerMatchMode !== void 0 && !card.exercise ? { answerMatchMode: card.answerMatchMode } : {},
                ...card.exercise?.kind === "cloze" && card.exercise.answerMatchMode !== void 0 ? { answerMatchMode: card.exercise.answerMatchMode } : {},
                ...selfRecall?.criteria === void 0 ? {} : { criteria: [...selfRecall.criteria] },
                ...request.checkedCriteria === void 0 ? {} : { checkedCriteria: [...request.checkedCriteria] }
              });
              enqueueAnswerHistory(s, { attempt: copy4(attempt), evidence });
            }
          }
          app.currentAttemptId = attempt.id;
          session.results.push({ cardId: card.id, attemptId: attempt.id, card: copy4(card) });
          (s.miniAppAttempts ??= []).push({ id: attempt.id, ...app.answerMatch === void 0 ? {} : { answerMatch: app.answerMatch } });
          if (request.advance) {
            const head = card.offline && s.offlineHeads?.find((row) => row.cardId === card.id);
            const updated = head ? { ...effective, cards: effective.cards.map((row) => row.id === card.id ? projectOfflineCard(head) : row) } : effective;
            nextCard(s, updated, suppressed, now);
          }
        }
      }
    }
    if (request.kind !== "finish" && session.status !== "finished") {
      app.startedAt ??= Math.min(now, session.snapshot.generatedAt);
      app.lastActivityAt = now;
    }
    app.revision++;
  }
  (s.miniAppReceipts ??= []).push({ id: request.requestId, hash: hash2 });
}
function replaceMiniAppGrade(s, id2, rating, effective, suppressed, now) {
  const app = s.miniApp, result = app.session.results.find((row) => row.attemptId === id2);
  invalid(result && canChangeGrade(s, id2, now));
  invalid(!(s.miniAppAttempts?.find((row) => row.id === id2)?.answerMatch === true && rating === 1));
  const pending = s.domain.pending.find((row) => row.id === id2);
  if (!pending) {
    const attempt = resultAttempt(s, id2), editable = s.editableGrades.find((row) => row.attemptId === id2);
    invalid(!(editable.answerMatch === true && rating === 1));
    if (editable.rating === rating) return;
    const correction = {
      id: opaque(),
      scope: attempt.scope,
      epoch: attempt.epoch,
      attemptId: id2,
      cardId: attempt.cardId,
      revision: attempt.revision,
      expectedReviewEventId: editable.reviewEventId,
      rating,
      correct: rating !== 1,
      requestedAt: now
    };
    (s.gradeCorrections ??= []).push({ correction });
    return;
  }
  if (pending.rating === rating) return;
  const replacement = { ...pending, id: opaque(), rating, correct: rating !== 1 };
  const head = pending.offline && s.offlineHeads?.find((head2) => head2.cardId === pending.cardId);
  if (head) {
    (s.supersededOfflineReviews ??= []).push({ attempt: copy4(pending), seed: head.seed });
    const step = decodeOfflineStep(pending.offline);
    step.after = advanceOfflineFsrs(head.seed, step.before, replacement.correct ? replacement.rating : 1, replacement.occurredAt);
    replacement.offline = encodeOfflineStep(step);
    head.state = step.after;
    head.lastAttemptId = replacement.id;
  }
  validateAttempt(replacement);
  s.domain.pending = s.domain.pending.map((row) => row.id === id2 ? replacement : row);
  const written = s.writtenRecalls?.find((row) => row.attempt.id === id2);
  if (written) written.attempt = copy4(replacement);
  replacePendingAnswerHistoryAttempt(s, id2, replacement);
  const origin = s.miniAppAttempts?.find((row) => row.id === id2);
  if (origin) origin.id = replacement.id;
  result.attemptId = replacement.id;
  if (app.currentAttemptId === id2) app.currentAttemptId = replacement.id;
  if (head && (app.session.current?.revision === id2 || app.session.waitUntil !== void 0)) {
    nextCard(s, { ...effective, cards: effective.cards.map((card) => card.id === head.cardId ? projectOfflineCard(head) : card) }, suppressed, now);
  }
}
function miniAppMediaAsset(s, id2, now) {
  invalid(miniAppSessionAllowed(s, now) && s.attachmentConsent === true, "Mini App media unavailable");
  const app = s.miniApp, card = app.session.current;
  invalid((app.pausedAt !== void 0 || now < idleExpiresAt(app)) && now < (app.startedAt ?? app.session.snapshot.generatedAt) + MINIAPP_SESSION_TTL_MS && ["active", "paused"].includes(app.session.status) && card && cardSourceAllowed(s, card, now));
  const asset = card.media?.find((row) => row.id === id2 && (row.side === "question" || app.revealed));
  invalid(asset, "Mini App media unavailable");
  return copy4(asset);
}

// src/infrastructure/companion/server/native-poll-state.ts
function storedPollCard(s, row) {
  const panel = row.pollPanel, session = s.studySession;
  if (!panel || session?.id !== panel.sessionId) return;
  const cards = [...session.current ? [session.current] : [], ...session.frames ?? [], ...session.results.flatMap((result) => result.card ? [result.card] : []), ...session.snapshot.cards];
  const card = cards.find((card2) => card2.id === panel.cardId && card2.revision === panel.revision);
  return card ? { card, snapshot: session.snapshot } : void 0;
}
function validateStoredPoll(s, row) {
  const panel = row.pollPanel;
  record2(panel);
  keys(panel, ["cardId", "revision", "sessionId", "expiresAt", "pollId", "sealed", "selection"]);
  token2(panel.cardId);
  token2(panel.revision);
  token2(panel.sessionId);
  timestamp(panel.expiresAt);
  timestamp(row.snapshotSequence);
  invalid(panel.expiresAt > 0 && row.method === "sendPoll" && row.sessionContent?.sessionId === panel.sessionId && row.sessionContent.cardId === panel.cardId && row.sessionContent.revision === panel.revision && !row.answerHandle && !row.mediaPlaceholder && !row.ratingPanel && !row.questionPanel && !row.hintPanel && !row.hintLease && !row.sessionPanel);
  invalid(panel.sealed === void 0 || panel.sealed === true);
  invalid(row.status === "sent" ? validNativePollId(panel.pollId) && Number.isSafeInteger(row.messageId) && Number(row.messageId) > 0 : panel.pollId === void 0);
  validateNativePollPayload(row.payload);
  invalid(row.payload.close_date === void 0 || row.payload.close_date === Math.floor(panel.expiresAt / 1e3));
  const source = storedPollCard(s, row);
  invalid(row.status !== "queued" || source !== void 0, "poll source missing");
  if (source) {
    invalid(panel.expiresAt <= source.snapshot.expiresAt, "poll lease differs");
    const view = nativePollView(source.card);
    invalid(view, "poll source unsupported");
    const { chat_id: _chat, disable_notification: _silent, close_date: _close, reply_markup: _markup, ...storedView } = row.payload;
    invalid(canonical2(storedView) === canonical2(view), "poll source differs");
  }
  if (panel.selection !== void 0) {
    invalid(panel.sealed === true && Array.isArray(panel.selection) && panel.selection.length <= 12 && new Set(panel.selection).size === panel.selection.length && panel.selection.every((index2) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < 12));
    if (source) {
      const exercise = source.card.exercise;
      invalid(exercise && (exercise.kind === "single" || exercise.kind === "multiple"));
      invalid(panel.selection.every((index2) => index2 < exercise.options.length) && (exercise.kind !== "single" || panel.selection.length <= 1));
    }
  }
  const kinds3 = { "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442": "reveal", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430": "hint", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438": "hint-panel", "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441": "skip-card" };
  for (const buttons of row.payload.reply_markup?.inline_keyboard ?? []) {
    const button = buttons[0], handle2 = s.handles.find((handle3) => handle3.id === button.callback_data);
    if (!handle2) continue;
    const action = handle2.action;
    invalid(action.kind === kinds3[button.text] && handle2.expiresAt <= panel.expiresAt);
    if (action.kind === "hint-panel") {
      const target = s.outbox.find((target2) => target2.id === action.panelId), hint = target?.hintPanel;
      invalid(hint?.cardId === panel.cardId && hint.revision === panel.revision && hint.sessionId === panel.sessionId && target?.sessionContent?.sessionId === panel.sessionId && Number.isSafeInteger(action.index) && Number(action.index) >= 0 && Number(action.index) < hint.count && typeof action.collapsed === "boolean");
    } else {
      invalid(action.cardId === panel.cardId && action.revision === panel.revision && handle2.sequence === row.snapshotSequence && action.sequence === row.snapshotSequence);
      if (source) {
        invalid(handle2.epoch === source.snapshot.epoch && action.scope === source.snapshot.scope && action.epoch === source.snapshot.epoch);
        if (action.kind === "hint") invalid(Number.isSafeInteger(action.index) && Number(action.index) >= 0 && Number(action.index) < (source.card.hints?.length ?? 0));
      }
    }
  }
}

// src/infrastructure/companion/server/result-lifecycle.ts
var TARGET = 1e3;
var COMPACT_AT = 2e3;
function resultCounts(state) {
  if (state.resultLedger) {
    const { total, applied: applied2, rejected } = state.resultLedger;
    return { total, applied: applied2, rejected };
  }
  const applied = state.domain.outcomes.filter((row) => row.status === "applied").length;
  return { total: state.domain.outcomes.length, applied, rejected: state.domain.outcomes.length - applied };
}
function ledger(state) {
  return state.resultLedger ??= {
    ...resultCounts(state),
    archiveUsed: false,
    archiveRevision: 0,
    entries: state.domain.outcomes.map((row, index2) => ({ id: row.attempt.id, ordinal: index2 + 1 }))
  };
}
function addResultOrdinal(state, id2, status) {
  const value = state.resultLedger;
  if (!value) return;
  invalid(!value.entries.some((row) => row.id === id2));
  value.total++;
  if (status === "applied") value.applied++;
  else value.rejected++;
  value.entries.push({ id: id2, ordinal: value.total });
}
function hydrateResult(state, archive, scope, epoch, id2, now) {
  if (state.domain.outcomes.some((row2) => row2.attempt.id === id2) || !state.resultLedger?.archiveUsed) return;
  invalid(archive, "Result archive unavailable");
  const row = archive.get(scope, epoch, id2);
  if (!row) return;
  state.domain.outcomes.push(row.outcome);
  state.receipts.push({ id: id2, hash: row.receiptHash });
  state.resultLedger.entries.push({ id: id2, ordinal: row.ordinal });
  if (row.miniAppAttempt && !state.miniAppAttempts?.some((value) => value.id === id2)) (state.miniAppAttempts ??= []).push(row.miniAppAttempt);
  const editable = row.editableGrade;
  if (editable && editable.expiresAt > now && (state.materialConsentIds?.includes(editable.materialId) ?? true) && (state.attachmentConsent !== false || !editable.withAttachments) && !state.editableGrades?.some((value) => value.attemptId === id2)) (state.editableGrades ??= []).push(editable);
  for (const correction of row.corrections ?? []) if (!state.gradeCorrections?.some((value) => value.correction.id === correction.correction.id)) (state.gradeCorrections ??= []).push(correction);
}
function pinnedResults(state) {
  const pinned = /* @__PURE__ */ new Set(), attempts2 = new Map([...state.domain.pending, ...state.domain.outcomes.map((row) => row.attempt)].map((row) => [row.id, row]));
  for (const head of state.offlineHeads ?? []) if (head.lastAttemptId) pinned.add(head.lastAttemptId);
  for (const attempt of state.domain.pending) if (attempt.offline) {
    const parent = decodeOfflineStep(attempt.offline).parentId;
    if (parent) pinned.add(parent);
  }
  for (const session of [state.studySession, state.miniApp?.session]) if (session) {
    for (const result of session.results) pinned.add(result.attemptId);
    for (const card of [...session.current ? [session.current] : [], ...session.frames ?? [], ...session.results.flatMap((row) => row.card ? [row.card] : [])])
      if (card.offline && attempts2.has(card.revision)) pinned.add(card.revision);
  }
  if (state.miniApp?.currentAttemptId) pinned.add(state.miniApp.currentAttemptId);
  for (const row of state.gradeCorrections ?? []) if (!row.receipt) pinned.add(row.correction.attemptId);
  for (const row of state.writtenRecalls ?? []) pinned.add(row.attempt.id);
  const acknowledgedText = new Set(state.answerHistoryReceipts?.map((row) => row.attemptId));
  for (const row of state.answerHistory ?? []) if (!acknowledgedText.has(row.attempt.id)) pinned.add(row.attempt.id);
  for (const row of state.supersededOfflineReviews ?? []) if (row.attempt.offline) {
    const parent = decodeOfflineStep(row.attempt.offline).parentId;
    if (parent) pinned.add(parent);
  }
  const queue = [...pinned];
  for (let index2 = 0; index2 < queue.length; index2++) {
    const attempt = attempts2.get(queue[index2]);
    if (!attempt?.offline) continue;
    const parent = decodeOfflineStep(attempt.offline).parentId;
    if (parent && !pinned.has(parent)) {
      pinned.add(parent);
      queue.push(parent);
    }
  }
  return pinned;
}
function compactResults(state, committed, archive) {
  if (!archive || !committed || state.domain.outcomes.length <= COMPACT_AT) return;
  const value = ledger(state), pinned = pinnedResults(state), previous = new Map(committed.domain.outcomes.map((row) => [row.attempt.id, row]));
  const hashes = new Map(state.receipts.map((row) => [row.id, row.hash])), oldHashes = new Map(committed.receipts.map((row) => [row.id, row.hash]));
  const ordinals = new Map(value.entries.map((row) => [row.id, row.ordinal]));
  const metadata3 = (source) => {
    const mini2 = new Map(source.miniAppAttempts?.map((row) => [row.id, row])), editable2 = new Map(source.editableGrades?.map((row) => [row.attemptId, row]));
    const corrections = /* @__PURE__ */ new Map();
    for (const row of source.gradeCorrections ?? []) {
      const group = corrections.get(row.correction.attemptId) ?? [];
      group.push(row);
      corrections.set(row.correction.attemptId, group);
    }
    return new Map(source.domain.outcomes.map((row) => [row.attempt.id, canonical2([mini2.get(row.attempt.id) ?? null, editable2.get(row.attempt.id) ?? null, corrections.get(row.attempt.id) ?? []])]));
  };
  const currentMetadata = metadata3(state), oldMetadata = metadata3(committed);
  const candidates = state.domain.outcomes.filter((row) => {
    const old = previous.get(row.attempt.id);
    return !pinned.has(row.attempt.id) && old && old.status === row.status && sameAttempt(old.attempt, row.attempt) && hashes.get(row.attempt.id) === oldHashes.get(row.attempt.id) && currentMetadata.get(row.attempt.id) === oldMetadata.get(row.attempt.id);
  }).sort((a, b) => ordinals.get(a.attempt.id) - ordinals.get(b.attempt.id));
  const retiring = candidates.slice(0, Math.max(0, state.domain.outcomes.length - Math.max(TARGET, pinned.size)));
  if (!retiring.length) return;
  const mini = new Map(state.miniAppAttempts?.map((row) => [row.id, row])), editable = new Map(state.editableGrades?.map((row) => [row.attemptId, row]));
  const rows = retiring.map((outcome) => {
    const id2 = outcome.attempt.id, receiptHash = hashes.get(id2), ordinal2 = ordinals.get(id2);
    invalid(receiptHash && ordinal2, "Missing committed result identity");
    const corrections = state.gradeCorrections?.filter((row) => row.correction.attemptId === id2);
    invalid(!corrections?.some((row) => !row.receipt));
    return {
      version: 1,
      outcome,
      receiptHash,
      ordinal: ordinal2,
      ...mini.has(id2) ? { miniAppAttempt: mini.get(id2) } : {},
      ...editable.has(id2) ? { editableGrade: editable.get(id2) } : {},
      ...corrections?.length ? { corrections } : {}
    };
  });
  archive.putMany(rows, () => {
  });
  const removed = new Set(retiring.map((row) => row.attempt.id));
  state.domain.outcomes = state.domain.outcomes.filter((row) => !removed.has(row.attempt.id));
  state.receipts = state.receipts.filter((row) => !removed.has(row.id));
  state.miniAppAttempts = state.miniAppAttempts?.filter((row) => !removed.has(row.id));
  state.editableGrades = state.editableGrades?.filter((row) => !removed.has(row.attemptId));
  state.gradeCorrections = state.gradeCorrections?.filter((row) => !removed.has(row.correction.attemptId));
  value.entries = value.entries.filter((row) => !removed.has(row.id));
  value.archiveUsed = true;
  value.archiveRevision++;
}
function validateResultLedger(state) {
  const value = state.resultLedger;
  if (!value) return;
  record2(value);
  invalid(Object.keys(value).every((key2) => ["total", "applied", "rejected", "archiveUsed", "archiveRevision", "entries"].includes(key2)));
  for (const count of [value.total, value.applied, value.rejected, value.archiveRevision]) invalid(Number.isSafeInteger(count) && count >= 0);
  invalid(value.total === value.applied + value.rejected && value.total >= state.domain.outcomes.length && typeof value.archiveUsed === "boolean" && Array.isArray(value.entries) && value.entries.length === state.domain.outcomes.length);
  const ids = /* @__PURE__ */ new Set(), ordinals = /* @__PURE__ */ new Set(), outcomes = new Map(state.domain.outcomes.map((row) => [row.attempt.id, row]));
  for (const row of value.entries) {
    record2(row);
    invalid(Object.keys(row).every((key2) => ["id", "ordinal"].includes(key2)) && outcomes.has(row.id) && !ids.has(row.id) && Number.isSafeInteger(row.ordinal) && row.ordinal > 0 && row.ordinal <= value.total && !ordinals.has(row.ordinal));
    ids.add(row.id);
    ordinals.add(row.ordinal);
  }
  if (!value.archiveUsed) invalid(value.total === state.domain.outcomes.length);
  invalid(value.applied >= state.domain.outcomes.filter((row) => row.status === "applied").length && value.rejected >= state.domain.outcomes.filter((row) => row.status !== "applied").length);
}
function resultHistory(state, archive, scope, epoch, offset) {
  const total = resultCounts(state).total, end = Math.max(0, total - offset), start = Math.max(1, end - 19), byOrdinal = /* @__PURE__ */ new Map();
  const outcomes = new Map(state.domain.outcomes.map((row) => [row.attempt.id, row]));
  for (const row of state.resultLedger?.entries ?? state.domain.outcomes.map((row2, index2) => ({ id: row2.attempt.id, ordinal: index2 + 1 }))) {
    const outcome = outcomes.get(row.id);
    if (outcome) byOrdinal.set(row.ordinal, outcome);
  }
  const missing3 = Array.from({ length: Math.max(0, end - start + 1) }, (_, index2) => start + index2).filter((ordinal2) => !byOrdinal.has(ordinal2));
  if (missing3.length) {
    invalid(archive, "Result archive unavailable");
    for (const row of archive.page(scope, epoch, missing3)) byOrdinal.set(row.ordinal, row.outcome);
  }
  return Array.from({ length: Math.max(0, end - start + 1) }, (_, index2) => {
    const row = byOrdinal.get(start + index2);
    invalid(row, "Result history incomplete");
    return row;
  });
}

// src/infrastructure/companion/server/replay-lifecycle.ts
var HOT_ROWS = 1024;
function retiredRows(rows, committed) {
  if (rows.length <= HOT_ROWS * 2) return [];
  const known = new Map(committed.map((row) => [row.id, row.hash]));
  return rows.filter((row) => known.get(row.id) === row.hash).slice(0, rows.length - HOT_ROWS);
}
function compactServerReplay(state, committed, archive) {
  if (!archive || !committed) return;
  const updates = retiredRows(state.updates, committed.updates);
  const callbacks = retiredRows(state.callbackIds, committed.callbackIds);
  const miniApp = retiredRows(state.miniAppReceipts ?? [], committed.miniAppReceipts ?? []);
  if (!updates.length && !callbacks.length && !miniApp.length) return;
  archive.putMany(state.binding, [
    ...updates.map((row) => ({ kind: "update", id: String(row.id), hash: row.hash })),
    ...callbacks.map((row) => ({ kind: "callback", id: row.id, hash: row.hash })),
    ...miniApp.map((row) => ({ kind: "miniapp", id: row.id, hash: row.hash }))
  ]);
  const updateIds = new Set(updates.map((row) => row.id)), callbackIds = new Set(callbacks.map((row) => row.id));
  state.updates = state.updates.filter((row) => !updateIds.has(row.id));
  state.callbackIds = state.callbackIds.filter((row) => !callbackIds.has(row.id));
  if (miniApp.length) {
    const requestIds = new Set(miniApp.map((row) => row.id));
    state.miniAppReceipts = state.miniAppReceipts.filter((row) => !requestIds.has(row.id));
  }
  state.replayArchived = true;
}

// src/infrastructure/companion/server/reminders.ts
function zoneParts(now, timeZone) {
  const f = new Intl.DateTimeFormat("en-CA", { timeZone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
  const parts = f.formatToParts(now), get = (name) => Number(parts.find((p) => p.type === name).value);
  return { year: get("year"), month: get("month"), day: get("day"), hour: get("hour"), minute: get("minute") };
}
function validateTimeZone(zone) {
  invalid(typeof zone === "string" && zone.length <= 100);
  zoneParts(0, zone);
}
function studyDay(now, zone) {
  const p = zoneParts(now, zone);
  return new Date(Date.UTC(p.year, p.month - 1, p.day, p.hour - 4)).toISOString().slice(0, 10);
}
function sessionOrder(now, zone) {
  const p = zoneParts(now, zone);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute);
}
function sessionKey(now, zone) {
  const p = zoneParts(now, zone);
  return `${p.year}-${p.month}-${p.day}-${p.hour}-${p.minute}`;
}
function latestSession(now, zone, minutes) {
  const start = Math.floor(now / 6e4) * 6e4;
  for (let i = 0; i <= 14; i++) {
    const t = start - i * 6e4, p = zoneParts(t, zone);
    if (minutes.includes(p.hour * 60 + p.minute)) return t;
  }
  return 0;
}
function nextSession(now, zone, minutes, previousSession = 0) {
  const start = Math.floor(now / 6e4) * 6e4;
  const currentKey = sessionKey(now, zone);
  for (let i = 1; i <= 3 * 1440; i++) {
    const t = start + i * 6e4, p = zoneParts(t, zone);
    if (minutes.includes(p.hour * 60 + p.minute) && sessionKey(t, zone) !== currentKey && (!previousSession || sessionOrder(t, zone) > sessionOrder(previousSession, zone))) return t;
  }
  throw new Error("no future reminder session");
}

// src/infrastructure/companion/server/study-plan-actions.ts
var copy5 = (value) => JSON.parse(JSON.stringify(value));
function validateCompanionPlanCommandState(state) {
  const pending = state.planCommands ?? [], receipts = state.planCommandReceipts ?? [];
  invalid(Array.isArray(pending) && Array.isArray(receipts));
  const ids = /* @__PURE__ */ new Set();
  for (const command of pending) {
    validateCompanionPlanCommand(command);
    invalid(!ids.has(command.id));
    ids.add(command.id);
  }
  for (const receipt of receipts) {
    validateCompanionPlanCommandReceipt(receipt);
    invalid(!ids.has(receipt.command.id));
    ids.add(receipt.command.id);
  }
}
function enqueueCompanionPlanCommand(state, plan, command, now) {
  validateCompanionPlanCommand(command);
  validateCompanionStudyPlan(plan);
  validateCompanionPlanCommandState(state);
  const prior = state.planCommands?.find((row) => row.id === command.id) ?? state.planCommandReceipts?.find((row) => row.command.id === command.id)?.command;
  if (prior) {
    invalid(sameCompanionPlanCommand(prior, command), "plan command ID collision");
    return;
  }
  invalid(now < plan.expiresAt && plan.generatedAt <= now + 3e5 && command.requestedAt <= now + 3e5 && now - command.requestedAt <= COMPANION_PLAN_ACTION_TTL, "expired plan command");
  const entry = (plan.overview ?? plan.entries).find((row) => row.id === command.entryId);
  invalid(entry?.action && entry.action.revision === command.revision, "stale plan command");
  invalid(!(state.planCommands ?? []).some((row) => row.entryId === command.entryId), "plan command pending");
  if (command.action === "reschedule") {
    invalid(entry.action.canMoveDate || command.date === entry.action.date, "daily block date cannot move");
    const [hour, minute2] = command.time.split(":").map(Number);
    invalid(zonedClock(plan.timeZone).instant(command.date, hour * 60 + minute2) !== void 0, "invalid plan wall time");
  }
  (state.planCommands ??= []).push(copy5(command));
}
function acknowledgeCompanionPlanCommand(state, command, receipt) {
  validateCompanionPlanCommandReceipt(receipt, command);
  validateCompanionPlanCommandState(state);
  const previous = state.planCommandReceipts?.find((row) => row.command.id === command.id);
  if (previous) {
    invalid(previous.status === receipt.status && sameCompanionPlanCommand(previous.command, receipt.command), "plan command receipt collision");
    return;
  }
  const pending = state.planCommands?.find((row) => row.id === command.id);
  invalid(pending && sameCompanionPlanCommand(pending, command), "unknown plan command");
  state.planCommands = state.planCommands.filter((row) => row.id !== command.id);
  (state.planCommandReceipts ??= []).push(copy5(receipt));
}
function companionPlanEntryPending(state, entryId, revision) {
  if (state.planCommands?.some((row) => row.entryId === entryId)) return true;
  return !!state.planCommandReceipts?.some((row) => row.status === "applied" && row.command.entryId === entryId && row.command.revision === revision);
}
function companionPlanCommandViews(state, plan) {
  const recent = [...state.planCommandReceipts ?? [], ...(state.planCommands ?? []).map((command) => ({ command, status: "pending" }))].sort((a, b) => a.command.requestedAt - b.command.requestedAt).slice(-100);
  const entries = new Map(plan?.overview?.map((row) => [row.id, row]));
  const delivery = (receipt) => {
    if (receipt.status !== "applied") return void 0;
    const command = receipt.command, entry = entries.get(command.entryId);
    if (!entry?.action || !entry.calendar) return void 0;
    if (entry.action.revision === command.revision) return { state: "waiting" };
    const matches = command.action === "reschedule" ? entry.action.date === command.date && entry.action.time === command.time && entry.action.durationMinutes === command.durationMinutes : command.action === "complete" ? entry.completed === true : entry.completed !== true;
    return matches ? { ...entry.calendar } : void 0;
  };
  return recent.map((row) => {
    const calendar = row.status === "pending" ? void 0 : delivery(row);
    return {
      id: row.command.id,
      entryId: row.command.entryId,
      action: row.command.action,
      status: row.status,
      requestedAt: row.command.requestedAt,
      ...calendar ? { calendar } : {}
    };
  });
}

// src/infrastructure/companion/server/study-plan-reminders.ts
function validateMiniAppUrl(value) {
  invalid(typeof value === "string" && value.length <= 2048);
  const url = new URL(value);
  invalid(url.protocol === "https:" && !url.username && !url.password && !url.search && !url.hash && url.pathname === "/miniapp/" && url.href === value, "invalid Mini App URL");
}
function miniAppLaunchUrl(base, planId, vaultId) {
  validateMiniAppUrl(base);
  invalid(planId === void 0 || /^[a-f0-9]{64}$/.test(planId));
  invalid(vaultId === void 0 || /^[a-f0-9]{48}$/.test(vaultId));
  return base + (planId === void 0 ? "" : "?plan=" + planId) + (vaultId === void 0 ? "" : "#vault=" + vaultId);
}
var DAILY_REMINDER_TEXT = "\u041F\u043E\u0440\u0430 \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0442\u044C. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 go \u0438 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B.";
function reminderMiniAppPayload(payload, miniAppUrl, vaultId) {
  const launchUrl = miniAppLaunchUrl(miniAppUrl, void 0, vaultId);
  keys(payload, ["chat_id", "text", "disable_notification", "link_preview_options", "reply_markup"]);
  invalid(Number.isSafeInteger(payload.chat_id) && Number(payload.chat_id) > 0 && payload.text === DAILY_REMINDER_TEXT && payload.disable_notification === false);
  record2(payload.link_preview_options);
  keys(payload.link_preview_options, ["is_disabled"]);
  invalid(payload.link_preview_options.is_disabled === true);
  record2(payload.reply_markup);
  keys(payload.reply_markup, ["inline_keyboard"]);
  const rows = payload.reply_markup.inline_keyboard;
  const labels = ["\u0427\u0435\u0440\u0435\u0437 12 \u0447\u0430\u0441\u043E\u0432", "\u0427\u0435\u0440\u0435\u0437 24 \u0447\u0430\u0441\u0430", "\u0414\u043E \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0439 \u0441\u0435\u0441\u0441\u0438\u0438", "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0443\u0447\u0435\u0431\u043D\u044B\u0439 \u0434\u0435\u043D\u044C"];
  invalid(Array.isArray(rows) && rows.length === labels.length);
  rows.forEach((row, index2) => {
    invalid(Array.isArray(row) && row.length === 1);
    record2(row[0]);
    keys(row[0], ["text", "callback_data"]);
    invalid(row[0].text === labels[index2] && typeof row[0].callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(row[0].callback_data));
  });
  return {
    ...payload,
    text: "\u041F\u043E\u0440\u0430 \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0442\u044C. \u041D\u0430\u0447\u043D\u0438\u0442\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435 \u0438\u043B\u0438 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0438\u0442\u0435 \u043D\u0430\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0435.",
    reply_markup: { inline_keyboard: [...rows, [{ text: "\u041D\u0430\u0447\u0430\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435", web_app: { url: launchUrl } }]] }
  };
}
function validateReminderMiniAppPayload(payload, miniAppUrl, vaultId) {
  record2(payload.reply_markup);
  const rows = payload.reply_markup.inline_keyboard;
  invalid(Array.isArray(rows) && rows.length === 5);
  const legacy = { ...payload, text: DAILY_REMINDER_TEXT, reply_markup: { inline_keyboard: rows.slice(0, -1) } };
  invalid(canonical2(payload) === canonical2(reminderMiniAppPayload(legacy, miniAppUrl, vaultId)), "unowned reminder launch");
}
function studyPlanPayload(chatId, delivery, vaultId) {
  const time3 = new Intl.DateTimeFormat("ru-RU", { timeZone: delivery.timeZone, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(delivery.startAt);
  return {
    chat_id: chatId,
    text: `${delivery.title}
${time3}`,
    disable_notification: false,
    link_preview_options: { is_disabled: true },
    reply_markup: { inline_keyboard: [[{ text: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435", web_app: { url: miniAppLaunchUrl(delivery.miniAppUrl, delivery.id, vaultId) } }]] }
  };
}
function validateStudyPlanDelivery(value) {
  record2(value);
  keys(value, ["id", "notifyAt", "startAt", "title", "timeZone", "miniAppUrl"]);
  invalid(typeof value.id === "string" && value.id.length === 64 && /^[a-f0-9]{64}$/.test(value.id));
  timestamp(value.notifyAt);
  timestamp(value.startAt);
  invalid(value.notifyAt <= value.startAt);
  invalid(typeof value.title === "string" && value.title.length > 0 && value.title.length <= 200 && !/[\u0000-\u001f\u007f]/.test(value.title));
  validateTimeZone(value.timeZone);
  validateMiniAppUrl(value.miniAppUrl);
}
function validateStudyPlanPayload(payload, delivery, vaultId) {
  validateStudyPlanDelivery(delivery);
  invalid(Number.isSafeInteger(payload.chat_id) && Number(payload.chat_id) > 0);
  invalid(canonical2(payload) === canonical2(studyPlanPayload(Number(payload.chat_id), delivery, vaultId)), "unowned plan message");
}
function activeStudyPlanEntry(s, id2, now) {
  const plan = s.studyPlan;
  if (!plan?.enabled || s.domain.revoked || now < plan.generatedAt || now >= plan.expiresAt || !s.domain.snapshot || !companionSnapshotIsCurrent(s.domain.snapshot, now)) return;
  const entry = plan.entries.find((row) => row.id === id2);
  if (!entry || (entry.materialIds.length ? !entry.materialIds.every((materialId) => s.materialConsentIds?.includes(materialId)) : !s.materialConsentIds?.length)) return;
  return entry;
}
function planNotificationsAllowed(s, now, timeZone) {
  return s.domain.reminders.enabled && now >= s.mutedUntil && now >= s.domain.reminders.mutedUntil && s.domain.reminders.skippedDay !== studyDay(now, timeZone);
}

// src/infrastructure/companion/server/rich-checkbox-demo-state.ts
function noLearningMetadata(row) {
  invalid(row.snapshotSequence === void 0 && row.answerHandle === void 0 && row.mediaPlaceholder === void 0 && row.hintLease === void 0 && row.hintPanel === void 0 && row.ratingPanel === void 0 && row.sessionPanel === void 0 && row.sessionContent === void 0 && row.questionPanel === void 0 && row.pollPanel === void 0, "demo cannot carry learning data");
}
function validateStoredRichDemo(s, row) {
  invalid(row.method === "sendRichMessage" && row.target === void 0 && row.after === void 0);
  noLearningMetadata(row);
  const panel = row.richDemoPanel;
  record2(panel);
  keys(panel, ["selectedOptionIndexes", "checked", "expiresAt"]);
  timestamp(panel.expiresAt);
  invalid(panel.expiresAt > 0);
  validateRichCheckboxDemoPayload(row.payload);
  const initial = readRichCheckboxDemoMessage(row.payload.rich_message);
  invalid(initial.selectedOptionIndexes.length === 0 && initial.checked === false, "demo initial source differs");
  richCheckboxDemoView({ ...initial, selectedOptionIndexes: panel.selectedOptionIndexes, checked: panel.checked });
  const callbacks = [...initial.toggleHandles, initial.checkHandle, initial.resetHandle];
  for (let index2 = 0; index2 < callbacks.length; index2++) {
    const handle2 = s.handles.find((handle3) => handle3.id === callbacks[index2]);
    if (!handle2) continue;
    const expected = { kind: "rich-demo", panelId: row.id, operation: index2 < 4 ? "toggle" : index2 === 4 ? "check" : "reset", ...index2 < 4 ? { index: index2 } : {} };
    invalid(handle2.sequence === 0 && handle2.expiresAt === panel.expiresAt && canonical2(handle2.action) === canonical2(expected), "demo control differs");
  }
}
function validateStoredRichDemoEdit(s, row, target) {
  invalid(s.outbox.includes(target) && target.method === "sendRichMessage" && target.status === "sent" && Number.isSafeInteger(target.messageId) && Number(target.messageId) > 0 && row.method === "editMessageText" && row.target === target.id && row.after === target.id && row.richDemoPanel === void 0, "unowned demo edit");
  noLearningMetadata(row);
  validateStoredRichDemo(s, target);
  keys(row.payload, ["chat_id", "rich_message"]);
  validateRichCheckboxDemoPayload({ ...row.payload, message_id: target.messageId }, true);
  invalid(row.payload.chat_id === target.payload.chat_id, "demo edit chat differs");
  const callbacks = richCheckboxDemoCallbacks(target.payload.rich_message);
  invalid(canonical2(richCheckboxDemoCallbacks(row.payload.rich_message)) === canonical2(callbacks), "demo edit controls differ");
  if (row.status === "queued") {
    const panel = target.richDemoPanel;
    invalid(canonical2(row.payload.rich_message) === canonical2(richCheckboxDemoView({ ...callbacks, selectedOptionIndexes: panel.selectedOptionIndexes, checked: panel.checked })), "demo edit state differs");
  }
}

// src/infrastructure/companion/server/server-state.ts
function validateConfig(c) {
  invalid(c.enabled === true, "server disabled");
  for (const v of [c.scope, c.epoch, c.enrollment]) token2(v);
  invalid([c.ownerChatId, c.ownerUserId].every((v) => Number.isSafeInteger(v) && v > 0));
  invalid(typeof c.webhookSecret === "string" && /^[A-Za-z0-9_-]{32,256}$/.test(c.webhookSecret));
  invalid(typeof c.bridgeSecret === "string" && c.bridgeSecret.length >= 32 && c.bridgeSecret.length <= 256);
  invalid(c.webhookSecret !== c.bridgeSecret, "separate secrets required");
  invalid(c.port === void 0 || Number.isInteger(c.port) && c.port > 0 && c.port <= 65535);
  invalid(c.host === void 0 || ["127.0.0.1", "::1", "localhost"].includes(c.host) || c.externalTlsProxy === true, "external bind requires TLS proxy declaration");
  invalid(c.quietUpdates === void 0 || typeof c.quietUpdates === "boolean");
  if (c.miniAppUrl !== void 0) validateMiniAppUrl(c.miniAppUrl);
  invalid(c.miniAppVaultId === void 0 || typeof c.miniAppVaultId === "string" && /^[a-f0-9]{48}$/.test(c.miniAppVaultId) && c.miniAppVaultId === c.enrollment);
  invalid(c.botUsername === void 0 || typeof c.botUsername === "string" && /^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(c.botUsername));
  validateTimeZone(c.timeZone);
  invalid(Array.isArray(c.sessionsLocal) && c.sessionsLocal.length > 0 && c.sessionsLocal.length <= 24 && c.sessionsLocal.every((v) => Number.isInteger(v) && v >= 0 && v < 1440));
}
var sessionCards = (session) => [...session.current ? [session.current] : [], ...session.frames ?? [], ...session.results.flatMap((row) => row.card ? [row.card] : []), ...session.snapshot.cards];
function ratingSources(s, panel) {
  const p = panel.ratingPanel;
  if (!p) return [];
  const sources = [];
  if (s.domain.snapshot) {
    for (const card of s.domain.snapshot.cards) if (card.id === p.cardId && card.revision === p.revision) sources.push({ card, snapshot: s.domain.snapshot });
  }
  if (s.studySession && (!panel.sessionContent || panel.sessionContent.sessionId === s.studySession.id)) {
    for (const card of sessionCards(s.studySession)) if (card.id === p.cardId && card.revision === p.revision) sources.push({ card, snapshot: s.studySession.snapshot });
  }
  return sources;
}
function ratingFeedbackMatches(card, panel) {
  if (panel.exerciseFeedback === void 0) return true;
  try {
    return !!card.exercise && typeof panel.answerMatch === "boolean" && feedbackMatchesAnswer(card.exercise, panel.exerciseFeedback) === panel.answerMatch;
  } catch {
    return false;
  }
}
function ratingAnswerSource(s, panel) {
  const p = panel.ratingPanel;
  if (p?.answerText === void 0) return;
  return ratingSources(s, panel).find(({ card, snapshot }) => ratingFeedbackMatches(card, p) && [true, false].some((guidance) => renderCard(card, snapshot, true, p.answerMatch, guidance, [], false, true, p.exerciseFeedback).text === p.answerText || p.exerciseFeedback === void 0 && p.attemptId !== void 0 && renderCard(card, snapshot, true, void 0, guidance).text === p.answerText));
}
function ratingAnswerAllowed(s, panel, now) {
  const source = ratingAnswerSource(s, panel);
  if (!source) return false;
  const { card, snapshot } = source;
  return now < snapshot.expiresAt && (s.materialConsentIds?.includes(card.materialId) ?? true) && (s.attachmentConsent !== false || !card.hints?.length && !card.media?.length) && (!card.offline || s.offlineConsent === true && now < decodeOfflineSeed(card.offline).expiresAt);
}
function carriesGradeAnswer(text4, panel) {
  return panel.ratingPanel?.answerText !== void 0 && typeof text4 === "string" && text4.startsWith(panel.ratingPanel.answerText + "\n\n");
}
function mediaMethod(asset) {
  return asset.kind === "image" && ["png", "jpg", "jpeg"].includes(asset.format) && asset.bytes <= 1e7 ? "sendPhoto" : asset.kind === "audio" && ["mp3", "m4a"].includes(asset.format) ? "sendAudio" : asset.kind === "video" && asset.format === "mp4" ? "sendVideo" : "sendDocument";
}
var isMediaMethod = (method) => ["sendPhoto", "sendAudio", "sendVideo", "sendDocument", "editMessageMedia"].includes(method);
var isEditMethod = (method) => method === "editMessageMedia" || method === "editMessageText";
var MEDIA_LOADING_ERROR = "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0432\u043B\u043E\u0436\u0435\u043D\u0438\u0435. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u0441\u043D\u043E\u0432\u0430.";
var MINI_APP_LAUNCH_TEXT = "\u0417\u0430\u043D\u044F\u0442\u0438\u044F \u043F\u0440\u043E\u0445\u043E\u0434\u044F\u0442 \u0432 Mini App. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C.";
var GRADE_SAVED_NOTICE = "\u041E\u0446\u0435\u043D\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u0432 \u0431\u043E\u0442\u0435.";
var loadingText = (kind2) => kind2 === "image" ? "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u043C \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435\u2026" : kind2 === "audio" ? "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u043C \u0430\u0443\u0434\u0438\u043E\u2026" : "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u043C \u0432\u0438\u0434\u0435\u043E\u2026";
var statuses = ["applied", "stale", "epoch-mismatch", "missing", "ineligible", "local-session-active", "expired", "clock-mismatch"];
function validateServerState(s, ownerChatId, results) {
  record2(s);
  keys(s, ["version", "binding", "domain", "handles", "updates", "callbackIds", "replayArchived", "nonces", "bridgeTimeFloor", "outbox", "receipts", "lastSession", "mutedUntil", "claimedAttempts", "studySession", "editableGrades", "gradeCorrections", "materialConsentIds", "attachmentConsent", "offlineConsent", "offlineHeads", "supersededOfflineReviews", "miniApp", "miniAppReceipts", "miniAppAttempts", "studyPlan", "studyPlanSent", "studyContext", "planCommands", "planCommandReceipts", "cardReportsEnabled", "cardReports", "cardReportReceipts", "writtenRecalls", "writtenRecallReceipts", "retainAnswers", "retainAnswersChangedAt", "answerHistoryFull", "answerHistory", "answerHistoryReferences", "answerHistoryReceipts", "resultLedger", "catalogRevision", "catalogRoot"]);
  invalid(s.replayArchived === void 0 || s.replayArchived === true);
  invalid(s.catalogRevision === void 0 === (s.catalogRoot === void 0), "incomplete catalog publication fence");
  if (s.catalogRoot !== void 0) {
    validateCatalogRoot(s.catalogRoot);
    invalid(s.catalogRevision === catalogRootRevision(s.catalogRoot) && s.domain.snapshot !== void 0, "catalog publication differs");
  }
  invalid(s.retainAnswers === void 0 || typeof s.retainAnswers === "boolean");
  invalid(s.answerHistoryFull === void 0 || typeof s.answerHistoryFull === "boolean");
  if (s.retainAnswersChangedAt !== void 0) timestamp(s.retainAnswersChangedAt);
  invalid(s.cardReportsEnabled === void 0 || typeof s.cardReportsEnabled === "boolean");
  invalid(s.offlineConsent === void 0 || typeof s.offlineConsent === "boolean");
  invalid(s.attachmentConsent === void 0 || typeof s.attachmentConsent === "boolean");
  invalid(s.version === 1 && typeof s.binding === "string" && /^[a-f0-9]{64}$/.test(s.binding));
  record2(s.domain);
  if (s.domain.snapshot !== void 0) validateImmutableSnapshot(s.domain.snapshot);
  validateState({ ...s.domain, snapshot: void 0 });
  validateResultLedger(s);
  for (const rows of [s.handles, s.updates, s.callbackIds, s.outbox, s.receipts]) invalid(Array.isArray(rows));
  invalid(Array.isArray(s.nonces) && s.nonces.length <= 1e4, "nonce window limit");
  timestamp(s.lastSession);
  timestamp(s.mutedUntil);
  timestamp(s.bridgeTimeFloor);
  const unique = (ids) => invalid(new Set(ids).size === ids.length);
  if (s.studyPlan !== void 0) validateCompanionStudyPlan(s.studyPlan);
  if (s.studyContext !== void 0) {
    validateImmutableStudyContext(s.studyContext);
    const cards = s.domain.snapshot && snapshotCardMap(s.domain.snapshot), permitted = new Set(s.materialConsentIds);
    invalid(cards && s.studyContext.cards.every((row) => {
      const card = cards.get(row.id);
      return card && permitted.has(card.materialId);
    }), "study metadata source differs");
  }
  if (s.studyPlanSent !== void 0) {
    invalid(s.studyPlan !== void 0 && Array.isArray(s.studyPlanSent));
    unique(s.studyPlanSent.map((row) => row.id + ":" + row.notifyAt));
    for (const row of s.studyPlanSent) {
      record2(row);
      keys(row, ["id", "notifyAt"]);
      invalid(typeof row.id === "string" && row.id.length === 64 && /^[a-f0-9]{64}$/.test(row.id));
      timestamp(row.notifyAt);
    }
  }
  if (s.supersededOfflineReviews !== void 0) {
    invalid(Array.isArray(s.supersededOfflineReviews));
    const attempts2 = [...s.domain.pending, ...s.domain.outcomes.map((row) => row.attempt), ...s.supersededOfflineReviews.map((row) => row.attempt)];
    const ancestors = new Map(attempts2.map((row) => [row.id, row]));
    invalid(ancestors.size === attempts2.length);
    for (const row of s.supersededOfflineReviews) {
      record2(row);
      keys(row, ["attempt", "seed"]);
      validateAttempt(row.attempt);
      invalid(row.attempt.offline !== void 0 && row.attempt.correct === (row.attempt.rating !== 1));
      const seed = decodeOfflineSeed(row.seed), step = decodeOfflineStep(row.attempt.offline);
      const parent = step.parentId && ancestors.get(step.parentId);
      invalid(step.rootRevision === seed.rootRevision && offlineReviewTimeAllowed(step, row.attempt.occurredAt) && step.after === advanceOfflineFsrs(seed, step.before, row.attempt.correct ? row.attempt.rating : 1, row.attempt.occurredAt), "superseded review differs");
      invalid(step.index === 1 ? step.before === seed.state : parent && parent.cardId === row.attempt.cardId && parent.offline && decodeOfflineStep(parent.offline).rootRevision === seed.rootRevision && decodeOfflineStep(parent.offline).index + 1 === step.index && decodeOfflineStep(parent.offline).after === step.before && parent.scope === row.attempt.scope && parent.epoch === row.attempt.epoch && parent.occurredAt <= row.attempt.occurredAt, "superseded ancestry differs");
    }
  }
  if (s.materialConsentIds !== void 0) {
    invalid(Array.isArray(s.materialConsentIds));
    unique(s.materialConsentIds);
    s.materialConsentIds.forEach(token2);
  }
  validateMiniAppState(s);
  validateCompanionPlanCommandState(s);
  validateCompanionCardReportState(s);
  const textAttempts = [...s.domain.pending, ...s.domain.outcomes.map((row) => row.attempt)], knownText = new Set(textAttempts.map((row) => row.id));
  const acknowledgedTextIds = /* @__PURE__ */ new Set([...(s.writtenRecallReceipts ?? []).map((row) => row.recall.attempt.id), ...(s.answerHistoryReceipts ?? []).map((row) => row.attemptId)]);
  const coldText = [...acknowledgedTextIds].filter((id2) => !knownText.has(id2));
  if (coldText.length) {
    invalid(s.resultLedger?.archiveUsed && results, "Retained answer result archive unavailable");
    const groups = /* @__PURE__ */ new Map();
    for (const row of [...(s.writtenRecallReceipts ?? []).map((row2) => row2.recall.attempt), ...(s.answerHistory ?? []).map((row2) => row2.attempt)]) {
      if (knownText.has(row.id) || !acknowledgedTextIds.has(row.id)) continue;
      const key2 = JSON.stringify([row.scope, row.epoch]), group = groups.get(key2) ?? [];
      group.push(row);
      groups.set(key2, group);
    }
    for (const group of groups.values()) {
      const found = results.getMany(group[0].scope, group[0].epoch, group.map((row) => row.id));
      for (const row of group) {
        const archived = found.get(row.id);
        invalid(archived, "Retained answer result missing");
        textAttempts.push(archived.outcome.attempt);
      }
    }
  }
  validateCompanionWrittenRecallState(s, textAttempts);
  validateAnswerHistoryState(s, textAttempts);
  if (s.miniAppAttempts !== void 0) {
    invalid(Array.isArray(s.miniAppAttempts));
    unique(s.miniAppAttempts.map((row) => row.id));
    for (const row of s.miniAppAttempts) {
      record2(row);
      keys(row, ["id", "answerMatch"]);
      token2(row.id);
      invalid(row.answerMatch === void 0 || typeof row.answerMatch === "boolean");
      invalid(knownText.has(row.id));
    }
  }
  if (s.studySession !== void 0) {
    const session = s.studySession;
    record2(session);
    keys(session, ["id", "snapshot", "status", "results", "skipped", "deferred", "current", "frames", "waitUntil", "mode"]);
    token2(session.id);
    validateSnapshot(session.snapshot);
    invalid(session.snapshot.cards.length <= 1e3, "session card limit");
    invalid(session.mode === void 0 || (session.mode === "core" || session.mode === "bank") && session.snapshot.cards.every((card) => card.mode === session.mode));
    const sessionAttempts = [...s.domain.pending, ...s.domain.outcomes.map((row) => row.attempt)];
    const frozenAncestors = [...sessionAttempts, ...(s.supersededOfflineReviews ?? []).map((row) => row.attempt)];
    const validateFrame = (card) => {
      validateSessionFrame(card, session.snapshot);
      if (!card.offline) return;
      const seed = decodeOfflineSeed(card.offline);
      const parent = frozenAncestors.find((attempt) => attempt.id === card.revision && attempt.cardId === card.id && attempt.offline);
      const previous = parent && decodeOfflineStep(parent.offline);
      const state = card.revision === seed.rootRevision ? seed.state : previous?.rootRevision === seed.rootRevision ? previous.after : void 0;
      invalid(state && card.dueAt === offlineStateDue(state), "offline occurrence differs");
      return state;
    };
    invalid(["active", "paused", "finished"].includes(session.status) && Array.isArray(session.results) && session.results.length <= 1e3 && Array.isArray(session.skipped));
    invalid(session.deferred === void 0 || Array.isArray(session.deferred));
    unique(session.results.map((row) => row.attemptId));
    unique([...session.skipped, ...session.deferred ?? []]);
    unique(session.results.filter((row) => !row.card?.offline).map((row) => row.cardId));
    for (const row of session.results) {
      record2(row);
      keys(row, ["cardId", "attemptId", "card"]);
      token2(row.cardId);
      token2(row.attemptId);
      invalid(session.snapshot.cards.some((card) => card.id === row.cardId));
      if (row.card) {
        const before = validateFrame(row.card);
        invalid(row.card.id === row.cardId);
        if (row.card.offline) {
          const attempt = sessionAttempts.find((attempt2) => attempt2.id === row.attemptId);
          invalid(attempt?.offline && attempt.cardId === row.cardId && attempt.revision === row.card.revision && decodeOfflineStep(attempt.offline).before === before, "offline result differs");
        }
      }
    }
    if (session.current !== void 0) validateFrame(session.current);
    if (session.frames !== void 0) {
      invalid(Array.isArray(session.frames) && session.frames.length <= 1001);
      for (const card of session.frames) validateFrame(card);
    }
    if (session.waitUntil !== void 0) timestamp(session.waitUntil);
    for (const id2 of [...session.skipped, ...session.deferred ?? []]) {
      token2(id2);
      invalid(session.snapshot.cards.some((card) => card.id === id2));
    }
  }
  invalid(s.offlineConsent === true || !s.offlineHeads?.length);
  if (s.offlineHeads !== void 0) validateOfflineHeads(s.offlineHeads, s.domain.snapshot, [...s.domain.pending, ...s.domain.outcomes.filter((row) => row.status === "applied").map((row) => row.attempt)]);
  if (s.editableGrades !== void 0) {
    invalid(Array.isArray(s.editableGrades));
    unique(s.editableGrades.map((row) => row.attemptId));
    const applied = new Set(s.domain.outcomes.filter((row) => row.status === "applied").map((row) => row.attempt.id));
    for (const row of s.editableGrades) {
      record2(row);
      keys(row, ["attemptId", "materialId", "withAttachments", "reviewEventId", "rating", "expiresAt", "answerMatch"]);
      token2(row.attemptId);
      token2(row.materialId);
      token2(row.reviewEventId);
      timestamp(row.expiresAt);
      invalid(typeof row.withAttachments === "boolean");
      invalid([1, 2, 3, 4].includes(row.rating) && (row.answerMatch === void 0 || typeof row.answerMatch === "boolean") && applied.has(row.attemptId));
    }
  }
  if (s.gradeCorrections !== void 0) {
    invalid(Array.isArray(s.gradeCorrections));
    unique(s.gradeCorrections.map((row) => row.correction.id));
    for (const row of s.gradeCorrections) {
      record2(row);
      keys(row, ["correction", "receipt"]);
      validateCompanionGradeCorrection(row.correction);
      if (row.receipt !== void 0) validateCompanionGradeCorrectionReceipt(row.receipt, row.correction);
    }
  }
  if (s.claimedAttempts !== void 0) {
    invalid(Array.isArray(s.claimedAttempts));
    unique(s.claimedAttempts);
    const pending = new Set(s.domain.pending.map((row) => row.id));
    for (const id2 of s.claimedAttempts) {
      token2(id2);
      invalid(pending.has(id2));
    }
  }
  unique(s.handles.map((h) => h.id));
  unique(s.updates.map((u) => u.id));
  unique(s.callbackIds.map((c) => c.id));
  unique(s.nonces.map((n) => n.nonce));
  unique(s.outbox.map((o) => o.id));
  unique(s.receipts.map((r) => r.id));
  for (const r of s.receipts) {
    record2(r);
    keys(r, ["id", "hash"]);
    token2(r.id);
    invalid(typeof r.hash === "string" && /^[a-f0-9]{64}$/.test(r.hash));
  }
  for (const h of s.handles) {
    record2(h);
    keys(h, ["id", "epoch", "sequence", "expiresAt", "action"]);
    token2(h.id);
    token2(h.epoch);
    timestamp(h.sequence);
    timestamp(h.expiresAt);
    record2(h.action);
    invalid(Buffer.byteLength(canonical2(h.action)) <= 8192);
    if (h.action.kind === "rich-demo") {
      keys(h.action, ["kind", "panelId", "operation", "index"]);
      token2(h.action.panelId);
      invalid(h.sequence === 0 && ["toggle", "check", "reset"].includes(String(h.action.operation)));
      invalid(h.action.operation === "toggle" ? Number.isSafeInteger(h.action.index) && Number(h.action.index) >= 0 && Number(h.action.index) < 4 : h.action.index === void 0);
    }
    if (["select-option", "toggle-option", "submit-options", "skip-card"].includes(String(h.action.kind))) {
      keys(h.action, ["kind", "scope", "epoch", "sequence", "cardId", "revision", "index"]);
      for (const field of [h.action.scope, h.action.epoch, h.action.cardId, h.action.revision]) token2(field);
      invalid(h.sequence > 0 && h.action.sequence === h.sequence && h.action.epoch === h.epoch);
      invalid(["select-option", "toggle-option"].includes(String(h.action.kind)) ? Number.isSafeInteger(h.action.index) && Number(h.action.index) >= 0 && Number(h.action.index) < 12 : h.action.index === void 0);
    }
    if (h.action.kind === "answer") {
      keys(h.action, ["kind", "scope", "epoch", "sequence", "cardId", "revision"]);
      for (const field of [h.action.scope, h.action.epoch, h.action.cardId, h.action.revision]) token2(field);
      invalid(h.sequence > 0 && h.action.sequence === h.sequence && h.action.epoch === h.epoch);
    }
    if (h.action.kind === "hint") {
      keys(h.action, ["kind", "scope", "epoch", "sequence", "cardId", "revision", "index"]);
      for (const field of [h.action.scope, h.action.epoch, h.action.cardId, h.action.revision]) token2(field);
      invalid(h.sequence > 0 && h.action.sequence === h.sequence && h.action.epoch === h.epoch && Number.isSafeInteger(h.action.index) && Number(h.action.index) >= 0 && Number(h.action.index) < 10);
    }
    if (h.action.kind === "hint-panel") {
      keys(h.action, ["kind", "panelId", "index", "collapsed"]);
      token2(h.action.panelId);
      invalid(h.sequence === 0 && Number.isSafeInteger(h.action.index) && Number(h.action.index) >= 0 && Number(h.action.index) < 10 && typeof h.action.collapsed === "boolean");
    }
    if (["change-saved-grade", "replace-saved-grade"].includes(String(h.action.kind))) {
      keys(h.action, ["kind", "attemptId", "expectedReviewEventId", "rating", "correct"]);
      token2(h.action.attemptId);
      token2(h.action.expectedReviewEventId);
      invalid(h.sequence === 0);
      if (h.action.kind === "replace-saved-grade") invalid([1, 2, 3, 4].includes(Number(h.action.rating)) && h.action.correct === (h.action.rating !== 1));
      else invalid(h.action.rating === void 0 && h.action.correct === void 0);
    }
    if (String(h.action.kind).startsWith("session-")) {
      keys(h.action, ["kind", "sessionId", "cardId", "offset", "attemptId"]);
      token2(h.action.sessionId);
      invalid(h.sequence === 0 && ["session-history", "session-result", "session-pause", "session-resume", "session-finish", "session-new"].includes(String(h.action.kind)));
      if (h.action.attemptId !== void 0) token2(h.action.attemptId);
      if (h.action.cardId !== void 0) token2(h.action.cardId);
      if (h.action.offset !== void 0) timestamp(h.action.offset);
    }
    if (["change-grade", "replace-grade"].includes(String(h.action.kind))) {
      keys(h.action, ["kind", "attemptId", "rating", "correct", "answerMatch"]);
      token2(h.action.attemptId);
      invalid(h.sequence === 0);
      if (h.action.kind === "replace-grade") invalid([1, 2, 3, 4].includes(Number(h.action.rating)) && h.action.correct === (h.action.rating !== 1) && !(h.action.answerMatch === true && h.action.rating === 1));
      else invalid(h.action.rating === void 0 && h.action.correct === void 0);
    }
    if (h.action.answerMatch !== void 0) invalid(["review", "change-grade", "replace-grade"].includes(String(h.action.kind)) && typeof h.action.answerMatch === "boolean");
  }
  for (const u of s.updates) {
    record2(u);
    keys(u, ["id", "hash"]);
    timestamp(u.id);
    invalid(typeof u.hash === "string" && /^[a-f0-9]{64}$/.test(u.hash));
  }
  for (const c of s.callbackIds) {
    record2(c);
    keys(c, ["id", "hash"]);
    invalid(typeof c.id === "string" && c.id.length > 0 && c.id.length <= 128 && typeof c.hash === "string" && /^[a-f0-9]{64}$/.test(c.hash));
  }
  for (const n of s.nonces) {
    record2(n);
    keys(n, ["nonce", "time", "hash", "response"]);
    token2(n.nonce);
    timestamp(n.time);
    invalid(typeof n.hash === "string" && /^[a-f0-9]{64}$/.test(n.hash));
    canonical2(n.response);
  }
  const handles = new Map(s.handles.map((h) => [h.id, h]));
  const outbox = new Map(s.outbox.map((row) => [row.id, row]));
  const planDeliveries = new Set(s.studyPlanSent?.map((row) => row.id + ":" + row.notifyAt));
  const hintBodies = /* @__PURE__ */ new Map();
  const hintContent = (panel, text4) => {
    const p = panel.hintPanel, session = s.studySession;
    if (session?.id !== p.sessionId) return;
    const card = sessionCards(session).find((card2) => card2.id === p.cardId && card2.revision === p.revision);
    invalid(card?.hints?.length && p.count <= card.hints.length && p.expiresAt <= session.snapshot.expiresAt, "hint source differs");
    let allowed = hintBodies.get(panel.id);
    if (!allowed) {
      allowed = /* @__PURE__ */ new Set();
      hintBodies.set(panel.id, allowed);
      for (let count = 1; count <= p.count; count++) {
        allowed.add(hintPanelView(card.hints, count, 0, true).text);
        for (let index2 = 0; index2 < count; index2++) allowed.add(hintPanelView(card.hints, count, index2, false).text);
      }
    }
    invalid(typeof text4 === "string" && allowed.has(text4), "hint content differs");
  };
  const questionContent = (panel, text4, replyMarkup, status) => {
    const p = panel.questionPanel, session = s.studySession;
    if (!session || session.id !== panel.sessionContent?.sessionId) return;
    const card = sessionCards(session).find((card2) => card2.id === p.cardId && card2.revision === p.revision);
    invalid(card && (card.exercise || card.offline) && p.expiresAt <= session.snapshot.expiresAt, "question source differs");
    const choice = card.exercise?.kind === "single" || card.exercise?.kind === "multiple" ? card.exercise : void 0;
    invalid(p.selectedOptionIndexes.every((index2) => choice && index2 < choice.options.length) && (choice?.kind === "multiple" || p.selectedOptionIndexes.length <= (choice ? 1 : 0)), "question selection differs");
    const adaptive = p.choiceLayout !== void 0, checkboxes = p.choiceLayout === "checkboxes";
    invalid(!adaptive || choice, "question layout differs");
    invalid(!checkboxes || choice?.kind === "multiple", "checkbox layout differs");
    invalid([true, false].some((guidance) => renderCard(card, session.snapshot, false, void 0, guidance, p.selectedOptionIndexes, !adaptive, checkboxes).text === text4), "question content differs");
    const markup = replyMarkup;
    const exact2 = card.exercise?.kind === "cloze" || !card.exercise && card.evaluationMode === "exact";
    invalid(markup.force_reply === (exact2 ? true : void 0), "question reply mode differs");
    invalid(exact2 ? typeof panel.answerHandle === "string" : panel.answerHandle === void 0, "question reply binding differs");
    const answer = panel.answerHandle === void 0 ? void 0 : handles.get(panel.answerHandle);
    if (answer) invalid(answer.action.kind === "answer" && answer.action.cardId === card.id && answer.action.revision === card.revision && answer.action.scope === session.snapshot.scope && answer.action.epoch === session.snapshot.epoch && answer.action.sequence === panel.snapshotSequence && answer.expiresAt <= p.expiresAt, "question answer source differs");
    const layout = choice ? adaptive ? choiceButtonLayout(choice) : { columns: 1, labels: choice.options.map((_, i) => String(i + 1)) } : void 0;
    const optionRows = layout ? Math.ceil(layout.labels.length / layout.columns) : 0;
    for (const [rowIndex, row] of markup.inline_keyboard.entries()) {
      const optionRow = layout && rowIndex < optionRows;
      invalid(row.length === (optionRow ? Math.min(layout.columns, layout.labels.length - rowIndex * layout.columns) : 1), "question row differs");
      for (const [column, button] of row.entries()) {
        const index2 = optionRow ? rowIndex * layout.columns + column : void 0;
        if (index2 !== void 0) {
          const label2 = layout.labels[index2], mark = adaptive && !checkboxes ? "\u2713" : "\u2611", selected = choice.kind === "multiple" && button.text === `${mark} ${label2}`;
          invalid(button.text === (selected ? `${mark} ${label2}` : choice.kind === "multiple" && (!adaptive || checkboxes) ? `\u2610 ${label2}` : label2) && button.style === (adaptive && selected ? "primary" : void 0), "question option differs");
        } else invalid(button.style === void 0, "question control style differs");
        const handle2 = handles.get(button.callback_data);
        if (!handle2) {
          invalid(status !== "queued", "question control missing");
          continue;
        }
        const action = handle2.action;
        if (index2 !== void 0) {
          invalid(action.kind === (choice.kind === "single" ? "select-option" : "toggle-option") && action.index === index2, "question option differs");
        } else if (button.text === "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438") {
          const hint = (typeof action.panelId === "string" ? outbox.get(action.panelId) : void 0)?.hintPanel;
          invalid(action.kind === "hint-panel" && hint?.cardId === card.id && hint.revision === card.revision && hint.sessionId === session.id, "question hint differs");
          continue;
        } else {
          const kind2 = { "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442": "reveal", "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430": "hint", "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441": "skip-card", "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u043E\u0442\u0432\u0435\u0442": "submit-options" }[button.text];
          invalid(kind2 && action.kind === kind2 && (kind2 !== "submit-options" || choice?.kind === "multiple"), "question action differs");
        }
        invalid(action.cardId === card.id && action.revision === card.revision && action.scope === session.snapshot.scope && action.epoch === session.snapshot.epoch && action.sequence === panel.snapshotSequence, "question binding differs");
      }
    }
  };
  unique(s.outbox.filter((o) => o.messageId !== void 0).map((o) => o.messageId));
  unique(s.outbox.filter((o) => o.answerHandle !== void 0).map((o) => o.answerHandle));
  unique(s.outbox.filter((o) => o.studyPlanEntry !== void 0).map((o) => o.studyPlanEntry.id + ":" + o.studyPlanEntry.notifyAt));
  const preceding = /* @__PURE__ */ new Map();
  const pollIds = /* @__PURE__ */ new Set(), pollStops = /* @__PURE__ */ new Set();
  for (const o of s.outbox) {
    record2(o);
    keys(o, ["id", "method", "payload", "status", "snapshotSequence", "answerHandle", "messageId", "after", "target", "mediaPlaceholder", "failureHandled", "hintLease", "hintPanel", "ratingPanel", "sessionPanel", "sessionContent", "questionPanel", "pollPanel", "richDemoPanel", "studyPlanEntry", "miniAppPlan"]);
    token2(o.id);
    if (o.snapshotSequence !== void 0) timestamp(o.snapshotSequence);
    invalid(["sendMessage", "answerCallbackQuery", "sendPhoto", "sendAudio", "sendVideo", "sendDocument", "editMessageMedia", "editMessageText", "sendPoll", "stopPoll", "sendRichMessage"].includes(o.method) && ["queued", "unknown", "sent"].includes(o.status));
    record2(o.payload);
    if (o.miniAppPlan !== void 0) {
      invalid(o.method === "sendMessage" && o.payload.text === MINI_APP_LAUNCH_TEXT && typeof o.miniAppPlan === "string" && /^[a-f0-9]{64}$/.test(o.miniAppPlan));
    }
    if (o.studyPlanEntry !== void 0) {
      invalid(o.method === "sendMessage" && Object.keys(o).every((key2) => ["id", "method", "payload", "status", "messageId", "studyPlanEntry"].includes(key2)));
      validateStudyPlanPayload(o.payload, o.studyPlanEntry);
      invalid(planDeliveries.has(o.studyPlanEntry.id + ":" + o.studyPlanEntry.notifyAt), "missing plan delivery marker");
    }
    if (o.richDemoPanel !== void 0) validateStoredRichDemo(s, o);
    invalid(o.method !== "sendRichMessage" || o.richDemoPanel !== void 0);
    if (o.pollPanel !== void 0) {
      validateStoredPoll(s, o);
      if (o.pollPanel.pollId !== void 0) {
        invalid(!pollIds.has(o.pollPanel.pollId), "duplicate poll binding");
        pollIds.add(o.pollPanel.pollId);
      }
    }
    invalid(o.method !== "sendPoll" || o.pollPanel !== void 0);
    if (o.sessionContent !== void 0) {
      record2(o.sessionContent);
      keys(o.sessionContent, ["sessionId", "cardId", "revision"]);
      token2(o.sessionContent.sessionId);
      invalid(o.method !== "answerCallbackQuery" && (o.answerHandle === void 0 || o.questionPanel !== void 0) && o.sessionPanel === void 0);
      invalid(o.sessionContent.cardId === void 0 === (o.sessionContent.revision === void 0));
      if (o.sessionContent.cardId !== void 0) {
        token2(o.sessionContent.cardId);
        token2(o.sessionContent.revision);
      }
    }
    if (o.questionPanel !== void 0) {
      const p = o.questionPanel;
      record2(p);
      keys(p, ["cardId", "revision", "selectedOptionIndexes", "expiresAt", "choiceLayout"]);
      token2(p.cardId);
      token2(p.revision);
      timestamp(p.expiresAt);
      invalid(p.choiceLayout === void 0 || p.choiceLayout === "adaptive" || p.choiceLayout === "checkboxes");
      invalid(o.method === "sendMessage" && o.sessionContent && !o.ratingPanel && !o.hintPanel && !o.hintLease && !o.mediaPlaceholder && !o.sessionPanel && o.snapshotSequence !== void 0 && o.payload.entities === void 0 && Array.isArray(p.selectedOptionIndexes) && p.selectedOptionIndexes.length <= 12 && p.selectedOptionIndexes.every((index2, i) => Number.isSafeInteger(index2) && index2 >= 0 && index2 < 12 && (i === 0 || p.selectedOptionIndexes[i - 1] < index2)));
      validateQuestionPanelEdit(o.payload.text, o.payload.reply_markup);
      questionContent(o, o.payload.text, o.payload.reply_markup, o.status);
    }
    if (o.sessionPanel !== void 0) {
      record2(o.sessionPanel);
      keys(o.sessionPanel, ["sessionId"]);
      token2(o.sessionPanel.sessionId);
      invalid(o.method === "sendMessage" && !o.ratingPanel && !o.answerHandle && !o.mediaPlaceholder);
      validateSessionPanelEdit(o.payload.text, o.payload.reply_markup);
    }
    if (o.ratingPanel !== void 0) {
      record2(o.ratingPanel);
      keys(o.ratingPanel, ["cardId", "revision", "attemptId", "answerMatch", "answerText", "exerciseFeedback"]);
      token2(o.ratingPanel.cardId);
      token2(o.ratingPanel.revision);
      invalid(o.ratingPanel.answerMatch === void 0 || typeof o.ratingPanel.answerMatch === "boolean");
      if (o.ratingPanel.exerciseFeedback !== void 0) {
        validateCompanionExerciseFeedback(o.ratingPanel.exerciseFeedback);
        invalid(typeof o.ratingPanel.answerMatch === "boolean");
        if (o.ratingPanel.exerciseFeedback.kind === "cloze") invalid(o.ratingPanel.answerMatch === o.ratingPanel.exerciseFeedback.matchedBlanks.every(Boolean));
        else if (o.ratingPanel.exerciseFeedback.kind === "choice" && !o.ratingPanel.exerciseFeedback.selectedOptionIndexes.length) invalid(o.ratingPanel.answerMatch === false);
        const sources = ratingSources(s, o);
        if (sources.length) invalid(sources.some(({ card }) => ratingFeedbackMatches(card, o.ratingPanel)), "exercise feedback source differs");
      }
      if (o.ratingPanel.attemptId !== void 0) token2(o.ratingPanel.attemptId);
      invalid(o.method === "sendMessage" && o.answerHandle === void 0 && o.mediaPlaceholder === void 0 && o.payload.entities === void 0);
      const answerText = o.ratingPanel.answerText;
      invalid(answerText === void 0 || typeof answerText === "string" && combinedGradeText(answerText, GRADE_PROMPT) !== void 0);
      if (answerText !== void 0 && o.status === "queued" && carriesGradeAnswer(o.payload.text, o)) invalid(ratingAnswerSource(s, o), "rating answer source differs");
      if (o.payload.text !== GRADE_PROMPT && o.payload.text !== "\u041E\u0446\u0435\u043D\u0438\u0442\u0435 \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u0435:" && (answerText === void 0 || o.payload.text !== combinedGradeText(answerText, GRADE_PROMPT))) validateGradePanelEdit(o.payload.text, o.payload.reply_markup, answerText);
    }
    if (o.hintLease !== void 0) {
      record2(o.hintLease);
      keys(o.hintLease, ["cardId", "revision", "index", "expiresAt"]);
      token2(o.hintLease.cardId);
      token2(o.hintLease.revision);
      timestamp(o.hintLease.expiresAt);
      invalid(o.method === "sendMessage" && o.snapshotSequence !== void 0 && o.answerHandle === void 0 && o.mediaPlaceholder === void 0 && o.payload.entities !== void 0 && Number.isSafeInteger(o.hintLease.index) && o.hintLease.index >= 0 && o.hintLease.index < 10 && o.hintLease.expiresAt > 0);
    }
    if (o.hintPanel !== void 0) {
      const panel = o.hintPanel;
      record2(panel);
      keys(panel, ["cardId", "revision", "sessionId", "count", "index", "collapsed", "expiresAt", "readOnly"]);
      token2(panel.cardId);
      token2(panel.revision);
      token2(panel.sessionId);
      timestamp(panel.expiresAt);
      invalid(o.method === "sendMessage" && !o.answerHandle && !o.mediaPlaceholder && !o.ratingPanel && !o.sessionPanel && !o.hintLease && o.payload.entities === void 0 && o.sessionContent?.sessionId === panel.sessionId && Number.isSafeInteger(panel.count) && panel.count > 0 && panel.count <= 10 && Number.isSafeInteger(panel.index) && panel.index >= 0 && panel.index < panel.count && typeof panel.collapsed === "boolean" && (panel.readOnly === void 0 || panel.readOnly === true));
      validateHintPanelEdit(o.payload.text, o.payload.reply_markup);
      hintContent(o, o.payload.text);
    }
    if (o.after !== void 0) {
      token2(o.after);
      invalid(preceding.has(o.after), "delivery dependency missing");
    }
    if (o.method === "stopPoll") {
      token2(o.target);
      const target = preceding.get(o.target);
      invalid(target?.method === "sendPoll" && target.status === "sent" && target.pollPanel !== void 0 && target.pollPanel.pollId === o.payload.pollId && target.pollPanel.sealed === true && target.payload.chat_id === o.payload.chat_id && o.after === o.target && !pollStops.has(o.target), "unowned poll target");
      pollStops.add(o.target);
    } else if (isEditMethod(o.method)) {
      if (o.method === "editMessageText" && o.payload.rich_message !== void 0) {
        token2(o.target);
        const target = preceding.get(o.target);
        invalid(target?.method === "sendRichMessage" && target.richDemoPanel && target.status === "sent" && target.messageId !== void 0 && target.payload.chat_id === o.payload.chat_id && o.after === o.target, "unowned rich demo target");
        validateStoredRichDemoEdit(s, o, target);
      } else {
        token2(o.target);
        const target = preceding.get(o.target);
        invalid(target?.method === "sendMessage" && target.payload.chat_id === o.payload.chat_id && o.after === o.target && (o.method === "editMessageText" && o.payload.reply_markup !== void 0 ? target.ratingPanel !== void 0 || target.sessionPanel !== void 0 || target.hintPanel !== void 0 || target.questionPanel !== void 0 : target.mediaPlaceholder === true), "unowned edit target");
        if (o.method === "editMessageText" && target.questionPanel) {
          invalid(o.sessionContent?.sessionId === target.sessionContent?.sessionId && o.snapshotSequence === target.snapshotSequence);
          validateQuestionPanelEdit(o.payload.text, o.payload.reply_markup);
          questionContent(target, o.payload.text, o.payload.reply_markup, o.status);
        }
        if (o.method === "editMessageText" && o.payload.reply_markup !== void 0 && target.sessionPanel) validateSessionPanelEdit(o.payload.text, o.payload.reply_markup);
        if (o.method === "editMessageText" && o.payload.reply_markup !== void 0 && target.ratingPanel) {
          validateGradePanelEdit(o.payload.text, o.payload.reply_markup, target.ratingPanel.answerText);
          if (o.status === "queued" && carriesGradeAnswer(o.payload.text, target)) invalid(ratingAnswerSource(s, target), "rating answer source differs");
        }
        if (o.method === "editMessageText" && target.hintPanel) {
          invalid(o.sessionContent?.sessionId === target.hintPanel.sessionId);
          validateHintPanelEdit(o.payload.text, o.payload.reply_markup);
          hintContent(target, o.payload.text);
        }
        if (o.method === "editMessageMedia") invalid(o.snapshotSequence === target.snapshotSequence && target.payload.text === loadingText(String(o.payload.kind)), "media target differs");
      }
    } else invalid(o.target === void 0);
    if (o.mediaPlaceholder !== void 0) invalid(o.mediaPlaceholder === true && o.method === "sendMessage" && o.answerHandle === void 0 && o.snapshotSequence !== void 0 && o.payload.entities === void 0 && [loadingText("image"), loadingText("audio"), loadingText("video")].includes(String(o.payload.text)));
    if (o.failureHandled !== void 0) invalid(o.failureHandled === true && o.status === "unknown" && (isMediaMethod(o.method) || o.mediaPlaceholder === true || o.hintPanel !== void 0 || o.questionPanel !== void 0 || o.method === "editMessageText" || o.method === "sendPoll" || o.method === "stopPoll" || o.method === "sendRichMessage"));
    preceding.set(o.id, o);
    if (o.answerHandle !== void 0) {
      token2(o.answerHandle);
      invalid(o.method === "sendMessage" && o.snapshotSequence !== void 0);
      const h = handles.get(o.answerHandle);
      invalid(!h || h.action.kind === "answer" && h.sequence === o.snapshotSequence);
    }
    if (o.messageId !== void 0) invalid(o.method !== "answerCallbackQuery" && o.method !== "stopPoll" && !isEditMethod(o.method) && o.status === "sent" && Number.isSafeInteger(o.messageId) && o.messageId > 0);
    if (o.method === "answerCallbackQuery") {
      keys(o.payload, ["callback_query_id", "text"]);
      invalid(typeof o.payload.callback_query_id === "string" && o.payload.callback_query_id.length > 0 && o.payload.callback_query_id.length <= 128);
      invalid(o.payload.text === void 0 || o.payload.text === GRADE_SAVED_NOTICE);
    } else if (o.method === "sendRichMessage") {
      keys(o.payload, ["chat_id", "rich_message", "disable_notification"]);
      validateRichCheckboxDemoMessage(o.payload.rich_message);
      invalid(Number.isSafeInteger(o.payload.chat_id) && Number(o.payload.chat_id) > 0 && (ownerChatId === void 0 || o.payload.chat_id === ownerChatId) && o.payload.disable_notification === true);
    } else if (o.method === "editMessageText" && o.payload.rich_message !== void 0) {
      keys(o.payload, ["chat_id", "rich_message"]);
      validateRichCheckboxDemoMessage(o.payload.rich_message);
      invalid(Number.isSafeInteger(o.payload.chat_id) && Number(o.payload.chat_id) > 0 && (ownerChatId === void 0 || o.payload.chat_id === ownerChatId));
    } else if (o.method === "sendPoll") {
      validateNativePollPayload(o.payload);
      invalid(ownerChatId === void 0 || o.payload.chat_id === ownerChatId);
    } else if (o.method === "stopPoll") {
      keys(o.payload, ["chat_id", "pollId"]);
      invalid(validNativePollId(o.payload.pollId) && Number.isSafeInteger(o.payload.chat_id) && Number(o.payload.chat_id) > 0 && (ownerChatId === void 0 || o.payload.chat_id === ownerChatId));
    } else if (o.method === "editMessageText") {
      keys(o.payload, ["chat_id", "text", "link_preview_options", "reply_markup"]);
      if (o.payload.reply_markup === void 0) invalid(o.payload.text === MEDIA_LOADING_ERROR);
      else if (preceding.get(o.target)?.questionPanel) validateQuestionPanelEdit(o.payload.text, o.payload.reply_markup);
      else if (preceding.get(o.target)?.ratingPanel) validateGradePanelEdit(o.payload.text, o.payload.reply_markup, preceding.get(o.target).ratingPanel.answerText);
      else if (String(o.payload.text).startsWith("\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \xB7 ")) validateSessionPanelEdit(o.payload.text, o.payload.reply_markup);
      else if (String(o.payload.text).startsWith("\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A")) validateHintPanelEdit(o.payload.text, o.payload.reply_markup);
      else validateGradePanelEdit(o.payload.text, o.payload.reply_markup);
      invalid(Number.isSafeInteger(o.payload.chat_id) && Number(o.payload.chat_id) > 0 && (ownerChatId === void 0 || o.payload.chat_id === ownerChatId));
      record2(o.payload.link_preview_options);
      keys(o.payload.link_preview_options, ["is_disabled"]);
      invalid(o.payload.link_preview_options.is_disabled === true);
    } else if (isMediaMethod(o.method)) {
      keys(o.payload, ["chat_id", "assetId", "kind", "format", "bytes", "side", "caption", "disable_notification"]);
      invalid(Number.isSafeInteger(o.payload.chat_id) && Number(o.payload.chat_id) > 0 && (ownerChatId === void 0 || o.payload.chat_id === ownerChatId));
      validateCompanionMediaIdentity({ id: o.payload.assetId, kind: o.payload.kind, format: o.payload.format, bytes: o.payload.bytes });
      invalid(o.payload.side === "question" || o.payload.side === "answer");
      invalid(o.payload.caption === void 0 || typeof o.payload.caption === "string" && o.payload.caption.length <= 500);
      invalid(typeof o.payload.disable_notification === "boolean" && (o.method === "editMessageMedia" || o.method === mediaMethod(o.payload)) && o.snapshotSequence !== void 0);
    } else {
      keys(o.payload, ["chat_id", "text", "disable_notification", "link_preview_options", "reply_markup", "entities"]);
      invalid(Number.isSafeInteger(o.payload.chat_id) && o.payload.chat_id > 0 && (ownerChatId === void 0 || o.payload.chat_id === ownerChatId));
      invalid(typeof o.payload.text === "string" && o.payload.text.length > 0 && o.payload.text.length <= 4096 && typeof o.payload.disable_notification === "boolean");
      if (o.payload.entities !== void 0) validateCompanionSpoilers(o.payload.text, o.payload.entities);
      record2(o.payload.link_preview_options);
      keys(o.payload.link_preview_options, ["is_disabled"]);
      invalid(o.payload.link_preview_options.is_disabled === true);
      record2(o.payload.reply_markup);
      if (o.answerHandle !== void 0 && o.payload.reply_markup.inline_keyboard === void 0) {
        keys(o.payload.reply_markup, ["force_reply", "selective"]);
        invalid(o.payload.reply_markup.force_reply === true && o.payload.reply_markup.selective === true);
      } else {
        keys(o.payload.reply_markup, o.answerHandle === void 0 ? ["inline_keyboard"] : ["inline_keyboard", "force_reply"]);
        invalid(o.answerHandle === void 0 || o.payload.reply_markup.force_reply === true);
        const keyboard = o.payload.reply_markup.inline_keyboard;
        invalid(Array.isArray(keyboard) && keyboard.length <= 100);
        for (const row of o.studyPlanEntry ? [] : keyboard) {
          const adaptive = o.questionPanel?.choiceLayout !== void 0;
          invalid(Array.isArray(row) && row.length > 0 && row.length <= (adaptive ? 3 : 1));
          for (const button of row) {
            record2(button);
            keys(button, adaptive ? ["text", "callback_data", "style"] : ["text", "callback_data"]);
            invalid(typeof button.text === "string" && button.text.length > 0 && button.text.length <= 120 && typeof button.callback_data === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(button.callback_data) && (button.style === void 0 || adaptive && button.style === "primary"));
          }
        }
      }
    }
  }
}

// src/infrastructure/companion/server/runtime.ts
var clone2 = cloneJsonValue;
var AlreadyAnswered = class extends Error {
};
var CompanionServer = class {
  constructor(config, journal, transport, media, observe) {
    this.config = config;
    this.journal = journal;
    this.transport = transport;
    this.media = media;
    this.observe = observe;
    validateConfig(config);
    if (journal.catalog) this.catalogTransfer = new CatalogPageTransfer(journal.catalog);
  }
  largePayload = new LargePayloadAssembler();
  catalogTransfer;
  state;
  tail = Promise.resolve();
  active = false;
  flushing;
  callbackFlushing;
  queuedAt = /* @__PURE__ */ new Map();
  coldResults;
  serial(f) {
    const p = this.tail.then(f);
    this.tail = p.then(() => void 0, () => void 0);
    return p;
  }
  async commit(s, committed = this.state) {
    const started = performance.now();
    try {
      compactResults(s, committed, this.journal.results);
      compactServerReplay(s, committed, this.journal.replay);
      const panels = new Map(s.outbox.filter((row) => row.ratingPanel?.answerText !== void 0).map((row) => [row.id, row]));
      for (const row of s.outbox) {
        const panel = row.method === "editMessageText" && row.status === "queued" && row.target !== void 0 ? panels.get(row.target) : void 0;
        if (panel && carriesGradeAnswer(row.payload.text, panel) && !ratingAnswerAllowed(s, panel, Date.now())) {
          validateGradePanelEdit(row.payload.text, row.payload.reply_markup, panel.ratingPanel.answerText);
          row.payload.text = row.payload.text.slice(panel.ratingPanel.answerText.length + 2);
        }
      }
      const copy7 = cloneServerState(s);
      if (this.journal.validateAndSave) await this.journal.validateAndSave(copy7, this.config.ownerChatId);
      else {
        validateServerState(s, this.config.ownerChatId, this.journal.results);
        await this.journal.save(copy7);
      }
    } catch {
      this.active = false;
      throw new Error("journal unavailable; restart required");
    }
    this.state = s;
    if (this.observe) {
      const queued = new Set(s.outbox.filter((row) => row.status === "queued").map((row) => row.id)), now = performance.now();
      for (const id2 of queued) if (!this.queuedAt.has(id2)) this.queuedAt.set(id2, now);
      for (const id2 of this.queuedAt.keys()) if (!queued.has(id2)) this.queuedAt.delete(id2);
    }
    recordPerformance(this.observe, "runtime.commit", performance.now() - started);
  }
  async start() {
    return this.serial(async () => {
      invalid(!this.active);
      const binding2 = digest({ scope: this.config.scope, epoch: this.config.epoch, enrollment: this.config.enrollment, owner: this.config.ownerUserId, chat: this.config.ownerChatId, timeZone: this.config.timeZone });
      const loaded = await this.journal.load();
      const s = loaded ?? { version: 1, binding: binding2, domain: emptyState(), handles: [], updates: [], callbackIds: [], nonces: [], bridgeTimeFloor: 0, receipts: [], outbox: [], lastSession: 0, mutedUntil: 0, claimedAttempts: [] };
      validateServerState(s, this.config.ownerChatId, this.journal.results);
      invalid(s.binding === binding2, "journal enrollment differs; explicit reconcile/migration required");
      if (s.resultLedger?.archiveUsed) {
        invalid(this.journal.results, "Result archive unavailable");
        this.journal.results.assertPresent(this.config.scope, this.config.epoch);
      }
      if (s.replayArchived) {
        invalid(this.journal.replay, "Request replay archive unavailable");
        this.journal.replay.assertPresent(s.binding);
      }
      const committed = loaded && cloneServerState(loaded);
      delete s.answerHistoryFull;
      s.claimedAttempts ??= s.domain.pending.map((attempt) => attempt.id);
      s.editableGrades ??= [];
      s.gradeCorrections ??= [];
      invalid(!s.studySession || s.studySession.snapshot.scope === this.config.scope && s.studySession.snapshot.epoch === this.config.epoch);
      invalid(s.gradeCorrections.every((row) => row.correction.scope === this.config.scope && row.correction.epoch === this.config.epoch));
      invalid(!s.domain.snapshot || s.domain.snapshot.scope === this.config.scope && s.domain.snapshot.epoch === this.config.epoch);
      invalid(!s.studyPlan || s.studyPlan.timeZone === this.config.timeZone, "study plan timezone differs");
      invalid([...s.domain.pending, ...s.domain.outcomes.map((o) => o.attempt)].every((a) => a.scope === this.config.scope && a.epoch === this.config.epoch));
      invalid([...s.planCommands ?? [], ...(s.planCommandReceipts ?? []).map((row) => row.command)].every((row) => row.scope === this.config.scope && row.epoch === this.config.epoch));
      invalid([...s.cardReports ?? [], ...(s.cardReportReceipts ?? []).map((row) => row.report)].every((row) => row.scope === this.config.scope && row.epoch === this.config.epoch));
      invalid([...s.writtenRecalls ?? [], ...(s.writtenRecallReceipts ?? []).map((row) => row.recall)].every((row) => row.attempt.scope === this.config.scope && row.attempt.epoch === this.config.epoch));
      invalid((s.answerHistory ?? []).every((row) => row.attempt.scope === this.config.scope && row.attempt.epoch === this.config.epoch));
      invalid((s.supersededOfflineReviews ?? []).every((row) => row.attempt.scope === this.config.scope && row.attempt.epoch === this.config.epoch));
      if (this.config.miniAppUrl) this.retireChatStudy(s, Date.now());
      this.reconcileMediaFailures(s);
      this.retirePolls(s, Date.now());
      this.reconcilePlanDeliveries(s, Date.now());
      await this.commit(s, committed);
      this.active = true;
    });
  }
  /** Sanitized operational counts only; never return cached card text or credentials. */
  async drain() {
    let failed;
    do {
      const results = await Promise.allSettled([this.flushing, this.callbackFlushing]);
      await this.tail;
      failed ??= results.find((result) => result.status === "rejected");
    } while (this.flushing || this.callbackFlushing);
    if (failed) throw failed.reason;
  }
  async health() {
    await this.tail;
    return { active: this.active, pending: this.state?.domain.pending.length ?? 0, unknownDeliveries: this.state?.outbox.filter((o) => o.status === "unknown").length ?? 0 };
  }
  async miniApp(request, now = Date.now()) {
    validateMiniAppRequest(request);
    timestamp(now);
    return this.serial(async () => {
      invalid(this.active);
      let s = cloneServerState(this.state);
      if (expireMiniAppSession(s, now)) {
        await this.commit(s);
        s = cloneServerState(s);
      }
      if ((request.kind === "view" || request.kind === "today" || request.kind === "plan") && request.answerHistoryVersion === 1 && s.retainAnswers === void 0) {
        s.retainAnswers = false;
        s.retainAnswersChangedAt = 0;
        if (s.miniApp) {
          delete s.miniApp.retainedAnswer;
          if (s.miniApp.selfRecall && !s.miniApp.currentAttemptId) s.miniApp.selfRecall.answer = "";
        }
        await this.commit(s);
        s = cloneServerState(s);
      }
      if (this.config.miniAppUrl && ["view", "today", "plan"].includes(request.kind) && this.retireChatStudy(s, now)) {
        await this.commit(s);
        s = cloneServerState(s);
      }
      const prior = "requestId" in request ? s.miniAppReceipts?.find((row) => row.id === request.requestId)?.hash ?? (s.replayArchived ? this.journal.replay.get(s.binding, "miniapp", request.requestId) : void 0) : void 0;
      if (prior !== void 0) {
        invalid(prior === digest(request), "Mini App request collision");
      } else if (request.kind === "plan-action") {
        invalid(request.viewToken === miniAppViewToken(s), "stale Mini App view");
        invalid(this.config.miniAppUrl && this.planLaunchEntry(s, request.id, now)?.action, "Study plan entry unavailable");
        const { kind: _kind, requestId, viewToken: _token, id: id2, ...fields4 } = request;
        enqueueCompanionPlanCommand(s, s.studyPlan, { ...fields4, id: requestId, entryId: id2, scope: this.config.scope, epoch: this.config.epoch, requestedAt: now }, now);
        (s.miniAppReceipts ??= []).push({ id: request.requestId, hash: digest(request) });
        this.reconcilePlanDeliveries(s, now);
        await this.commit(s);
      } else if (request.kind === "report-card") {
        invalid(request.viewToken === miniAppViewToken(s), "stale Mini App view");
        const snapshot = this.effectiveSnapshot(s, now), current = miniAppView(s, snapshot, this.suppressed(s), now).card;
        const card = s.miniApp?.session.current;
        invalid(s.cardReportsEnabled && current && card && current.id === card.id && current.revision === card.revision, "card report unavailable");
        enqueueCompanionCardReport(s, {
          id: request.requestId,
          scope: this.config.scope,
          epoch: this.config.epoch,
          cardId: card.id,
          materialId: card.materialId,
          contentHash: companionCardReportContentHash(card),
          requestedAt: now,
          ...request.reason === void 0 ? {} : { reason: request.reason },
          ...request.note === void 0 ? {} : { note: request.note }
        }, card, now);
        (s.miniAppReceipts ??= []).push({ id: request.requestId, hash: digest(request) });
        await this.commit(s);
      } else if (request.kind === "finish-chat") {
        invalid(request.viewToken === miniAppViewToken(s), "stale Mini App view");
        const snapshot = this.effectiveSnapshot(s, now), session = s.studySession;
        invalid(!s.domain.revoked && snapshot && companionSnapshotIsCurrent(snapshot, now), "Mini App unavailable");
        invalid(session && session.id === request.chatSessionId && session.status !== "finished" && now < session.snapshot.expiresAt, "stale Mini App view");
        this.finishSession(s, now, !!this.config.miniAppUrl);
        (s.miniAppReceipts ??= []).push({ id: request.requestId, hash: digest(request) });
        await this.commit(s);
      } else if (request.kind === "finish") {
        finishMiniAppRequest(s, request, now);
        await this.commit(s);
      } else if (request.kind !== "view" && request.kind !== "plan" && request.kind !== "today") {
        this.renewOfflineBaselines(s, now);
        if (request.kind === "start") this.retireSettledOfflineHeads(s, now, true);
        let snapshot = this.effectiveSnapshot(s, now);
        invalid(snapshot, "Mini App unavailable");
        if (request.kind === "start" && request.planId !== void 0) {
          const entry = this.config.miniAppUrl && this.planLaunchEntry(s, request.planId, now);
          invalid(entry && !(entry.completed || entry.skipped) && (request.mode === void 0 || entry.mode === void 0 || request.mode === entry.mode), "Study plan entry unavailable");
          const ids = entry.cardIds && new Set(entry.cardIds);
          snapshot = { ...snapshot, cards: snapshot.cards.filter((card) => (ids ? ids.has(card.id) : !entry.materialIds.length || entry.materialIds.includes(card.materialId)) && (entry.mode === void 0 || card.mode === entry.mode)) };
        }
        applyMiniAppRequest(s, request, snapshot, this.suppressed(s), now);
        await this.commit(s);
      }
      const view = miniAppView(s, this.effectiveSnapshot(s, now), this.suppressed(s), now);
      if (request.kind === "plan") {
        const entry = this.config.miniAppUrl ? this.planLaunchEntry(s, request.id, now) : void 0;
        let materials = entry ? view.materials.filter((row) => (!entry.materialIds.length || entry.materialIds.includes(row.id)) && (entry.mode === void 0 || row.mode === entry.mode)) : [];
        if (entry?.cardIds) {
          const ids = new Set(entry.cardIds), counts = /* @__PURE__ */ new Map();
          view.catalog = view.catalog?.filter((card) => ids.has(card.id) && card.mode === "core");
          for (const card of view.catalog ?? []) counts.set(card.materialId, (counts.get(card.materialId) ?? 0) + 1);
          materials = view.materials.filter((row) => row.mode === "core" && counts.has(row.id)).map((row) => ({ ...row, count: counts.get(row.id) }));
          view.materials = materials;
        }
        view.launch = entry ? { id: entry.id, title: entry.title, materialIds: !entry.cardIds && entry.materialIds.length ? [...entry.materialIds] : [...new Set(materials.map((row) => row.id))], ...entry.mode ? { mode: entry.mode } : {}, ...entry.action ? { action: clone2(entry.action) } : {}, ..."completed" in entry ? { completed: entry.completed === true } : {}, ..."skipped" in entry ? { skipped: entry.skipped === true } : {}, available: !("completed" in entry && entry.completed || "skipped" in entry && entry.skipped) && materials.length > 0 } : { id: request.id, title: "\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E", materialIds: [], available: false };
      }
      if (s.studyPlan && this.planWindowAllowed(s, now)) {
        const plan = s.studyPlan, consent = new Set(s.materialConsentIds);
        const entries = (plan.overview ?? plan.entries).filter((row) => consent.size && row.materialIds.every((id2) => consent.has(id2)));
        const entryIds = new Set(entries.map((row) => row.id));
        view.planActions = entries.some((row) => row.action);
        view.planCommands = companionPlanCommandViews(s, plan).filter((row) => entryIds.has(row.entryId));
        if (request.kind === "today" || request.kind === "plan-action") {
          const materialIds = new Set(view.materials.map((material) => material.id));
          const coreIds = new Set(view.materials.filter((material) => material.mode === "core").map((material) => material.id));
          const bankIds = new Set(view.materials.filter((material) => material.mode === "bank").map((material) => material.id));
          const dayFormatter = new Intl.DateTimeFormat("en-CA", { timeZone: plan.timeZone, year: "numeric", month: "2-digit", day: "2-digit" });
          const dayKey = (time3) => {
            const parts = dayFormatter.formatToParts(time3);
            const get = (name) => Number(parts.find((part) => part.type === name).value);
            return Date.UTC(get("year"), get("month") - 1, get("day"));
          };
          const today = dayKey(now), summary = { timeZone: plan.timeZone, generatedAt: plan.generatedAt, expiresAt: plan.expiresAt };
          view.today = { ...summary, rows: [] };
          view.week = { ...summary, rows: [] };
          for (const row of entries.sort((a, b) => a.startAt - b.startAt || a.id.localeCompare(b.id))) {
            const day2 = dayKey(row.startAt);
            if (day2 < today || day2 >= today + 7 * 864e5) continue;
            const eligible = row.mode === "core" ? coreIds : row.mode === "bank" ? bankIds : materialIds;
            const completed = row.completed === true, skipped = row.skipped === true;
            const available = !completed && !skipped && (row.materialIds.length ? row.materialIds.some((id2) => eligible.has(id2)) : eligible.size > 0);
            const item = {
              id: row.id,
              title: row.title,
              startAt: row.startAt,
              completed,
              skipped,
              available,
              materialIds: row.materialIds.length ? [...row.materialIds] : [...eligible],
              ...row.mode === void 0 ? {} : { mode: row.mode },
              ...row.action ? { action: clone2(row.action) } : {},
              ...row.calendar ? { calendar: clone2(row.calendar) } : {}
            };
            if (day2 === today) view.today.rows.push(item);
            view.week.rows.push(item);
          }
        }
      }
      if (request.kind === "view" || request.kind === "today" || request.kind === "plan") recordPerformance(this.observe, "miniapp.view", 0);
      return view;
    }).catch((error) => {
      if (error instanceof Error && error.message === "stale Mini App view") recordPerformance(this.observe, "miniapp.view-conflict", 0);
      throw error;
    });
  }
  planWindowAllowed(s, now) {
    return !!s.studyPlan && !s.domain.revoked && now >= s.studyPlan.generatedAt - COMPANION_CLOCK_SKEW && now < s.studyPlan.expiresAt && !!s.domain.snapshot && companionSnapshotIsCurrent(s.domain.snapshot, now);
  }
  planLaunchEntry(s, id2, now) {
    if (s.domain.snapshot?.studyTarget?.id === id2) {
      const target = s.domain.snapshot.studyTarget, effective = this.effectiveSnapshot(s, now);
      if (!target.enabled || now >= target.transitionEndAt || !effective || s.domain.revoked || !companionSnapshotIsCurrent(effective, now)) return;
      const cards = miniAppStudyTargetCards(s, effective, now);
      return {
        id: id2,
        title: `\u041F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0430 \u043A ${target.targetDate.split("-").reverse().join(".")}`,
        mode: "core",
        startAt: now,
        notifyAt: now,
        materialIds: [...new Set(cards.map((card) => card.materialId))],
        cardIds: cards.map((card) => card.id)
      };
    }
    if (!this.planWindowAllowed(s, now)) return;
    const entry = (s.studyPlan.overview ?? s.studyPlan.entries).find((row) => row.id === id2);
    return entry && (entry.materialIds.length ? entry.materialIds.every((materialId) => s.materialConsentIds?.includes(materialId)) : !!s.materialConsentIds?.length) ? entry : void 0;
  }
  async miniAppMedia(id2, now = Date.now()) {
    timestamp(now);
    invalid(typeof id2 === "string" && /^[a-f0-9]{64}$/.test(id2));
    return this.serial(async () => {
      invalid(this.active && this.media);
      const state = cloneServerState(this.state);
      if (expireMiniAppSession(state, now)) await this.commit(state);
      const asset = miniAppMediaAsset(this.state, id2, now);
      const stored = await this.media.read(id2);
      invalid(canonical2(stored.asset) === canonical2({ id: asset.id, kind: asset.kind, format: asset.format, bytes: asset.bytes }));
      invalid(this.active);
      miniAppMediaAsset(this.state, id2, Math.max(now, Date.now()));
      return { asset, bytes: stored.bytes };
    });
  }
  ownsPoll(pollId, userId) {
    return userId === this.config.ownerUserId && validNativePollId(pollId) && (this.state?.outbox.some((row) => row.method === "sendPoll" && row.status === "sent" && row.messageId !== void 0 && row.pollPanel?.pollId === pollId) ?? false);
  }
  pollDeliveryPending() {
    return !!this.flushing && this.state.outbox.some((row) => row.method === "sendPoll" && row.status === "unknown" && row.pollPanel?.pollId === void 0);
  }
  ownsCallback(handle2) {
    return this.state?.handles.some((row) => row.id === handle2) ?? false;
  }
  ownsReply(messageId) {
    return this.state?.outbox.some((row) => row.method === "sendMessage" && row.status === "sent" && row.messageId === messageId && row.answerHandle !== void 0) ?? false;
  }
  replyDeliveryPending() {
    return !!this.flushing && this.state.outbox.some((row) => row.method === "sendMessage" && row.status === "unknown" && row.answerHandle !== void 0);
  }
  ownsPlanLaunch(planId, now) {
    return !!this.state && !!this.config.miniAppUrl && !!this.planLaunchEntry(this.state, planId, now);
  }
  sealPoll(s, panel, now = Date.now()) {
    const p = panel.pollPanel;
    invalid(p);
    p.sealed = true;
    const existing = s.outbox.find((row) => row.method === "stopPoll" && row.target === panel.id);
    if (existing) return existing.id;
    if (panel.status !== "sent" || panel.messageId === void 0 || p.pollId === void 0) return;
    if (typeof panel.payload.close_date === "number" && now >= panel.payload.close_date * 1e3) return;
    return this.enqueue(s, "stopPoll", { chat_id: this.config.ownerChatId, pollId: p.pollId }, void 0, void 0, panel.id, panel.id);
  }
  pollAllowed(s, panel, now) {
    const p = panel.pollPanel, source = p && storedPollCard(s, panel), session = s.studySession;
    if (!p || p.sealed || !source || !session || session.id !== p.sessionId || session.status === "finished" || now >= p.expiresAt || typeof panel.payload.close_date === "number" && now >= panel.payload.close_date * 1e3 || now >= source.snapshot.expiresAt || !s.domain.snapshot || now >= s.domain.snapshot.expiresAt || !(s.materialConsentIds?.includes(source.card.materialId) ?? true) || s.attachmentConsent === false && (!!source.card.hints?.length || !!source.card.media?.length)) return false;
    if (source.card.offline && (s.offlineConsent !== true || now >= decodeOfflineSeed(source.card.offline).expiresAt)) return false;
    const head = source.card.offline && s.offlineHeads?.find((row) => row.cardId === p.cardId);
    const live = head ? projectOfflineCard(head) : s.domain.snapshot.cards.find((card) => card.id === p.cardId && card.revision === p.revision);
    return !!live && canonical2(live) === canonical2(source.card) && session.current?.id === p.cardId && session.current.revision === p.revision;
  }
  pollCard(s, panel, now) {
    invalid(panel.status === "sent" && panel.messageId !== void 0 && panel.pollPanel?.pollId !== void 0 && this.pollAllowed(s, panel, now), "stale poll");
    const card = this.effectiveSnapshot(s, now)?.cards.find((row) => row.id === panel.pollPanel.cardId && row.revision === panel.pollPanel.revision);
    invalid(card && !s.studySession?.deferred?.includes(card.id) && !this.suppressed(s).some((row) => row.cardId === card.id), "stale poll");
    return card;
  }
  retirePolls(s, now) {
    let changed = false;
    for (const row of [...s.outbox]) if (row.pollPanel && !row.pollPanel.sealed && !this.pollAllowed(s, row, now)) {
      if (row.status === "queued") this.cancelQueuedContent(s, /* @__PURE__ */ new Set([row.id]));
      else if (row.status === "sent" && row.payload.close_date !== void 0 && now >= row.pollPanel.expiresAt) row.pollPanel.sealed = true;
      else this.sealPoll(s, row, now);
      changed = true;
    }
    return changed;
  }
  pollAnswer(s, pollId, optionIds, now) {
    const panel = s.outbox.find((row) => row.method === "sendPoll" && row.status === "sent" && row.pollPanel?.pollId === pollId);
    invalid(panel, "unowned poll");
    if (panel.pollPanel.sealed || optionIds.length === 0) return;
    const card = this.pollCard(s, panel, now), exercise = card.exercise;
    invalid(exercise.kind === "single" || exercise.kind === "multiple");
    invalid(optionIds.every((index2) => index2 < exercise.options.length) && (exercise.kind === "multiple" || optionIds.length === 1), "invalid poll selection");
    panel.pollPanel.selection = [...optionIds];
    const after = this.sealPoll(s, panel, now);
    invalid(after);
    this.card(
      s,
      card,
      now,
      true,
      evaluateCompanionExercise(exercise, { selectedOptionIndexes: optionIds }),
      panel.pollPanel.expiresAt,
      after,
      createCompanionExerciseFeedback(exercise, { selectedOptionIndexes: optionIds })
    );
  }
  id() {
    return (0, import_node_crypto8.randomBytes)(24).toString("base64url");
  }
  richDemo(s, now) {
    invalid(s.handles.length <= 9994);
    const id2 = this.enqueue(s, "sendRichMessage", {}), panel = s.outbox.find((row) => row.id === id2), expiresAt = now + 30 * 6e4;
    const control = (operation, index2) => {
      const handle2 = this.id();
      s.handles.push({
        id: handle2,
        epoch: this.config.epoch,
        sequence: 0,
        expiresAt,
        action: { kind: "rich-demo", panelId: id2, operation, ...index2 === void 0 ? {} : { index: index2 } }
      });
      return handle2;
    };
    const toggleHandles = [0, 1, 2, 3].map((index2) => control("toggle", index2));
    panel.richDemoPanel = { selectedOptionIndexes: [], checked: false, expiresAt };
    panel.payload = { chat_id: this.config.ownerChatId, disable_notification: true, rich_message: richCheckboxDemoView({
      selectedOptionIndexes: [],
      checked: false,
      toggleHandles,
      checkHandle: control("check"),
      resetHandle: control("reset")
    }) };
  }
  actRichDemo(s, action, handleId, now) {
    const panel = s.outbox.find((row) => row.id === action.panelId), p = panel?.richDemoPanel;
    invalid(panel?.method === "sendRichMessage" && p && panel.status === "sent" && panel.messageId !== void 0 && now < p.expiresAt, "stale rich demo");
    const view = readRichCheckboxDemoMessage(panel.payload.rich_message), index2 = Number(action.index);
    const expected = action.operation === "toggle" ? view.toggleHandles[index2] : action.operation === "check" ? view.checkHandle : action.operation === "reset" ? view.resetHandle : void 0;
    invalid(handleId && expected === handleId, "unowned rich demo control");
    const before = canonical2(p);
    if (action.operation === "toggle") {
      p.selectedOptionIndexes = p.selectedOptionIndexes.includes(index2) ? p.selectedOptionIndexes.filter((value) => value !== index2) : [...p.selectedOptionIndexes, index2].sort((a, b) => a - b);
      p.checked = false;
    } else if (action.operation === "check") p.checked = true;
    else {
      p.selectedOptionIndexes = [];
      p.checked = false;
    }
    if (canonical2(p) === before) return;
    s.outbox = s.outbox.filter((row) => !(row.status === "queued" && row.method === "editMessageText" && row.target === panel.id && row.payload.rich_message !== void 0));
    this.enqueue(s, "editMessageText", { chat_id: this.config.ownerChatId, rich_message: richCheckboxDemoView({
      ...view,
      selectedOptionIndexes: p.selectedOptionIndexes,
      checked: p.checked
    }) }, void 0, void 0, panel.id, panel.id);
  }
  enqueue(s, method, payload, snapshotSequence, answerHandle, after, target, mediaPlaceholder) {
    const id2 = this.id();
    s.outbox.push({ id: id2, method, payload, status: "queued", ...snapshotSequence === void 0 ? {} : { snapshotSequence }, ...answerHandle === void 0 ? {} : { answerHandle }, ...after === void 0 ? {} : { after }, ...target === void 0 ? {} : { target }, ...mediaPlaceholder === void 0 ? {} : { mediaPlaceholder } });
    return id2;
  }
  keyboard(s, buttons, now, deadline, reuse = false) {
    return groupCompanionButtons(buttons, (b) => {
      const existing = reuse && s.handles.find((h) => now < h.expiresAt && h.expiresAt <= (deadline ?? Infinity) && h.sequence === s.domain.snapshot?.sequence && canonical2(h.action) === canonical2(b.action));
      if (existing) return { text: b.text, callback_data: existing.id, ...b.style ? { style: b.style } : {} };
      const id2 = this.id(), grade = ["change-grade", "replace-grade", "change-saved-grade", "replace-saved-grade", "hint-panel"].includes(String(b.action.kind)) || String(b.action.kind).startsWith("session-"), control = grade || ["status", "snooze", "skip", "notifications"].includes(String(b.action.kind));
      const expiresAt = s.domain.snapshot?.expiresAt ?? now + 864e5;
      s.handles.push({
        id: id2,
        epoch: this.config.epoch,
        sequence: control ? 0 : s.domain.snapshot?.sequence ?? 0,
        expiresAt: grade ? Math.min(deadline ?? expiresAt, expiresAt) : control ? now + 864e5 : Math.min(expiresAt, deadline ?? expiresAt),
        action: clone2(b.action)
      });
      return { text: b.text, callback_data: id2, ...b.style ? { style: b.style } : {} };
    });
  }
  message(s, m, now, after, contentSequence, deadline) {
    invalid(m.text.length > 0 && m.text.length <= 4096 && m.buttons.length <= 100);
    if (m.entities !== void 0) validateCompanionSpoilers(m.text, m.entities);
    const entities = m.entities === void 0 ? {} : { entities: clone2(m.entities) };
    if (m.answerAction) {
      const id2 = this.id(), snapshot = s.domain.snapshot;
      invalid(snapshot);
      s.handles.push({ id: id2, epoch: this.config.epoch, sequence: snapshot.sequence, expiresAt: Math.min(snapshot.expiresAt, deadline ?? snapshot.expiresAt), action: clone2(m.answerAction) });
      const prompt = this.enqueue(s, "sendMessage", { chat_id: this.config.ownerChatId, text: m.text, ...entities, disable_notification: m.disableNotification ?? false, link_preview_options: { is_disabled: true }, reply_markup: { inline_keyboard: this.keyboard(s, m.buttons, now, deadline), force_reply: true } }, snapshot.sequence, id2, after);
      return prompt;
    }
    const inline_keyboard = this.keyboard(s, m.buttons, now, deadline);
    return this.enqueue(s, "sendMessage", { chat_id: this.config.ownerChatId, text: m.text, ...entities, disable_notification: m.disableNotification ?? false, link_preview_options: { is_disabled: true }, reply_markup: { inline_keyboard } }, contentSequence ?? (m.buttons.some((b) => ["material", "reveal", "review", "hint", "more", "all", "search"].includes(String(b.action.kind))) ? s.domain.snapshot?.sequence : void 0), void 0, after);
  }
  hintCard(s, panel, now) {
    const p = panel.hintPanel, session = s.studySession;
    invalid(p && session?.id === p.sessionId && now < p.expiresAt && now < session.snapshot.expiresAt, "stale hints");
    const card = sessionCards(session).find((card2) => card2.id === p.cardId && card2.revision === p.revision);
    invalid(card?.hints?.length && p.count <= card.hints.length && s.materialConsentIds?.includes(card.materialId) && s.attachmentConsent !== false, "hint consent revoked");
    if (!session.results.some((row) => row.cardId === card.id && (row.card?.revision ?? card.revision) === p.revision)) {
      const current = this.effectiveSnapshot(s, now)?.cards.find((row) => row.id === card.id);
      const superseded = s.supersededOfflineReviews?.some((row) => row.attempt.id === p.revision && row.attempt.cardId === card.id);
      const closedSummary = (session.status === "finished" || session.deferred?.includes(card.id) || superseded) && p.readOnly && p.collapsed;
      invalid(closedSummary || session.status !== "finished" && !session.skipped.includes(card.id) && !session.deferred?.includes(card.id) && s.domain.snapshot && now < s.domain.snapshot.expiresAt && panel.snapshotSequence === s.domain.snapshot.sequence && current?.eligible && canonical2(current) === canonical2(card), "stale hints");
    }
    return card;
  }
  updateHintPanel(s, panel, now) {
    const p = panel.hintPanel, card = this.hintCard(s, panel, now), snapshot = s.domain.snapshot;
    const view = hintPanelView(card.hints, p.count, p.index, p.collapsed);
    const superseded = s.supersededOfflineReviews?.some((row) => row.attempt.id === p.revision && row.attempt.cardId === p.cardId);
    const retired = (s.studySession.status === "finished" || s.studySession.deferred?.includes(p.cardId) || superseded) && !s.studySession.results.some((row) => row.cardId === p.cardId && (row.card?.revision ?? p.revision) === p.revision);
    const last = [...s.outbox].reverse().find((row) => row.method === "editMessageText" && row.target === panel.id)?.payload ?? panel.payload;
    if (retired && last.text === view.text && last.reply_markup.inline_keyboard.length === 0) return;
    s.handles = s.handles.filter((h) => !(h.action.kind === "hint-panel" && h.action.panelId === panel.id) && !(h.action.kind === "hint" && h.action.cardId === p.cardId));
    const show = (index2, collapsed = false) => ({ kind: "hint-panel", panelId: panel.id, index: index2, collapsed });
    const buttons = retired ? [] : p.collapsed ? [{ text: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438", action: show(p.count - 1) }] : [
      ...view.paged && p.index > 0 ? [{ text: "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0430\u044F \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", action: show(p.index - 1) }] : [],
      ...view.paged && p.index + 1 < p.count ? [{ text: "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", action: show(p.index + 1) }] : [],
      ...!p.readOnly && p.count < card.hints.length ? [{ text: "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430", action: {
        kind: "hint",
        cardId: card.id,
        revision: card.revision,
        scope: snapshot.scope,
        epoch: snapshot.epoch,
        sequence: snapshot.sequence,
        index: p.count
      } }] : [],
      { text: "\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438", action: show(p.index, true) }
    ];
    const reply_markup = { inline_keyboard: this.keyboard(s, buttons, now, p.expiresAt) };
    validateHintPanelEdit(view.text, reply_markup);
    s.outbox = s.outbox.filter((row) => !(row.method === "editMessageText" && row.target === panel.id && row.status === "queued"));
    if (panel.status === "queued") {
      panel.payload.text = view.text;
      panel.payload.reply_markup = reply_markup;
      return;
    }
    if (panel.status !== "sent" || panel.messageId === void 0) return;
    const id2 = this.enqueue(s, "editMessageText", { chat_id: this.config.ownerChatId, text: view.text, reply_markup, link_preview_options: { is_disabled: true } }, panel.snapshotSequence, void 0, panel.id, panel.id);
    s.outbox.find((row) => row.id === id2).sessionContent = { sessionId: p.sessionId };
  }
  freezeHints(s, cardId, now, collapse, revision) {
    for (const panel of [...s.outbox]) {
      const p = panel.hintPanel;
      if (!p || p.cardId !== cardId || p.sessionId !== s.studySession?.id || now >= p.expiresAt || revision !== void 0 && p.revision !== revision) continue;
      p.readOnly = true;
      if (collapse) {
        p.collapsed = true;
        delete panel.snapshotSequence;
      }
      this.updateHintPanel(s, panel, now);
    }
  }
  gradePanel(s, attempt, now, stage, answerMatch, deadline, original) {
    if (s.miniAppAttempts?.some((row) => row.id === attempt.id)) return;
    const panels = s.outbox.filter((row) => row.ratingPanel?.attemptId === attempt.id);
    if (!original && panels.length > 1) {
      for (const panel2 of panels) this.gradePanel(s, attempt, now, stage, answerMatch, deadline, panel2);
      return;
    }
    const binding2 = { attemptId: attempt.id, ...answerMatch === void 0 ? {} : { answerMatch } };
    const editable = s.editableGrades?.find((row) => row.attemptId === attempt.id && row.expiresAt > now);
    const savedBinding = editable && { attemptId: attempt.id, expectedReviewEventId: editable.reviewEventId };
    const buttons = stage === "selected" ? [{ text: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0446\u0435\u043D\u043A\u0443", action: { kind: "change-grade", ...binding2 } }] : stage === "applied" && savedBinding ? [{ text: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0446\u0435\u043D\u043A\u0443", action: { kind: "change-saved-grade", ...savedBinding } }] : stage === "changing" ? ((editable?.answerMatch ?? answerMatch) === true ? [2, 3, 4] : [1, 2, 3, 4]).map((rating) => ({ text: GRADE_LABELS[rating - 1], action: savedBinding ? { kind: "replace-saved-grade", ...savedBinding, rating, correct: rating !== 1 } : { kind: "replace-grade", ...binding2, rating, correct: rating !== 1 } })) : [];
    const panel = original?.ratingPanel ? original : s.outbox.find((row) => row.ratingPanel?.attemptId === attempt.id);
    const answerText = panel?.ratingPanel?.answerText !== void 0 && ratingAnswerAllowed(s, panel, now) ? panel.ratingPanel.answerText : void 0;
    const text4 = gradePanelText(attempt.rating, stage, answerText);
    if (!panel) {
      const id2 = this.message(s, { text: text4, buttons, disableNotification: true }, now, void 0, void 0, deadline);
      s.outbox.find((row) => row.id === id2).ratingPanel = { cardId: attempt.cardId, revision: attempt.revision, attemptId: attempt.id, ...answerMatch === void 0 ? {} : { answerMatch } };
      return;
    }
    invalid(panel.ratingPanel?.cardId === attempt.cardId && panel.ratingPanel.revision === attempt.revision);
    panel.ratingPanel.attemptId = attempt.id;
    if (answerMatch !== void 0) panel.ratingPanel.answerMatch = answerMatch;
    if (panel.ratingPanel.answerText === void 0) delete panel.snapshotSequence;
    const last = [...s.outbox].reverse().find((row) => row.method === "editMessageText" && row.target === panel.id);
    if (!buttons.length && last?.payload.text === text4) return;
    const reply_markup = { inline_keyboard: this.keyboard(s, buttons, now, deadline) };
    validateGradePanelEdit(text4, reply_markup, panel.ratingPanel.answerText);
    if (panel.status === "queued") {
      panel.payload.text = text4;
      panel.payload.reply_markup = reply_markup;
      return;
    }
    s.outbox = s.outbox.filter((row) => !(row.method === "editMessageText" && row.target === panel.id && row.status === "queued"));
    this.enqueue(s, "editMessageText", { chat_id: this.config.ownerChatId, text: text4, link_preview_options: { is_disabled: true }, reply_markup }, void 0, void 0, panel.id, panel.id);
  }
  resultAttempt(s, id2) {
    hydrateResult(s, this.journal.results, this.config.scope, this.config.epoch, id2, Date.now());
    const attempt = s.domain.pending.find((row) => row.id === id2) ?? s.domain.outcomes.find((row) => row.attempt.id === id2)?.attempt;
    if (!attempt) return;
    const corrected = [...s.gradeCorrections ?? []].reverse().find((row) => row.correction.attemptId === id2 && row.receipt?.status === "applied");
    return corrected ? { ...attempt, rating: corrected.correction.rating, correct: corrected.correction.correct } : attempt;
  }
  sessionPanel(s, now) {
    const session = s.studySession;
    invalid(session);
    const buttons = session.status === "finished" ? [{ text: "\u0418\u0441\u0442\u043E\u0440\u0438\u044F", action: { kind: "session-history", sessionId: session.id } }, { text: "\u041D\u043E\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435", action: { kind: "session-new", sessionId: session.id } }] : [
      { text: "\u0418\u0441\u0442\u043E\u0440\u0438\u044F", action: { kind: "session-history", sessionId: session.id } },
      { text: session.status === "paused" || session.waitUntil !== void 0 ? "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C" : "\u041F\u0430\u0443\u0437\u0430", action: { kind: session.status === "paused" || session.waitUntil !== void 0 ? "session-resume" : "session-pause", sessionId: session.id } },
      { text: "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C", action: { kind: "session-finish", sessionId: session.id } }
    ];
    const text4 = studySessionText(
      new Set(session.results.map((row) => row.cardId)).size,
      session.snapshot.cards.length,
      session.status,
      session.deferred?.length ?? 0,
      { answers: session.results.length, waitUntil: session.waitUntil, timeZone: this.config.timeZone }
    );
    const panel = s.outbox.find((row) => row.sessionPanel?.sessionId === session.id);
    if (!panel) {
      const id2 = this.message(s, { text: text4, buttons, disableNotification: true }, now, void 0, void 0, session.snapshot.expiresAt);
      s.outbox.find((row) => row.id === id2).sessionPanel = { sessionId: session.id };
      return;
    }
    const last = [...s.outbox].reverse().find((row) => row.method === "editMessageText" && row.target === panel.id);
    if ((last?.payload.text ?? panel.payload.text) === text4) return;
    const reply_markup = { inline_keyboard: this.keyboard(s, buttons, now, session.snapshot.expiresAt) };
    validateSessionPanelEdit(text4, reply_markup);
    if (panel.status === "queued") {
      panel.payload.text = text4;
      panel.payload.reply_markup = reply_markup;
      return;
    }
    s.outbox = s.outbox.filter((row) => !(row.method === "editMessageText" && row.target === panel.id && row.status === "queued"));
    this.enqueue(s, "editMessageText", { chat_id: this.config.ownerChatId, text: text4, reply_markup, link_preview_options: { is_disabled: true } }, void 0, void 0, panel.id, panel.id);
  }
  sessionHistory(s, now, offset = 0) {
    const session = s.studySession;
    invalid(session && Number.isSafeInteger(offset) && offset >= 0 && offset <= 1e3);
    if (now >= session.snapshot.expiresAt) {
      this.message(s, { text: "\u0414\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u044F \u0443\u0441\u0442\u0430\u0440\u0435\u043B\u0438. \u041D\u0430\u0447\u043D\u0438\u0442\u0435 \u043D\u043E\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435 \u0447\u0435\u0440\u0435\u0437 /go.", buttons: [] }, now);
      return;
    }
    const rows = session.results.slice(offset, offset + 15);
    const buttons = rows.map((row, index2) => {
      const card = row.card ?? session.snapshot.cards.find((card2) => card2.id === row.cardId), attempt = this.resultAttempt(s, row.attemptId);
      return { text: `${offset + index2 + 1}. ${card.question.replace(/\s+/g, " ").slice(0, 60)} \xB7 ${attempt ? GRADE_LABELS[attempt.rating - 1] : "\u043D\u0435\u0442 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430"}`, action: { kind: "session-result", sessionId: session.id, cardId: row.cardId, ...row.card?.offline ? { attemptId: row.attemptId } : {} } };
    });
    if (offset > 0) buttons.push({ text: "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B", action: { kind: "session-history", sessionId: session.id, offset: Math.max(0, offset - 15) } });
    if (offset + 15 < session.results.length) buttons.push({ text: "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B", action: { kind: "session-history", sessionId: session.id, offset: offset + 15 } });
    if (session.status !== "finished") buttons.push({ text: "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435", action: { kind: "session-resume", sessionId: session.id } });
    buttons.push(session.status === "finished" ? { text: "\u041D\u043E\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435", action: { kind: "session-new", sessionId: session.id } } : { text: "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435", action: { kind: "session-finish", sessionId: session.id } });
    const completed = new Set(session.results.map((row) => row.cardId)).size;
    const id2 = this.message(s, { text: `\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0437\u0430\u043D\u044F\u0442\u0438\u044F \xB7 ${completed} \u0438\u0437 ${session.snapshot.cards.length}${session.results.length > completed ? `
\u041E\u0442\u0432\u0435\u0442\u043E\u0432: ${session.results.length}.` : ""}${session.deferred?.length ? `
\u041F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u043E: ${session.deferred.length}.` : ""}${session.skipped.length ? `
\u041D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A: ${session.skipped.length}.` : ""}
${rows.length ? "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u0438\u043B\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043E\u0446\u0435\u043D\u043A\u0438." : "\u041E\u0446\u0435\u043D\u043E\u043A \u043F\u043E\u043A\u0430 \u043D\u0435\u0442."}`, buttons, disableNotification: true }, now, void 0, void 0, session.snapshot.expiresAt);
    s.outbox.find((row) => row.id === id2).sessionContent = { sessionId: session.id };
  }
  sessionResult(s, now, cardId, attemptId) {
    const session = s.studySession, result = session?.results.find((row) => row.cardId === cardId && (attemptId === void 0 || row.attemptId === attemptId)), card = result?.card ?? session?.snapshot.cards.find((card2) => card2.id === cardId);
    const attempt = result && this.resultAttempt(s, result.attemptId);
    invalid(session && card && attempt && now < session.snapshot.expiresAt);
    const content2 = (id3) => {
      s.outbox.find((row) => row.id === id3).sessionContent = { sessionId: session.id };
      return id3;
    };
    const sourcePanel = s.outbox.find((row) => row.ratingPanel?.attemptId === attempt.id && row.ratingPanel.cardId === cardId && row.ratingPanel.revision === attempt.revision && row.ratingPanel.answerMatch !== void 0)?.ratingPanel;
    const answerMatch = sourcePanel?.answerMatch, exerciseFeedback = sourcePanel?.exerciseFeedback;
    const rendered = renderCard(card, session.snapshot, true, exerciseFeedback === void 0 ? void 0 : answerMatch, false, [], false, true, exerciseFeedback);
    const combined = !card.media?.length && combinedGradeText(rendered.text, GRADE_PROMPT) !== void 0;
    let after = combined ? void 0 : content2(this.message(s, { ...rendered, buttons: [] }, now));
    for (const asset of card.media ?? []) {
      const sequence = s.domain.snapshot?.sequence ?? session.snapshot.sequence;
      const placeholder = content2(this.enqueue(s, "sendMessage", { chat_id: this.config.ownerChatId, text: loadingText(asset.kind), disable_notification: true, link_preview_options: { is_disabled: true }, reply_markup: { inline_keyboard: [] } }, sequence, void 0, after, void 0, true));
      after = content2(this.enqueue(s, "editMessageMedia", { chat_id: this.config.ownerChatId, assetId: asset.id, kind: asset.kind, format: asset.format, bytes: asset.bytes, side: asset.side, ...asset.caption === void 0 ? {} : { caption: asset.caption }, disable_notification: true }, sequence, void 0, placeholder, placeholder));
    }
    const pending = s.domain.pending.some((row) => row.id === attempt.id), outcome = s.domain.outcomes.find((row) => row.attempt.id === attempt.id);
    const stage = pending ? s.claimedAttempts?.includes(attempt.id) ? "sent" : "selected" : outcome?.status === "applied" ? "applied" : "rejected";
    const id2 = content2(this.message(s, { text: gradePanelText(attempt.rating, stage, combined ? rendered.text : void 0), buttons: [], disableNotification: true }, now, after, combined ? session.snapshot.sequence : void 0));
    const panel = s.outbox.find((row) => row.id === id2);
    panel.ratingPanel = {
      cardId,
      revision: attempt.revision,
      attemptId: attempt.id,
      ...answerMatch === void 0 ? {} : { answerMatch },
      ...combined ? { answerText: rendered.text } : {},
      ...exerciseFeedback === void 0 ? {} : { exerciseFeedback: clone2(exerciseFeedback) }
    };
    this.gradePanel(s, attempt, now, stage, answerMatch, session.snapshot.expiresAt, panel);
  }
  sessionNext(s, now) {
    const session = s.studySession;
    invalid(session);
    if (session.status === "paused") {
      this.sessionPanel(s, now);
      return;
    }
    if (session.status === "finished") {
      this.sessionPanel(s, now);
      this.sessionHistory(s, now);
      return;
    }
    const effective = this.effectiveSnapshot(s, now), available = [];
    let waitUntil;
    delete session.waitUntil;
    for (const original of session.snapshot.cards) {
      const answered = session.results.some((row) => row.cardId === original.id);
      if (!original.offline && answered || session.skipped.includes(original.id) || session.deferred?.includes(original.id)) continue;
      const card = effective?.cards.find((card2) => card2.id === original.id && card2.eligible);
      const head = s.offlineHeads?.find((head2) => head2.cardId === original.id);
      if (!card || now >= session.snapshot.expiresAt || !original.offline && canonical2(card) !== canonical2(original) || original.offline && (!head || head.seed !== original.offline) || this.suppressed(s).some((attempt) => attempt.cardId === original.id)) {
        session.skipped.push(original.id);
        continue;
      }
      if (head && answered && !stateIsShortStep(head.state)) continue;
      if (card.offline && card.dueAt > now) {
        if (head && stateIsShortStep(head.state)) waitUntil = Math.min(waitUntil ?? Infinity, card.dueAt);
        continue;
      }
      available.push(card);
    }
    available.sort((a, b) => Number(!!s.offlineHeads?.some((head) => head.cardId === b.id && head.index > 0 && stateIsShortStep(head.state))) - Number(!!s.offlineHeads?.some((head) => head.cardId === a.id && head.index > 0 && stateIsShortStep(head.state))));
    const next = available[0];
    if (next && session.results.length < 1e3) {
      session.current = clone2(next);
      if (next.offline && !session.frames?.some((card) => card.id === next.id && card.revision === next.revision)) (session.frames ??= []).push(clone2(next));
      this.sessionPanel(s, now);
      this.card(s, next, now);
      return;
    }
    delete session.current;
    if (waitUntil !== void 0 && session.results.length < 1e3) {
      session.waitUntil = waitUntil;
      this.sessionPanel(s, now);
      return;
    }
    this.finishSession(s, now);
  }
  finishSession(s, now, quiet = false) {
    const session = s.studySession;
    invalid(session);
    session.status = "finished";
    for (const row of s.outbox) if (row.pollPanel?.sessionId === session.id && !row.pollPanel.sealed) this.sealPoll(s, row, now);
    delete session.waitUntil;
    delete session.current;
    const unfinished = new Set(session.snapshot.cards.filter((card) => card.offline || !session.results.some((row) => row.cardId === card.id)).map((card) => card.id));
    const removed = new Set(s.handles.filter((handle2) => unfinished.has(String(handle2.action.cardId)) && ["answer", "reveal", "hint", "review", "select-option", "toggle-option", "submit-options", "skip-card"].includes(String(handle2.action.kind))).map((handle2) => handle2.id));
    s.handles = s.handles.filter((handle2) => !removed.has(handle2.id));
    this.cancelQueuedContent(s, new Set(s.outbox.filter((row) => row.status === "queued" && (row.answerHandle && removed.has(row.answerHandle) || row.hintLease && unfinished.has(row.hintLease.cardId) || row.payload.reply_markup?.inline_keyboard?.some((buttons) => buttons.some((button) => removed.has(button.callback_data))))).map((row) => row.id)));
    for (const cardId of unfinished) this.freezeHints(s, cardId, now, true);
    if (!quiet) {
      this.sessionPanel(s, now);
      this.sessionHistory(s, now);
    }
  }
  cancelSessionContent(s) {
    this.cancelQueuedContent(s, new Set(s.outbox.filter((row) => row.status === "queued" && row.sessionContent && row.sessionContent.sessionId !== s.studySession?.id).map((row) => row.id)));
  }
  card(s, card, now, reveal = false, answerMatch, deadline, dependency, exerciseFeedback) {
    invalid(card.exercise?.kind !== "matching" && card.exercise?.kind !== "ordering", "This exercise is available in the Mini App");
    if (card.offline) {
      invalid(s.offlineConsent === true);
      deadline = Math.min(deadline ?? Infinity, decodeOfflineSeed(card.offline).expiresAt);
    }
    const previousOutboxIds = new Set(s.outbox.map((row) => row.id));
    const replaceControls = card.evaluationMode === "exact" || !!card.media?.length;
    if (replaceControls || card.hints?.length) {
      const removed = new Set(s.handles.filter((h) => h.action.cardId === card.id && (replaceControls || h.action.kind === "hint")).map((h) => h.id));
      s.handles = s.handles.filter((h) => !removed.has(h.id));
      const cancelled = new Set(s.outbox.filter((o) => o.status === "queued" && (o.answerHandle !== void 0 && removed.has(o.answerHandle) || o.payload.reply_markup?.inline_keyboard?.some((row) => row.some((button) => removed.has(button.callback_data))))).map((o) => o.id));
      this.cancelQueuedContent(s, cancelled);
    }
    const showGuidance = s.domain.pending.length + s.domain.outcomes.length < 2;
    const snapshot = s.domain.snapshot, rendered = renderCard(card, snapshot, reveal, answerMatch, showGuidance, [], false, true, exerciseFeedback);
    const hints = [...s.outbox].reverse().find((row) => row.status !== "unknown" && row.hintPanel?.sessionId === s.studySession?.id && row.hintPanel?.cardId === card.id && row.hintPanel?.revision === card.revision);
    if (!reveal && hints?.hintPanel && now < hints.hintPanel.expiresAt) {
      rendered.buttons = rendered.buttons.map((button) => button.action.kind !== "hint" ? button : { text: "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438", action: {
        kind: "hint-panel",
        panelId: hints.id,
        index: hints.hintPanel.count - 1,
        collapsed: false
      } });
    }
    const attachments = card.media?.filter((asset) => asset.side === (reveal ? "answer" : "question")) ?? [];
    const combined = reveal && !attachments.length ? combinedGradeText(rendered.text, GRADE_PROMPT) : void 0;
    let after = dependency;
    if (!reveal) {
      for (const row of s.outbox) if (row.pollPanel && row.pollPanel.sessionId === s.studySession?.id && !row.pollPanel.sealed) this.sealPoll(s, row, now);
    }
    const pollContentStart = s.outbox.length;
    if (reveal && combined === void 0) after = this.message(s, { ...rendered, buttons: [] }, now, after, snapshot.sequence);
    for (const asset of attachments) {
      if (this.transport.cachedMedia?.(this.config.enrollment, asset)) {
        after = this.enqueue(s, mediaMethod(asset), {
          chat_id: this.config.ownerChatId,
          assetId: asset.id,
          kind: asset.kind,
          format: asset.format,
          bytes: asset.bytes,
          side: asset.side,
          ...asset.caption === void 0 ? {} : { caption: asset.caption },
          disable_notification: true
        }, snapshot.sequence, void 0, after);
        continue;
      }
      const placeholder = this.enqueue(s, "sendMessage", { chat_id: this.config.ownerChatId, text: loadingText(asset.kind), disable_notification: true, link_preview_options: { is_disabled: true }, reply_markup: { inline_keyboard: [] } }, snapshot.sequence, void 0, after, void 0, true);
      after = this.enqueue(s, "editMessageMedia", {
        chat_id: this.config.ownerChatId,
        assetId: asset.id,
        kind: asset.kind,
        format: asset.format,
        bytes: asset.bytes,
        side: asset.side,
        ...asset.caption === void 0 ? {} : { caption: asset.caption },
        disable_notification: true
      }, snapshot.sequence, void 0, placeholder, placeholder);
    }
    if (reveal) {
      const id2 = this.message(s, { text: combined ?? GRADE_PROMPT, buttons: rendered.buttons }, now, after, snapshot.sequence, deadline);
      const panel = s.outbox.find((row) => row.id === id2);
      panel.ratingPanel = {
        cardId: card.id,
        revision: card.revision,
        ...combined === void 0 ? {} : { answerText: rendered.text },
        ...answerMatch === void 0 ? {} : { answerMatch },
        ...exerciseFeedback === void 0 ? {} : { exerciseFeedback: clone2(exerciseFeedback) }
      };
      if (combined !== void 0 && s.studySession) panel.sessionContent = { sessionId: s.studySession.id, cardId: card.id, revision: card.revision };
      this.freezeHints(s, card.id, now, false);
    } else {
      const expiresAt = Math.min(snapshot.expiresAt, deadline ?? snapshot.expiresAt, s.studySession?.snapshot.expiresAt ?? snapshot.expiresAt);
      const pollExpiresAt = Math.floor(expiresAt / 1e3) * 1e3;
      const poll = this.transport.supportsNativePolls?.() === true && pollExpiresAt - now >= 1e4 ? nativePollView(card) : void 0;
      if (poll && s.studySession) {
        const controls = rendered.buttons.filter((button) => !["select-option", "toggle-option", "submit-options"].includes(String(button.action.kind)));
        const id3 = this.enqueue(s, "sendPoll", {
          chat_id: this.config.ownerChatId,
          ...poll,
          close_date: pollExpiresAt / 1e3,
          disable_notification: false,
          reply_markup: { inline_keyboard: this.keyboard(s, controls, now, pollExpiresAt) }
        }, snapshot.sequence, void 0, after);
        const row = s.outbox.find((row2) => row2.id === id3);
        row.pollPanel = { cardId: card.id, revision: card.revision, sessionId: s.studySession.id, expiresAt: pollExpiresAt };
        for (const content2 of s.outbox.slice(pollContentStart)) content2.sessionContent = { sessionId: s.studySession.id, cardId: card.id, revision: card.revision };
        return;
      }
      const id2 = this.message(s, rendered, now, after, snapshot.sequence, deadline);
      if (card.exercise || card.offline) {
        const panel = s.outbox.find((row) => row.id === id2);
        invalid(s.studySession);
        panel.questionPanel = {
          cardId: card.id,
          revision: card.revision,
          selectedOptionIndexes: [],
          expiresAt: Math.min(snapshot.expiresAt, deadline ?? snapshot.expiresAt),
          ...card.exercise?.kind === "single" || card.exercise?.kind === "multiple" ? { choiceLayout: card.exercise.kind === "multiple" ? "checkboxes" : "adaptive" } : {}
        };
        panel.sessionContent = { sessionId: s.studySession.id };
      }
    }
    if ((card.offline || exerciseFeedback !== void 0) && s.studySession) {
      for (const row of s.outbox) if (!previousOutboxIds.has(row.id) && !row.ratingPanel && row.method !== "stopPoll") row.sessionContent = { sessionId: s.studySession.id, cardId: card.id, revision: card.revision };
    }
  }
  answer(s, replyMessageId, text4, now) {
    const sent = s.outbox.find((o) => o.method === "sendMessage" && o.status === "sent" && o.messageId === replyMessageId && o.answerHandle !== void 0);
    const h = sent && s.handles.find((h2) => h2.id === sent.answerHandle);
    invalid(h && h.action.kind === "answer" && h.epoch === this.config.epoch && now < h.expiresAt, "stale");
    const snapshot = s.domain.snapshot;
    invalid(snapshot && sent.snapshotSequence === snapshot.sequence && h.sequence === snapshot.sequence && h.action.scope === snapshot.scope && h.action.epoch === snapshot.epoch && h.action.sequence === snapshot.sequence, "stale");
    const card = this.page(s, now, { kind: "answer" }).cards.find((c) => c.id === h.action.cardId && c.revision === h.action.revision);
    invalid(card && card.evaluationMode === "exact", "stale");
    if (card.offline) invalid(sent.questionPanel && this.questionCard(s, sent, now).revision === card.revision);
    let matched, exerciseFeedback;
    if (card.exercise) {
      invalid(card.exercise.kind === "cloze" && sent.questionPanel && this.questionCard(s, sent, now).id === card.id);
      const count = companionExerciseBlankCount(card.exercise), answers = count === 1 ? [text4] : text4.replace(/\r\n?/g, "\n").split("\n");
      if (answers.length !== count || answers.some((answer) => !answer.trim())) {
        this.message(s, { text: `\u041D\u0443\u0436\u043D\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u044C ${count} \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0430: \u043E\u0442\u043F\u0440\u0430\u0432\u044C\u0442\u0435 \u043A\u0430\u0436\u0434\u044B\u0439 \u043E\u0442\u0432\u0435\u0442 \u0441 \u043D\u043E\u0432\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438, \u0431\u0435\u0437 \u043D\u043E\u043C\u0435\u0440\u043E\u0432.`, buttons: [] }, now);
        return;
      }
      matched = evaluateCompanionExercise(card.exercise, { clozeAnswers: answers });
      exerciseFeedback = createCompanionExerciseFeedback(card.exercise, { clozeAnswers: answers });
    } else matched = card.acceptedAnswers === void 0 ? isExactTestAnswerCorrect(text4, card.reference, card.answerMatchMode) : isExplicitTestAnswerCorrect(text4, card.acceptedAnswers, card.answerMatchMode);
    this.card(s, card, now, true, matched, h.expiresAt, void 0, exerciseFeedback);
  }
  questionCard(s, panel, now, requireDelivery = true) {
    const p = panel.questionPanel, session = s.studySession, snapshot = this.effectiveSnapshot(s, now);
    invalid(p && (!requireDelivery || panel.status === "sent" && panel.messageId !== void 0) && session && session.id === panel.sessionContent?.sessionId && session.status !== "finished" && now < p.expiresAt && snapshot && companionSnapshotIsCurrent(snapshot, now) && panel.snapshotSequence === snapshot.sequence, "stale question");
    const card = snapshot.cards.find((card2) => card2.id === p.cardId && card2.revision === p.revision && card2.eligible);
    invalid(card && (card.exercise || card.offline) && sessionCards(session).some((row) => canonical2(row) === canonical2(card)) && !session.deferred?.includes(card.id) && !session.skipped.includes(card.id) && !this.suppressed(s).some((attempt) => attempt.cardId === card.id), "stale question");
    const buttons = panel.payload.reply_markup.inline_keyboard;
    invalid(s.handles.some((h) => h.action.cardId === card.id && h.action.revision === card.revision && now < h.expiresAt && (h.id === panel.answerHandle || buttons.some((row) => row.some((button) => button.callback_data === h.id)))), "replaced question");
    return card;
  }
  questionView(s, panel, card, now) {
    const view = renderCard(
      card,
      s.domain.snapshot,
      false,
      void 0,
      false,
      panel.questionPanel.selectedOptionIndexes,
      panel.questionPanel.choiceLayout === void 0,
      panel.questionPanel.choiceLayout === "checkboxes"
    );
    view.text = panel.payload.text;
    const hints = [...s.outbox].reverse().find((row) => row.status !== "unknown" && row.hintPanel?.sessionId === s.studySession?.id && row.hintPanel?.cardId === card.id && row.hintPanel?.revision === card.revision);
    if (hints?.hintPanel && now < hints.hintPanel.expiresAt) view.buttons = view.buttons.map((button) => button.action.kind !== "hint" ? button : {
      text: "\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438",
      action: { kind: "hint-panel", panelId: hints.id, index: hints.hintPanel.count - 1, collapsed: false }
    });
    return view;
  }
  updateQuestionPanel(s, panel, card, now) {
    const view = this.questionView(s, panel, card, now);
    const reply_markup = { inline_keyboard: this.keyboard(s, view.buttons, now, panel.questionPanel.expiresAt, true), ...view.answerAction ? { force_reply: true } : {} };
    validateQuestionPanelEdit(view.text, reply_markup);
    s.outbox = s.outbox.filter((row) => !(row.method === "editMessageText" && row.target === panel.id && row.status === "queued"));
    const id2 = this.enqueue(s, "editMessageText", { chat_id: this.config.ownerChatId, text: view.text, reply_markup, link_preview_options: { is_disabled: true } }, panel.snapshotSequence, void 0, panel.id, panel.id);
    s.outbox.find((row) => row.id === id2).sessionContent = { ...panel.sessionContent };
  }
  effectiveSnapshot(s, now, cardIds) {
    const snapshot = s.domain.snapshot;
    if (!snapshot) return;
    const heads = new Map((s.offlineHeads ?? []).map((head) => [head.cardId, head]));
    const knownRoots = new Set([...s.domain.pending, ...s.domain.outcomes.filter((row) => row.status === "applied").map((row) => row.attempt)].filter((row) => row.offline).map((row) => `${row.cardId}:${decodeOfflineStep(row.offline).rootRevision}`));
    for (const root of this.coldResultIndex(s).offlineRoots) knownRoots.add(root);
    const correcting = new Set(s.gradeCorrections?.filter((row) => !row.receipt).map((row) => row.correction.cardId));
    const { studyTarget: _studyTarget, ...effective } = snapshot;
    const indexed = cardIds && snapshotCardMap(snapshot);
    const cards = cardIds ? [...cardIds].flatMap((id2) => {
      const card = indexed.get(id2);
      return card ? [card] : [];
    }) : snapshot.cards;
    return { ...effective, cards: cards.flatMap((card) => {
      if (!card.offline) return [card];
      const head = heads.get(card.id), seed = head ? decodeOfflineSeed(head.seed) : snapshotOfflineSeed(snapshot, card.id);
      if (s.offlineConsent !== true || now >= seed.expiresAt || now + COMPANION_CLOCK_SKEW < seed.issuedAt) return [];
      if ((!head || head.index === 0) && knownRoots.has(`${card.id}:${seed.rootRevision}`)) return [];
      if (correcting.has(card.id)) return [];
      return [head ? projectOfflineCard(head) : card];
    }) };
  }
  renewOfflineBaselines(s, now) {
    const snapshot = s.domain.snapshot;
    if (s.offlineConsent !== true || !snapshot || !companionSnapshotIsCurrent(snapshot, now)) return;
    const cards = snapshotCardMap(snapshot);
    s.offlineHeads = s.offlineHeads?.map((head) => {
      const old = decodeOfflineSeed(head.seed), card = cards.get(head.cardId), next = card?.offline && decodeOfflineSeed(card.offline);
      if (old.expiresAt > now || !card || !next || next.expiresAt <= now || next.state !== head.state || next.rootRevision === old.rootRevision || s.domain.pending.some((attempt) => attempt.cardId === head.cardId && attempt.offline) || s.gradeCorrections?.some((row) => row.correction.cardId === head.cardId && !row.receipt)) return head;
      const { studyTarget: _studyTarget, ...baseline } = snapshot;
      return reconcileOfflineHeads([head], { ...baseline, cards: [card] }, now)[0];
    });
  }
  /** A new desktop baseline can replace settled ancestry after its presentation lease ends. */
  retireSettledOfflineHeads(s, now, replacingMiniApp = false) {
    const snapshot = s.domain.snapshot;
    if (!snapshot || !companionSnapshotIsCurrent(snapshot, now)) return;
    const cards = snapshotCardMap(snapshot), protectedIds = new Set(s.domain.pending.map((row) => row.cardId));
    for (const session of [s.studySession, ...!replacingMiniApp || s.miniApp?.session.status !== "finished" ? [s.miniApp?.session] : []])
      if (session && now < session.snapshot.expiresAt) for (const card of sessionCards(session)) protectedIds.add(card.id);
    for (const row of s.gradeCorrections ?? []) if (!row.receipt) protectedIds.add(row.correction.cardId);
    for (const handle2 of s.handles) if (handle2.expiresAt > now && typeof handle2.action.cardId === "string") protectedIds.add(handle2.action.cardId);
    for (const row of s.outbox) if (row.ratingPanel && s.editableGrades?.some((grade) => grade.attemptId === row.ratingPanel.attemptId && grade.expiresAt > now)) protectedIds.add(row.ratingPanel.cardId);
    const authored3 = (card) => canonical2(Object.fromEntries(Object.entries(card).filter(([key2]) => !["offline", "revision", "dueAt", "eligible"].includes(key2))));
    s.offlineHeads = s.offlineHeads?.filter((head) => {
      if (protectedIds.has(head.cardId)) return true;
      const card = cards.get(head.cardId);
      if (!card?.offline) return true;
      const old = decodeOfflineSeed(head.seed), next = decodeOfflineSeed(card.offline);
      if (head.index > 0 && (old.rootRevision === next.rootRevision || head.state !== next.state)) return true;
      return old.config !== next.config || authored3(head.baseCard) !== authored3(card);
    });
  }
  coldResultIndex(s) {
    const snapshot = s.domain.snapshot;
    if (!snapshot || !s.resultLedger?.archiveUsed) return { attempts: [], offlineRoots: /* @__PURE__ */ new Set() };
    invalid(this.journal.results, "Result archive unavailable");
    if (this.coldResults?.snapshot !== snapshot || this.coldResults.revision !== s.resultLedger.archiveRevision)
      this.coldResults = { snapshot, revision: s.resultLedger.archiveRevision, value: this.journal.results.suppressed(snapshot) };
    return this.coldResults.value;
  }
  suppressed(s) {
    const cards = s.domain.snapshot && snapshotCardMap(s.domain.snapshot);
    return [
      ...this.coldResultIndex(s).attempts,
      ...s.domain.pending.filter((attempt) => !attempt.offline),
      ...s.domain.outcomes.filter((row) => !row.attempt.offline && cards?.get(row.attempt.cardId)?.revision === row.attempt.revision).map((row) => row.attempt)
    ];
  }
  carryCardControls(s, next, now) {
    const needed = /* @__PURE__ */ new Set();
    for (const handle2 of s.handles) if (typeof handle2.action.cardId === "string") needed.add(handle2.action.cardId);
    for (const row of s.outbox) for (const id2 of [row.hintLease?.cardId, row.questionPanel?.cardId, row.hintPanel?.cardId]) if (id2) needed.add(id2);
    const old = needed.size ? this.effectiveSnapshot(s, now, needed) : void 0, retained = /* @__PURE__ */ new Set(), deliveries = /* @__PURE__ */ new Set();
    const unchanged = /* @__PURE__ */ new Map();
    if (old && old.scope === next.scope && old.epoch === next.epoch && companionSnapshotIsCurrent(old, now)) {
      const suppressed = new Set(this.suppressed(s).map((attempt) => attempt.cardId));
      const nextCards = /* @__PURE__ */ new Map(), heads = /* @__PURE__ */ new Map();
      for (const card of next.cards) if (needed.has(card.id) && !nextCards.has(card.id)) nextCards.set(card.id, card);
      for (const head of s.offlineHeads ?? []) if (!heads.has(head.cardId)) heads.set(head.cardId, head);
      for (const card of old.cards) {
        const nextBase = nextCards.get(card.id), head = heads.get(card.id);
        const candidateHead = nextBase?.offline && head ? reconcileOfflineHeads([head], { ...next, cards: [nextBase] }, now)[0] : void 0;
        const current = candidateHead ? projectOfflineCard(candidateHead) : nextBase;
        if (card.eligible && current?.eligible && !suppressed.has(card.id) && canonical2(card) === canonical2(current)) unchanged.set(card.id, card);
      }
      for (const h of s.handles) {
        const card = typeof h.action.cardId === "string" ? unchanged.get(h.action.cardId) : void 0;
        if (!card || !["answer", "reveal", "hint", "review", "select-option", "toggle-option", "submit-options", "skip-card"].includes(String(h.action.kind)) || h.epoch !== old.epoch || h.sequence !== old.sequence || h.action.scope !== old.scope || h.action.epoch !== old.epoch || h.action.sequence !== old.sequence || h.action.revision !== card.revision || now >= h.expiresAt) continue;
        h.sequence = next.sequence;
        h.action.sequence = next.sequence;
        h.expiresAt = Math.min(h.expiresAt, next.expiresAt);
        retained.add(h.id);
      }
      for (const row of s.outbox) if (row.snapshotSequence === old.sequence && (row.answerHandle !== void 0 && retained.has(row.answerHandle) || row.payload.reply_markup?.inline_keyboard?.some((buttons) => buttons.some((button) => retained.has(button.callback_data))))) deliveries.add(row.id);
      for (const row of s.outbox) {
        const lease = row.hintLease, card = lease && unchanged.get(lease.cardId), hint = lease && card?.hints?.[lease.index];
        if (!lease || !card || hint === void 0 || row.status !== "queued" || row.snapshotSequence !== old.sequence || lease.revision !== card.revision || now >= lease.expiresAt) continue;
        const header = `\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430 ${lease.index + 1} \u0438\u0437 ${card.hints.length}:
`;
        if (row.payload.text !== header + hint || canonical2(row.payload.entities) !== canonical2([{ type: "spoiler", offset: header.length, length: hint.length }])) continue;
        lease.expiresAt = Math.min(lease.expiresAt, next.expiresAt);
        deliveries.add(row.id);
      }
      for (const row of s.outbox) {
        const p = row.questionPanel, card = p && unchanged.get(p.cardId);
        if (!p || !card || row.sessionContent?.sessionId !== s.studySession?.id || p.revision !== card.revision || now >= p.expiresAt || row.snapshotSequence !== old.sequence) continue;
        p.expiresAt = Math.min(p.expiresAt, next.expiresAt);
        deliveries.add(row.id);
        for (const edit of s.outbox) if (edit.target === row.id && edit.snapshotSequence === old.sequence) deliveries.add(edit.id);
      }
      for (const row of s.outbox) {
        const p = row.hintPanel, card = p && unchanged.get(p.cardId);
        if (!p || !card || p.sessionId !== s.studySession?.id || p.revision !== card.revision || now >= p.expiresAt || row.snapshotSequence !== old.sequence) continue;
        p.expiresAt = Math.min(p.expiresAt, next.expiresAt);
        deliveries.add(row.id);
        for (const edit of s.outbox) if (edit.target === row.id && edit.snapshotSequence === old.sequence) deliveries.add(edit.id);
      }
      for (const row of [...s.outbox].reverse()) if (deliveries.has(row.id) && row.after !== void 0) deliveries.add(row.after);
      for (const row of s.outbox) if (deliveries.has(row.id) && row.snapshotSequence === old.sequence) row.snapshotSequence = next.sequence;
    }
    s.handles = s.handles.filter((h) => {
      if (h.action.kind === "hint-panel") {
        const panel = s.outbox.find((row) => row.id === h.action.panelId), p = panel?.hintPanel;
        if (!panel || !p || p.sessionId !== s.studySession?.id || now >= p.expiresAt || now >= h.expiresAt) return false;
        return s.studySession.results.some((row) => row.cardId === p.cardId) || unchanged.has(p.cardId);
      }
      if (String(h.action.kind).startsWith("session-")) return s.studySession?.id === h.action.sessionId && now < h.expiresAt;
      if (["change-saved-grade", "replace-saved-grade"].includes(String(h.action.kind))) return s.editableGrades?.some((row) => row.attemptId === h.action.attemptId && row.expiresAt > now) && now < h.expiresAt;
      if (["change-grade", "replace-grade"].includes(String(h.action.kind))) {
        const pending = s.domain.pending.find((attempt) => attempt.id === h.action.attemptId);
        return pending && (pending.offline || next.cards.some((card) => card.id === pending.cardId && card.revision === pending.revision)) && now < h.expiresAt;
      }
      return h.sequence === 0 || retained.has(h.id);
    });
    return deliveries;
  }
  page(s, now, action) {
    const snapshot = this.effectiveSnapshot(s, now);
    invalid(snapshot, "stale");
    const chatSnapshot = { ...snapshot, cards: snapshot.cards.filter((card) => card.exercise?.kind !== "matching" && card.exercise?.kind !== "ordering") };
    return queryCards(chatSnapshot, this.suppressed(s), { now, all: ["all", "material", "reveal", "review", "answer", "hint", "select-option", "toggle-option", "submit-options", "skip-card"].includes(String(action.kind)), materialId: typeof action.materialId === "string" ? action.materialId : void 0, search: typeof action.search === "string" ? action.search : void 0, cursor: typeof action.cursor === "string" ? action.cursor : void 0 });
  }
  retireChatStudy(s, now) {
    const active = !!s.studySession && s.studySession.status !== "finished", count = s.outbox.length;
    if (active) this.finishSession(s, now, true);
    this.cancelQueuedContent(s, new Set(s.outbox.filter((row) => row.status === "queued" && (row.sessionContent || row.sessionPanel || row.hintLease || row.hintPanel || row.questionPanel || row.pollPanel || row.richDemoPanel || row.snapshotSequence !== void 0 && !row.ratingPanel?.attemptId)).map((row) => row.id)));
    s.outbox = s.outbox.filter((row) => row.status !== "queued" || row.payload.text !== MEDIA_LOADING_ERROR);
    return active || s.outbox.length !== count;
  }
  miniAppLauncher(s, now, planId) {
    invalid(this.config.miniAppUrl, "Mini App unavailable");
    if (planId !== void 0) invalid(this.planLaunchEntry(s, planId, now), "Study plan entry unavailable");
    this.retireChatStudy(s, now);
    if (s.outbox.some((row) => row.status === "queued" && row.payload.text === MINI_APP_LAUNCH_TEXT && row.miniAppPlan === planId)) return;
    const id2 = this.message(s, { text: MINI_APP_LAUNCH_TEXT, buttons: [], disableNotification: true }, now);
    if (planId !== void 0) s.outbox.find((row) => row.id === id2).miniAppPlan = planId;
  }
  act(s, action, now, handleId, deadline, delivery) {
    if (this.config.miniAppUrl && !["status", "snooze", "skip", "notifications"].includes(String(action.kind))) {
      this.miniAppLauncher(s, now);
      return;
    }
    if (action.kind === "rich-demo") {
      this.actRichDemo(s, action, handleId, now);
      return;
    }
    if (["go", "material"].includes(String(action.kind)) && s.miniApp?.session.status === "active" && miniAppSessionAllowed(s, now)) {
      this.message(s, { text: "\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u043E \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438. \u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435 \u0438\u043B\u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u0435\u0433\u043E \u0442\u0430\u043C, \u0437\u0430\u0442\u0435\u043C \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go.", buttons: [] }, now);
      return;
    }
    if (action.kind === "go") {
      this.renewOfflineBaselines(s, now);
      if (s.studySession && s.studySession.status !== "finished" && now >= s.studySession.snapshot.expiresAt && s.domain.snapshot && companionSnapshotIsCurrent(s.domain.snapshot, now)) this.finishSession(s, now);
    }
    const showGuidance = s.domain.pending.length + s.domain.outcomes.length < 2;
    const clickedPanel = delivery?.target ? s.outbox.find((row) => row.id === delivery.target) : delivery;
    if (action.kind === "hint-panel") {
      const panel = s.outbox.find((row) => row.id === action.panelId), p = panel?.hintPanel;
      invalid(panel && p && panel.status === "sent" && panel.messageId !== void 0 && Number.isSafeInteger(action.index) && Number(action.index) >= 0 && Number(action.index) < p.count && typeof action.collapsed === "boolean", "stale hints");
      this.hintCard(s, panel, now);
      p.index = Number(action.index);
      p.collapsed = action.collapsed;
      this.updateHintPanel(s, panel, now);
      return;
    }
    if (String(action.kind).startsWith("session-")) {
      const session = s.studySession;
      invalid(session && session.id === action.sessionId, "stale session");
      if (action.kind === "session-history") {
        this.sessionHistory(s, now, Number(action.offset ?? 0));
        return;
      }
      if (action.kind === "session-result") {
        this.sessionResult(s, now, String(action.cardId), action.attemptId === void 0 ? void 0 : String(action.attemptId));
        return;
      }
      if (action.kind === "session-pause") {
        if (session.status !== "finished") session.status = "paused";
        this.sessionPanel(s, now);
        return;
      }
      if (action.kind === "session-finish") {
        this.finishSession(s, now);
        return;
      }
      if (action.kind === "session-new") {
        invalid(session.status === "finished");
        this.act(s, { kind: "go" }, now);
        return;
      }
      if (action.kind === "session-resume") {
        if (session.status !== "finished") session.status = "active";
        this.sessionNext(s, now);
        return;
      }
    }
    if (action.kind === "go" && s.studySession && s.studySession.status !== "finished") {
      this.sessionNext(s, now);
      return;
    }
    if (action.kind === "change-saved-grade" || action.kind === "replace-saved-grade") {
      const attempt = this.resultAttempt(s, String(action.attemptId));
      invalid(attempt);
      if (attempt.offline && s.offlineHeads?.find((head) => head.cardId === attempt.cardId)?.lastAttemptId !== attempt.id) {
        this.gradePanel(s, attempt, now, "correction-rejected", void 0, deadline, clickedPanel);
        return;
      }
      const editable = s.editableGrades?.find((row) => row.attemptId === attempt.id && row.expiresAt > now);
      const waiting = s.gradeCorrections?.find((row) => row.correction.attemptId === attempt.id && !row.receipt);
      if (waiting) {
        this.gradePanel(s, { ...attempt, rating: waiting.correction.rating, correct: waiting.correction.correct }, now, "correcting", void 0, deadline, clickedPanel);
        return;
      }
      if (!editable) {
        this.gradePanel(s, attempt, now, "correction-rejected", void 0, deadline, clickedPanel);
        return;
      }
      if (editable.reviewEventId !== action.expectedReviewEventId) {
        this.gradePanel(s, attempt, now, "applied", void 0, deadline, clickedPanel);
        return;
      }
      if (action.kind === "change-saved-grade") {
        this.gradePanel(s, attempt, now, "changing", editable.answerMatch, Math.min(editable.expiresAt, deadline ?? editable.expiresAt), clickedPanel);
        return;
      }
      invalid(handleId && [1, 2, 3, 4].includes(Number(action.rating)) && action.correct === (action.rating !== 1) && !(editable.answerMatch === true && action.rating === 1));
      if (editable.rating === action.rating) {
        this.gradePanel(s, attempt, now, "applied", void 0, deadline, clickedPanel);
        return;
      }
      const correction = {
        id: handleId,
        scope: attempt.scope,
        epoch: attempt.epoch,
        attemptId: attempt.id,
        cardId: attempt.cardId,
        revision: attempt.revision,
        expectedReviewEventId: editable.reviewEventId,
        rating: action.rating,
        correct: action.correct,
        requestedAt: now
      };
      validateCompanionGradeCorrection(correction);
      (s.gradeCorrections ??= []).push({ correction });
      this.gradePanel(s, { ...attempt, rating: correction.rating, correct: correction.correct }, now, "correcting", void 0, deadline);
      return;
    }
    if (action.kind === "change-grade" || action.kind === "replace-grade") {
      const pending = s.domain.pending.find((attempt) => attempt.id === action.attemptId);
      const outcome = s.domain.outcomes.find((row) => row.attempt.id === action.attemptId);
      if (!pending || s.claimedAttempts?.includes(pending.id)) {
        const attempt = pending ?? this.resultAttempt(s, String(action.attemptId));
        invalid(attempt, "stale");
        this.gradePanel(s, attempt, now, outcome ? outcome.status === "applied" ? "applied" : "rejected" : "sent");
        return;
      }
      const offlineHead = pending.offline && s.offlineHeads?.find((head) => head.cardId === pending.cardId);
      if (pending.offline && (!offlineHead || offlineHead.lastAttemptId !== pending.id)) {
        this.gradePanel(s, pending, now, "correction-rejected", void 0, deadline, clickedPanel);
        return;
      }
      if (action.kind === "change-grade") {
        this.gradePanel(s, pending, now, "changing", action.answerMatch, deadline, clickedPanel);
        return;
      }
      invalid(handleId && [1, 2, 3, 4].includes(Number(action.rating)) && action.correct === (action.rating !== 1) && !(action.answerMatch === true && action.rating === 1));
      const replacement = { ...pending, id: handleId, rating: action.rating, correct: action.correct };
      if (offlineHead) {
        (s.supersededOfflineReviews ??= []).push({ attempt: clone2(pending), seed: offlineHead.seed });
        const step = decodeOfflineStep(pending.offline);
        step.after = advanceOfflineFsrs(offlineHead.seed, step.before, replacement.correct ? replacement.rating : 1, replacement.occurredAt);
        replacement.offline = encodeOfflineStep(step);
        offlineHead.state = step.after;
        offlineHead.lastAttemptId = replacement.id;
        s.handles = s.handles.filter((handle2) => !(handle2.action.cardId === pending.cardId && handle2.action.revision === pending.id));
        this.cancelQueuedContent(s, new Set(s.outbox.filter((row) => row.status === "queued" && (row.sessionContent?.cardId === pending.cardId && row.sessionContent.revision === pending.id || row.questionPanel?.cardId === pending.cardId && row.questionPanel.revision === pending.id || row.ratingPanel?.cardId === pending.cardId && row.ratingPanel.revision === pending.id && !row.ratingPanel.attemptId)).map((row) => row.id)));
        this.freezeHints(s, pending.cardId, now, true, pending.id);
      }
      validateAttempt(replacement);
      s.domain.pending = s.domain.pending.map((attempt) => attempt.id === pending.id ? replacement : attempt);
      for (const result of s.studySession?.results ?? []) if (result.attemptId === pending.id) result.attemptId = replacement.id;
      for (const panel of s.outbox) if (panel.ratingPanel?.attemptId === pending.id) panel.ratingPanel.attemptId = replacement.id;
      this.gradePanel(s, replacement, now, "selected", action.answerMatch, deadline);
      if (offlineHead && s.studySession?.status === "active" && (s.studySession.waitUntil !== void 0 || s.studySession.current?.id === pending.cardId)) this.sessionNext(s, now);
      return;
    }
    if (action.kind === "snooze") {
      invalid([12, 24, "next"].includes(action.hours));
      s.mutedUntil = action.hours === "next" ? nextSession(now, this.config.timeZone, this.config.sessionsLocal, s.lastSession) : now + Number(action.hours) * 36e5;
      this.message(s, { text: "\u041D\u0430\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u044F \u043E\u0442\u043B\u043E\u0436\u0435\u043D\u044B. \u0420\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u043E.", buttons: [] }, now);
      return;
    }
    if (action.kind === "notifications") {
      s.domain.reminders.enabled = action.enabled === true;
      this.message(s, { text: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043D\u0430\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0439 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B. \u0420\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u043E.", buttons: [] }, now);
      return;
    }
    if (action.kind === "skip") {
      s.domain.reminders.skippedDay = studyDay(now, this.config.timeZone);
      this.message(s, { text: "\u041D\u0430\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u044F \u043F\u0440\u043E\u043F\u0443\u0449\u0435\u043D\u044B \u0434\u043E \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0433\u043E \u0443\u0447\u0435\u0431\u043D\u043E\u0433\u043E \u0434\u043D\u044F (\u0433\u0440\u0430\u043D\u0438\u0446\u0430 04:00 \u043F\u043E \u0447\u0430\u0441\u043E\u0432\u043E\u043C\u0443 \u043F\u043E\u044F\u0441\u0443 Obsidian). \u0420\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u043E.", buttons: [] }, now);
      return;
    }
    const snapshot = s.domain.snapshot;
    if (action.kind === "search" && action.search === void 0) {
      this.message(s, { text: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 search \u0438 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u0430 \u0438\u043B\u0438 \u0441\u043B\u043E\u0432\u0430 \u0432\u043E\u043F\u0440\u043E\u0441\u0430.", buttons: [] }, now);
      return;
    }
    if (action.kind === "status") {
      invalid(action.details === void 0 || typeof action.details === "boolean");
      if (action.details !== true && action.offset === void 0) {
        const totals = resultCounts(s);
        this.message(s, renderCompanionStatus({
          now,
          lastContactAt: s.bridgeTimeFloor,
          pending: s.domain.pending.length,
          applied: totals.applied,
          rejected: totals.rejected,
          pendingCorrections: s.gradeCorrections?.filter((row) => !row.receipt).length ?? 0,
          ...snapshot ? { snapshot: { generatedAt: snapshot.generatedAt, expiresAt: snapshot.expiresAt } } : {}
        }), now);
        return;
      }
      const offset = Number(action.offset ?? 0);
      invalid(Number.isSafeInteger(offset) && offset >= 0);
      const total = resultCounts(s).total, end = Math.max(0, total - offset), rows = resultHistory(s, this.journal.results, this.config.scope, this.config.epoch, offset);
      this.message(s, {
        text: `\u041E\u0436\u0438\u0434\u0430\u044E\u0442 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F Obsidian: ${s.domain.pending.length}. \u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432: ${total}.
${rows.map((o) => `${o.attempt.cardId}: ${o.status}`).join("\n") || "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0439 \u0435\u0449\u0451 \u043D\u0435\u0442."}`,
        buttons: [
          ...end > 20 ? [{ text: "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0435 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B", action: { kind: "status", details: true, offset: offset + 20 } }] : [],
          { text: "\u041A\u0440\u0430\u0442\u043A\u0438\u0439 \u0441\u0442\u0430\u0442\u0443\u0441", action: { kind: "status" } }
        ]
      }, now);
      return;
    }
    invalid(snapshot && companionSnapshotIsCurrent(snapshot, now), "stale");
    if (handleId) invalid(action.scope === snapshot.scope && action.epoch === snapshot.epoch && action.sequence === snapshot.sequence, "stale");
    if (["reveal", "hint", "review", "select-option", "toggle-option", "submit-options", "skip-card"].includes(String(action.kind)) && this.suppressed(s).some((attempt) => attempt.cardId === action.cardId)) throw new AlreadyAnswered();
    const page2 = this.page(s, now, action);
    if (clickedPanel?.pollPanel && ["reveal", "hint", "skip-card"].includes(String(action.kind))) {
      const card = this.pollCard(s, clickedPanel, now);
      if (action.kind === "reveal") {
        const after = this.sealPoll(s, clickedPanel, now);
        this.card(s, card, now, true, void 0, deadline, after);
        return;
      }
      if (action.kind === "skip-card") this.sealPoll(s, clickedPanel, now);
    }
    if (action.kind === "skip-card") {
      const card = page2.cards.find((card2) => card2.id === action.cardId && card2.revision === action.revision), session = s.studySession;
      invalid(handleId && card && session && session.status !== "finished" && !session.deferred?.includes(card.id) && !session.skipped.includes(card.id) && sessionCards(session).some((row) => canonical2(row) === canonical2(card)), "stale session");
      (session.deferred ??= []).push(card.id);
      const removed = new Set(s.handles.filter((h) => h.action.cardId === card.id).map((h) => h.id));
      s.handles = s.handles.filter((h) => !removed.has(h.id));
      this.cancelQueuedContent(s, new Set(s.outbox.filter((row) => row.status === "queued" && (row.questionPanel?.cardId === card.id || row.answerHandle && removed.has(row.answerHandle) || row.payload.reply_markup?.inline_keyboard?.some((buttons) => buttons.some((button) => removed.has(button.callback_data))))).map((row) => row.id)));
      this.freezeHints(s, card.id, now, true);
      this.sessionNext(s, now);
      return;
    }
    if (["select-option", "toggle-option", "submit-options"].includes(String(action.kind))) {
      invalid(handleId);
      const panel = s.outbox.find((row) => row.questionPanel?.cardId === action.cardId && row.questionPanel.revision === action.revision && row.sessionContent?.sessionId === s.studySession?.id && row.status === "sent" && row.messageId !== void 0 && row.payload.reply_markup.inline_keyboard.some((buttons) => buttons.some((button) => button.callback_data === handleId)));
      const editedPanel = !panel && clickedPanel?.questionPanel ? clickedPanel : panel;
      invalid(editedPanel);
      const card = this.questionCard(s, editedPanel, now), exercise = card.exercise;
      invalid(exercise.kind === "single" || exercise.kind === "multiple");
      if (action.kind === "select-option") {
        invalid(exercise.kind === "single" && Number.isSafeInteger(action.index) && Number(action.index) >= 0 && Number(action.index) < exercise.options.length);
        this.card(
          s,
          card,
          now,
          true,
          evaluateCompanionExercise(exercise, { selectedOptionIndexes: [Number(action.index)] }),
          deadline,
          void 0,
          createCompanionExerciseFeedback(exercise, { selectedOptionIndexes: [Number(action.index)] })
        );
        return;
      }
      invalid(exercise.kind === "multiple");
      const selected = editedPanel.questionPanel.selectedOptionIndexes;
      if (action.kind === "toggle-option") {
        const index2 = Number(action.index);
        invalid(Number.isSafeInteger(index2) && index2 >= 0 && index2 < exercise.options.length);
        editedPanel.questionPanel.selectedOptionIndexes = selected.includes(index2) ? selected.filter((value) => value !== index2) : [...selected, index2].sort((a, b) => a - b);
        this.updateQuestionPanel(s, editedPanel, card, now);
        return;
      }
      invalid(selected.length > 0);
      this.card(
        s,
        card,
        now,
        true,
        evaluateCompanionExercise(exercise, { selectedOptionIndexes: selected }),
        deadline,
        void 0,
        createCompanionExerciseFeedback(exercise, { selectedOptionIndexes: selected })
      );
      return;
    }
    if (["hint", "reveal", "review"].includes(String(action.kind))) invalid(!s.studySession?.deferred?.includes(String(action.cardId)), "skipped question");
    if (action.kind === "hint") {
      invalid(handleId);
      const card = page2.cards.find((c) => c.id === action.cardId && c.revision === action.revision), index2 = Number(action.index);
      invalid(card?.hints && Number.isSafeInteger(index2) && index2 >= 0 && index2 < card.hints.length, "stale");
      const session = s.studySession;
      invalid(session && session.status !== "finished" && sessionCards(session).some((row) => canonical2(row) === canonical2(card)), "stale session");
      let panel = [...s.outbox].reverse().find((row) => row.status !== "unknown" && row.hintPanel?.sessionId === session.id && row.hintPanel.cardId === card.id && row.hintPanel.revision === card.revision);
      if (clickedPanel?.pollPanel && panel?.hintPanel && !panel.hintPanel.readOnly) {
        panel.hintPanel.collapsed = false;
        this.updateHintPanel(s, panel, now);
        return;
      }
      invalid(index2 === (panel?.hintPanel?.count ?? 0) && !panel?.hintPanel?.readOnly, "hint order differs");
      if (!panel) {
        const id2 = this.message(s, { text: hintPanelView(card.hints, 1, 0, false).text, buttons: [], disableNotification: true }, now, void 0, snapshot.sequence, deadline);
        panel = s.outbox.find((row) => row.id === id2);
        panel.hintPanel = { cardId: card.id, revision: card.revision, sessionId: session.id, count: 1, index: 0, collapsed: false, expiresAt: Math.min(snapshot.expiresAt, deadline ?? snapshot.expiresAt) };
        panel.sessionContent = { sessionId: session.id };
      } else {
        panel.hintPanel.count = index2 + 1;
        panel.hintPanel.index = index2;
        panel.hintPanel.collapsed = false;
      }
      this.updateHintPanel(s, panel, now);
      return;
    }
    if (action.kind === "review") {
      invalid(handleId);
      const c = page2.cards.find((c2) => c2.id === action.cardId && c2.revision === action.revision);
      invalid(c, "stale");
      invalid([1, 2, 3, 4].includes(Number(action.rating)) && typeof action.correct === "boolean");
      const attempt = appendCompanionReview(s, c, handleId, action.rating, action.correct, now);
      this.gradePanel(s, attempt, now, "selected", action.answerMatch, deadline, delivery);
      const session = s.studySession;
      if (session && session.status !== "finished" && sessionCards(session).some((card) => card.id === c.id && card.revision === c.revision)) {
        invalid(c.offline || !session.results.some((row) => row.cardId === c.id));
        session.results.push({ cardId: c.id, attemptId: attempt.id, ...c.offline ? { card: clone2(c) } : {} });
      }
      this.freezeHints(s, c.id, now, true);
      if (showGuidance) this.message(s, { text: "\u041E\u0442\u0432\u0435\u0442 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 \u0431\u043E\u0442\u0430. Obsidian \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442 \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u0435; \u0435\u0433\u043E \u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u043C\u0435\u044E\u0442 \u043F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442.", buttons: [] }, now);
      if (session && session.status !== "finished") {
        this.sessionNext(s, now);
        return;
      }
      const next = this.page(s, now, { kind: "material", materialId: c.materialId }).cards[0];
      if (next) this.card(s, next, now);
      else this.message(s, { text: "\u0412 \u044D\u0442\u043E\u043C \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 go.", buttons: [] }, now);
      return;
    }
    if (action.kind === "material" || action.kind === "reveal") {
      if (action.kind === "material") {
        if (s.studySession && s.studySession.status !== "finished") {
          this.sessionPanel(s, now);
          this.sessionHistory(s, now);
          return;
        }
        invalid(page2.cards.length > 0);
        const originals = page2.cards.slice(0, 1e3).map((card) => card.offline ? ensureOfflineHead(s.offlineHeads ??= [], s.domain.snapshot, card.id).baseCard : card);
        const { studyTarget: _studyTarget, cards: _cards, ...sessionSnapshot } = snapshot;
        s.studySession = { id: this.id(), snapshot: { ...sessionSnapshot, expiresAt: Math.min(snapshot.expiresAt, ...originals.map((card) => card.offline ? decodeOfflineSeed(card.offline).expiresAt : snapshot.expiresAt)), cards: clone2(originals) }, status: "active", results: [], skipped: [], deferred: [] };
        this.cancelSessionContent(s);
        this.sessionNext(s, now);
        return;
      }
      const c = action.kind === "reveal" ? page2.cards.find((c2) => c2.id === action.cardId && c2.revision === action.revision) : page2.cards[0];
      invalid(c, "stale");
      this.card(s, c, now, action.kind === "reveal", void 0, deadline);
      return;
    }
    invalid(["go", "more", "all", "search"].includes(String(action.kind)));
    if (!page2.totalMaterials && ["go", "all"].includes(String(action.kind)) && queryCards(snapshot, this.suppressed(s), { now, all: true }).cards.some((card) => card.exercise?.kind === "matching" || card.exercise?.kind === "ordering")) {
      this.message(s, { text: "\u0421\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0438 \u043F\u043E\u0440\u044F\u0434\u043E\u043A \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /app, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435.", buttons: [] }, now);
      return;
    }
    if (page2.materials.length > 20) {
      for (let i = 0; i < page2.materials.length; i += 20) this.message(s, renderMaterials(snapshot, { ...page2, materials: page2.materials.slice(i, i + 20) }, showGuidance), now);
    } else this.message(s, renderMaterials(snapshot, page2, showGuidance), now);
  }
  unavailableAction(s, request, now) {
    const handle2 = request.handle ? s.handles.find((row) => row.id === request.handle) : void 0;
    if (handle2?.action.kind === "rich-demo") return "\u041F\u0440\u043E\u0431\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u0438\u043B\u0438 \u0441\u0440\u043E\u043A \u0435\u0451 \u043A\u043D\u043E\u043F\u043E\u043A \u0438\u0441\u0442\u0451\u043A. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /checkboxdemo, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u043E\u0432\u0443\u044E.";
    const delivery = [...s.outbox].reverse().find((row) => row.status === "sent" && (request.pollId ? row.pollPanel?.pollId === request.pollId : request.handle ? row.payload.reply_markup?.inline_keyboard?.some((buttons) => buttons.some((button) => button.callback_data === request.handle)) : request.replyToMessageId !== void 0 && row.messageId === request.replyToMessageId && row.answerHandle !== void 0));
    const source = delivery?.target ? s.outbox.find((row) => row.id === delivery.target) : delivery;
    const action = handle2?.action ?? (source?.answerHandle ? s.handles.find((row) => row.id === source.answerHandle)?.action : void 0);
    const kind2 = String(action?.kind ?? ""), learning = source?.answerHandle !== void 0 || ["answer", "reveal", "hint", "hint-panel", "review", "select-option", "toggle-option", "submit-options", "skip-card"].includes(kind2);
    let sessionId = typeof action?.sessionId === "string" ? action.sessionId : source?.sessionContent?.sessionId ?? source?.sessionPanel?.sessionId ?? source?.hintPanel?.sessionId ?? source?.pollPanel?.sessionId;
    if (!sessionId && source && (source.ratingPanel || learning)) {
      const index2 = s.outbox.indexOf(source);
      sessionId = s.outbox.slice(0, index2).reverse().find((row) => row.sessionPanel)?.sessionPanel?.sessionId;
    }
    const session = s.studySession, snapshotExpired = s.domain.snapshot && now >= s.domain.snapshot.expiresAt;
    const command = request.text?.trim().replace(/^\//, "").toLowerCase();
    if (!sessionId && session && !request.handle && request.replyToMessageId === void 0 && ["go", "start", "history", "pause", "resume", "finish"].includes(command ?? "")) sessionId = session.id;
    const restart = "\u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u0447\u0430\u0442\u044C \u043D\u043E\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435.";
    const synchronize = "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0439\u0442\u0435 Telegram \u0432 Obsidian, \u0437\u0430\u0442\u0435\u043C \u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u0447\u0430\u0442\u044C \u043D\u043E\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435.";
    if (sessionId && sessionId !== session?.id) return (request.replyToMessageId === void 0 ? "\u042D\u0442\u0430 \u043A\u043D\u043E\u043F\u043A\u0430 \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F" : "\u042D\u0442\u043E\u0442 \u0432\u043E\u043F\u0440\u043E\u0441 \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0441\u044F") + " \u043A \u043F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0435\u043C\u0443 \u0437\u0430\u043D\u044F\u0442\u0438\u044E. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0442\u0435\u043A\u0443\u0449\u0435\u0435 \u0438\u043B\u0438 \u043D\u0430\u0447\u0430\u0442\u044C \u043D\u043E\u0432\u043E\u0435.";
    if (session && sessionId === session.id && now >= session.snapshot.expiresAt) return "\u0421\u0440\u043E\u043A \u044D\u0442\u043E\u0433\u043E \u0437\u0430\u043D\u044F\u0442\u0438\u044F \u0438\u0441\u0442\u0451\u043A. " + (snapshotExpired ? synchronize : restart);
    if (session?.status === "finished" && sessionId === session.id && (learning || source?.ratingPanel || source?.questionPanel)) return "\u042D\u0442\u043E \u0437\u0430\u043D\u044F\u0442\u0438\u0435 \u0443\u0436\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E. " + restart;
    const needsSnapshot = learning || ["material", "more", "all", "search"].includes(kind2) || sessionId !== void 0 || command === "go" || command === "start";
    if (snapshotExpired && needsSnapshot) return "\u0421\u0440\u043E\u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043A\u043E\u043F\u0438\u0438 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0438\u0441\u0442\u0451\u043A. " + synchronize;
    if (handle2 && now >= handle2.expiresAt) return "\u0421\u0440\u043E\u043A \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u044D\u0442\u043E\u0439 \u043A\u043D\u043E\u043F\u043A\u0438 \u0438\u0441\u0442\u0451\u043A. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F.";
    return "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E: \u043A\u043D\u043E\u043F\u043A\u0430 \u0438\u043B\u0438 \u0441\u043D\u0438\u043C\u043E\u043A \u0443\u0441\u0442\u0430\u0440\u0435\u043B\u0438 \u043B\u0438\u0431\u043E \u0437\u0430\u043F\u0440\u043E\u0441 \u043D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0435\u043D. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 go; \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u043D\u0438\u043C\u043E\u043A \u0438\u0437 Obsidian \u043F\u0440\u0438 \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u0438.";
  }
  async webhook(raw, secretHeader, now) {
    invalid(Buffer.byteLength(raw) <= 65536);
    timestamp(now);
    invalid(secretHeader.length <= 256 && equal(secretHeader, this.config.webhookSecret), "unauthorized");
    const u = JSON.parse(raw);
    record2(u);
    keys(u, ["update_id", "message", "callback_query", "poll_answer"]);
    invalid([u.message, u.callback_query, u.poll_answer].filter((value) => value !== void 0).length === 1);
    const update = verifyPrivateTelegramUpdate(raw, secretHeader, { enabled: true, webhookSecret: this.config.webhookSecret, userId: this.config.ownerUserId, chatId: this.config.ownerChatId });
    invalid(update.updateId >= 0);
    const result = await this.serial(async () => {
      invalid(this.active);
      const s = cloneServerState(this.state), hash2 = digest(u);
      const archive = s.replayArchived ? this.journal.replay : void 0;
      const previous = s.updates.find((r) => r.id === update.updateId)?.hash ?? archive?.get(s.binding, "update", String(update.updateId));
      if (previous !== void 0) {
        invalid(previous === hash2);
        return { ok: true };
      }
      s.updates.push({ id: update.updateId, hash: hash2 });
      if (update.callbackId) {
        const callbackHash = digest({ handle: update.handle });
        const existing = s.callbackIds.find((c) => c.id === update.callbackId)?.hash ?? archive?.get(s.binding, "callback", update.callbackId);
        if (existing !== void 0) {
          invalid(existing === callbackHash, "callback collision");
          await this.commit(s);
          return { ok: true };
        }
        s.callbackIds.push({ id: update.callbackId, hash: callbackHash });
        this.enqueue(s, "answerCallbackQuery", { callback_query_id: update.callbackId });
      }
      const working = cloneServerState(s);
      try {
        if (update.pollId !== void 0) {
          if (this.config.miniAppUrl) this.miniAppLauncher(working, now);
          else this.pollAnswer(working, update.pollId, update.optionIds, now);
        } else if (update.handle) {
          const h = working.handles.find((h2) => h2.id === update.handle);
          if (this.config.miniAppUrl && (!h || !["status", "snooze", "skip", "notifications"].includes(String(h.action.kind)))) {
            this.miniAppLauncher(working, now);
            await this.commit(working);
            return { ok: true };
          }
          if ([...working.domain.pending, ...working.domain.outcomes.map((outcome) => outcome.attempt)].some((attempt) => attempt.id === update.handle) || h && ["reveal", "hint", "review", "select-option", "toggle-option", "submit-options", "skip-card"].includes(String(h.action.kind)) && this.suppressed(working).some((attempt) => attempt.cardId === h.action.cardId)) throw new AlreadyAnswered();
          invalid(h && h.epoch === this.config.epoch && now < h.expiresAt && (h.sequence === 0 || h.sequence === (working.domain.snapshot?.sequence ?? 0)), "stale");
          const deliveries = working.outbox.filter((o) => (o.method === "sendMessage" || o.method === "editMessageText" || o.method === "sendPoll") && o.payload.reply_markup?.inline_keyboard?.some((row) => row.some((button) => button.callback_data === h.id)));
          const delivery = h.action.kind === "rich-demo" ? working.outbox.find((row) => row.id === h.action.panelId && row.method === "sendRichMessage") : ["select-option", "toggle-option", "submit-options"].includes(String(h.action.kind)) ? [...deliveries].reverse().find((row) => row.status === "sent") : deliveries.at(-1);
          invalid(delivery?.after === void 0 || delivery.status === "sent", "delivery incomplete");
          this.act(working, h.action, now, h.id, h.expiresAt, delivery);
          if (h.action.kind === "review" && working.domain.pending.length + working.domain.outcomes.length > 2) {
            invalid(working.domain.pending.some((attempt) => attempt.id === h.id));
            const acknowledgement = working.outbox.find((row) => row.method === "answerCallbackQuery" && row.payload.callback_query_id === update.callbackId);
            invalid(acknowledgement);
            acknowledgement.payload.text = GRADE_SAVED_NOTICE;
          }
        } else {
          const text4 = (update.text ?? "").trim();
          const planParameter = /^\/?start(?:@[A-Za-z0-9_]+)?\s+(\S+)$/i.exec(text4)?.[1];
          const planId = planParameter && parseStudyPlanStartParameter(planParameter);
          if (planId && this.config.miniAppUrl) this.miniAppLauncher(working, now, planId);
          else if (/^\/?checkboxdemo$/i.test(text4)) {
            if (this.config.miniAppUrl) this.miniAppLauncher(working, now);
            else this.richDemo(working, now);
          } else if (update.replyToMessageId !== void 0) {
            if (this.config.miniAppUrl) this.miniAppLauncher(working, now);
            else this.answer(working, update.replyToMessageId, update.text ?? "", now);
          } else if (/^\/?(go|start|app)(?:@[A-Za-z0-9_]+)?$/i.test(text4)) {
            if (!this.config.miniAppUrl && /^\/?app/i.test(text4)) this.message(working, { text: "Mini App \u0435\u0449\u0451 \u043D\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D. \u041E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0443 \u0441\u0435\u0440\u0432\u0438\u0441\u0430.", buttons: [] }, now);
            else this.act(working, { kind: "go" }, now);
          } else if (/^\/?notifications (on|off)$/i.test(text4)) this.act(working, { kind: "notifications", enabled: / on$/i.test(text4) }, now);
          else if (/^\/?skip$/i.test(text4)) this.act(working, { kind: "skip" }, now);
          else if (/^\/?status$/i.test(text4)) this.act(working, { kind: "status" }, now);
          else if (this.config.miniAppUrl && /^\/?finish(?:@[A-Za-z0-9_]+)?$/i.test(text4)) {
            finishMiniAppSession(working, now);
            this.message(working, { text: "\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043E. \u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043E\u0446\u0435\u043D\u043A\u0438 \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u0432 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0438 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438.", buttons: [] }, now);
            this.miniAppLauncher(working, now);
          } else if (/^\/?(history|pause|resume|finish)$/i.test(text4)) {
            if (this.config.miniAppUrl) this.miniAppLauncher(working, now);
            else if (!working.studySession) this.message(working, { text: "\u041D\u0430\u0447\u043D\u0438\u0442\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435 \u0447\u0435\u0440\u0435\u0437 /go.", buttons: [] }, now);
            else this.act(working, { kind: "session-" + text4.replace(/^\//, "").toLowerCase(), sessionId: working.studySession.id }, now);
          } else if (/^\/?search(?:\s|$)/i.test(text4)) {
            const q = text4.replace(/^\/?search\s*/i, "");
            invalid(q.length <= 200);
            this.act(working, q ? { kind: "search", search: q } : { kind: "search" }, now);
          } else if (this.config.miniAppUrl) this.miniAppLauncher(working, now);
          else this.message(working, { text: "\u041A\u043E\u043C\u0430\u043D\u0434\u044B: go \u2014 \u0437\u0430\u043D\u044F\u0442\u0438\u0435; history \u2014 \u0435\u0433\u043E \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B; pause / resume \u2014 \u043F\u0430\u0443\u0437\u0430 \u0438 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0435\u043D\u0438\u0435; finish \u2014 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C; search \u0442\u0435\u043A\u0441\u0442 \u2014 \u043F\u043E\u0438\u0441\u043A; status \u2014 \u043E\u0447\u0435\u0440\u0435\u0434\u044C. \u0414\u043B\u044F \u0442\u043E\u0447\u043D\u043E\u0433\u043E \u043E\u0442\u0432\u0435\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u043E\u0442\u0432\u0435\u0442 \u043D\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441 \u0432\u043E\u043F\u0440\u043E\u0441\u043E\u043C.", buttons: [] }, now);
        }
      } catch (error) {
        this.message(s, { text: error instanceof AlreadyAnswered ? "\u041E\u0442\u0432\u0435\u0442 \u043D\u0430 \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u0443\u0436\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D. \u041F\u043E\u0432\u0442\u043E\u0440\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u043D\u0435 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0430. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C." : this.unavailableAction(s, update, now), buttons: [] }, now);
        await this.commit(s);
        return { ok: true };
      }
      await this.commit(working);
      return { ok: true };
    });
    if (update.callbackId && (this.flushing || this.callbackFlushing)) void this.flushCallbacks().catch(() => void 0);
    return result;
  }
  async bridge(path, raw, signature, now, binary = false) {
    invalid(Buffer.byteLength(raw) <= MAX_COMPANION_BRIDGE_BYTES && /^[a-f0-9]{64}$/.test(signature));
    timestamp(now);
    const e = JSON.parse(raw);
    record2(e);
    keys(e, ["version", "method", "path", "scope", "epoch", "enrollment", "time", "nonce", "payload"]);
    invalid(e.version === 1 && e.method === "POST" && e.path === path && ["/bridge/snapshot", "/bridge/pending", "/bridge/ack"].includes(path));
    invalid(e.scope === this.config.scope && e.epoch === this.config.epoch && e.enrollment === this.config.enrollment);
    timestamp(e.time);
    token2(e.nonce);
    invalid(Math.abs(now - e.time) <= COMPANION_CLOCK_SKEW && equal(signature, sign(this.config.bridgeSecret, e)), "unauthorized");
    return this.serial(async () => {
      invalid(this.active);
      const s = cloneServerState(this.state), hash2 = digest(e);
      invalid(now >= s.bridgeTimeFloor, "server clock rollback; wait for clock recovery");
      s.bridgeTimeFloor = now;
      s.nonces = s.nonces.filter((n) => n.time + COMPANION_CLOCK_SKEW >= now);
      const previous = s.nonces.find((n) => n.nonce === e.nonce);
      if (previous) {
        invalid(previous.hash === hash2, "nonce collision");
        await this.commit(s);
        return clone2(previous.response);
      }
      invalid(s.nonces.length < 1e4);
      let response;
      record2(e.payload);
      let uploadResponse;
      let uploadStartedAt;
      let catalogCommit;
      if (path === "/bridge/snapshot" && ["catalog-pages-begin", "catalog-pages-missing", "catalog-pages-put", "catalog-pages-put-batch", "catalog-pages-commit"].includes(String(e.payload.operation))) {
        invalid(this.catalogTransfer, "paged catalog storage unavailable; update the server");
        const transfer = await this.catalogTransfer.accept(e.payload, now, s.catalogRevision ?? null, s.domain.snapshot?.sequence);
        if ("response" in transfer) uploadResponse = transfer;
        else {
          catalogCommit = transfer;
          uploadStartedAt = transfer.startedAt;
          const { context: _context, ...payload } = transfer.payload;
          e.payload = payload;
        }
      }
      record2(e.payload);
      if (path === "/bridge/snapshot" && ["large-payload-begin", "large-payload-chunk", "large-payload-commit"].includes(String(e.payload.operation))) {
        const transfer = this.largePayload.accept(e.payload, now);
        if ("payload" in transfer) {
          e.payload = transfer.payload;
          uploadStartedAt = transfer.startedAt;
        } else uploadResponse = transfer;
      }
      record2(e.payload);
      if (uploadResponse) response = uploadResponse.response;
      else if (path === "/bridge/snapshot" && e.payload.operation === "media-chunk") {
        validateCompanionMediaChunk(e.payload, binary ? MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES : MAX_COMPANION_MEDIA_CHUNK_BYTES);
        invalid(this.media, "media storage unavailable");
        response = await this.media.put(e.payload);
        validateCompanionMediaAck(response, e.payload.asset);
      } else if (path === "/bridge/snapshot" && e.payload.operation === "study-context") {
        keys(e.payload, ["operation", "context"]);
        validateCompanionStudyContext(e.payload.context);
        const contextCards = s.domain.snapshot ? snapshotCardMap(s.domain.snapshot) : /* @__PURE__ */ new Map();
        const contextMaterials = new Set(s.materialConsentIds ?? []);
        invalid(s.domain.snapshot && companionSnapshotIsCurrent(s.domain.snapshot, now) && e.payload.context.cards.every((row) => {
          const card = contextCards.get(row.id);
          return card && contextMaterials.has(card.materialId);
        }), "study metadata consent differs");
        s.studyContext = clone2(e.payload.context);
        response = { accepted: true };
        delete s.catalogRevision;
        delete s.catalogRoot;
      } else if (path === "/bridge/snapshot" && e.payload.operation === "study-plan") {
        keys(e.payload, ["operation", "plan"]);
        validateCompanionStudyPlan(e.payload.plan);
        const plan = e.payload.plan;
        invalid(plan.timeZone === this.config.timeZone && Math.abs((uploadStartedAt ?? now) - plan.generatedAt) <= COMPANION_CLOCK_SKEW && now < plan.expiresAt, "study plan clock mismatch");
        invalid(!s.studyPlan || plan.generatedAt > s.studyPlan.generatedAt || plan.generatedAt === s.studyPlan.generatedAt && jsonFingerprintEqual(plan, s.studyPlan), "study plan generation differs");
        s.studyPlan = clone2(plan);
        s.studyPlanSent ??= [];
        this.reconcilePlanDeliveries(s, now);
        response = { accepted: true };
      } else if (path === "/bridge/snapshot") {
        keys(e.payload, ["snapshot", "consentIds", "timeZone", "materialConsentIds", "attachmentConsent", "offlineConsent"]);
        invalid(e.payload.timeZone === this.config.timeZone, "vault timezone mismatch");
        if (catalogCommit) validateImmutableSnapshot(e.payload.snapshot);
        else validateSnapshot(e.payload.snapshot);
        const snapshot = e.payload.snapshot;
        invalid(e.payload.offlineConsent === void 0 || typeof e.payload.offlineConsent === "boolean");
        const offlineConsent = e.payload.offlineConsent ?? false;
        invalid(offlineConsent || !snapshot.cards.some((card) => card.offline));
        invalid(snapshot.scope === this.config.scope && snapshot.epoch === this.config.epoch);
        invalid(companionSnapshotIsCurrent(snapshot, now) && (uploadStartedAt ?? now) - snapshot.generatedAt <= COMPANION_CLOCK_SKEW);
        invalid(Array.isArray(e.payload.consentIds) && e.payload.consentIds.every((v) => typeof v === "string"));
        const consentIds = new Set(e.payload.consentIds);
        invalid(snapshot.cards.every((c) => consentIds.has(c.id)));
        const materialConsentIds = e.payload.materialConsentIds ?? [...new Set(snapshot.cards.map((card) => card.materialId))];
        invalid(Array.isArray(materialConsentIds) && new Set(materialConsentIds).size === materialConsentIds.length);
        materialConsentIds.forEach(token2);
        const materialConsent = new Set(materialConsentIds);
        invalid(snapshot.cards.every((card) => materialConsent.has(card.materialId)));
        const attachmentConsent = e.payload.attachmentConsent ?? snapshot.cards.some((card) => card.hints?.length || card.media?.length);
        invalid(typeof attachmentConsent === "boolean" && (attachmentConsent || !snapshot.cards.some((card) => card.hints?.length || card.media?.length)));
        const checkedMedia = /* @__PURE__ */ new Map();
        for (const card of snapshot.cards) for (const asset of card.media ?? []) {
          const identity5 = { id: asset.id, kind: asset.kind, format: asset.format, bytes: asset.bytes }, checked = checkedMedia.get(asset.id);
          if (checked) invalid(canonical2(checked) === canonical2(identity5), "media identity collision");
          else {
            invalid(this.media && await this.media.has(identity5), "snapshot media incomplete");
            checkedMedia.set(asset.id, identity5);
          }
        }
        const old = s.domain.snapshot;
        delete s.studyContext;
        s.materialConsentIds = [...materialConsentIds];
        s.attachmentConsent = attachmentConsent;
        if (s.studySession?.snapshot.cards.some((card) => !materialConsent.has(card.materialId) || !attachmentConsent && (card.media?.length || card.hints?.length) || card.offline && !offlineConsent)) s.studySession = void 0;
        this.cancelSessionContent(s);
        s.editableGrades = s.editableGrades?.filter((row) => materialConsent.has(row.materialId) && (attachmentConsent || !row.withAttachments));
        if (old && snapshot.sequence === old.sequence) {
          invalid(catalogCommit && s.catalogRoot && jsonFingerprintEqual(catalogCommit.root.snapshot, s.catalogRoot.snapshot) || jsonFingerprintEqual(snapshot, old), "snapshot collision");
          if (catalogCommit) s.domain.snapshot = snapshot;
        } else {
          invalid(!old || snapshot.sequence > old.sequence);
          const activeCards = [
            ...s.studySession && s.studySession.status !== "finished" ? sessionCards(s.studySession) : [],
            ...s.miniApp && s.miniApp.session.status !== "finished" ? sessionCards(s.miniApp.session) : []
          ];
          const retainedIds = new Set(activeCards.map((card) => card.id));
          const priorHeads = (s.offlineHeads ?? []).filter((head) => head.index > 0 || retainedIds.has(head.cardId));
          if (s.domain.snapshot) {
            for (const card of activeCards) if (card.offline && !priorHeads.some((head) => head.cardId === card.id))
              ensureOfflineHead(priorHeads, s.domain.snapshot, card.id);
          }
          const nextHeads = offlineConsent ? reconcileOfflineHeads(priorHeads, snapshot, now, s.domain.pending, true) : [];
          const retainedDeliveries = this.carryCardControls(s, snapshot, now);
          s.domain.snapshot = catalogCommit ? snapshot : clone2(snapshot);
          s.offlineConsent = offlineConsent;
          s.offlineHeads = nextHeads;
          this.retireSettledOfflineHeads(s, now);
          this.cancelQueuedContent(s, new Set(s.outbox.filter((o) => o.status === "queued" && o.snapshotSequence !== void 0 && !o.ratingPanel?.attemptId && !retainedDeliveries.has(o.id)).map((o) => o.id)));
        }
        if (offlineConsent === false) {
          s.offlineConsent = false;
          s.offlineHeads = [];
        }
        this.retirePolls(s, now);
        this.reconcilePlanDeliveries(s, now);
        response = { sequence: snapshot.sequence };
        if (!catalogCommit) {
          delete s.catalogRevision;
          delete s.catalogRoot;
        }
      } else if (path === "/bridge/pending" && e.payload.operation === "snapshot-capacity") {
        keys(e.payload, ["operation", "version"]);
        invalid(e.payload.version === void 0 || e.payload.version === 2);
        response = { maxCards: e.payload.version === 2 ? 1e5 : 1e3, maxBytes: MAX_COMPANION_BRIDGE_BYTES };
      } else if (path === "/bridge/pending" && e.payload.operation === "catalog-pages-capacity") {
        keys(e.payload, ["operation", "version"]);
        invalid(e.payload.version === void 0 || e.payload.version === 1 || e.payload.version === 2);
        invalid(this.catalogTransfer, "paged catalog storage unavailable");
        response = {
          version: e.payload.version ?? 1,
          maxCards: null,
          maxBytes: MAX_COMPANION_BRIDGE_BYTES,
          pageBytes: CATALOG_PAGE_BYTES,
          referenceBatch: CATALOG_REFERENCE_BATCH,
          gzip: true,
          baseRevision: s.catalogRevision ?? null
        };
      } else if (path === "/bridge/pending" && e.payload.operation === "large-payload-capacity") {
        keys(e.payload, ["operation"]);
        response = { version: 1, maxBytes: MAX_COMPANION_SNAPSHOT_BYTES, chunkBytes: MAX_COMPANION_SNAPSHOT_CHUNK_BYTES };
      } else if (path === "/bridge/pending" && e.payload.operation === "media-upload-capacity") {
        keys(e.payload, ["operation", "version"]);
        invalid(e.payload.version === void 0 || e.payload.version === 2 || e.payload.version === 3);
        invalid(this.media?.status, "media status unavailable");
        response = {
          version: e.payload.version ?? 1,
          chunkBytes: e.payload.version === 3 ? MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES : MAX_COMPANION_MEDIA_CHUNK_BYTES,
          maxAssets: MAX_COMPANION_MEDIA_STATUS_ASSETS,
          ...e.payload.version !== void 0 ? { binary: true } : {}
        };
      } else if (path === "/bridge/pending" && e.payload.operation === "media-status") {
        keys(e.payload, ["operation", "assets"]);
        validateCompanionMediaStatusAssets(e.payload.assets);
        invalid(this.media?.status, "media status unavailable");
        const assets = e.payload.assets, files = await this.media.status(assets);
        invalid(Array.isArray(files) && files.length === assets.length);
        files.forEach((file, index2) => validateCompanionMediaAck(file, assets[index2]));
        response = { files };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-context-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-filter-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-plan-action-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1, ...this.config.botUsername ? { botUsername: this.config.botUsername } : {} };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-plan-calendar-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1, calendarStatus: true, ...this.config.botUsername ? { botUsername: this.config.botUsername } : {} };
      } else if (path === "/bridge/pending" && e.payload.operation === "card-report-capabilities") {
        keys(e.payload, ["operation"]);
        s.cardReportsEnabled = true;
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "answer-history-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1, retainAnswers: s.retainAnswers === true, retainAnswersChangedAt: s.retainAnswersChangedAt ?? 0 };
      } else if (path === "/bridge/pending" && e.payload.operation === "answer-history") {
        keys(e.payload, ["operation"]);
        const records = [];
        let bytes = Buffer.byteLength('{"records":[]}');
        for (const value of pendingAnswerHistory(s, 50)) {
          const row = { record: value, capability: answerHistoryCapability(this.config.bridgeSecret, this.config.enrollment, value) }, size = Buffer.byteLength(JSON.stringify(row)) + (records.length ? 1 : 0);
          if (bytes + size > 48e4) break;
          records.push(row);
          bytes += size;
        }
        response = { records };
      } else if (path === "/bridge/pending" && e.payload.operation === "written-recall-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "written-recalls") {
        keys(e.payload, ["operation"]);
        const recalls = [];
        let bytes = Buffer.byteLength('{"recalls":[]}');
        for (const recall of (s.writtenRecalls ?? []).slice(0, 50)) {
          const row = { recall, capability: writtenRecallCapability(this.config.bridgeSecret, this.config.enrollment, recall) };
          const size = Buffer.byteLength(JSON.stringify(row)) + (recalls.length ? 1 : 0);
          if (bytes + size > 48e4) break;
          recalls.push(row);
          bytes += size;
        }
        response = { recalls };
      } else if (path === "/bridge/pending" && e.payload.operation === "card-reports") {
        keys(e.payload, ["operation"]);
        response = { reports: (s.cardReports ?? []).slice(0, 100).map((report) => ({ report, capability: cardReportCapability(this.config.bridgeSecret, this.config.enrollment, report) })) };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-plan-actions") {
        keys(e.payload, ["operation"]);
        response = { commands: (s.planCommands ?? []).slice(0, 100).map((command) => ({ command, capability: planCommandCapability(this.config.bridgeSecret, this.config.enrollment, command) })) };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-plan-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "study-target-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "offline-fsrs-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, engine: OFFLINE_FSRS_ENGINE };
      } else if (path === "/bridge/pending" && e.payload.operation === "snapshot-lifetime") {
        keys(e.payload, ["operation"]);
        response = { version: 1, maxLifetimeMs: COMPANION_STUDY_COPY_TTL };
      } else if (path === "/bridge/pending" && e.payload.operation === "early-short-repeat-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true };
      } else if (path === "/bridge/pending" && e.payload.operation === "bank-practice-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true, version: 1 };
      } else if (path === "/bridge/pending" && e.payload.operation === "correction-capabilities") {
        keys(e.payload, ["operation"]);
        response = { supported: true };
      } else if (path === "/bridge/pending" && e.payload.operation === "corrections") {
        keys(e.payload, ["operation"]);
        response = { corrections: (s.gradeCorrections ?? []).filter((row) => !row.receipt).slice(0, 100).map((row) => ({ correction: row.correction, capability: correctionCapability(this.config.bridgeSecret, this.config.enrollment, row.correction) })) };
      } else if (path === "/bridge/pending") {
        keys(e.payload, []);
        const attempts2 = s.domain.pending.slice(0, 100), claimed = new Set(s.claimedAttempts ?? []);
        for (const attempt of attempts2) if (!claimed.has(attempt.id)) {
          claimed.add(attempt.id);
          this.gradePanel(s, attempt, now, "sent");
        }
        s.claimedAttempts = [...claimed];
        response = { attempts: attempts2.map((attempt) => ({ attempt, capability: this.capability(attempt) })) };
      } else if (path === "/bridge/ack" && e.payload.operation === "study-plan-action") {
        keys(e.payload, ["operation", "command", "capability", "receipt"]);
        invalid(verifyPlanCommandCapability(this.config.bridgeSecret, this.config, e.payload.command, e.payload.capability), "unauthorized plan command");
        const command = e.payload.command;
        acknowledgeCompanionPlanCommand(s, command, e.payload.receipt);
        this.reconcilePlanDeliveries(s, now);
        response = { id: command.id, status: e.payload.receipt.status };
      } else if (path === "/bridge/ack" && e.payload.operation === "card-report") {
        keys(e.payload, ["operation", "report", "capability", "receipt"]);
        invalid(verifyCardReportCapability(this.config.bridgeSecret, this.config, e.payload.report, e.payload.capability), "unauthorized card report");
        const report = e.payload.report;
        acknowledgeCompanionCardReport(s, report, e.payload.receipt);
        response = { id: report.id, status: e.payload.receipt.status };
      } else if (path === "/bridge/ack" && e.payload.operation === "answer-retention") {
        keys(e.payload, ["operation", "enabled", "changedAt"]);
        invalid(typeof e.payload.enabled === "boolean");
        timestamp(e.payload.changedAt);
        const changedAt = e.payload.changedAt;
        invalid(changedAt <= now + COMPANION_CLOCK_SKEW, "Answer retention time is ahead of the server clock");
        if (changedAt === (s.retainAnswersChangedAt ?? 0) && s.retainAnswers !== void 0) invalid(s.retainAnswers === e.payload.enabled, "Answer retention timestamp collision");
        if (s.retainAnswers === void 0 || changedAt > (s.retainAnswersChangedAt ?? 0)) {
          s.retainAnswers = e.payload.enabled;
          s.retainAnswersChangedAt = changedAt;
          if (!s.retainAnswers && s.miniApp) {
            delete s.miniApp.retainedAnswer;
            if (s.miniApp.selfRecall && !s.miniApp.currentAttemptId) s.miniApp.selfRecall.answer = "";
          }
        }
        response = { enabled: s.retainAnswers === true, changedAt: s.retainAnswersChangedAt ?? 0 };
      } else if (path === "/bridge/ack" && e.payload.operation === "answer-history") {
        keys(e.payload, ["operation", "record", "capability", "receipt"]);
        invalid(verifyAnswerHistoryCapability(this.config.bridgeSecret, this.config, e.payload.record, e.payload.capability), "Unauthorized answer history");
        const value = e.payload.record;
        hydrateResult(s, this.journal.results, this.config.scope, this.config.epoch, value.attempt.id, now);
        invalid(s.domain.outcomes.some((row) => sameAttempt(row.attempt, value.attempt)), "Answer history grade not acknowledged");
        acknowledgeAnswerHistory(s, value, e.payload.receipt);
        response = { id: value.attempt.id, status: e.payload.receipt.status };
      } else if (path === "/bridge/ack" && e.payload.operation === "written-recall") {
        keys(e.payload, ["operation", "recall", "capability", "receipt"]);
        invalid(verifyWrittenRecallCapability(this.config.bridgeSecret, this.config, e.payload.recall, e.payload.capability), "unauthorized written recall");
        const recall = e.payload.recall;
        hydrateResult(s, this.journal.results, this.config.scope, this.config.epoch, recall.attempt.id, now);
        invalid(s.domain.outcomes.some((row) => sameAttempt(row.attempt, recall.attempt)), "written recall grade not acknowledged");
        acknowledgeCompanionWrittenRecall(s, recall, e.payload.receipt);
        response = { id: recall.attempt.id, status: e.payload.receipt.status };
      } else if (e.payload.operation === "correction") {
        keys(e.payload, ["operation", "correction", "capability", "receipt"]);
        validateCompanionGradeCorrection(e.payload.correction);
        const correction = e.payload.correction;
        hydrateResult(s, this.journal.results, this.config.scope, this.config.epoch, correction.attemptId, now);
        invalid(correction.scope === this.config.scope && correction.epoch === this.config.epoch && typeof e.payload.capability === "string" && equal(e.payload.capability, correctionCapability(this.config.bridgeSecret, this.config.enrollment, correction)));
        const row = s.gradeCorrections?.find((row2) => row2.correction.id === correction.id);
        invalid(row && canonical2(row.correction) === canonical2(correction));
        validateCompanionGradeCorrectionReceipt(e.payload.receipt, correction);
        const receipt = e.payload.receipt;
        if (row.receipt) invalid(canonical2(row.receipt) === canonical2(receipt), "correction receipt collision");
        else {
          const editable = s.editableGrades?.find((grade) => grade.attemptId === correction.attemptId);
          if (receipt.status === "applied") {
            if (editable) {
              invalid(editable.reviewEventId === correction.expectedReviewEventId);
              editable.reviewEventId = receipt.reviewEventId;
              editable.rating = correction.rating;
            }
          } else s.editableGrades = s.editableGrades?.filter((grade) => grade.attemptId !== correction.attemptId);
          row.receipt = clone2(receipt);
          const attempt = this.resultAttempt(s, correction.attemptId);
          invalid(attempt);
          if (attempt.offline && receipt.status === "applied") s.offlineHeads = s.offlineHeads?.filter((head) => head.cardId !== attempt.cardId);
          this.gradePanel(s, attempt, now, receipt.status === "applied" ? "applied" : "correction-rejected");
        }
        response = { id: correction.id, status: receipt.status };
      } else {
        keys(e.payload, ["attempt", "capability", "receipt", "correctable"]);
        validateAttempt(e.payload.attempt);
        const attempt = e.payload.attempt;
        invalid(e.payload.correctable === void 0 || typeof e.payload.correctable === "boolean");
        invalid(attempt.scope === this.config.scope && attempt.epoch === this.config.epoch && typeof e.payload.capability === "string" && equal(e.payload.capability, this.capability(attempt)));
        record2(e.payload.receipt);
        const receipt = e.payload.receipt;
        keys(receipt, attempt.mode === "core" ? ["attempt", "status", "reviewEventId", "nextDueAt", "charge"] : ["attempt", "status", "reviewEventId", "nextDueAt"]);
        record2(receipt.attempt);
        const { offline: _offline, ...publicAttempt } = attempt;
        invalid(canonical2(receipt.attempt) === canonical2(attempt.mode === "core" ? { ...publicAttempt, receivedAt: attempt.occurredAt } : publicAttempt));
        invalid(statuses.includes(receipt.status));
        const status = receipt.status;
        invalid(attempt.mode === "core" || ["applied", "stale", "epoch-mismatch", "missing", "ineligible", "local-session-active", "expired", "clock-mismatch"].includes(status));
        if (attempt.mode === "core" && status === "applied") {
          token2(receipt.reviewEventId);
          timestamp(receipt.nextDueAt);
          record2(receipt.charge);
          keys(receipt.charge, ["day", "kind"]);
          invalid(Number.isSafeInteger(receipt.charge.day) && ["new", "review", "step"].includes(String(receipt.charge.kind)));
        } else if (attempt.mode === "bank" && status === "applied") {
          invalid(receipt.charge === void 0);
          if (e.payload.correctable === true || receipt.reviewEventId !== void 0 || receipt.nextDueAt !== void 0) {
            token2(receipt.reviewEventId);
            timestamp(receipt.nextDueAt);
          }
        } else invalid(receipt.reviewEventId === void 0 && receipt.nextDueAt === void 0 && receipt.charge === void 0);
        hydrateResult(s, this.journal.results, this.config.scope, this.config.epoch, attempt.id, now);
        const outcome = s.domain.outcomes.find((o) => o.attempt.id === attempt.id);
        if (outcome) invalid(sameAttempt(outcome.attempt, attempt) && outcome.status === status && s.receipts.find((r) => r.id === attempt.id)?.hash === digest(receipt));
        else {
          const pending = s.domain.pending.find((a) => a.id === attempt.id);
          invalid(pending && sameAttempt(pending, attempt));
          s.receipts.push({ id: attempt.id, hash: digest(receipt) });
          s.domain.outcomes.push({ attempt: clone2(attempt), status });
          s.domain.pending = s.domain.pending.filter((a) => a.id !== attempt.id);
          addResultOrdinal(s, attempt.id, status);
          s.claimedAttempts = s.claimedAttempts?.filter((id2) => id2 !== attempt.id);
          if (status === "applied" && e.payload.correctable === true) {
            const panel = s.outbox.find((row) => row.ratingPanel?.attemptId === attempt.id);
            const miniResult = s.miniApp?.session.results.find((row) => row.attemptId === attempt.id);
            const expiresAt = s.handles.find((handle2) => handle2.id === attempt.id)?.expiresAt ?? (miniResult && s.miniApp?.session.snapshot.expiresAt) ?? s.studySession?.snapshot.expiresAt ?? s.domain.snapshot?.expiresAt ?? now;
            const source = miniResult?.card ?? (s.studySession && sessionCards(s.studySession).find((card) => card.id === attempt.cardId && card.revision === attempt.revision)) ?? s.domain.snapshot?.cards.find((card) => card.id === attempt.cardId && card.revision === attempt.revision);
            const withAttachments = !!(source?.hints?.length || source?.media?.length);
            const answerMatch = s.miniAppAttempts?.find((row) => row.id === attempt.id)?.answerMatch ?? panel?.ratingPanel?.answerMatch;
            if (source && (s.materialConsentIds?.includes(source.materialId) ?? true) && (s.attachmentConsent !== false || !withAttachments)) (s.editableGrades ??= []).push({ attemptId: attempt.id, materialId: source.materialId, withAttachments, reviewEventId: receipt.reviewEventId, rating: attempt.rating, expiresAt, ...answerMatch === void 0 ? {} : { answerMatch } });
          }
          this.gradePanel(s, attempt, now, status === "applied" ? "applied" : "rejected");
          if (attempt.offline && status !== "applied") {
            const root = decodeOfflineStep(attempt.offline).rootRevision;
            s.offlineHeads = s.offlineHeads?.filter((head) => head.cardId !== attempt.cardId || decodeOfflineSeed(head.seed).rootRevision !== root);
          }
        }
        response = { id: attempt.id, status };
      }
      if (catalogCommit) {
        if (catalogCommit.payload.context) {
          const context = catalogCommit.payload.context;
          validateImmutableStudyContext(context);
          const cards = snapshotCardMap(s.domain.snapshot), materials = new Set(s.materialConsentIds ?? []);
          invalid(context.cards.every((row) => {
            const card = cards.get(row.id);
            return card && materials.has(card.materialId);
          }), "study metadata consent differs");
          s.studyContext = context;
        } else delete s.studyContext;
        s.catalogRoot = clone2(catalogCommit.root);
        s.catalogRevision = catalogCommit.revision;
        response = { sequence: s.domain.snapshot.sequence, revision: catalogCommit.revision };
      }
      s.nonces.push({ nonce: e.nonce, time: e.time, hash: hash2, response: clone2(response) });
      await this.commit(s);
      return clone2(response);
    });
  }
  capability(attempt) {
    return pendingCapability(this.config.bridgeSecret, this.config.enrollment, attempt);
  }
  mediaErrorEdit(s, target) {
    if (s.outbox.some((o) => o.method === "editMessageText" && o.target === target.id)) return;
    this.enqueue(s, "editMessageText", { chat_id: this.config.ownerChatId, text: MEDIA_LOADING_ERROR, link_preview_options: { is_disabled: true } }, void 0, void 0, target.id, target.id);
  }
  reconcileMediaFailures(s) {
    let changed = false;
    for (const item of [...s.outbox]) {
      if (item.status !== "unknown" || item.failureHandled || !(isMediaMethod(item.method) || item.mediaPlaceholder || item.hintPanel || item.questionPanel || item.method === "editMessageText" || item.method === "sendPoll" || item.method === "stopPoll" || item.method === "sendRichMessage")) continue;
      item.failureHandled = true;
      changed = true;
      if (item.richDemoPanel || item.method === "editMessageText" && s.outbox.find((row) => row.id === item.target)?.richDemoPanel) {
        this.message(s, { text: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u043E\u043A\u0430\u0437 \u043F\u0440\u043E\u0431\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0438 Rich Messages. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /checkboxdemo, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u043F\u0440\u043E\u0431\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u043D\u043E\u0432\u043E.", buttons: [] }, Date.now());
        continue;
      }
      if (item.method === "sendPoll" || item.method === "stopPoll") {
        this.message(s, { text: item.method === "sendPoll" ? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043E\u043F\u0440\u043E\u0441. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C." : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043A\u0440\u044B\u0442\u044C \u043E\u043F\u0440\u043E\u0441. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C.", buttons: [] }, Date.now());
        continue;
      }
      if (item.questionPanel) {
        this.message(s, { text: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0432\u043E\u043F\u0440\u043E\u0441. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C.", buttons: [] }, Date.now());
        continue;
      }
      if (item.hintPanel) {
        this.message(s, { text: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C.", buttons: [] }, Date.now());
        continue;
      }
      const target = item.target === void 0 ? void 0 : s.outbox.find((o) => o.id === item.target);
      if (item.method === "editMessageText" && (target?.ratingPanel || target?.sessionPanel || target?.hintPanel || target?.questionPanel)) {
        this.message(s, { text: target.questionPanel ? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0432\u044B\u0431\u043E\u0440. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C." : target.hintPanel ? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0438. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C." : target.ratingPanel ? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441 \u043E\u0446\u0435\u043D\u043A\u043E\u0439. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0435\u0451 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 \u0447\u0435\u0440\u0435\u0437 /status." : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043F\u0430\u043D\u0435\u043B\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u044F. \u041D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 /go, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C.", buttons: [] }, Date.now());
        continue;
      }
      if (item.method === "editMessageMedia" && target?.status === "sent" && target.messageId !== void 0) this.mediaErrorEdit(s, target);
      else this.message(s, { text: MEDIA_LOADING_ERROR, buttons: [] }, Date.now());
    }
    return changed;
  }
  cancelQueuedContent(s, cancelled) {
    for (const row of [...s.outbox].reverse()) if (cancelled.has(row.id) && row.after !== void 0 && s.outbox.find((o) => o.id === row.after)?.status === "queued") cancelled.add(row.after);
    for (const row of s.outbox) if (row.status === "queued" && row.after !== void 0 && cancelled.has(row.after)) cancelled.add(row.id);
    const targets = s.outbox.filter((o) => cancelled.has(o.id) && o.method === "editMessageMedia").map((o) => s.outbox.find((target) => target.id === o.target)).filter((o) => o?.status === "sent" && o.messageId !== void 0);
    s.outbox = s.outbox.filter((o) => o.status !== "queued" || !cancelled.has(o.id));
    for (const target of targets) this.mediaErrorEdit(s, target);
  }
  async mediaFailed() {
    await this.serial(async () => {
      invalid(this.active);
      const s = cloneServerState(this.state);
      if (this.reconcileMediaFailures(s)) await this.commit(s);
    });
  }
  /** Call periodically; notices never alter Core/Bank scheduling or attempts. */
  async tick(now) {
    timestamp(now);
    return this.serial(async () => {
      invalid(this.active);
      const s = cloneServerState(this.state), retired = this.retirePolls(s, now);
      if (s.studyPlan !== void 0) {
        if (now < s.lastSession || now < s.bridgeTimeFloor) {
          if (retired) await this.commit(s);
          return;
        }
        this.reconcilePlanDeliveries(s, now);
        if (now >= s.lastSession && now >= s.bridgeTimeFloor) {
          s.lastSession = now;
          const delivered = new Set((s.studyPlanSent ?? []).map((row) => row.id + ":" + row.notifyAt));
          const due = s.studyPlan.entries.filter((entry) => entry.notifyAt <= now && now - entry.notifyAt < 15 * 6e4 && !delivered.has(entry.id + ":" + entry.notifyAt) && this.planDeliveryAllowed(s, entry.id, entry.notifyAt, now));
          for (const entry of due.sort((a, b) => b.notifyAt - a.notifyAt || a.id.localeCompare(b.id)).slice(0, 3)) {
            (s.studyPlanSent ??= []).push({ id: entry.id, notifyAt: entry.notifyAt });
            const delivery = this.planDelivery(s, entry.id);
            const id2 = this.enqueue(s, "sendMessage", studyPlanPayload(this.config.ownerChatId, delivery));
            s.outbox.find((row) => row.id === id2).studyPlanEntry = delivery;
          }
        }
        await this.commit(s);
        return;
      }
      const latest = latestSession(now, this.config.timeZone, this.config.sessionsLocal);
      if (!latest || latest <= s.lastSession || s.lastSession && sessionOrder(latest, this.config.timeZone) <= sessionOrder(s.lastSession, this.config.timeZone)) {
        if (retired) await this.commit(s);
        return;
      }
      s.lastSession = latest;
      if (s.domain.reminders.enabled && s.domain.reminders.skippedDay !== studyDay(now, this.config.timeZone) && now >= s.mutedUntil && s.domain.snapshot && companionSnapshotIsCurrent(s.domain.snapshot, now) && this.page(s, now, { kind: "go" }).cards.length) {
        this.message(s, { text: DAILY_REMINDER_TEXT, buttons: [
          { text: "\u0427\u0435\u0440\u0435\u0437 12 \u0447\u0430\u0441\u043E\u0432", action: { kind: "snooze", hours: 12 } },
          { text: "\u0427\u0435\u0440\u0435\u0437 24 \u0447\u0430\u0441\u0430", action: { kind: "snooze", hours: 24 } },
          { text: "\u0414\u043E \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0439 \u0441\u0435\u0441\u0441\u0438\u0438", action: { kind: "snooze", hours: "next" } },
          { text: "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0443\u0447\u0435\u0431\u043D\u044B\u0439 \u0434\u0435\u043D\u044C", action: { kind: "skip" } }
        ] }, now);
      }
      await this.commit(s);
    });
  }
  planDelivery(s, id2) {
    const entry = s.studyPlan?.entries.find((row) => row.id === id2);
    if (!entry || !this.config.miniAppUrl || !s.studyPlan) return;
    return { id: entry.id, notifyAt: entry.notifyAt, startAt: entry.startAt, title: entry.title, timeZone: s.studyPlan.timeZone, miniAppUrl: this.config.miniAppUrl };
  }
  planDeliveryAllowed(s, id2, notifyAt, now) {
    const entry = activeStudyPlanEntry(s, id2, now);
    return !!this.config.miniAppUrl && !!entry && entry.notifyAt === notifyAt && notifyAt <= now && now - notifyAt < 15 * 6e4 && !companionPlanEntryPending(s, id2, entry.action?.revision) && planNotificationsAllowed(s, now, this.config.timeZone);
  }
  reconcilePlanDeliveries(s, now) {
    s.outbox = s.outbox.filter((row) => {
      if (s.studyPlan && row.status === "queued" && row.payload.text === DAILY_REMINDER_TEXT) return false;
      if (!row.studyPlanEntry || row.status !== "queued") return true;
      if (!this.planDeliveryAllowed(s, row.studyPlanEntry.id, row.studyPlanEntry.notifyAt, now)) return false;
      row.studyPlanEntry = this.planDelivery(s, row.studyPlanEntry.id);
      row.payload = studyPlanPayload(this.config.ownerChatId, row.studyPlanEntry);
      return true;
    });
    if (s.studyPlanSent) {
      const retained = new Set(s.outbox.flatMap((row) => row.studyPlanEntry ? [row.studyPlanEntry.id + ":" + row.studyPlanEntry.notifyAt] : []));
      s.studyPlanSent = s.studyPlanSent.filter((row) => retained.has(row.id + ":" + row.notifyAt) || now - row.notifyAt < 8 * 864e5);
    }
  }
  /** Queued intents are safe to start after restart; unknown intents NEVER retry automatically.
   * Persist unknown before crossing the external side-effect boundary. */
  async flushLane(callbacks) {
    if (this.transport.ready && !this.transport.ready()) return;
    for (let i = 0; i < 100; i++) {
      const selected = await this.serial(async () => {
        invalid(this.active);
        const byId = new Map(this.state.outbox.map((row) => [row.id, row]));
        const queued = this.state.outbox.find((o) => o.status === "queued" && o.method === "answerCallbackQuery" === callbacks && (o.after === void 0 || byId.get(o.after)?.status === "sent") && (o.target === void 0 || byId.get(o.target)?.status === "sent" && byId.get(o.target)?.messageId !== void 0));
        if (!queued) return void 0;
        const queuedAt = this.queuedAt.get(queued.id);
        if (queuedAt !== void 0) recordPerformance(this.observe, callbacks ? "runtime.callback_queue" : "runtime.queue", performance.now() - queuedAt);
        const targetMessageId2 = queued.target === void 0 ? void 0 : byId.get(queued.target).messageId;
        const gradeAnswer2 = queued.method === "editMessageText" && queued.target !== void 0 ? byId.get(queued.target)?.ratingPanel?.answerText : void 0;
        const s = cloneServerState(this.state);
        s.outbox.find((o) => o.id === queued.id).status = "unknown";
        await this.commit(s);
        return { item: clone2(queued), targetMessageId: targetMessageId2, gradeAnswer: gradeAnswer2 };
      });
      if (!selected) return;
      const { item, targetMessageId, gradeAnswer } = selected;
      let result, superseded = false;
      const authorize = () => {
        if (!this.active) return false;
        if (this.config.miniAppUrl && (item.sessionContent || item.questionPanel || item.pollPanel || item.richDemoPanel || item.hintLease || item.hintPanel)) return false;
        if (item.miniAppPlan !== void 0 && !this.planLaunchEntry(this.state, item.miniAppPlan, Date.now())) return false;
        if (item.studyPlanEntry && (!this.planDeliveryAllowed(this.state, item.studyPlanEntry.id, item.studyPlanEntry.notifyAt, Date.now()) || canonical2(this.planDelivery(this.state, item.studyPlanEntry.id)) !== canonical2(item.studyPlanEntry))) return false;
        if (item.method === "sendRichMessage" || item.method === "editMessageText" && item.payload.rich_message !== void 0) {
          const demo = this.state.outbox.find((row) => row.id === (item.richDemoPanel ? item.id : item.target)), panel = demo?.richDemoPanel;
          if (!demo || !panel || Date.now() >= panel.expiresAt) return false;
          const expected = richCheckboxDemoView({ ...readRichCheckboxDemoMessage(demo.payload.rich_message), selectedOptionIndexes: panel.selectedOptionIndexes, checked: panel.checked });
          if (canonical2(expected) !== canonical2(item.payload.rich_message)) {
            superseded = item.method === "editMessageText";
            return false;
          }
        }
        if (item.method === "sendPoll") {
          const poll = this.state.outbox.find((row) => row.id === item.id);
          if (!poll || !this.pollAllowed(this.state, poll, Date.now())) return false;
        }
        const rating = this.state.outbox.find((row) => row.id === (item.ratingPanel ? item.id : item.target));
        if (rating?.ratingPanel?.answerText !== void 0 && carriesGradeAnswer(item.payload.text, rating) && !ratingAnswerAllowed(this.state, rating, Date.now())) return false;
        if (!item.sessionContent) return true;
        const session = this.state.studySession;
        if (!(session?.id === item.sessionContent.sessionId && Date.now() < session.snapshot.expiresAt && session.snapshot.cards.every((card) => (this.state.materialConsentIds?.includes(card.materialId) ?? false) && (this.state.attachmentConsent !== false || !card.media?.length && !card.hints?.length) && (!card.offline || this.state.offlineConsent === true && Date.now() < decodeOfflineSeed(card.offline).expiresAt)))) return false;
        const hint = this.state.outbox.find((row) => row.id === (item.hintPanel ? item.id : item.target));
        try {
          if (item.sessionContent.cardId !== void 0) {
            const cardId = item.sessionContent.cardId, revision = item.sessionContent.revision;
            const historical = session.results.some((row) => row.cardId === cardId && row.card?.revision === revision);
            const live = this.effectiveSnapshot(this.state, Date.now())?.cards.find((card) => card.id === cardId && card.revision === revision);
            if (!historical && (!live || !session.current || canonical2(session.current) !== canonical2(live))) return false;
          }
          const question = this.state.outbox.find((row) => row.id === (item.questionPanel ? item.id : item.target));
          if (question?.questionPanel) {
            const card = this.questionCard(this.state, question, Date.now(), !item.questionPanel), view = this.questionView(this.state, question, card, Date.now());
            const rows = item.payload.reply_markup.inline_keyboard.map((row) => row.map((button) => ({ text: button.text, ...button.style ? { style: button.style } : {} })));
            const expected = groupCompanionButtons(view.buttons, (button) => ({ text: button.text, ...button.style ? { style: button.style } : {} }));
            if (item.payload.text !== view.text || canonical2(rows) !== canonical2(expected)) {
              superseded = item.method === "editMessageText" && item.target === question.id;
              return false;
            }
          }
          if (hint?.hintPanel) {
            const card = this.hintCard(this.state, hint, Date.now()), p = hint.hintPanel;
            if (item.payload.text !== hintPanelView(card.hints, p.count, p.index, p.collapsed).text) return false;
          }
        } catch {
          return false;
        }
        return true;
      };
      try {
        const reminderLaunch = item.method === "sendMessage" && item.payload.text === DAILY_REMINDER_TEXT && this.config.miniAppUrl;
        const appLaunch = item.method === "sendMessage" && item.payload.text === MINI_APP_LAUNCH_TEXT && this.config.miniAppUrl;
        const vaultId = this.config.miniAppVaultId;
        const owned = item.studyPlanEntry ? { studyPlan: clone2(item.studyPlanEntry) } : reminderLaunch ? { miniAppUrl: reminderLaunch } : appLaunch ? { miniAppUrl: appLaunch, ...item.miniAppPlan ? { planId: item.miniAppPlan } : {} } : void 0;
        const payload = {
          ...item.studyPlanEntry && vaultId ? studyPlanPayload(this.config.ownerChatId, item.studyPlanEntry, vaultId) : reminderLaunch ? reminderMiniAppPayload(clone2(item.payload), reminderLaunch, vaultId) : clone2(item.payload),
          ...appLaunch ? { reply_markup: { inline_keyboard: [[{ text: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435", web_app: { url: miniAppLaunchUrl(appLaunch, item.miniAppPlan, vaultId) } }]] } } : {},
          ...targetMessageId === void 0 ? {} : { message_id: targetMessageId },
          ...gradeAnswer === void 0 ? {} : { gradeAnswer }
        };
        result = await this.transport.call(item.method, payload, authorize, owned && vaultId ? { ...owned, vaultId } : owned);
      } catch {
        if (superseded) {
          await this.serial(async () => {
            invalid(this.active);
            const s = cloneServerState(this.state);
            invalid(!s.outbox.some((row) => row.after === item.id || row.target === item.id));
            s.outbox = s.outbox.filter((row) => row.id !== item.id);
            await this.commit(s);
          });
        } else if (!callbacks) await this.mediaFailed();
        continue;
      }
      const pollResult = typeof result === "object" && result !== null ? result : void 0;
      if (item.method === "sendPoll" ? !pollResult || !validNativePollId(pollResult.pollId) : pollResult !== void 0 || item.method === "stopPoll" && result !== void 0) {
        await this.mediaFailed();
        continue;
      }
      const messageId = pollResult?.messageId ?? (typeof result === "number" ? result : void 0);
      if ((item.answerHandle !== void 0 || item.mediaPlaceholder || item.hintPanel || item.questionPanel || item.pollPanel || item.richDemoPanel) && messageId === void 0 || isEditMethod(item.method) && messageId !== targetMessageId || messageId !== void 0 && (!Number.isSafeInteger(messageId) || messageId <= 0)) {
        await this.mediaFailed();
        continue;
      }
      const confirmed = await this.serial(async () => {
        invalid(this.active);
        const s = cloneServerState(this.state), row = s.outbox.find((o) => o.id === item.id);
        if (!isEditMethod(item.method) && messageId !== void 0 && s.outbox.some((o) => o.messageId === messageId)) return false;
        if (pollResult && s.outbox.some((o) => o.pollPanel?.pollId === pollResult.pollId)) return false;
        row.status = "sent";
        if (item.method !== "answerCallbackQuery" && !isEditMethod(item.method) && messageId !== void 0) row.messageId = messageId;
        if (row.pollPanel && pollResult) {
          row.pollPanel.pollId = pollResult.pollId;
          if (row.pollPanel.sealed) this.sealPoll(s, row);
        }
        await this.commit(s);
        return true;
      });
      if (!confirmed) await this.mediaFailed();
    }
  }
  flushCallbacks() {
    return this.callbackFlushing ??= this.flushLane(true).finally(() => {
      this.callbackFlushing = void 0;
    });
  }
  flushAcknowledgements() {
    return this.flushCallbacks();
  }
  async flush() {
    const callbacks = this.flushCallbacks();
    const content2 = this.flushing ??= this.flushLane(false).finally(() => {
      this.flushing = void 0;
    });
    const results = await Promise.allSettled([callbacks, content2]);
    const failed = results.find((result) => result.status === "rejected");
    if (failed) throw failed.reason;
  }
};

// src/infrastructure/companion/server/journal.ts
var import_node_fs3 = require("node:fs");
var import_promises3 = require("node:fs/promises");
var import_node_path3 = require("node:path");
var import_node_crypto10 = require("node:crypto");

// src/infrastructure/companion/server/journal-content.ts
var import_node_crypto9 = require("node:crypto");
var import_node_fs2 = require("node:fs");
var import_promises2 = require("node:fs/promises");
var import_node_path2 = require("node:path");
var JOURNAL_FORMAT = "anchor-recall-journal-v2";
var PAGED_JOURNAL_FORMAT = "anchor-recall-journal-v3";
var digest2 = (raw) => (0, import_node_crypto9.createHash)("sha256").update(raw).digest("hex");
var privateMetadata = (info) => {
  invalid(info.isFile() && !info.isSymbolicLink() && info.nlink === 1 && (info.mode & 63) === 0, "private catalog required");
};
function reference(value) {
  record2(value);
  keys(value, ["sha256", "bytes"]);
  invalid(typeof value.sha256 === "string" && /^[a-f0-9]{64}$/.test(value.sha256) && Number.isSafeInteger(value.bytes) && Number(value.bytes) > 0 && Number(value.bytes) <= MAX_COMPANION_SNAPSHOT_BYTES, "invalid catalog reference");
}
var JournalContent = class {
  directory;
  pages;
  cachedCatalog;
  cachedPublication;
  constructor(journalPath) {
    this.directory = `${journalPath}.blobs`;
    this.pages = new DesktopCatalogPageStorage(journalPath);
  }
  async checkDirectory() {
    const info = await (0, import_promises2.lstat)(this.directory);
    invalid(info.isDirectory() && !info.isSymbolicLink() && (info.mode & 63) === 0, "private catalog directory required");
  }
  path(ref) {
    reference(ref);
    return (0, import_node_path2.join)(this.directory, `${ref.sha256}.json`);
  }
  async read(ref) {
    await this.checkDirectory();
    const path = this.path(ref);
    privateMetadata(await (0, import_promises2.lstat)(path));
    const file = await (0, import_promises2.open)(path, import_node_fs2.constants.O_RDONLY | (import_node_fs2.constants.O_NOFOLLOW ?? 0));
    let raw;
    try {
      const before = await file.stat();
      privateMetadata(before);
      invalid(before.size === ref.bytes);
      const buffer = Buffer.allocUnsafe(ref.bytes + 1);
      let offset = 0;
      while (offset < buffer.length) {
        const result = await file.read(buffer, offset, buffer.length - offset, offset);
        if (!result.bytesRead) break;
        offset += result.bytesRead;
      }
      raw = buffer.subarray(0, offset);
      const after = await file.stat();
      privateMetadata(after);
      invalid(before.ino === after.ino && before.size === after.size && before.mtimeMs === after.mtimeMs && raw.byteLength === ref.bytes && digest2(raw) === ref.sha256, "catalog integrity mismatch");
    } finally {
      await file.close();
    }
    return JSON.parse(raw.toString("utf8"));
  }
  async publicationFence(state, root) {
    if (!state.catalogRoot) {
      this.cachedPublication = void 0;
      return;
    }
    validateCatalogRoot(state.catalogRoot);
    invalid(typeof state.catalogRevision === "string", "catalog publication revision missing");
    invalid(jsonFingerprintEqual(state.catalogRoot.snapshot, root.snapshot) && jsonFingerprintEqual(state.catalogRoot.context, root.context), "catalog publication pointer differs");
    if (!this.cachedPublication || this.cachedPublication.revision !== state.catalogRevision) {
      const captured = await this.pages.capture(async () => {
        await readCatalogList(state.catalogRoot.consentIds, this.pages);
        if (state.catalogRoot.materialConsentIds) await readCatalogList(state.catalogRoot.materialConsentIds, this.pages);
      });
      this.cachedPublication = { revision: state.catalogRevision, references: captured.references };
    }
    await this.pages.assertUnchanged(this.cachedPublication.references);
  }
  async encode(state) {
    const builder = new CatalogPageBuilder(), stored = { format: PAGED_JOURNAL_FORMAT, state: builder.value(mutableServerState(state)) };
    for (const source of builder.pages.values()) await this.pages.put(source.reference, source.bytes());
    if (state.domain.snapshot) {
      validateImmutableSnapshot(state.domain.snapshot);
      if (state.studyContext) validateImmutableStudyContext(state.studyContext);
      let root = this.cachedCatalog?.snapshot === state.domain.snapshot && this.cachedCatalog.context === state.studyContext ? this.cachedCatalog.root : void 0;
      if (!root) {
        const received = verifiedCatalogPublication(this.pages, state.domain.snapshot, state.studyContext, state.catalogRoot);
        if (received) {
          root = received.root;
          this.cachedCatalog = { snapshot: state.domain.snapshot, context: state.studyContext, root, references: received.references };
        } else {
          const build = buildCatalogPages({ snapshot: state.domain.snapshot, context: state.studyContext, consentIds: [], timeZone: "UTC" });
          for (const source of build.pages.values()) await this.pages.put(source.reference, source.bytes());
          root = build.root;
          this.cachedCatalog = { snapshot: state.domain.snapshot, context: state.studyContext, root, references: [...build.pages.values()].map((source) => source.reference) };
        }
      }
      await this.pages.assertUnchanged(this.cachedCatalog.references);
      await this.publicationFence(state, root);
      stored.catalog = root;
    }
    await this.pages.flush();
    return stored;
  }
  async decode(value) {
    record2(value);
    if (value.format === PAGED_JOURNAL_FORMAT) {
      keys(value, ["format", "state", "catalog"]);
      validateCatalogReference(value.state);
      const state2 = await readPagedJson(value.state, this.pages);
      record2(state2);
      record2(state2.domain);
      invalid(state2.domain.snapshot === void 0 && state2.studyContext === void 0, "ambiguous catalog journal");
      if (value.catalog !== void 0) {
        validateCatalogRoot(value.catalog);
        const captured = await this.pages.capture(() => readCatalogRoot(value.catalog, this.pages)), content2 = captured.value;
        validateImmutableSnapshot(content2.snapshot);
        state2.domain.snapshot = content2.snapshot;
        if (content2.context) {
          validateImmutableStudyContext(content2.context);
          state2.studyContext = content2.context;
        }
        this.cachedCatalog = { snapshot: content2.snapshot, context: content2.context, root: value.catalog, references: captured.references };
        await this.publicationFence(state2, value.catalog);
      }
      return state2;
    }
    if (value.format !== JOURNAL_FORMAT) return value;
    keys(value, ["format", "state", "snapshot", "studyContext"]);
    record2(value.state);
    record2(value.state.domain);
    invalid(value.state.domain.snapshot === void 0 && value.state.studyContext === void 0, "ambiguous catalog journal");
    const state = value.state;
    if (value.snapshot !== void 0) {
      reference(value.snapshot);
      const snapshot = await this.read(value.snapshot);
      validateImmutableSnapshot(snapshot);
      state.domain.snapshot = snapshot;
    }
    if (value.studyContext !== void 0) {
      reference(value.studyContext);
      const context = await this.read(value.studyContext);
      validateImmutableStudyContext(context);
      state.studyContext = context;
    }
    return state;
  }
};

// src/features/companion/authority-archive.ts
var companionArchiveKey = (...parts) => JSON.stringify(parts);

// src/infrastructure/companion/desktop-authority-archive.ts
var import_fs2 = require("fs");
var import_path2 = require("path");
var import_crypto3 = require("crypto");
var import_zlib = require("zlib");

// src/infrastructure/companion/desktop-proof-storage.ts
var import_fs = require("fs");
var import_path = require("path");
var import_crypto2 = require("crypto");
function fail5() {
  throw new Error("\u041B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0434\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E Telegram \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E. \u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B; \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0444\u0430\u0439\u043B\u043E\u0432.");
}
function freeze2(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze2);
    Object.freeze(value);
  }
  return value;
}
var version2 = (info) => [info.dev, info.ino, info.size, info.mtimeMs, info.ctimeMs].join(":");
var missing = (error) => error.code === "ENOENT";
var PAGED = "anchor-recall-proof-pages-v1";
var PAGE = "anchor-recall-proof-page-v1";
var PAGE_TARGET = 4 * 1024 * 1024;
var object6 = (value) => !!value && typeof value === "object" && !Array.isArray(value);
var keys3 = (value, allowed) => Object.keys(value).every((key2) => allowed.includes(key2));
var digest3 = (raw) => (0, import_crypto2.createHash)("sha256").update(raw, "utf8").digest("hex");
function readBoundedCompanionFile(descriptor, expectedBytes) {
  if (!Number.isSafeInteger(expectedBytes) || expectedBytes < 0 || expectedBytes > MAX_COMPANION_SNAPSHOT_BYTES) fail5();
  const bytes = Buffer.allocUnsafe(expectedBytes + 1);
  let length = 0;
  while (length < bytes.length) {
    const read = (0, import_fs.readSync)(descriptor, bytes, length, bytes.length - length, null);
    if (!read) break;
    length += read;
  }
  if (length !== expectedBytes) fail5();
  return bytes.subarray(0, length);
}
var DesktopCompanionProofStorage = class {
  constructor(pluginDirectory, binding2, kind2, legacyRead) {
    this.pluginDirectory = pluginDirectory;
    this.kind = kind2;
    this.legacyRead = legacyRead;
    if (!/^[a-f0-9]{64}$/.test(binding2) || !["bank", "offline", "media", "authority-archive", "sequence", "written-recall", "card-reports", "plan-actions", "answer-history"].includes(kind2)) fail5();
    this.pluginDirectory = (0, import_path.resolve)(pluginDirectory);
    this.directory = (0, import_path.join)(this.pluginDirectory, "companion-proofs", binding2);
    this.file = (0, import_path.join)(this.directory, `${kind2}.json`);
    this.pagesDirectory = (0, import_path.join)(this.directory, `${kind2}.proof-pages`);
  }
  immutable = true;
  directory;
  file;
  pagesDirectory;
  cached;
  observed;
  observedDigest;
  reclaimedAnswerHistoryVersion;
  checkDirectory(directory, privateDirectory2 = false) {
    const info = (0, import_fs.lstatSync)(directory);
    if (info.isSymbolicLink() || !info.isDirectory() || privateDirectory2 && process.platform !== "win32" && (Number(info.mode) & 63) !== 0) fail5();
  }
  checkParents(create) {
    this.checkDirectory(this.pluginDirectory);
    for (const directory of [(0, import_path.join)(this.pluginDirectory, "companion-proofs"), this.directory]) {
      try {
        this.checkDirectory(directory, true);
      } catch (error) {
        if (!missing(error)) throw error;
        if (!create) return;
        (0, import_fs.mkdirSync)(directory, { mode: 448 });
        this.checkDirectory(directory, true);
      }
      if (create) this.syncDirectory((0, import_path.dirname)(directory));
    }
  }
  info(file = this.file) {
    try {
      this.checkParents(false);
      if (file !== this.file) this.checkDirectory(this.pagesDirectory, true);
      const info = (0, import_fs.lstatSync)(file);
      if (!info.isFile() || info.isSymbolicLink() || Number(info.nlink) !== 1 || info.size > (this.kind === "sequence" ? String(Number.MAX_SAFE_INTEGER).length : MAX_COMPANION_SNAPSHOT_BYTES) || process.platform !== "win32" && (Number(info.mode) & 63) !== 0) fail5();
      return info;
    } catch (error) {
      if (missing(error)) return void 0;
      throw error;
    }
  }
  readFile(info, file = this.file) {
    const identity5 = version2(info), descriptor = (0, import_fs.openSync)(file, import_fs.constants.O_RDONLY | import_fs.constants.O_NONBLOCK | (process.platform === "win32" ? 0 : import_fs.constants.O_NOFOLLOW));
    try {
      if (version2((0, import_fs.fstatSync)(descriptor)) !== identity5) fail5();
      const raw = new TextDecoder("utf-8", { fatal: true }).decode(readBoundedCompanionFile(descriptor, Number(info.size))), after = this.info(file);
      if (version2((0, import_fs.fstatSync)(descriptor)) !== identity5 || !after || version2(after) !== identity5) fail5();
      return raw;
    } finally {
      (0, import_fs.closeSync)(descriptor);
    }
  }
  reference(value) {
    if (!object6(value) || !keys3(value, ["sha256", "bytes", "rows"]) || typeof value.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(value.sha256) || !Number.isSafeInteger(value.bytes) || Number(value.bytes) < 1 || Number(value.bytes) > MAX_COMPANION_SNAPSHOT_BYTES || !Number.isSafeInteger(value.rows) || Number(value.rows) < 1) fail5();
  }
  decode(value) {
    const pages = /* @__PURE__ */ new Map(), decodedPages = /* @__PURE__ */ new Map();
    if (!object6(value) || value.format !== PAGED) return { value: freeze2(value), pages, decodedPages };
    if (!keys3(value, ["format", "fields"]) || !Array.isArray(value.fields)) fail5();
    const result = {}, names = /* @__PURE__ */ new Set();
    for (const field of value.fields) {
      if (!object6(field) || typeof field.name !== "string" || names.has(field.name)) fail5();
      names.add(field.name);
      let hydrated;
      if (Object.prototype.hasOwnProperty.call(field, "value")) {
        if (!keys3(field, ["name", "value"])) fail5();
        hydrated = field.value;
      } else {
        if (!keys3(field, ["name", "length", "head"]) || !Number.isSafeInteger(field.length) || Number(field.length) < 0 || field.length === 0 !== (field.head === void 0)) fail5();
        const batches = [], seen = /* @__PURE__ */ new Set();
        let count = 0, next = field.head;
        while (next !== void 0) {
          this.reference(next);
          if (seen.has(next.sha256)) fail5();
          seen.add(next.sha256);
          const file = (0, import_path.join)(this.pagesDirectory, `${next.sha256}.json`), info = this.info(file);
          if (!info || info.size !== next.bytes) fail5();
          const raw = this.readFile(info, file);
          if (Buffer.byteLength(raw, "utf8") !== next.bytes || digest3(raw) !== next.sha256) fail5();
          const cached = this.cached?.decodedPages.get(file);
          const page2 = cached?.version === version2(info) ? cached.value : JSON.parse(raw);
          if (!object6(page2) || !keys3(page2, ["format", "values", "previous"]) || page2.format !== PAGE || !Array.isArray(page2.values) || page2.values.length !== next.rows) fail5();
          count += page2.values.length;
          if (count > Number(field.length)) fail5();
          pages.set(file, version2(info));
          decodedPages.set(file, { version: version2(info), value: freeze2(page2) });
          batches.push(page2.values);
          next = page2.previous;
        }
        if (count !== field.length) fail5();
        const values = [];
        for (let index2 = batches.length - 1; index2 >= 0; index2--) for (const row of batches[index2]) values.push(row);
        hydrated = values;
      }
      Object.defineProperty(result, field.name, { value: hydrated, enumerable: true, configurable: true, writable: true });
    }
    return { value: freeze2(result), pages, decodedPages };
  }
  shouldPage(value) {
    if (this.kind === "authority-archive" || !object6(value)) return false;
    let bytes = 2;
    for (const [name, field] of Object.entries(value)) {
      bytes += Buffer.byteLength(JSON.stringify(name), "utf8") + 2;
      if (Array.isArray(field)) {
        for (const row of field) {
          bytes += Buffer.byteLength(JSON.stringify(row) ?? "null", "utf8") + 1;
          if (bytes > PAGE_TARGET) return true;
        }
      } else {
        bytes += Buffer.byteLength(JSON.stringify(field) ?? "null", "utf8");
      }
    }
    return bytes > PAGE_TARGET && Object.values(value).some(Array.isArray);
  }
  syncDirectory(directory) {
    if (process.platform === "win32") return;
    const descriptor = (0, import_fs.openSync)(directory, import_fs.constants.O_RDONLY | import_fs.constants.O_NOFOLLOW);
    try {
      (0, import_fs.fsyncSync)(descriptor);
    } finally {
      (0, import_fs.closeSync)(descriptor);
    }
  }
  page(raw, rows, pages) {
    const ref = { sha256: digest3(raw), bytes: Buffer.byteLength(raw, "utf8"), rows };
    this.reference(ref);
    const file = (0, import_path.join)(this.pagesDirectory, `${ref.sha256}.json`), previous = this.info(file);
    if (previous) {
      if (this.readFile(previous, file) !== raw) fail5();
      pages.set(file, version2(previous));
      return ref;
    }
    const temporary = (0, import_path.join)(this.pagesDirectory, `.${(0, import_crypto2.randomUUID)()}.tmp`);
    try {
      const descriptor = (0, import_fs.openSync)(temporary, "wx", 384);
      try {
        (0, import_fs.writeFileSync)(descriptor, raw, "utf8");
        (0, import_fs.fsyncSync)(descriptor);
      } finally {
        (0, import_fs.closeSync)(descriptor);
      }
      const existing = this.info(file);
      if (existing) {
        if (this.readFile(existing, file) !== raw) fail5();
      } else (0, import_fs.renameSync)(temporary, file);
      const committed = this.info(file);
      if (!committed || this.readFile(committed, file) !== raw) fail5();
      pages.set(file, version2(committed));
      return ref;
    } finally {
      if ((0, import_fs.existsSync)(temporary)) (0, import_fs.unlinkSync)(temporary);
    }
  }
  encode(value, pages) {
    if (!this.shouldPage(value)) return JSON.stringify(value);
    try {
      this.checkDirectory(this.pagesDirectory, true);
    } catch (error) {
      if (!missing(error)) throw error;
      (0, import_fs.mkdirSync)(this.pagesDirectory, { mode: 448 });
      this.checkDirectory(this.pagesDirectory, true);
    }
    const manifest = { format: PAGED, fields: [] };
    for (const [name, field] of Object.entries(value)) {
      if (!Array.isArray(field)) {
        const raw = JSON.stringify(field);
        if (raw !== void 0) {
          if (Buffer.byteLength(raw, "utf8") > MAX_COMPANION_SNAPSHOT_BYTES) fail5();
          manifest.fields.push({ name, value: JSON.parse(raw) });
        }
        continue;
      }
      let head, size = 0, pieces = [];
      const flush = () => {
        if (!pieces.length) return;
        const raw = `{"format":${JSON.stringify(PAGE)},"values":[${pieces.join(",")}]${head ? `,"previous":${JSON.stringify(head)}` : ""}}`;
        head = this.page(raw, pieces.length, pages);
        pieces = [];
        size = 0;
      };
      for (const row of field) {
        const raw = JSON.stringify(row) ?? "null", bytes = Buffer.byteLength(raw, "utf8");
        if (bytes + 1024 > MAX_COMPANION_SNAPSHOT_BYTES) fail5();
        if (pieces.length && size + bytes + 1024 > PAGE_TARGET) flush();
        pieces.push(raw);
        size += bytes + 1;
      }
      flush();
      manifest.fields.push({ name, length: field.length, ...head ? { head } : {} });
    }
    this.syncDirectory(this.pagesDirectory);
    return JSON.stringify(manifest);
  }
  read() {
    try {
      const info = this.info();
      if (!info) {
        this.observed = null;
        this.observedDigest = null;
        const legacy = this.legacyRead();
        return legacy === void 0 ? void 0 : freeze2(cloneJsonValue(legacy));
      }
      const identity5 = version2(info);
      this.observed = identity5;
      const verify = this.kind === "authority-archive" || info.size <= PAGE_TARGET || !!this.cached?.pages.size;
      const raw = verify || this.cached?.version !== identity5 ? this.readFile(info) : void 0, rawDigest = raw === void 0 ? this.cached.digest : digest3(raw);
      this.observedDigest = rawDigest;
      if (this.cached?.version === identity5 && this.cached.digest === rawDigest && [...this.cached.pages].every(([file, expected]) => {
        const info2 = this.info(file);
        return !!info2 && version2(info2) === expected;
      })) return this.cached.value;
      if (raw === void 0) fail5();
      const decoded = this.decode(JSON.parse(raw));
      const after = this.info();
      if (!after || version2(after) !== identity5) fail5();
      if ((verify || decoded.pages.size) && digest3(this.readFile(after)) !== rawDigest) fail5();
      this.cached = { version: identity5, digest: rawDigest, ...decoded };
      return decoded.value;
    } catch {
      return fail5();
    }
  }
  /** Raw answers are erasable: never retain superseded private pages as an archive.
   * Called by the vault's serialized history writer, only after a durable verified root.
   * Other proof kinds deliberately retain their previous authority pages.
   */
  reclaimAnswerHistoryPages() {
    if (this.kind !== "answer-history") fail5();
    this.read();
    const root = this.info();
    if (!root) return false;
    const expected = version2(root), rootDigest = digest3(this.readFile(root));
    if (!this.cached || this.cached.version !== expected || this.cached.digest !== rootDigest) fail5();
    if (this.reclaimedAnswerHistoryVersion === expected) return true;
    const keep = new Set(this.cached.pages.keys());
    const current = () => {
      const info = this.info();
      if (!info || version2(info) !== expected || digest3(this.readFile(info)) !== rootDigest) fail5();
    };
    const erase = (file) => {
      current();
      const info = (0, import_fs.lstatSync)(file);
      if (!info.isFile() || info.isSymbolicLink() || Number(info.nlink) !== 1 || info.size > MAX_COMPANION_SNAPSHOT_BYTES || process.platform !== "win32" && (Number(info.mode) & 63) !== 0) fail5();
      if (version2((0, import_fs.lstatSync)(file)) !== version2(info)) fail5();
      (0, import_fs.unlinkSync)(file);
    };
    try {
      this.checkDirectory(this.pagesDirectory, true);
      for (const name of (0, import_fs.readdirSync)(this.pagesDirectory)) {
        if (!/^(?:[a-f0-9]{64}\.json|\.[a-f0-9-]{36}\.tmp)$/.test(name)) fail5();
        const file = (0, import_path.join)(this.pagesDirectory, name);
        if (!keep.has(file)) erase(file);
      }
      this.syncDirectory(this.pagesDirectory);
    } catch (error) {
      if (!missing(error)) throw error;
    }
    for (const name of (0, import_fs.readdirSync)(this.directory)) {
      if (/^\.answer-history\.[a-f0-9-]{36}\.tmp$/.test(name)) erase((0, import_path.join)(this.directory, name));
    }
    this.syncDirectory(this.directory);
    current();
    for (const [file, identity5] of this.cached.pages) {
      const info = this.info(file);
      if (!info || version2(info) !== identity5) fail5();
    }
    this.reclaimedAnswerHistoryVersion = expected;
    return true;
  }
  write(value) {
    let temporary, renamed = false;
    this.reclaimedAnswerHistoryVersion = void 0;
    try {
      const before = this.info(), baseline = before ? version2(before) : void 0;
      if (this.observed !== void 0 && this.observed !== (baseline ?? null)) fail5();
      const baselineDigest = before ? digest3(this.readFile(before)) : null;
      if (this.observedDigest !== void 0 && this.observedDigest !== baselineDigest) fail5();
      if (before && (this.cached?.version !== baseline || this.cached?.digest !== baselineDigest)) this.read();
      this.checkParents(true);
      if (this.kind === "sequence" && (typeof value !== "number" || !Number.isSafeInteger(value) || value <= 0)) fail5();
      const pages = /* @__PURE__ */ new Map(), raw = this.encode(value, pages);
      if (Buffer.byteLength(raw, "utf8") > MAX_COMPANION_SNAPSHOT_BYTES) fail5();
      temporary = (0, import_path.join)(this.directory, this.kind === "answer-history" ? `.answer-history.${(0, import_crypto2.randomUUID)()}.tmp` : `.${(0, import_crypto2.randomUUID)()}.tmp`);
      const descriptor = (0, import_fs.openSync)(temporary, "wx", 384);
      try {
        (0, import_fs.writeFileSync)(descriptor, raw, "utf8");
        (0, import_fs.fsyncSync)(descriptor);
      } finally {
        (0, import_fs.closeSync)(descriptor);
      }
      const current = this.info();
      if ((current ? version2(current) : void 0) !== baseline) fail5();
      if ((current ? digest3(this.readFile(current)) : null) !== baselineDigest) fail5();
      for (const [file, expected] of pages) {
        const info = this.info(file);
        if (!info || version2(info) !== expected) fail5();
      }
      (0, import_fs.renameSync)(temporary, this.file);
      renamed = true;
      this.syncDirectory(this.directory);
      const committed = this.info();
      if (!committed) fail5();
      const readback = this.readFile(committed);
      if (readback !== raw) fail5();
      const decoded = this.decode(JSON.parse(readback)), after = this.info();
      if (!after || version2(after) !== version2(committed)) fail5();
      if (digest3(this.readFile(after)) !== digest3(readback)) fail5();
      this.cached = { version: version2(committed), digest: digest3(readback), ...decoded };
      this.observed = this.cached.version;
      this.observedDigest = this.cached.digest;
      if (this.kind === "answer-history") this.reclaimAnswerHistoryPages();
    } catch {
      this.cached = void 0;
      throw new Error(renamed ? "\u0417\u0430\u043F\u0438\u0441\u044C \u0434\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430 Telegram \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u043E\u0441\u043B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F. \u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435." : "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0434\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E Telegram. \u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0438\u0439 \u0444\u0430\u0439\u043B \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D.");
    } finally {
      if (temporary && (0, import_fs.existsSync)(temporary)) (0, import_fs.unlinkSync)(temporary);
    }
  }
};

// src/infrastructure/companion/desktop-authority-archive.ts
var kinds2 = ["core-offer", "offline-root", "offline-attempt", "bank-grant", "core-receipt", "core-answered", "bank-proof", "offline-rejected", "core-grade-proof", "server-result", "server-replay"];
var SEGMENT_TARGET_BYTES = 4 * 1024 * 1024;
var CACHE_BYTES = 8 * 1024 * 1024;
var CACHE_ENTRIES = 32;
var FILTER_BYTES = 8192;
var INITIALIZED = "anchor-recall-authority-archive-v1\n";
var digest4 = (bytes) => (0, import_crypto3.createHash)("sha256").update(bytes).digest("hex");
var clone3 = (value) => JSON.parse(JSON.stringify(value));
var missing2 = (error) => error.code === "ENOENT";
function check5(value) {
  if (!value) throw new Error("\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u043E\u043B\u043D\u043E\u043C\u043E\u0447\u0438\u0439 Telegram \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430. \u0421\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B.");
}
function object7(value) {
  check5(value && typeof value === "object" && !Array.isArray(value));
}
function keys4(value, allowed) {
  check5(Object.keys(value).every((key2) => allowed.includes(key2)));
}
function key(value) {
  check5(typeof value === "string" && value.length > 0 && value.length <= 16384);
}
function kind(value) {
  check5(kinds2.includes(value));
}
function reference2(value) {
  object7(value);
  keys4(value, ["sha256", "bytes", "filter", "encoding", "uncompressedBytes"]);
  check5(typeof value.sha256 === "string" && /^[a-f0-9]{64}$/.test(value.sha256) && Number.isSafeInteger(value.bytes) && Number(value.bytes) > 0 && Number(value.bytes) <= MAX_COMPANION_SNAPSHOT_BYTES);
  check5(value.encoding === void 0 ? value.uncompressedBytes === void 0 : value.encoding === "gzip" && Number.isSafeInteger(value.uncompressedBytes) && Number(value.uncompressedBytes) > 0 && Number(value.uncompressedBytes) <= MAX_COMPANION_SNAPSHOT_BYTES);
  check5(value.filter === void 0 || typeof value.filter === "string" && value.filter.length === Math.ceil(FILTER_BYTES / 3) * 4 && Buffer.from(value.filter, "base64").length === FILTER_BYTES && Buffer.from(value.filter, "base64").toString("base64") === value.filter);
}
var positions = (name) => {
  const hash2 = (0, import_crypto3.createHash)("sha256").update(name).digest();
  return [0, 2, 4, 6].map((offset) => hash2.readUInt16BE(offset));
};
var contains = (filter, name) => positions(name).every((bit) => (filter[bit >>> 3] & 1 << (bit & 7)) !== 0);
var include = (filter, name) => {
  for (const bit of positions(name)) filter[bit >>> 3] |= 1 << (bit & 7);
};
var prefixOf = (value) => digest4(value).slice(0, 1);
var segmentFile = (ref) => ref.sha256 + (ref.encoding === "gzip" ? ".json.gz" : ".json");
var manifestValue = (heads) => ({ version: 1, heads, checksum: digest4(JSON.stringify({ version: 1, heads })) });
var identity2 = (info) => [info.dev, info.ino, info.size, info.mtimeMs, info.ctimeMs].join(":");
function privateFile2(info) {
  check5(info.isFile() && !info.isSymbolicLink() && Number(info.nlink) === 1 && info.size > 0 && info.size <= MAX_COMPANION_SNAPSHOT_BYTES && (process.platform === "win32" || (Number(info.mode) & 63) === 0));
}
var DesktopCompanionAuthorityArchive = class {
  constructor(pluginDirectory, binding2) {
    this.pluginDirectory = pluginDirectory;
    this.binding = binding2;
    check5(/^[a-f0-9]{64}$/.test(binding2));
    this.pluginDirectory = (0, import_path2.resolve)(pluginDirectory);
    this.directory = (0, import_path2.join)(this.pluginDirectory, "companion-proofs", binding2);
    this.manifest = new DesktopCompanionProofStorage(this.pluginDirectory, binding2, "authority-archive", () => void 0);
  }
  directory;
  manifest;
  cache = /* @__PURE__ */ new Map();
  cacheBytes = 0;
  observed;
  seenManifest = false;
  validatedManifest;
  load() {
    const before = this.manifestIdentity();
    if (before === null) check5(!this.seenManifest && !this.initialized());
    if (this.observed !== void 0 && this.observed !== before) {
      this.observed = before;
      check5(false);
    }
    const value = this.manifest.read();
    const after = this.manifestIdentity();
    if (after !== before) {
      this.observed = after;
      this.seenManifest ||= after !== null;
      check5(false);
    }
    this.observed = after;
    this.seenManifest ||= after !== null;
    this.initialized();
    if (value === void 0) return manifestValue({});
    if (value === this.validatedManifest) return this.validatedManifest;
    object7(value);
    keys4(value, ["version", "heads", "checksum"]);
    check5(value.version === 1);
    object7(value.heads);
    check5(value.checksum === digest4(JSON.stringify({ version: 1, heads: value.heads })));
    for (const [bucket, head] of Object.entries(value.heads)) {
      const split = bucket.lastIndexOf(":"), owner = bucket.slice(0, split), prefix = bucket.slice(split + 1);
      kind(owner);
      check5(/^[a-f0-9]$/.test(prefix));
      reference2(head);
    }
    this.validatedManifest = value;
    return this.validatedManifest;
  }
  checkDirectory(path, create) {
    let info;
    try {
      info = (0, import_fs2.lstatSync)(path);
    } catch (error) {
      if (!create || !missing2(error)) throw error;
      (0, import_fs2.mkdirSync)(path, { mode: 448 });
      info = (0, import_fs2.lstatSync)(path);
    }
    check5(info.isDirectory() && !info.isSymbolicLink() && (path === this.pluginDirectory || process.platform === "win32" || (Number(info.mode) & 63) === 0));
    if (create && process.platform !== "win32") {
      const descriptor = (0, import_fs2.openSync)((0, import_path2.dirname)(path), "r");
      try {
        (0, import_fs2.fsyncSync)(descriptor);
      } finally {
        (0, import_fs2.closeSync)(descriptor);
      }
    }
  }
  bucketDirectory(owner, prefix, create) {
    let path = this.baseDirectory(create);
    for (const part of ["authority-archive", owner, prefix]) {
      path = (0, import_path2.join)(path, part);
      this.checkDirectory(path, create);
    }
    return path;
  }
  baseDirectory(create) {
    this.checkDirectory(this.pluginDirectory, false);
    let path = this.pluginDirectory;
    for (const part of ["companion-proofs", this.binding]) {
      path = (0, import_path2.join)(path, part);
      this.checkDirectory(path, create);
    }
    return path;
  }
  manifestIdentity() {
    try {
      this.baseDirectory(false);
      const path = (0, import_path2.join)(this.directory, "authority-archive.json"), info = (0, import_fs2.lstatSync)(path);
      privateFile2(info);
      const descriptor = (0, import_fs2.openSync)(path, import_fs2.constants.O_RDONLY | import_fs2.constants.O_NONBLOCK | (process.platform === "win32" ? 0 : import_fs2.constants.O_NOFOLLOW));
      try {
        const before = (0, import_fs2.fstatSync)(descriptor);
        privateFile2(before);
        check5(identity2(before) === identity2(info));
        const raw = readBoundedCompanionFile(descriptor, Number(info.size)), after = (0, import_fs2.fstatSync)(descriptor), current = (0, import_fs2.lstatSync)(path);
        privateFile2(after);
        privateFile2(current);
        check5(identity2(after) === identity2(info) && identity2(current) === identity2(info) && raw.length === info.size);
        return identity2(info) + ":" + digest4(raw);
      } finally {
        (0, import_fs2.closeSync)(descriptor);
      }
    } catch (error) {
      if (missing2(error)) return null;
      throw error;
    }
  }
  initialized() {
    const path = (0, import_path2.join)(this.directory, "authority-archive.initialized");
    try {
      this.baseDirectory(false);
      const info = (0, import_fs2.lstatSync)(path);
      privateFile2(info);
      check5(info.size === Buffer.byteLength(INITIALIZED));
      const descriptor = (0, import_fs2.openSync)(path, import_fs2.constants.O_RDONLY | (process.platform === "win32" ? 0 : import_fs2.constants.O_NOFOLLOW));
      try {
        check5(identity2((0, import_fs2.fstatSync)(descriptor)) === identity2(info) && readBoundedCompanionFile(descriptor, Number(info.size)).toString("utf8") === INITIALIZED && identity2((0, import_fs2.lstatSync)(path)) === identity2(info));
      } finally {
        (0, import_fs2.closeSync)(descriptor);
      }
      return true;
    } catch (error) {
      if (missing2(error)) return false;
      throw error;
    }
  }
  markInitialized() {
    if (this.initialized()) return;
    const path = (0, import_path2.join)(this.directory, "authority-archive.initialized"), temporary = (0, import_path2.join)(this.directory, `.${(0, import_crypto3.randomUUID)()}.initialized.tmp`);
    try {
      const descriptor = (0, import_fs2.openSync)(temporary, "wx", 384);
      try {
        (0, import_fs2.writeFileSync)(descriptor, INITIALIZED);
        (0, import_fs2.fsyncSync)(descriptor);
      } finally {
        (0, import_fs2.closeSync)(descriptor);
      }
      (0, import_fs2.renameSync)(temporary, path);
      if (process.platform !== "win32") {
        const descriptor2 = (0, import_fs2.openSync)(this.directory, "r");
        try {
          (0, import_fs2.fsyncSync)(descriptor2);
        } finally {
          (0, import_fs2.closeSync)(descriptor2);
        }
      }
      check5(this.initialized());
    } finally {
      if ((0, import_fs2.existsSync)(temporary)) (0, import_fs2.unlinkSync)(temporary);
    }
  }
  read(owner, prefix, ref) {
    reference2(ref);
    const path = (0, import_path2.join)(this.bucketDirectory(owner, prefix, false), segmentFile(ref)), info = (0, import_fs2.lstatSync)(path);
    privateFile2(info);
    check5(info.size === ref.bytes);
    const observed = identity2(info), cached = this.cache.get(path);
    if (cached?.identity === observed) {
      check5(cached.bytes === (ref.uncompressedBytes ?? ref.bytes));
      this.cache.delete(path);
      this.cache.set(path, cached);
      return cached.value;
    }
    const descriptor = (0, import_fs2.openSync)(path, import_fs2.constants.O_RDONLY | (process.platform === "win32" ? 0 : import_fs2.constants.O_NOFOLLOW));
    let raw;
    try {
      const before = (0, import_fs2.fstatSync)(descriptor);
      privateFile2(before);
      check5(identity2(before) === observed);
      raw = readBoundedCompanionFile(descriptor, Number(before.size));
      const after = (0, import_fs2.fstatSync)(descriptor), current = (0, import_fs2.lstatSync)(path);
      privateFile2(after);
      privateFile2(current);
      check5(identity2(after) === observed && identity2(current) === observed && raw.length === ref.bytes && digest4(raw) === ref.sha256);
    } finally {
      (0, import_fs2.closeSync)(descriptor);
    }
    const decoded = ref.encoding === "gzip" ? (0, import_zlib.gunzipSync)(raw, { maxOutputLength: ref.uncompressedBytes }) : raw;
    check5(decoded.length === (ref.uncompressedBytes ?? ref.bytes));
    const value = JSON.parse(decoded.toString("utf8"));
    object7(value);
    keys4(value, ["version", "kind", "prefix", "previous", "rows"]);
    check5(value.version === 1 && value.kind === owner && value.prefix === prefix && Array.isArray(value.rows) && value.rows.length > 0);
    if (value.previous !== void 0) reference2(value.previous);
    const seen = /* @__PURE__ */ new Set();
    for (const row of value.rows) {
      object7(row);
      keys4(row, ["key", "value"]);
      key(row.key);
      check5(Object.prototype.hasOwnProperty.call(row, "value") && prefixOf(row.key) === prefix && !seen.has(row.key));
      seen.add(row.key);
    }
    if (ref.filter !== void 0) {
      const filter = Buffer.from(ref.filter, "base64");
      for (const name of seen) check5(contains(filter, name));
      if (value.previous !== void 0 && value.previous.filter !== void 0) {
        const previous = Buffer.from(value.previous.filter, "base64");
        check5(previous.every((byte, index2) => (filter[index2] & byte) === byte));
      }
    }
    const segment = value;
    if (decoded.length <= CACHE_BYTES) {
      if (cached) {
        this.cache.delete(path);
        this.cacheBytes -= cached.bytes;
      }
      this.cache.set(path, { identity: observed, bytes: decoded.length, value: segment });
      this.cacheBytes += decoded.length;
      while (this.cacheBytes > CACHE_BYTES || this.cache.size > CACHE_ENTRIES) {
        const first = this.cache.keys().next().value;
        this.cacheBytes -= this.cache.get(first).bytes;
        this.cache.delete(first);
      }
    }
    return segment;
  }
  get(owner, name) {
    return this.getMany(owner, [name]).get(name);
  }
  getMany(owner, names) {
    kind(owner);
    check5(Array.isArray(names));
    const state = this.load(), groups = /* @__PURE__ */ new Map(), result = /* @__PURE__ */ new Map();
    for (const name of names) {
      key(name);
      const prefix = prefixOf(name);
      if (!groups.has(prefix)) groups.set(prefix, /* @__PURE__ */ new Set());
      groups.get(prefix).add(name);
    }
    for (const [prefix, unresolved] of groups) {
      let ref = state.heads[`${owner}:${prefix}`];
      const visited = /* @__PURE__ */ new Set();
      while (ref && unresolved.size) {
        if (ref.filter !== void 0) {
          const filter = Buffer.from(ref.filter, "base64");
          if (![...unresolved].some((name) => contains(filter, name))) break;
        }
        check5(!visited.has(ref.sha256));
        visited.add(ref.sha256);
        const segment = this.read(owner, prefix, ref);
        for (const row of segment.rows) if (unresolved.has(row.key)) {
          result.set(row.key, clone3(row.value));
          unresolved.delete(row.key);
        }
        ref = segment.previous;
      }
    }
    return result;
  }
  write(owner, prefix, rows, previous, current) {
    const segment = { version: 1, kind: owner, prefix, ...previous ? { previous } : {}, rows }, raw = Buffer.from(JSON.stringify(segment));
    check5(raw.length <= MAX_COMPANION_SNAPSHOT_BYTES);
    current();
    const filter = Buffer.alloc(FILTER_BYTES);
    let cursor = previous;
    const visited = /* @__PURE__ */ new Set();
    while (cursor) {
      if (cursor.filter !== void 0) {
        const prior = Buffer.from(cursor.filter, "base64");
        prior.forEach((byte, index2) => filter[index2] |= byte);
        break;
      }
      check5(!visited.has(cursor.sha256));
      visited.add(cursor.sha256);
      const segment2 = this.read(owner, prefix, cursor);
      for (const row of segment2.rows) include(filter, row.key);
      cursor = segment2.previous;
    }
    for (const row of rows) include(filter, row.key);
    const compressed = (0, import_zlib.gzipSync)(raw, { level: 6 }), encoded = compressed.length < raw.length ? compressed : raw;
    check5(encoded.length <= MAX_COMPANION_SNAPSHOT_BYTES);
    const directory = this.bucketDirectory(owner, prefix, true), ref = {
      sha256: digest4(encoded),
      bytes: encoded.length,
      filter: filter.toString("base64"),
      ...encoded === compressed ? { encoding: "gzip", uncompressedBytes: raw.length } : {}
    }, destination = (0, import_path2.join)(directory, segmentFile(ref));
    try {
      (0, import_fs2.lstatSync)(destination);
      this.read(owner, prefix, ref);
      return ref;
    } catch (error) {
      if (!missing2(error)) throw error;
    }
    const temporary = (0, import_path2.join)(directory, `.${(0, import_crypto3.randomUUID)()}.tmp`);
    try {
      const descriptor = (0, import_fs2.openSync)(temporary, "wx", 384);
      try {
        (0, import_fs2.writeFileSync)(descriptor, encoded);
        (0, import_fs2.fsyncSync)(descriptor);
      } finally {
        (0, import_fs2.closeSync)(descriptor);
      }
      current();
      (0, import_fs2.renameSync)(temporary, destination);
      if (process.platform !== "win32") {
        const descriptor2 = (0, import_fs2.openSync)(directory, "r");
        try {
          (0, import_fs2.fsyncSync)(descriptor2);
        } finally {
          (0, import_fs2.closeSync)(descriptor2);
        }
      }
      this.read(owner, prefix, ref);
      return ref;
    } finally {
      if ((0, import_fs2.existsSync)(temporary)) (0, import_fs2.unlinkSync)(temporary);
    }
  }
  putMany(owner, rows, current) {
    kind(owner);
    check5(Array.isArray(rows));
    current();
    const state = this.load(), heads = { ...state.heads }, groups = /* @__PURE__ */ new Map();
    const before = this.manifestIdentity();
    const seen = /* @__PURE__ */ new Map(), normalized2 = /* @__PURE__ */ new Map();
    for (const row of rows) {
      object7(row);
      keys4(row, ["key", "value"]);
      key(row.key);
      const raw = JSON.stringify(row.value);
      check5(raw !== void 0);
      const value = JSON.parse(raw);
      if (seen.has(row.key)) {
        check5(jsonFingerprint(seen.get(row.key)) === jsonFingerprint(value));
        continue;
      }
      seen.set(row.key, value);
      const prefix = prefixOf(row.key);
      if (!normalized2.has(prefix)) normalized2.set(prefix, []);
      normalized2.get(prefix).push({ key: row.key, value });
    }
    for (const [prefix, group] of normalized2) {
      const existing = this.getMany(owner, group.map((row) => row.key));
      const changed = group.filter((row) => !existing.has(row.key) || jsonFingerprint(existing.get(row.key)) !== jsonFingerprint(row.value));
      if (changed.length) groups.set(prefix, changed);
    }
    if (!groups.size) {
      current();
      check5(this.manifestIdentity() === before);
      if (before !== null) {
        this.markInitialized();
        if (process.platform !== "win32") {
          const descriptor = (0, import_fs2.openSync)(this.directory, "r");
          try {
            (0, import_fs2.fsyncSync)(descriptor);
          } finally {
            (0, import_fs2.closeSync)(descriptor);
          }
        }
        check5(this.manifestIdentity() === before);
      }
      return;
    }
    for (const [prefix, group] of groups) {
      let chunk = [], bytes = 0, previous = heads[`${owner}:${prefix}`];
      for (const row of group) {
        const size = Buffer.byteLength(JSON.stringify(row));
        check5(size + 1024 <= MAX_COMPANION_SNAPSHOT_BYTES);
        if (chunk.length && bytes + size > SEGMENT_TARGET_BYTES) {
          previous = this.write(owner, prefix, chunk, previous, current);
          chunk = [];
          bytes = 0;
        }
        chunk.push(row);
        bytes += size;
      }
      if (chunk.length) previous = this.write(owner, prefix, chunk, previous, current);
      heads[`${owner}:${prefix}`] = previous;
    }
    current();
    check5(this.manifestIdentity() === before);
    const published = manifestValue(heads);
    this.manifest.write(published);
    const committed = this.manifestIdentity();
    check5(committed !== null && JSON.stringify(this.manifest.read()) === JSON.stringify(published));
    this.seenManifest = true;
    this.markInitialized();
    check5(this.manifestIdentity() === committed);
    this.observed = committed;
  }
};

// src/infrastructure/companion/server/result-archive.ts
var copy6 = (value) => JSON.parse(JSON.stringify(value));
var statuses2 = ["applied", "stale", "epoch-mismatch", "missing", "ineligible", "local-session-active", "expired", "clock-mismatch", "core-adapter-unavailable"];
var resultKey = (scope, epoch, id2) => companionArchiveKey("result", scope, epoch, id2);
var ordinalKey = (scope, epoch, ordinal2) => companionArchiveKey("ordinal", scope, epoch, String(ordinal2));
var sentinelKey = (scope, epoch) => companionArchiveKey("present", scope, epoch);
var ordinal = (value) => invalid(Number.isSafeInteger(value) && Number(value) >= 1, "Invalid archived result ordinal");
function validate(value) {
  record2(value);
  keys(value, ["version", "outcome", "receiptHash", "ordinal", "miniAppAttempt", "editableGrade", "corrections"]);
  invalid(value.version === 1);
  record2(value.outcome);
  keys(value.outcome, ["attempt", "status"]);
  validateAttempt(value.outcome.attempt);
  const attempt = value.outcome.attempt;
  invalid(statuses2.includes(value.outcome.status) && typeof value.receiptHash === "string" && /^[a-f0-9]{64}$/.test(value.receiptHash));
  ordinal(value.ordinal);
  if (value.miniAppAttempt !== void 0) {
    record2(value.miniAppAttempt);
    keys(value.miniAppAttempt, ["id", "answerMatch"]);
    invalid(value.miniAppAttempt.id === attempt.id && (value.miniAppAttempt.answerMatch === void 0 || typeof value.miniAppAttempt.answerMatch === "boolean"));
  }
  if (value.editableGrade !== void 0) {
    record2(value.editableGrade);
    keys(value.editableGrade, ["attemptId", "materialId", "withAttachments", "reviewEventId", "rating", "expiresAt", "answerMatch"]);
    const grade = value.editableGrade;
    invalid(value.outcome.status === "applied" && grade.attemptId === attempt.id && typeof grade.withAttachments === "boolean" && [1, 2, 3, 4].includes(grade.rating) && (grade.answerMatch === void 0 || typeof grade.answerMatch === "boolean"));
    token2(grade.materialId);
    token2(grade.reviewEventId);
    timestamp(grade.expiresAt);
  }
  if (value.corrections !== void 0) {
    invalid(Array.isArray(value.corrections));
    const ids = /* @__PURE__ */ new Set();
    for (const row of value.corrections) {
      record2(row);
      keys(row, ["correction", "receipt"]);
      validateCompanionGradeCorrection(row.correction);
      const correction = row.correction;
      invalid(correction.scope === attempt.scope && correction.epoch === attempt.epoch && correction.attemptId === attempt.id && correction.cardId === attempt.cardId && correction.revision === attempt.revision && !ids.has(correction.id));
      ids.add(correction.id);
      if (row.receipt !== void 0) validateCompanionGradeCorrectionReceipt(row.receipt, correction);
    }
  }
}
function merge(previous, incoming) {
  invalid(sameAttempt(previous.outcome.attempt, incoming.outcome.attempt) && previous.outcome.status === incoming.outcome.status && previous.receiptHash === incoming.receiptHash && previous.ordinal === incoming.ordinal, "Archived result identity collision");
  const result = copy6(incoming);
  if (previous.miniAppAttempt) {
    invalid(!result.miniAppAttempt || previous.miniAppAttempt.answerMatch === void 0 || result.miniAppAttempt.answerMatch === void 0 || result.miniAppAttempt.answerMatch === previous.miniAppAttempt.answerMatch, "Archived Mini App result collision");
    result.miniAppAttempt = {
      ...copy6(previous.miniAppAttempt),
      ...result.miniAppAttempt,
      ...previous.miniAppAttempt.answerMatch === void 0 ? {} : { answerMatch: previous.miniAppAttempt.answerMatch }
    };
  }
  const corrections = new Map((previous.corrections ?? []).map((row) => [row.correction.id, copy6(row)]));
  for (const row of incoming.corrections ?? []) {
    const old = corrections.get(row.correction.id);
    if (old) {
      invalid(canonical2(old.correction) === canonical2(row.correction) && (!old.receipt || !row.receipt || canonical2(old.receipt) === canonical2(row.receipt)), "Archived correction identity collision");
      corrections.set(row.correction.id, { correction: copy6(row.correction), ...row.receipt || old.receipt ? { receipt: copy6(row.receipt ?? old.receipt) } : {} });
    } else corrections.set(row.correction.id, copy6(row));
  }
  if (corrections.size) result.corrections = [...corrections.values()];
  if (previous.editableGrade) {
    const next = result.editableGrade;
    if (next && canonical2(next) !== canonical2(previous.editableGrade)) {
      const latest = [...corrections.values()].filter((row) => row.receipt?.status === "applied").at(-1);
      invalid(latest?.receipt?.reviewEventId === next.reviewEventId && latest?.correction.rating === next.rating, "Archived grade head lacks its correction receipt");
      invalid(next.materialId === previous.editableGrade.materialId && next.withAttachments === previous.editableGrade.withAttachments && next.expiresAt === previous.editableGrade.expiresAt && (previous.editableGrade.answerMatch === void 0 || next.answerMatch === previous.editableGrade.answerMatch), "Archived grade metadata collision");
    }
    result.editableGrade ??= copy6(previous.editableGrade);
  }
  validate(result);
  return result;
}
function index(value) {
  record2(value);
  keys(value, ["version", "id"]);
  invalid(value.version === 1);
  token2(value.id);
  return value.id;
}
var DesktopServerResultArchive = class {
  archive;
  constructor(directory, binding2) {
    this.archive = new DesktopCompanionAuthorityArchive(directory, binding2);
  }
  get(scope, epoch, id2) {
    return this.getMany(scope, epoch, [id2]).get(id2);
  }
  getMany(scope, epoch, ids) {
    token2(scope);
    token2(epoch);
    for (const id2 of ids) token2(id2);
    const values = this.archive.getMany("server-result", ids.map((id2) => resultKey(scope, epoch, id2))), result = /* @__PURE__ */ new Map();
    for (const id2 of ids) {
      const row = values.get(resultKey(scope, epoch, id2));
      if (row === void 0) continue;
      validate(row);
      const attempt = row.outcome.attempt;
      invalid(attempt.scope === scope && attempt.epoch === epoch && attempt.id === id2, "Archived result identity collision");
      result.set(id2, copy6(row));
    }
    return result;
  }
  assertPresent(scope, epoch) {
    token2(scope);
    token2(epoch);
    const value = this.archive.get("server-result", sentinelKey(scope, epoch));
    record2(value);
    keys(value, ["version", "scope", "epoch"]);
    invalid(value.version === 1 && value.scope === scope && value.epoch === epoch, "Result archive unavailable");
  }
  page(scope, epoch, ordinals) {
    token2(scope);
    token2(epoch);
    for (const value of ordinals) ordinal(value);
    const positions2 = this.archive.getMany("server-result", ordinals.map((value) => ordinalKey(scope, epoch, value)));
    const ids = ordinals.map((value) => index(positions2.get(ordinalKey(scope, epoch, value)))), values = this.getMany(scope, epoch, ids);
    return ordinals.map((value, position) => {
      const row = values.get(ids[position]);
      invalid(row && row.ordinal === value, "Archived result page unavailable");
      return row;
    });
  }
  putMany(rows, current) {
    current();
    const staged = /* @__PURE__ */ new Map();
    for (const row of rows) {
      validate(row);
      const attempt = row.outcome.attempt, key2 = resultKey(attempt.scope, attempt.epoch, attempt.id), old = staged.get(key2);
      staged.set(key2, old ? merge(old, row) : copy6(row));
    }
    const previous = this.archive.getMany("server-result", [...staged.keys()]);
    const positions2 = this.archive.getMany("server-result", [...staged.values()].map((row) => ordinalKey(row.outcome.attempt.scope, row.outcome.attempt.epoch, row.ordinal)));
    const writes = /* @__PURE__ */ new Map();
    const write = (key2, value) => {
      writes.set(key2, { key: key2, value });
    };
    const assigned = /* @__PURE__ */ new Map();
    for (const [key2, incoming] of staged) {
      const prior = previous.get(key2);
      if (prior !== void 0) validate(prior);
      const row = prior === void 0 ? incoming : merge(prior, incoming), attempt = row.outcome.attempt, position = ordinalKey(attempt.scope, attempt.epoch, row.ordinal);
      const oldPosition = positions2.get(position);
      invalid(oldPosition === void 0 || index(oldPosition) === attempt.id, "Archived result ordinal collision");
      invalid(!assigned.has(position) || assigned.get(position) === attempt.id, "Archived result ordinal collision");
      assigned.set(position, attempt.id);
      write(key2, row);
      write(position, { version: 1, id: attempt.id });
      write(sentinelKey(attempt.scope, attempt.epoch), { version: 1, scope: attempt.scope, epoch: attempt.epoch });
      if (!attempt.offline) write(companionArchiveKey("suppressed", attempt.scope, attempt.epoch, attempt.cardId, attempt.revision), { version: 1, id: attempt.id });
      else if (row.outcome.status === "applied") write(companionArchiveKey("offline-root", attempt.scope, attempt.epoch, attempt.cardId, decodeOfflineStep(attempt.offline).rootRevision), { version: 1, id: attempt.id });
    }
    this.archive.putMany("server-result", [...writes.values()], current);
    current();
  }
  suppressed(snapshot) {
    token2(snapshot.scope);
    token2(snapshot.epoch);
    const queries = snapshot.cards.flatMap((card) => [
      { key: companionArchiveKey("suppressed", snapshot.scope, snapshot.epoch, card.id, card.revision), card, offline: false },
      ...card.offline ? [{ key: companionArchiveKey("offline-root", snapshot.scope, snapshot.epoch, card.id, decodeOfflineSeed(card.offline).rootRevision), card, offline: true }] : []
    ]);
    const positions2 = this.archive.getMany("server-result", queries.map((query) => query.key));
    const found = queries.flatMap((query) => {
      const value = positions2.get(query.key);
      return value === void 0 ? [] : [{ ...query, id: index(value) }];
    });
    const results = this.getMany(snapshot.scope, snapshot.epoch, found.map((query) => query.id)), attempts2 = [], offlineRoots = /* @__PURE__ */ new Set();
    for (const query of found) {
      const row = results.get(query.id);
      invalid(row && row.outcome.attempt.cardId === query.card.id, "Archived suppression evidence unavailable");
      const attempt = row.outcome.attempt;
      if (query.offline) {
        invalid(attempt.offline && row.outcome.status === "applied" && decodeOfflineStep(attempt.offline).rootRevision === decodeOfflineSeed(query.card.offline).rootRevision, "Archived offline root evidence unavailable");
        offlineRoots.add(`${attempt.cardId}:${decodeOfflineStep(attempt.offline).rootRevision}`);
      } else {
        invalid(!attempt.offline && attempt.revision === query.card.revision, "Archived revision evidence unavailable");
        attempts2.push(copy6(attempt));
      }
    }
    return { attempts: attempts2, offlineRoots };
  }
};

// src/infrastructure/companion/server/replay-archive.ts
var storageKind = "server-replay";
var isHash = (value) => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
function replayKey(enrollment, kind2, id2) {
  invalid(isHash(enrollment), "Invalid replay enrollment");
  invalid(typeof id2 === "string", "Invalid Telegram replay ID");
  if (kind2 === "update") {
    const number = Number(id2);
    invalid(Number.isSafeInteger(number) && number >= 0 && String(number) === id2, "Invalid Telegram update ID");
  } else invalid((kind2 === "callback" || kind2 === "miniapp") && id2.length > 0 && id2.length <= 128, "Invalid request ID");
  return companionArchiveKey(enrollment, kind2, id2);
}
var DesktopServerReplayArchive = class {
  archive;
  constructor(directory, binding2) {
    this.archive = new DesktopCompanionAuthorityArchive(directory, binding2);
  }
  assertPresent(enrollment) {
    invalid(isHash(enrollment) && this.archive.get(storageKind, companionArchiveKey(enrollment, "present")) === enrollment, "Telegram replay archive unavailable");
  }
  get(enrollment, kind2, id2) {
    const value = this.archive.get(storageKind, replayKey(enrollment, kind2, id2));
    if (value === void 0) return void 0;
    invalid(isHash(value), "Invalid Telegram replay digest");
    return value;
  }
  putMany(enrollment, rows) {
    if (!rows.length) return;
    const markerKey = companionArchiveKey(enrollment, "present");
    const staged = /* @__PURE__ */ new Map();
    for (const row of rows) {
      const key2 = replayKey(enrollment, row.kind, row.id), previous = staged.get(key2);
      invalid(isHash(row.hash), "Invalid Telegram replay digest");
      invalid(previous === void 0 || previous === row.hash, "Telegram replay identity collision");
      staged.set(key2, row.hash);
    }
    const existing = this.archive.getMany(storageKind, [markerKey, ...staged.keys()]);
    invalid(!existing.size || existing.get(markerKey) === enrollment, "Telegram replay archive unavailable");
    for (const [key2, hash2] of staged) {
      const previous = existing.get(key2);
      invalid(previous === void 0 || previous === hash2, "Telegram replay identity collision");
    }
    staged.set(markerKey, enrollment);
    this.archive.putMany(storageKind, [...staged].map(([key2, value]) => ({ key: key2, value })), () => void 0);
  }
};

// src/infrastructure/companion/server/journal.ts
var ServerJournal = class {
  constructor(path, observe) {
    this.observe = observe;
    this.path = (0, import_node_path3.resolve)(path);
    invalid((0, import_node_path3.basename)(this.path) !== "data.json", "not a plugin data file");
    this.content = new JournalContent(this.path);
    this.catalog = this.content.pages;
    this.results = new DesktopServerResultArchive((0, import_node_path3.dirname)(this.path), (0, import_node_crypto10.createHash)("sha256").update("server-results-v1:" + (0, import_node_path3.basename)(this.path)).digest("hex"));
    this.replay = new DesktopServerReplayArchive((0, import_node_path3.dirname)(this.path), (0, import_node_crypto10.createHash)("sha256").update("server-replay-v1:" + (0, import_node_path3.basename)(this.path)).digest("hex"));
  }
  lock;
  path;
  content;
  results;
  replay;
  catalog;
  async acquire() {
    invalid(!this.lock);
    const parent = await (0, import_promises3.lstat)((0, import_node_path3.dirname)(this.path));
    invalid(parent.isDirectory() && !parent.isSymbolicLink() && (parent.mode & 63) === 0, "journal directory must be private (0700)");
    this.lock = await (0, import_promises3.open)(`${this.path}.lock`, "wx", 384);
    await this.lock.writeFile(String(process.pid));
    await this.lock.sync();
  }
  async close() {
    if (this.lock) {
      await this.lock.close();
      this.lock = void 0;
      await (0, import_promises3.unlink)(`${this.path}.lock`);
    }
  }
  async load() {
    invalid(this.lock, "journal lock required");
    let raw;
    try {
      const info = await (0, import_promises3.lstat)(this.path);
      invalid(info.isFile() && !info.isSymbolicLink() && info.nlink === 1 && info.size <= 2e7 && (info.mode & 63) === 0);
      const file = await (0, import_promises3.open)(this.path, import_node_fs3.constants.O_RDONLY | (import_node_fs3.constants.O_NOFOLLOW ?? 0));
      try {
        const before = await file.stat();
        invalid(before.isFile() && before.nlink === 1 && before.ino === info.ino && before.size <= 2e7 && (before.mode & 63) === 0);
        const buffer = Buffer.allocUnsafe(before.size + 1);
        let offset = 0;
        while (offset < buffer.length) {
          const result = await file.read(buffer, offset, buffer.length - offset, offset);
          if (!result.bytesRead) break;
          offset += result.bytesRead;
        }
        invalid(offset === before.size);
        raw = buffer.subarray(0, offset).toString("utf8");
        const after = await file.stat();
        invalid(after.ino === before.ino && after.size === before.size && after.mtimeMs === before.mtimeMs && after.nlink === 1 && (after.mode & 63) === 0 && Buffer.byteLength(raw) <= 2e7);
      } finally {
        await file.close();
      }
    } catch (error) {
      if (error.code === "ENOENT") return void 0;
      throw new Error("journal unavailable; preserve for recovery");
    }
    const value = await this.content.decode(JSON.parse(raw));
    validateServerState(value, void 0, this.results);
    return value;
  }
  async save(state) {
    return this.validateAndSave(state);
  }
  /** The runtime may delegate its owner-specific check here instead of validating twice. */
  async validateAndSave(state, ownerChatId) {
    invalid(this.lock);
    const validationStarted = performance.now();
    try {
      validateServerState(state, ownerChatId, this.results);
    } finally {
      recordPerformance(this.observe, "journal.validate", performance.now() - validationStarted);
    }
    const started = performance.now();
    try {
      await this.write(state);
    } finally {
      recordPerformance(this.observe, "journal.write", performance.now() - started);
    }
  }
  async write(state) {
    const raw = JSON.stringify(await this.content.encode(state));
    invalid(Buffer.byteLength(raw) <= 2e7, "journal byte limit");
    const temp = `${this.path}.${(0, import_node_crypto10.randomUUID)()}.tmp`;
    let renamed = false;
    try {
      const file = await (0, import_promises3.open)(temp, "wx", 384);
      try {
        await file.writeFile(raw);
        await file.sync();
      } finally {
        await file.close();
      }
      await (0, import_promises3.rename)(temp, this.path);
      renamed = true;
      const dir = await (0, import_promises3.open)((0, import_node_path3.dirname)(this.path), "r");
      try {
        await dir.sync();
      } finally {
        await dir.close();
      }
    } catch {
      throw new Error(renamed ? "journal commit uncertain; restart required" : "journal commit failed");
    } finally {
      await (0, import_promises3.unlink)(temp).catch((error) => {
        if (error.code !== "ENOENT") throw error;
      });
    }
  }
};

// src/infrastructure/companion/server/shared-store.ts
var import_node_fs4 = require("node:fs");
var import_promises4 = require("node:fs/promises");
var import_node_path4 = require("node:path");
var import_node_crypto11 = require("node:crypto");
var SHARED_GATEWAY_FORMAT = "anchor-recall-gateway-v2";
var ROOT_BYTES = 2e7;
function privateFile3(info) {
  invalid(info.isFile() && !info.isSymbolicLink() && info.nlink === 1 && info.size <= ROOT_BYTES);
  if (process.platform !== "win32") invalid((info.mode & 63) === 0 && (process.getuid === void 0 || info.uid === process.getuid()));
}
var identity3 = (info) => [info.dev, info.ino, info.size, info.mode, info.nlink, info.mtimeMs, info.ctimeMs].join(":");
async function privateDirectory(path) {
  const info = await (0, import_promises4.lstat)(path);
  invalid(info.isDirectory() && !info.isSymbolicLink() && await (0, import_promises4.realpath)(path) === (0, import_node_path4.resolve)(path), "private directory required");
  if (process.platform !== "win32") {
    invalid((info.mode & 63) === 0 && (process.getuid === void 0 || info.uid === process.getuid()), "private directory required");
  }
}
var SharedFileStore = class {
  constructor(directory) {
    this.directory = directory;
    this.file = (0, import_node_path4.join)((0, import_node_path4.resolve)(directory), "gateway.json");
    this.pages = new DesktopCatalogPageStorage(this.file);
  }
  lock;
  file;
  pages;
  async acquire() {
    invalid(!this.lock);
    await privateDirectory(this.directory);
    this.lock = await (0, import_promises4.open)(this.file + ".lock", "wx", 384);
    await this.lock.writeFile(String(process.pid));
    await this.lock.sync();
  }
  async load() {
    invalid(this.lock);
    let info;
    try {
      info = await (0, import_promises4.lstat)(this.file);
    } catch (error) {
      if (error.code === "ENOENT") return void 0;
      throw new Error("gateway journal unavailable; preserve for recovery");
    }
    try {
      await privateDirectory(this.directory);
      privateFile3(info);
      const file = await (0, import_promises4.open)(this.file, import_node_fs4.constants.O_RDONLY | (import_node_fs4.constants.O_NOFOLLOW ?? 0));
      let raw;
      try {
        const before = await file.stat();
        privateFile3(before);
        invalid(identity3(before) === identity3(info));
        const buffer = Buffer.allocUnsafe(before.size + 1);
        let offset = 0;
        while (offset < buffer.length) {
          const read = await file.read(buffer, offset, buffer.length - offset, offset);
          if (!read.bytesRead) break;
          offset += read.bytesRead;
        }
        const after = await file.stat(), current = await (0, import_promises4.lstat)(this.file);
        privateFile3(after);
        privateFile3(current);
        invalid(offset === before.size && identity3(before) === identity3(after) && identity3(after) === identity3(current));
        raw = buffer.subarray(0, offset);
      } finally {
        await file.close();
      }
      const value = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(raw));
      if (value && typeof value === "object" && value.format === SHARED_GATEWAY_FORMAT) {
        record2(value);
        keys(value, ["format", "state"]);
        validateCatalogReference(value.state);
        return cloneJsonValue(await readPagedJson(value.state, this.pages));
      }
      return value;
    } catch {
      throw new Error("gateway journal unavailable; preserve for recovery");
    }
  }
  async save(value) {
    invalid(this.lock);
    const captured = cloneJsonValue(value);
    await privateDirectory(this.directory);
    const builder = new CatalogPageBuilder(), state = builder.value(captured);
    for (const page2 of builder.pages.values()) await this.pages.put(page2.reference, page2.bytes());
    await this.pages.flush();
    const raw = JSON.stringify({ format: SHARED_GATEWAY_FORMAT, state });
    invalid(Buffer.byteLength(raw) <= ROOT_BYTES);
    try {
      privateFile3(await (0, import_promises4.lstat)(this.file));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const temp = this.file + "." + (0, import_node_crypto11.randomUUID)() + ".tmp";
    try {
      const file = await (0, import_promises4.open)(temp, "wx", 384);
      try {
        await file.writeFile(raw);
        await file.sync();
      } finally {
        await file.close();
      }
      await (0, import_promises4.rename)(temp, this.file);
      if (process.platform !== "win32") {
        const directory = await (0, import_promises4.open)((0, import_node_path4.resolve)(this.directory), "r");
        try {
          await directory.sync();
        } finally {
          await directory.close();
        }
      }
    } finally {
      await (0, import_promises4.unlink)(temp).catch((error) => {
        if (error.code !== "ENOENT") throw error;
      });
    }
  }
  async close() {
    if (this.lock) {
      await this.lock.close();
      this.lock = void 0;
      await (0, import_promises4.unlink)(this.file + ".lock");
    }
  }
};

// src/infrastructure/companion/server/media-store.ts
var import_node_fs5 = require("node:fs");
var import_promises5 = require("node:fs/promises");
var import_node_path5 = require("node:path");
var import_node_crypto12 = require("node:crypto");
var budgetKeys = ["accountBytes", "totalBytes", "accountFiles", "totalFiles"];
function check6(value) {
  if (!value) throw new Error("Companion media unavailable; preserve private files");
}
function absent(error) {
  return error.code === "ENOENT";
}
function identity4(asset) {
  return { id: asset.id, kind: asset.kind, format: asset.format, bytes: asset.bytes };
}
function equal2(a, b) {
  return a.id === b.id && a.kind === b.kind && a.format === b.format && a.bytes === b.bytes;
}
function namespace(value) {
  check6(typeof value === "string" && /^[a-f0-9]{48}$/.test(value));
}
function privateFile4(info) {
  check6(info.isFile() && info.nlink === 1);
  if (process.platform !== "win32") check6((info.mode & 63) === 0 && (process.getuid === void 0 || info.uid === process.getuid()));
}
async function secureOpen(path, flags) {
  try {
    const info = await (0, import_promises5.lstat)(path);
    check6(!info.isSymbolicLink());
    privateFile4(info);
  } catch (error) {
    if (!absent(error) || !(flags & import_node_fs5.constants.O_CREAT)) throw error;
  }
  const file = await (0, import_promises5.open)(path, flags | (import_node_fs5.constants.O_NOFOLLOW ?? 0), 384);
  try {
    privateFile4(await file.stat());
    check6(!(await (0, import_promises5.lstat)(path)).isSymbolicLink());
    return file;
  } catch (error) {
    await file.close();
    throw error;
  }
}
async function syncDirectory2(path) {
  if (process.platform === "win32") return;
  const directory = await (0, import_promises5.open)(path, "r");
  try {
    await directory.sync();
  } finally {
    await directory.close();
  }
}
async function ensureDirectory(path, parent) {
  await privateDirectory(parent);
  try {
    await (0, import_promises5.mkdir)(path, { mode: 448 });
    await syncDirectory2(parent);
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
  }
  await privateDirectory(path);
}
async function metadata(path, id2) {
  const file = await secureOpen(path, import_node_fs5.constants.O_RDONLY);
  try {
    const info = await file.stat();
    check6(info.size > 0 && info.size <= 1024);
    const bytes = Buffer.alloc(1025), read = await file.read(bytes, 0, bytes.length, 0);
    check6(read.bytesRead === info.size && read.bytesRead <= 1024 && (await file.stat()).size === info.size);
    const value = JSON.parse(bytes.subarray(0, read.bytesRead).toString("utf8"));
    validateCompanionMediaIdentity(value);
    check6(value.id === id2);
    return identity4(value);
  } finally {
    await file.close();
  }
}
async function content(path, asset) {
  const file = await secureOpen(path, import_node_fs5.constants.O_RDONLY);
  try {
    check6((await file.stat()).size === asset.bytes);
    const bytes = Buffer.alloc(asset.bytes);
    let position = 0;
    while (position < bytes.length) {
      const result = await file.read(bytes, position, bytes.length - position, position);
      check6(result.bytesRead > 0);
      position += result.bytesRead;
    }
    const end = await file.read(Buffer.alloc(1), 0, 1, bytes.length);
    check6(end.bytesRead === 0 && (await file.stat()).size === asset.bytes && (0, import_node_crypto12.createHash)("sha256").update(bytes).digest("hex") === asset.id);
    return bytes;
  } finally {
    await file.close();
  }
}
var CompanionMediaRoot = class {
  root;
  state;
  limits;
  accounts = /* @__PURE__ */ new Map();
  accountBytes = /* @__PURE__ */ new Map();
  // A fresh process must also flush existing entries; failed barriers stay unknown.
  durableAccountDirectories = /* @__PURE__ */ new Set();
  totalBytes = 0;
  totalFiles = 0;
  initialized;
  tail = Promise.resolve();
  blocked = false;
  constructor(stateDirectory, limits = {}) {
    this.state = (0, import_node_path5.resolve)(stateDirectory);
    this.root = (0, import_node_path5.join)(this.state, "media");
    this.limits = { ...limits };
    check6(Object.keys(limits).every((key2) => budgetKeys.includes(key2)));
    for (const key2 of budgetKeys) if (this.limits[key2] !== void 0) check6(Number.isSafeInteger(this.limits[key2]) && this.limits[key2] > 0);
  }
  within(key2, value) {
    return Number.isSafeInteger(value) && value >= 0 && (this.limits[key2] === void 0 || value <= this.limits[key2]);
  }
  forAccount(enrollment) {
    namespace(enrollment);
    return { put: (chunk) => this.put(enrollment, chunk), status: (assets) => this.status(enrollment, assets), has: (asset) => this.has(enrollment, asset), read: (id2) => this.read(enrollment, id2) };
  }
  run(work) {
    const result = this.tail.then(async () => {
      check6(!this.blocked);
      await (this.initialized ??= this.scan());
      await privateDirectory(this.state);
      await privateDirectory(this.root);
      return work();
    });
    this.tail = result.then(() => void 0, () => void 0);
    return result.catch(() => {
      throw new Error("Companion media unavailable; preserve private files");
    });
  }
  async scan() {
    await privateDirectory(this.state);
    await ensureDirectory(this.root, this.state);
    let accountCount = 0;
    for await (const entry of await (0, import_promises5.opendir)(this.root)) {
      check6(this.within("totalFiles", ++accountCount));
      namespace(entry.name);
      check6(entry.isDirectory() && !entry.isSymbolicLink());
      const path = (0, import_node_path5.join)(this.root, entry.name);
      await privateDirectory(path);
      const records = /* @__PURE__ */ new Map(), files = /* @__PURE__ */ new Map();
      let count = 0;
      for await (const child of await (0, import_promises5.opendir)(path)) {
        ++count;
        check6(Number.isSafeInteger(count) && (this.limits.accountFiles === void 0 || count <= this.limits.accountFiles * 3));
        const match = /^([a-f0-9]{64})\.(json|part|bin)$/.exec(child.name);
        check6(match && child.isFile() && !child.isSymbolicLink());
        const info = await (0, import_promises5.lstat)((0, import_node_path5.join)(path, child.name));
        privateFile4(info);
        const kinds3 = files.get(match[1]) ?? /* @__PURE__ */ new Set();
        kinds3.add(match[2]);
        files.set(match[1], kinds3);
        if (match[2] === "json") records.set(match[1], await metadata((0, import_node_path5.join)(path, child.name), match[1]));
      }
      let bytes = 0;
      for (const [id2, kinds3] of files) {
        const asset = records.get(id2);
        check6(asset && !(kinds3.has("bin") && kinds3.has("part")));
        bytes += asset.bytes;
        for (const kind2 of ["part", "bin"]) if (kinds3.has(kind2)) {
          const size = (await (0, import_promises5.lstat)((0, import_node_path5.join)(path, id2 + "." + kind2))).size;
          check6(kind2 === "bin" ? size === asset.bytes : size <= asset.bytes);
        }
      }
      check6(this.within("accountBytes", bytes) && this.within("accountFiles", records.size));
      this.totalBytes += bytes;
      this.totalFiles += records.size;
      check6(this.within("totalBytes", this.totalBytes) && this.within("totalFiles", this.totalFiles));
      this.accounts.set(entry.name, records);
      this.accountBytes.set(entry.name, bytes);
    }
  }
  async account(enrollment) {
    const path = (0, import_node_path5.join)(this.root, enrollment);
    await privateDirectory(path);
    return path;
  }
  async syncAccountDirectory(path) {
    if (this.durableAccountDirectories.has(path)) return;
    await syncDirectory2(path);
    this.durableAccountDirectories.add(path);
  }
  async owned(enrollment, id2) {
    const known = this.accounts.get(enrollment)?.get(id2);
    if (!known) return void 0;
    const path = await this.account(enrollment), fresh = await metadata((0, import_node_path5.join)(path, id2 + ".json"), id2);
    check6(equal2(fresh, known));
    return fresh;
  }
  async reserve(enrollment, asset) {
    const records = this.accounts.get(enrollment) ?? /* @__PURE__ */ new Map();
    const bytes = this.accountBytes.get(enrollment) ?? 0;
    check6(this.within("accountFiles", records.size + 1) && this.within("totalFiles", this.totalFiles + 1) && this.within("accountBytes", bytes + asset.bytes) && this.within("totalBytes", this.totalBytes + asset.bytes));
    const path = (0, import_node_path5.join)(this.root, enrollment);
    await ensureDirectory(path, this.root);
    this.durableAccountDirectories.delete(path);
    try {
      const file = await secureOpen((0, import_node_path5.join)(path, asset.id + ".json"), import_node_fs5.constants.O_WRONLY | import_node_fs5.constants.O_CREAT | import_node_fs5.constants.O_EXCL);
      try {
        await file.writeFile(JSON.stringify(asset));
        await file.sync();
      } finally {
        await file.close();
      }
      await this.syncAccountDirectory(path);
    } catch (error) {
      this.blocked = true;
      throw error;
    }
    records.set(asset.id, asset);
    this.accounts.set(enrollment, records);
    this.accountBytes.set(enrollment, bytes + asset.bytes);
    this.totalFiles++;
    this.totalBytes += asset.bytes;
    return path;
  }
  async put(enrollment, chunk) {
    validateCompanionMediaChunk(chunk, MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES);
    const asset = identity4(chunk.asset), offset = chunk.offset, bytes = Buffer.from(chunk.data, "base64");
    check6(bytes.toString("base64") === chunk.data);
    return this.run(async () => {
      const known = await this.owned(enrollment, asset.id);
      check6(!known || equal2(known, asset));
      if (!known) check6(offset === 0);
      const path = known ? await this.account(enrollment) : await this.reserve(enrollment, asset);
      try {
        const complete = await content((0, import_node_path5.join)(path, asset.id + ".bin"), asset);
        check6(complete.subarray(offset, offset + bytes.length).equals(bytes));
        await this.syncAccountDirectory(path);
        return { id: asset.id, offset: asset.bytes, complete: true };
      } catch (error) {
        if (!absent(error)) throw error;
      }
      const partial = (0, import_node_path5.join)(path, asset.id + ".part"), directoryWasDurable = this.durableAccountDirectories.delete(path);
      let file;
      try {
        file = await secureOpen(partial, import_node_fs5.constants.O_RDWR | import_node_fs5.constants.O_CREAT | import_node_fs5.constants.O_EXCL);
      } catch (error) {
        if (error.code !== "EEXIST") throw error;
        if (directoryWasDurable) this.durableAccountDirectories.add(path);
        file = await secureOpen(partial, import_node_fs5.constants.O_RDWR);
      }
      let size;
      try {
        size = (await file.stat()).size;
        check6(size <= asset.bytes && offset <= size);
        const overlap = Math.min(bytes.length, size - offset), previous = Buffer.alloc(overlap);
        if (overlap) {
          const read = await file.read(previous, 0, overlap, offset);
          check6(read.bytesRead === overlap && previous.equals(bytes.subarray(0, overlap)));
        }
        let written = overlap;
        while (written < bytes.length) {
          const result = await file.write(bytes, written, bytes.length - written, offset + written);
          check6(result.bytesWritten > 0);
          written += result.bytesWritten;
        }
        await file.sync();
        size = (await file.stat()).size;
        check6(size <= asset.bytes);
      } finally {
        await file.close();
      }
      if (size === asset.bytes) {
        await content(partial, asset);
        this.durableAccountDirectories.delete(path);
        await (0, import_promises5.rename)(partial, (0, import_node_path5.join)(path, asset.id + ".bin"));
        await this.syncAccountDirectory(path);
        return { id: asset.id, offset: size, complete: true };
      }
      await this.syncAccountDirectory(path);
      return { id: asset.id, offset: size, complete: false };
    });
  }
  async status(enrollment, values) {
    validateCompanionMediaStatusAssets(values);
    const assets = values.map(identity4);
    return this.run(async () => {
      const files = [];
      for (const asset of assets) {
        const known = await this.owned(enrollment, asset.id);
        if (!known) {
          files.push({ id: asset.id, offset: 0, complete: false });
          continue;
        }
        check6(equal2(asset, known));
        const path = await this.account(enrollment);
        try {
          await content((0, import_node_path5.join)(path, asset.id + ".bin"), asset);
          await this.syncAccountDirectory(path);
          files.push({ id: asset.id, offset: asset.bytes, complete: true });
          continue;
        } catch (error) {
          if (!absent(error)) throw error;
        }
        const partial = (0, import_node_path5.join)(path, asset.id + ".part");
        let size = 0;
        try {
          const file = await secureOpen(partial, import_node_fs5.constants.O_RDWR);
          try {
            size = (await file.stat()).size;
            check6(size <= asset.bytes);
            await file.sync();
            check6((await file.stat()).size === size);
          } finally {
            await file.close();
          }
        } catch (error) {
          if (!absent(error)) throw error;
        }
        if (size === asset.bytes) {
          await content(partial, asset);
          this.durableAccountDirectories.delete(path);
          await (0, import_promises5.rename)(partial, (0, import_node_path5.join)(path, asset.id + ".bin"));
        }
        await this.syncAccountDirectory(path);
        files.push({ id: asset.id, offset: size, complete: size === asset.bytes });
      }
      return files;
    });
  }
  async has(enrollment, value) {
    validateCompanionMediaIdentity(value);
    const asset = identity4(value);
    return this.run(async () => {
      const known = await this.owned(enrollment, asset.id);
      if (!known) return false;
      check6(equal2(asset, known));
      try {
        const path = await this.account(enrollment);
        await content((0, import_node_path5.join)(path, asset.id + ".bin"), asset);
        await this.syncAccountDirectory(path);
        return true;
      } catch (error) {
        if (absent(error)) return false;
        throw error;
      }
    });
  }
  async read(enrollment, id2) {
    namespace(enrollment);
    check6(isCompanionMediaId(id2));
    return this.run(async () => {
      const asset = await this.owned(enrollment, id2);
      check6(asset);
      const path = await this.account(enrollment), bytes = await content((0, import_node_path5.join)(path, id2 + ".bin"), asset);
      await this.syncAccountDirectory(path);
      return { asset: identity4(asset), bytes };
    });
  }
};

// src/infrastructure/companion/server/shared-runtime.ts
function validateSharedConfig(value) {
  record2(value);
  keys(value, ["version", "enabled", "botUsername", "botToken", "stateDirectory", "host", "port", "externalTlsProxy", "pairingTtlMinutes", "maxAccounts", "maxPendingPairings", "sessionsLocal", "quietUpdates", "miniAppUrl"]);
  invalid(value.version === 1 && value.enabled === true);
  invalid(typeof value.botUsername === "string" && /^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(value.botUsername));
  invalid(typeof value.botToken === "string" && /^\d+:[A-Za-z0-9_-]{20,256}$/.test(value.botToken));
  invalid(typeof value.stateDirectory === "string" && (0, import_node_path6.isAbsolute)(value.stateDirectory));
  invalid(value.host === void 0 || typeof value.host === "string" && (["127.0.0.1", "::1", "localhost"].includes(value.host) || value.externalTlsProxy === true));
  invalid(value.externalTlsProxy === void 0 || typeof value.externalTlsProxy === "boolean");
  invalid(value.port === void 0 || Number.isInteger(value.port) && Number(value.port) > 0 && Number(value.port) <= 65535);
  for (const [key2, max] of [["pairingTtlMinutes", 10], ["maxPendingPairings", 1e4]])
    invalid(value[key2] === void 0 || Number.isInteger(value[key2]) && Number(value[key2]) > 0 && Number(value[key2]) <= max);
  invalid(value.maxAccounts === void 0 || Number.isSafeInteger(value.maxAccounts) && Number(value.maxAccounts) > 0);
  invalid(Array.isArray(value.sessionsLocal) && value.sessionsLocal.length > 0 && value.sessionsLocal.length <= 24 && value.sessionsLocal.every((v) => Number.isInteger(v) && Number(v) >= 0 && Number(v) < 1440));
  invalid(value.quietUpdates === void 0 || typeof value.quietUpdates === "boolean");
  if (value.miniAppUrl !== void 0) validateMiniAppUrl(value.miniAppUrl);
}
var clone4 = (value) => JSON.parse(JSON.stringify(value));
var hash = (value) => (0, import_node_crypto13.createHash)("sha256").update(value).digest("hex");
var opaque2 = () => (0, import_node_crypto13.randomBytes)(24).toString("hex");
var id = (value) => typeof value === "string" && /^[a-f0-9]{48}$/.test(value);
var positive = (value) => Number.isSafeInteger(value) && Number(value) > 0;
var validVaultName = (value) => typeof value === "string" && value.length > 0 && value.length <= 100 && value.trim() === value && !/[\p{Cc}]/u.test(value);
var ownedVaults = (state, userId, chatId) => state.accounts.filter((a) => a.active && a.userId === userId && a.chatId === chatId);
var physicalVault = (source) => source.vaultScope ?? source.scope;
var preferredVault = (owned) => owned.find((a) => a.preferred) ?? owned[0];
var baseVaultName = (account, index2) => account.vaultName ?? `\u0425\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 ${index2 + 1}`;
function vaultName(account, owned) {
  const index2 = owned.indexOf(account), name = baseVaultName(account, index2);
  if (!owned.some((entry, i) => entry !== account && baseVaultName(entry, i) === name)) return name;
  const suffix = ` (${index2 + 1})`;
  return name.slice(0, 100 - suffix.length).replace(/[\uD800-\uDBFF]$/u, "") + suffix;
}
function selectVault(owned, account) {
  for (const entry of owned) if (entry !== account) delete entry.preferred;
  account.preferred = true;
}
var planStartId = (text4) => typeof text4 === "string" ? parseStudyPlanStartParameter(/^\/start(?:@[A-Za-z0-9_]+)? (\S+)$/.exec(text4)?.[1] ?? "") : void 0;
function normalizedTelegramUpdate(update) {
  const value = update;
  if ([value.message, value.callback_query, value.poll_answer].filter((row) => row !== void 0).length !== 1) return { update_id: update.update_id };
  const poll = value.poll_answer;
  if (poll !== void 0) {
    const options = poll?.option_ids;
    if (!validNativePollId(poll?.poll_id) || !positive(poll?.user?.id) || poll?.user?.is_bot === true || poll?.voter_chat !== void 0 || !Array.isArray(options) || options.length > 12 || new Set(options).size !== options.length || !Array.from(options).every((option) => Number.isSafeInteger(option) && option >= 0 && option < 12)) return { update_id: update.update_id };
    return { update_id: update.update_id, poll_answer: { poll_id: poll.poll_id, user: { id: poll.user.id }, option_ids: [...options].sort((a, b) => a - b) } };
  }
  const callback = value.callback_query, message = callback?.message ?? value.message;
  const from = callback?.from ?? message?.from, chat = message?.chat;
  if (chat?.type !== "private" || !positive(chat.id) || !positive(from?.id) || chat.id !== from.id || from.is_bot === true) return { update_id: update.update_id };
  const owner = { id: from.id }, target = { id: chat.id, type: "private" };
  if (callback) return typeof callback.id === "string" && callback.id.length > 0 && callback.id.length <= 128 && typeof callback.data === "string" && /^[a-zA-Z0-9_-]{1,64}$/.test(callback.data) ? { update_id: update.update_id, callback_query: { id: callback.id, from: owner, message: { chat: target }, data: callback.data } } : { update_id: update.update_id };
  if (typeof message?.text !== "string" || message.text.length > 4096) return { update_id: update.update_id };
  if (message.reply_to_message !== void 0 && !positive(message.reply_to_message?.message_id)) return { update_id: update.update_id };
  return { update_id: update.update_id, message: {
    from: owner,
    chat: target,
    text: message.text,
    ...message.reply_to_message === void 0 ? {} : { reply_to_message: { message_id: message.reply_to_message.message_id } }
  } };
}
function messageAnchor(update) {
  if (update.poll_answer) return { kind: "poll", id: update.poll_answer.poll_id, userId: update.poll_answer.user.id };
  if (update.callback_query) {
    const data = update.callback_query.data;
    if (!/^(?:disconnect_|vault_)[a-f0-9]{48}$/.test(data)) return { kind: "callback", id: data };
  } else if (update.message?.reply_to_message) return { kind: "reply", id: update.message.reply_to_message.message_id };
  else {
    const planId = planStartId(update.message?.text);
    if (planId) return { kind: "plan", id: planId };
  }
  return void 0;
}
var binding = (value) => {
  token2(value.scope);
  token2(value.epoch);
  invalid(typeof value.timeZone === "string" && value.timeZone.length <= 100);
  new Intl.DateTimeFormat("en", { timeZone: value.timeZone });
};
var SharedCompanionGateway = class {
  constructor(config, transport, dependencies = {}) {
    this.config = config;
    this.transport = transport;
    this.dependencies = dependencies;
    validateSharedConfig(config);
    this.store = dependencies.store ?? new SharedFileStore(config.stateDirectory);
    this.mediaRoot = dependencies.mediaRoot ?? (dependencies.store === void 0 ? new CompanionMediaRoot(config.stateDirectory) : void 0);
  }
  state;
  active = false;
  tail = Promise.resolve();
  flushing;
  flushRequested = false;
  store;
  mediaRoot;
  accounts = /* @__PURE__ */ new Map();
  miniAppSessions = new MiniAppSessions();
  serial(work) {
    const next = this.tail.then(work);
    this.tail = next.then(() => void 0, () => void 0);
    return next;
  }
  check(now) {
    invalid(this.active, "gateway unavailable");
    timestamp(now);
    invalid(now >= this.state.timeFloor, "server clock moved backwards");
  }
  validate(state) {
    record2(state);
    keys(state, ["version", "botId", "pairs", "accounts", "inbox", "notices", "disconnects", "cursor", "lastUpdateAt", "timeFloor", "pairStarts"]);
    invalid(state.version === 1 && state.botId === this.config.botToken.split(":")[0]);
    timestamp(state.cursor);
    timestamp(state.lastUpdateAt);
    timestamp(state.timeFloor);
    invalid(Array.isArray(state.pairs) && state.pairs.length <= (this.config.maxPendingPairings ?? 1e3));
    invalid(Array.isArray(state.accounts));
    invalid(this.config.maxAccounts === void 0 || state.accounts.filter((account) => account.active).length <= this.config.maxAccounts);
    invalid(Array.isArray(state.inbox) && state.inbox.length <= 1e4 && Array.isArray(state.notices));
    invalid(state.notices.filter((notice) => notice.status === "queued").length <= 1e3);
    invalid(Array.isArray(state.disconnects) && state.disconnects.length <= 1e3);
    invalid(Array.isArray(state.pairStarts) && state.pairStarts.length <= 60);
    state.pairStarts.forEach(timestamp);
    const unique = (values) => invalid(new Set(values).size === values.length);
    unique(state.pairs.map((p) => p.id));
    unique(state.pairs.map((p) => p.code));
    unique(state.accounts.map((a) => a.enrollment));
    unique(state.accounts.filter((a) => a.active).map((a) => JSON.stringify([a.userId, a.chatId, a.scope])));
    unique(state.accounts.filter((a) => a.active).map((a) => JSON.stringify([a.userId, a.chatId, physicalVault(a)])));
    unique(state.accounts.filter((a) => a.active && a.preferred).map((a) => a.userId));
    unique(state.inbox.map((i) => i.updateId));
    unique(state.notices.map((n) => n.id));
    unique(state.disconnects.map((d) => d.id));
    for (const pair of state.pairs) {
      record2(pair);
      keys(pair, ["scope", "epoch", "timeZone", "id", "code", "pollHash", "expiresAt", "state", "userId", "chatId", "enrollment", "vaultName", "vaultScope"]);
      binding(pair);
      invalid(pair.vaultName === void 0 || validVaultName(pair.vaultName));
      if (pair.vaultScope !== void 0) token2(pair.vaultScope);
      invalid(id(pair.id) && id(pair.code) && typeof pair.pollHash === "string" && /^[a-f0-9]{64}$/.test(pair.pollHash));
      timestamp(pair.expiresAt);
      invalid(["pending", "approved", "confirmed"].includes(pair.state));
      invalid(pair.state === "pending" ? pair.userId === void 0 && pair.chatId === void 0 && pair.enrollment === void 0 : positive(pair.userId) && positive(pair.chatId));
      invalid(pair.state !== "confirmed" ? pair.enrollment === void 0 : id(pair.enrollment) && state.accounts.some((a) => a.enrollment === pair.enrollment && a.userId === pair.userId && a.chatId === pair.chatId && a.scope === pair.scope && a.epoch === pair.epoch && a.timeZone === pair.timeZone));
    }
    for (const account of state.accounts) {
      record2(account);
      keys(account, ["scope", "epoch", "timeZone", "enrollment", "userId", "chatId", "bridgeSecret", "webhookSecret", "active", "vaultName", "vaultScope", "preferred"]);
      binding(account);
      invalid(id(account.enrollment) && positive(account.userId) && account.chatId === account.userId && id(account.bridgeSecret) && id(account.webhookSecret) && account.bridgeSecret !== account.webhookSecret && typeof account.active === "boolean");
      invalid((account.vaultName === void 0 || validVaultName(account.vaultName)) && (account.preferred === void 0 || account.active && account.preferred === true));
      if (account.vaultScope !== void 0) token2(account.vaultScope);
    }
    for (const item of state.inbox) {
      record2(item);
      keys(item, ["updateId", "raw", "receivedAt", "enrollment", "candidates"]);
      timestamp(item.updateId);
      timestamp(item.receivedAt);
      invalid(typeof item.raw === "string" && Buffer.byteLength(item.raw) <= 65536 && (item.enrollment === void 0 || id(item.enrollment) && state.accounts.some((a) => a.enrollment === item.enrollment)));
      if (item.candidates !== void 0) {
        invalid(item.enrollment === void 0 && Array.isArray(item.candidates) && item.candidates.length > 0 && item.candidates.every((candidate) => id(candidate) && state.accounts.some((a) => a.enrollment === candidate)));
        unique(item.candidates);
      }
      const update = JSON.parse(item.raw);
      record2(update);
      invalid(update.update_id === item.updateId);
    }
    for (const item of state.notices) {
      record2(item);
      keys(item, ["id", "chatId", "text", "status", "confirmation", "callbackId", "miniAppEnrollment", "vaultChoices"]);
      invalid(id(item.id) && positive(item.chatId) && typeof item.text === "string" && item.text.length <= 500 && ["queued", "unknown"].includes(item.status));
      invalid(item.confirmation === void 0 || id(item.confirmation));
      invalid(item.callbackId === void 0 || typeof item.callbackId === "string" && item.callbackId.length > 0 && item.callbackId.length <= 128);
      invalid(item.miniAppEnrollment === void 0 || id(item.miniAppEnrollment) && !item.confirmation && !item.callbackId && state.accounts.some((a) => a.enrollment === item.miniAppEnrollment && a.chatId === item.chatId));
      invalid(item.vaultChoices === void 0 || item.vaultChoices === true && !item.confirmation && !item.callbackId && !item.miniAppEnrollment);
    }
    for (const item of state.disconnects) {
      record2(item);
      keys(item, ["id", "enrollment", "userId", "chatId", "expiresAt"]);
      invalid(id(item.id) && id(item.enrollment) && positive(item.userId) && positive(item.chatId));
      timestamp(item.expiresAt);
      invalid(state.accounts.some((a) => a.enrollment === item.enrollment && a.userId === item.userId && a.chatId === item.chatId));
    }
    invalid(Buffer.byteLength(JSON.stringify(state)) <= 2e7);
  }
  async commit(state) {
    this.validate(state);
    try {
      await this.store.save(state);
    } catch {
      this.active = false;
      throw new Error("gateway journal unavailable; restart required");
    }
    this.state = state;
  }
  async start() {
    await this.store.acquire();
    try {
      const loaded = await this.store.load();
      const state = loaded ?? { version: 1, botId: this.config.botToken.split(":")[0], pairs: [], accounts: [], inbox: [], notices: [], disconnects: [], cursor: 0, lastUpdateAt: 0, timeFloor: 0, pairStarts: [] };
      this.validate(state);
      await this.commit(state);
      this.active = true;
    } catch {
      await this.store.close();
      throw new Error("gateway startup failed; preserve state for recovery");
    }
  }
  prune(state, now) {
    state.pairs = state.pairs.filter((pair) => pair.expiresAt > now);
    state.disconnects = state.disconnects.filter((d) => d.expiresAt > now);
    state.pairStarts = state.pairStarts.filter((at) => at > now - 6e4);
    state.timeFloor = now;
  }
  async pairStart(payload, now = Date.now()) {
    record2(payload);
    keys(payload, ["version", "scope", "epoch", "timeZone", "vaultName", "vaultScope"]);
    invalid(payload.version === 1);
    binding(payload);
    const name = payload.vaultName, vaultScope = payload.vaultScope;
    invalid(name === void 0 || validVaultName(name));
    if (vaultScope !== void 0) token2(vaultScope);
    return this.serial(async () => {
      this.check(now);
      const next = clone4(this.state);
      this.prune(next, now);
      invalid(next.pairs.length < (this.config.maxPendingPairings ?? 1e3) && next.pairStarts.length < 60, "pairing capacity reached");
      const pollToken = (0, import_node_crypto13.randomBytes)(32).toString("hex"), pair = {
        id: opaque2(),
        code: opaque2(),
        pollHash: hash(pollToken),
        expiresAt: now + (this.config.pairingTtlMinutes ?? 10) * 6e4,
        scope: payload.scope,
        epoch: payload.epoch,
        timeZone: payload.timeZone,
        state: "pending",
        ...name === void 0 ? {} : { vaultName: name },
        ...vaultScope === void 0 ? {} : { vaultScope }
      };
      next.pairs.push(pair);
      next.pairStarts.push(now);
      await this.commit(next);
      return { pairingId: pair.id, startCode: pair.code, pollToken, expiresAt: pair.expiresAt, botUsername: this.config.botUsername };
    });
  }
  async pairing(payload, now) {
    this.check(now);
    record2(payload);
    keys(payload, ["pairingId", "pollToken"]);
    invalid(id(payload.pairingId) && typeof payload.pollToken === "string" && /^[a-f0-9]{64}$/.test(payload.pollToken), "invalid pairing");
    const pair = this.state.pairs.find((p) => p.id === payload.pairingId);
    invalid(pair && equal(pair.pollHash, hash(payload.pollToken)), "invalid or expired pairing");
    if (pair.expiresAt <= now) {
      const next = clone4(this.state);
      this.prune(next, now);
      await this.commit(next);
      throw new Error("pairing expired");
    }
    return pair;
  }
  async pairStatus(payload, now = Date.now()) {
    return this.serial(async () => {
      const pair = await this.pairing(payload, now);
      return { state: pair.state, expiresAt: pair.expiresAt, ...pair.userId === void 0 ? {} : { telegramUserId: pair.userId } };
    });
  }
  async pairConfirm(payload, now = Date.now()) {
    return this.serial(async () => {
      const pair = await this.pairing(payload, now);
      invalid(pair.state !== "pending", "approve in Telegram first");
      const next = clone4(this.state), current = next.pairs.find((p) => p.id === pair.id);
      if (pair.state === "confirmed") invalid(next.accounts.some((a) => a.enrollment === pair.enrollment && a.active), "pairing revoked");
      const owned = ownedVaults(next, current.userId, current.chatId);
      let account = owned.find((a) => a.scope === current.scope);
      if (account) invalid(account.epoch === current.epoch && account.timeZone === current.timeZone, "vault already linked; reconcile before changing its enrollment");
      else {
        invalid(this.config.maxAccounts === void 0 || next.accounts.filter((account2) => account2.active).length < this.config.maxAccounts, "account capacity reached");
        account = { enrollment: opaque2(), scope: current.scope, epoch: current.epoch, timeZone: current.timeZone, userId: current.userId, chatId: current.chatId, bridgeSecret: opaque2(), webhookSecret: opaque2(), active: true };
        next.accounts.push(account);
      }
      const vaultScope = account.vaultScope ?? current.vaultScope;
      invalid(!current.vaultScope || current.vaultScope === vaultScope, "vault already linked with another physical scope");
      invalid(owned.every((a) => a === account || physicalVault(a) !== (vaultScope ?? account.scope)), "vault already linked to this Telegram account");
      if (vaultScope !== void 0) account.vaultScope = vaultScope;
      if (current.vaultName && !account.vaultName) account.vaultName = current.vaultName;
      current.state = "confirmed";
      current.enrollment = account.enrollment;
      next.timeFloor = now;
      await this.commit(next);
      return { version: 1, scope: account.scope, epoch: account.epoch, enrollment: account.enrollment, timeZone: account.timeZone, bridgeSecret: account.bridgeSecret };
    });
  }
  async accountRuntime(account) {
    let opened = this.accounts.get(account.enrollment);
    if (opened) return opened;
    const authorized = () => this.active && this.state.accounts.some((a) => a.enrollment === account.enrollment && a.active);
    const target = {
      ready: () => authorized() && this.transport.ready?.() !== false,
      supportsNativePolls: () => authorized() && this.transport.supportsNativePolls?.() === true,
      cachedMedia: (enrollment, asset) => authorized() && enrollment === account.enrollment && this.transport.cachedMedia?.(account.enrollment, asset) === true,
      call: (method, payload, authorize, owned) => {
        const current = () => authorized() && authorize?.() !== false;
        invalid(current(), "enrollment archived");
        const media2 = isMediaMethod(method);
        return this.transport.call(method, media2 ? { ...payload, enrollment: account.enrollment } : payload, current, owned);
      }
    };
    const config = {
      enabled: true,
      scope: account.scope,
      epoch: account.epoch,
      enrollment: account.enrollment,
      ownerUserId: account.userId,
      ownerChatId: account.chatId,
      bridgeSecret: account.bridgeSecret,
      webhookSecret: account.webhookSecret,
      timeZone: account.timeZone,
      sessionsLocal: this.config.sessionsLocal,
      quietUpdates: this.config.quietUpdates,
      miniAppUrl: this.config.miniAppUrl,
      botUsername: this.config.botUsername,
      ...this.config.miniAppUrl ? { miniAppVaultId: account.enrollment } : {}
    };
    const media = this.mediaRoot?.forAccount(account.enrollment);
    if (this.dependencies.openAccount) opened = await this.dependencies.openAccount(account, config, target, media);
    else {
      const accountsRoot = (0, import_node_path6.join)(this.config.stateDirectory, "accounts"), directory = (0, import_node_path6.join)(accountsRoot, account.enrollment);
      await (0, import_promises6.mkdir)(accountsRoot, { mode: 448 }).catch((error) => {
        if (error.code !== "EEXIST") throw error;
      });
      await privateDirectory(accountsRoot);
      await (0, import_promises6.mkdir)(directory, { mode: 448 }).catch((error) => {
        if (error.code !== "EEXIST") throw error;
      });
      await privateDirectory(directory);
      const journalPath = (0, import_node_path6.join)(directory, "journal.json");
      try {
        const info = await (0, import_promises6.lstat)(journalPath);
        invalid(info.isFile() && !info.isSymbolicLink());
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      const journal = new ServerJournal(journalPath, this.dependencies.observe);
      await journal.acquire();
      try {
        const runtime = new CompanionServer(config, journal, target, media, this.dependencies.observe);
        await runtime.start();
        opened = { runtime, close: () => journal.close() };
      } catch {
        await journal.close();
        throw new Error("account journal unavailable");
      }
    }
    this.accounts.set(account.enrollment, opened);
    return opened;
  }
  async bridge(path, raw, signature, now = Date.now(), binary = false) {
    invalid(["/bridge/snapshot", "/bridge/pending", "/bridge/ack"].includes(path) && Buffer.byteLength(raw) <= MAX_COMPANION_BRIDGE_BYTES);
    return this.serial(async () => {
      this.check(now);
      const envelope = JSON.parse(raw);
      record2(envelope);
      const account = this.state.accounts.find((a) => a.enrollment === envelope.enrollment && a.active);
      invalid(account, "unknown or archived enrollment");
      return (await this.accountRuntime(account)).runtime.bridge(path, raw, signature, now, binary);
    });
  }
  async miniAppAuthenticate(payload, now = Date.now()) {
    record2(payload);
    keys(payload, ["initData", "vaultId", "planId"]);
    const planId = payload.planId;
    invalid(typeof payload.initData === "string" && (payload.vaultId === void 0 || id(payload.vaultId)) && (planId === void 0 || payload.vaultId === void 0 && typeof planId === "string" && /^[a-f0-9]{64}$/.test(planId)));
    return this.serial(async () => {
      this.check(now);
      invalid(this.config.miniAppUrl, "Mini App unavailable");
      const identity5 = verifyMiniAppInitData(payload.initData, this.config.botToken, now);
      const owned = ownedVaults(this.state, identity5.userId, identity5.chatId);
      let account = payload.vaultId === void 0 ? preferredVault(owned) : owned.find((a) => a.enrollment === payload.vaultId);
      if (typeof planId === "string" && owned.length > 1) {
        const target = await this.anchoredTarget(owned, { kind: "plan", id: planId }, false, now);
        account = !target.waiting && target.matches.length === 1 ? target.matches[0] : void 0;
      }
      invalid(account, "Mini App unauthorized");
      return this.miniAppVaultSession(account, owned, now);
    });
  }
  async miniAppSwitchVault(sessionToken, payload, now = Date.now()) {
    record2(payload);
    keys(payload, ["vaultId"]);
    invalid(id(payload.vaultId), "Mini App unauthorized");
    return this.serial(async () => {
      const previous = this.miniAppAccount(sessionToken, now), next = clone4(this.state);
      const owned = ownedVaults(next, previous.userId, previous.chatId);
      const account = owned.find((a) => a.enrollment === payload.vaultId);
      invalid(account, "Mini App unauthorized");
      if (!account.preferred) {
        selectVault(owned, account);
        next.timeFloor = now;
        await this.commit(next);
      }
      return this.miniAppVaultSession(account, owned, now, sessionToken);
    });
  }
  miniAppVaultSession(account, owned, now, previousToken) {
    const session = this.miniAppSessions.issue({ enrollment: account.enrollment, userId: account.userId, epoch: account.epoch }, now, previousToken);
    return {
      ...session,
      storageScope: hash(JSON.stringify(["miniapp-storage-v1", this.state.botId, account.userId, account.enrollment, account.scope, account.epoch])),
      vaultId: account.enrollment,
      vaults: owned.map((entry) => ({ id: entry.enrollment, name: vaultName(entry, owned) }))
    };
  }
  miniAppAccount(sessionToken, now) {
    this.check(now);
    invalid(this.config.miniAppUrl, "Mini App unauthorized");
    const binding2 = this.miniAppSessions.get(sessionToken, now);
    const account = binding2 && this.state.accounts.find((a) => a.active && a.enrollment === binding2.enrollment && a.userId === binding2.userId && a.epoch === binding2.epoch);
    invalid(account, "Mini App unauthorized");
    return account;
  }
  async miniAppStudy(sessionToken, payload, now = Date.now()) {
    return this.serial(async () => {
      const account = this.miniAppAccount(sessionToken, now);
      const view = await (await this.accountRuntime(account)).runtime.miniApp(payload, now);
      const active = ["question", "result", "waiting", "paused"].includes(view.status);
      const lessonDeadline = view.status !== "paused" ? view.session?.deadlineAt : void 0;
      const lessonCap = view.session?.startedAt === void 0 ? void 0 : view.session.startedAt + MINIAPP_SESSION_TTL_MS;
      const deadline = lessonDeadline === void 0 ? lessonCap : Math.min(lessonCap ?? Infinity, lessonDeadline + MINIAPP_FINISH_GRACE_MS);
      const expiresAt = active ? this.miniAppSessions.setExpiry(sessionToken, deadline, now) : this.miniAppSessions.expiresAt(sessionToken, now);
      invalid(expiresAt !== void 0, "Mini App unauthorized");
      return { ...view, connectionExpiresAt: expiresAt };
    });
  }
  async miniAppMedia(sessionToken, assetId, now = Date.now()) {
    return this.serial(async () => {
      const account = this.miniAppAccount(sessionToken, now);
      return (await this.accountRuntime(account)).runtime.miniAppMedia(assetId, now);
    });
  }
  nextUpdateOffset(now = Date.now()) {
    return this.state?.lastUpdateAt > 0 && now - this.state.lastUpdateAt < 6 * 864e5 ? this.state.cursor + 1 : void 0;
  }
  notice(state, chatId, text4) {
    invalid(state.notices.filter((notice2) => notice2.status === "queued").length < 1e3, "notice capacity reached");
    const notice = { id: opaque2(), chatId, text: text4, status: "queued" };
    state.notices.push(notice);
    return notice;
  }
  async anchoredTarget(accounts, anchor, waitForDelivery, now) {
    const matches = [];
    let waiting = false;
    for (const account of accounts) {
      try {
        const { runtime } = await this.accountRuntime(account);
        const owned = anchor.kind === "poll" ? runtime.ownsPoll(anchor.id, anchor.userId) : anchor.kind === "reply" ? runtime.ownsReply(anchor.id) : anchor.kind === "plan" ? runtime.ownsPlanLaunch(anchor.id, now) : runtime.ownsCallback(anchor.id);
        if (owned) matches.push(account);
        else if (account.active && (!(await runtime.health()).active || waitForDelivery && (anchor.kind === "poll" && runtime.pollDeliveryPending() || anchor.kind === "reply" && runtime.replyDeliveryPending()))) waiting = true;
      } catch {
        if (account.active) waiting = true;
      }
    }
    return { matches, waiting };
  }
  async telegramUpdate(update, now = Date.now()) {
    record2(update);
    timestamp(update.update_id);
    invalid(Number(update.update_id) < Number.MAX_SAFE_INTEGER);
    const normalized2 = normalizedTelegramUpdate(update), raw = JSON.stringify(normalized2);
    invalid(Buffer.byteLength(raw) <= 65536);
    await this.serial(async () => {
      this.check(now);
      const next = clone4(this.state);
      if (next.lastUpdateAt > 0 && update.update_id <= next.cursor && now - next.lastUpdateAt < 6 * 864e5) return;
      invalid(next.inbox.length < 1e4, "inbox capacity reached");
      const source = normalized2, message = source.callback_query?.message ?? source.message, from = source.callback_query?.from ?? message?.from;
      const owned = source.poll_answer ? ownedVaults(next, source.poll_answer.user.id, source.poll_answer.user.id) : message?.chat?.type === "private" && message.chat.id === from?.id && from?.is_bot !== true ? ownedVaults(next, from.id, message.chat.id) : [];
      const anchor = messageAnchor(source);
      const requireExactTarget = anchor && owned.length > 0 && next.accounts.filter((a) => a.userId === owned[0].userId && a.chatId === owned[0].chatId).length > 1;
      let account = requireExactTarget ? void 0 : preferredVault(owned);
      if (source.poll_answer) {
        if (account && anchor) {
          const target = await this.anchoredTarget([account], anchor, true, now);
          if (!target.waiting && !target.matches.length) account = void 0;
        }
      }
      next.inbox.push({
        updateId: update.update_id,
        raw,
        receivedAt: now,
        ...account ? { enrollment: account.enrollment } : {},
        ...requireExactTarget ? { candidates: owned.map((entry) => entry.enrollment) } : {}
      });
      next.cursor = update.update_id;
      next.lastUpdateAt = now;
      next.timeFloor = now;
      await this.commit(next);
      await this.processInbox(now);
    });
  }
  async processInbox(now = this.state.timeFloor) {
    for (const item of [...this.state.inbox]) {
      const update = JSON.parse(item.raw), callback = update.callback_query, message = callback?.message ?? update.message;
      const from = callback?.from ?? message?.from, chat = message?.chat;
      const principal = chat?.type === "private" && positive(chat.id) && positive(from?.id) && chat.id === from.id && from.is_bot !== true;
      let next = clone4(this.state), enrollment = item.enrollment;
      const anchor = messageAnchor(update);
      if (item.candidates && anchor) {
        const ownerId = update.poll_answer?.user.id ?? (principal ? from.id : void 0);
        const candidates = next.accounts.filter((a) => a.userId === ownerId && a.chatId === ownerId && item.candidates.includes(a.enrollment));
        const target = await this.anchoredTarget(candidates, anchor, item.receivedAt <= now && now - item.receivedAt <= 3e4, now);
        if (target.matches.length === 1 && !(anchor.kind === "plan" && target.waiting)) {
          const bound = next.inbox.find((row) => row.updateId === item.updateId);
          enrollment = target.matches[0].enrollment;
          bound.enrollment = enrollment;
          delete bound.candidates;
          await this.commit(next);
          next = clone4(this.state);
        } else if (target.waiting && target.matches.length < 2) continue;
        else if (anchor.kind === "plan" && principal) {
          this.notice(next, chat.id, target.matches.length > 1 ? "\u042D\u0442\u043E\u0442 \u043F\u043B\u0430\u043D \u0435\u0441\u0442\u044C \u0432 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u0445 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430\u0445. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043D\u0443\u0436\u043D\u043E\u0435 \u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u043B\u0430\u043D \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438." : "\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \u043F\u043E \u044D\u0442\u043E\u0439 \u0441\u0441\u044B\u043B\u043A\u0435 \u0443\u0436\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E. \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u0438 \u043E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u043B\u0430\u043D \u0432 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0438.").vaultChoices = true;
        }
      }
      if (update.poll_answer) {
        const vote = update.poll_answer, account = next.accounts.find((a) => a.enrollment === enrollment && a.userId === vote.user.id);
        if (account && !account.active) continue;
        if (account) {
          try {
            const { runtime } = await this.accountRuntime(account);
            verifyPrivateTelegramUpdate(item.raw, account.webhookSecret, { enabled: true, webhookSecret: account.webhookSecret, userId: account.userId, chatId: account.chatId });
            if (!(await runtime.health()).active) continue;
            if (runtime.ownsPoll(vote.poll_id, vote.user.id)) await runtime.webhook(item.raw, account.webhookSecret, item.receivedAt);
            else if (runtime.pollDeliveryPending() && item.receivedAt <= now && now - item.receivedAt <= 3e4) continue;
          } catch {
            continue;
          }
        }
      } else if (principal && typeof message?.text === "string" && !callback && message.reply_to_message === void 0 && /^\/start(?:@[A-Za-z0-9_]+)? [a-f0-9]{48}$/.test(message.text)) {
        const code = message.text.slice(message.text.lastIndexOf(" ") + 1), pair = next.pairs.find((p) => p.code === code);
        if (pair && pair.state === "pending" && pair.expiresAt > item.receivedAt) {
          pair.state = "approved";
          pair.userId = from.id;
          pair.chatId = chat.id;
          this.notice(next, chat.id, "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0432 Obsidian. \u0414\u043E \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u043D\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u044E\u0442\u0441\u044F.");
        }
      } else if (principal) {
        const owned = ownedVaults(next, from.id, chat.id);
        const account = next.accounts.find((a) => a.enrollment === enrollment && a.userId === from.id && a.chatId === chat.id);
        if (!callback && message.reply_to_message === void 0 && /^\/vaults(?:@[A-Za-z0-9_]+)?$/i.test(message.text)) {
          if (owned.length) this.notice(next, chat.id, "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435. \u041E\u043D\u043E \u0431\u0443\u0434\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0442\u044C\u0441\u044F \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E.").vaultChoices = true;
          else this.notice(next, chat.id, "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 Telegram \u0432 Obsidian.");
        } else if (callback && /^vault_[a-f0-9]{48}$/.test(callback.data)) {
          const chosen = owned.find((a) => a.enrollment === callback.data.slice(6));
          if (chosen) {
            selectVault(owned, chosen);
            const notice = this.notice(next, chat.id, `\u0412\u044B\u0431\u0440\u0430\u043D\u043E \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \xAB${vaultName(chosen, owned)}\xBB.`);
            if (this.config.miniAppUrl) notice.miniAppEnrollment = chosen.enrollment;
          }
          this.notice(next, chat.id, "").callbackId = callback.id;
        } else if (callback && /^disconnect_[a-f0-9]{48}$/.test(callback.data)) {
          const confirmation = next.disconnects.find((d) => d.id === callback.data.slice(11) && d.userId === from.id && d.chatId === chat.id && d.expiresAt > item.receivedAt);
          const target = confirmation && owned.find((a) => a.enrollment === confirmation.enrollment);
          if (target) {
            target.active = false;
            delete target.preferred;
            next.disconnects = next.disconnects.filter((d) => d.enrollment !== target.enrollment);
            this.miniAppSessions.revokeEnrollment(target.enrollment);
            next.pairs = next.pairs.filter((p) => !(p.userId === target.userId && p.chatId === target.chatId && (p.enrollment === target.enrollment || physicalVault(p) === physicalVault(target))));
            this.notice(next, chat.id, "\u0425\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u043E\u0442\u043A\u043B\u044E\u0447\u0435\u043D\u043E. \u0415\u0433\u043E \u043E\u0442\u0432\u0435\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u0432 \u0430\u0440\u0445\u0438\u0432\u0435.");
            this.notice(next, chat.id, "").callbackId = callback.id;
          }
        } else if (account && !account.active) continue;
        else if (account && !callback && message.reply_to_message === void 0 && /^\/disconnect(?:@[A-Za-z0-9_]+)?$/i.test(message.text)) {
          next.disconnects = next.disconnects.filter((d) => d.expiresAt > item.receivedAt && d.enrollment !== account.enrollment);
          invalid(next.disconnects.length < 1e3);
          const confirmation = opaque2();
          next.disconnects.push({ id: confirmation, enrollment: account.enrollment, userId: account.userId, chatId: account.chatId, expiresAt: item.receivedAt + 3e5 });
          this.notice(next, chat.id, `\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C \xAB${vaultName(account, owned)}\xBB? \u041D\u0435\u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0435 \u043E\u0442\u0432\u0435\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0442\u0441\u044F \u0432 \u0430\u0440\u0445\u0438\u0432\u0435. \u041A\u043D\u043E\u043F\u043A\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 5 \u043C\u0438\u043D\u0443\u0442.`).confirmation = confirmation;
        } else if (account) {
          const raw = JSON.stringify({ update_id: update.update_id, ...callback ? { callback_query: callback } : { message: update.message } });
          try {
            verifyPrivateTelegramUpdate(raw, account.webhookSecret, { enabled: true, webhookSecret: account.webhookSecret, userId: account.userId, chatId: account.chatId });
          } catch {
            next.inbox = next.inbox.filter((i) => i.updateId !== item.updateId);
            await this.commit(next);
            continue;
          }
          try {
            const { runtime } = await this.accountRuntime(account);
            if (anchor?.kind === "reply" && !runtime.ownsReply(anchor.id) && runtime.replyDeliveryPending() && now - item.receivedAt <= 3e4) continue;
            await runtime.webhook(raw, account.webhookSecret, item.receivedAt);
            if (callback && this.flushing) void runtime.flushAcknowledgements().catch(() => void 0);
          } catch {
            continue;
          }
        } else if (typeof message?.text === "string" && message.text === "/start") {
          this.notice(next, chat.id, "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 Telegram \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 Anchor Recall \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u043B\u0438\u0447\u043D\u0443\u044E \u0441\u0441\u044B\u043B\u043A\u0443.");
        }
      }
      next.inbox = next.inbox.filter((i) => i.updateId !== item.updateId);
      await this.commit(next);
    }
  }
  async tick(now = Date.now()) {
    await this.serial(async () => {
      this.check(now);
      await this.processInbox(now);
      for (const account of this.state.accounts.filter((a) => a.active)) {
        try {
          await (await this.accountRuntime(account)).runtime.tick(now);
        } catch {
        }
      }
    });
  }
  async flush() {
    if (this.transport.ready?.() === false) return;
    if (this.flushing) {
      this.flushRequested = true;
      return this.flushing;
    }
    this.flushing = (async () => {
      do {
        this.flushRequested = false;
        await this.tail;
        invalid(this.active);
        const chats = [.../* @__PURE__ */ new Set([
          ...this.state.notices.filter((n) => n.status === "queued").map((n) => n.chatId),
          ...this.state.accounts.filter((a) => a.active && this.accounts.has(a.enrollment)).map((a) => a.chatId)
        ])];
        let cursor = 0;
        const worker = async () => {
          while (cursor < chats.length) {
            const chatId = chats[cursor++];
            for (; ; ) {
              const notice = await this.serial(async () => {
                invalid(this.active);
                const found = this.state.notices.find((n) => n.chatId === chatId && n.status === "queued");
                if (!found) return void 0;
                const next = clone4(this.state);
                next.notices.find((n) => n.id === found.id).status = "unknown";
                await this.commit(next);
                return found;
              });
              if (!notice) break;
              try {
                const owned = notice.vaultChoices ? ownedVaults(this.state, chatId, chatId) : [];
                const launch = notice.miniAppEnrollment && this.config.miniAppUrl ? { miniAppUrl: this.config.miniAppUrl, vaultId: notice.miniAppEnrollment } : void 0;
                const keyboard = notice.confirmation ? [[{ text: "\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435", callback_data: "disconnect_" + notice.confirmation }]] : launch ? [[{ text: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435", web_app: { url: miniAppLaunchUrl(launch.miniAppUrl, void 0, launch.vaultId) } }]] : owned.map((account) => [{ text: vaultName(account, owned), callback_data: "vault_" + account.enrollment }]);
                const payload = notice.callbackId ? { callback_query_id: notice.callbackId } : { chat_id: notice.chatId, text: notice.text, disable_notification: true, link_preview_options: { is_disabled: true }, reply_markup: { inline_keyboard: keyboard } };
                await this.transport.call(
                  notice.callbackId ? "answerCallbackQuery" : "sendMessage",
                  payload,
                  () => !launch || this.state.accounts.some((a) => a.active && a.enrollment === launch.vaultId && a.chatId === notice.chatId),
                  launch
                );
              } catch {
                continue;
              }
              await this.serial(async () => {
                const next = clone4(this.state);
                next.notices = next.notices.filter((n) => n.id !== notice.id);
                await this.commit(next);
              });
            }
            for (const account of ownedVaults(this.state, chatId, chatId)) {
              const opened = this.accounts.get(account.enrollment);
              if (!opened) continue;
              try {
                await opened.runtime.flush();
              } catch {
              }
              if (this.state.inbox.some((item) => (item.enrollment === account.enrollment || item.candidates?.includes(account.enrollment)) && ["poll", "reply"].includes(messageAnchor(JSON.parse(item.raw))?.kind ?? ""))) await this.serial(async () => {
                const pending = this.state.inbox.length;
                await this.processInbox();
                if (this.state.inbox.length < pending) this.flushRequested = true;
              });
            }
          }
        };
        const results = await Promise.allSettled(Array.from({ length: Math.min(4, chats.length) }, worker));
        const failed = results.find((result) => result.status === "rejected");
        if (failed) throw failed.reason;
      } while (this.flushRequested);
    })().finally(() => {
      this.flushing = void 0;
    });
    return this.flushing;
  }
  async drain() {
    await this.flushing;
    await this.tail;
    for (const opened of this.accounts.values()) await opened.runtime.drain();
  }
  async health() {
    await this.tail;
    return { active: this.active, accounts: this.state?.accounts.filter((a) => a.active).length ?? 0, archivedAccounts: this.state?.accounts.filter((a) => !a.active).length ?? 0, pendingPairings: this.state?.pairs.filter((p) => p.state !== "confirmed").length ?? 0, inbox: this.state?.inbox.length ?? 0, unknownDeliveries: this.state?.notices.filter((n) => n.status === "unknown").length ?? 0 };
  }
  async close() {
    await this.drain();
    this.active = false;
    for (const opened of this.accounts.values()) await opened.close();
    this.accounts.clear();
    await this.store.close();
  }
};

// src/infrastructure/companion/server/http-shared.ts
var import_node_http = require("node:http");

// src/ui/companion/miniapp-local-state.ts
function createMiniAppLocalState(store, failed, now = () => Date.now()) {
  let scope = "", generation = 0, ready = false, answer = null, presets = [];
  let tail = Promise.resolve(), writing = false, presetWrite;
  const writes = /* @__PURE__ */ new Map();
  const fields4 = ["learningGroup", "questionKind", "section", "topic", "tag", "knowledgeState"];
  const copy7 = (value) => JSON.parse(JSON.stringify(value));
  const plain = (value) => !!value && typeof value === "object" && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
  const text4 = (value, max) => typeof value === "string" && value.length <= max;
  const indexes = (value, partial = false) => Array.isArray(value) && value.length <= 12 && value.every((index2) => Number.isSafeInteger(index2) && index2 >= (partial ? -1 : 0) && index2 < 12);
  const validDraft = (value) => plain(value) && Object.keys(value).length === 6 && ["key", "selected", "text", "blanks", "matches", "order"].every((key3) => Object.prototype.hasOwnProperty.call(value, key3)) && text4(value.key, 600) && !!value.key && indexes(value.selected) && new Set(value.selected).size === value.selected.length && text4(value.text, 4e3) && Array.isArray(value.blanks) && value.blanks.length <= 12 && value.blanks.every((item) => text4(item, 2e3)) && indexes(value.matches, true) && indexes(value.order);
  const validLimit = (value, max) => text4(value, 4) && (!value || /^\d+$/.test(value) && Number(value) >= 1 && Number(value) <= max);
  const validPreset = (value) => plain(value) && Object.keys(value).length === 8 && ["id", "name", "mode", "materials", "filters", "cardLimit", "timeLimitMinutes", "shuffle"].every((key3) => Object.prototype.hasOwnProperty.call(value, key3)) && typeof value.id === "string" && /^[a-zA-Z0-9._:-]{1,128}$/.test(value.id) && text4(value.name, 60) && !!value.name.trim() && ["core", "bank"].includes(value.mode) && Array.isArray(value.materials) && value.materials.length > 0 && value.materials.length <= 100 && value.materials.every((id2) => text4(id2, 128) && !!id2) && new Set(value.materials).size === value.materials.length && plain(value.filters) && Object.keys(value.filters).length === fields4.length && fields4.every((key3) => text4(value.filters[key3], 1024)) && validLimit(value.cardLimit, 1e3) && validLimit(value.timeLimitMinutes, 180) && typeof value.shuffle === "boolean";
  const key2 = (slot, owner = scope) => "ar_v1_" + owner + "_" + slot;
  function write(slot, value) {
    if (!scope || !store || !ready) return Promise.resolve(false);
    const name = key2(slot), bytes = value === null ? null : JSON.stringify(value);
    return new Promise((resolve7) => {
      const waiting = writes.get(name);
      writes.set(name, { bytes, generation, done: [...waiting?.done ?? [], resolve7] });
      drain();
    });
  }
  function drain() {
    if (writing || !store) return;
    writing = true;
    tail = (async () => {
      while (writes.size) {
        const entry = writes.entries().next();
        if (entry.done) break;
        const [name, task] = entry.value;
        writes.delete(name);
        let success = true;
        try {
          if (task.bytes === null) await store.remove(name);
          else await store.set(name, task.bytes);
        } catch (_) {
          success = false;
          if (generation === task.generation) {
            try {
              failed();
            } catch (_2) {
            }
          }
        }
        task.done.forEach((done) => done(success));
      }
    })().finally(() => {
      writing = false;
      if (writes.size) drain();
    });
  }
  async function bind(value) {
    const ownedGeneration = ++generation;
    scope = typeof value === "string" && /^[a-f0-9]{64}$/.test(value) ? value : "";
    ready = false;
    answer = null;
    presets = [];
    if (!scope) return;
    if (!store) {
      try {
        failed();
      } catch (_) {
      }
      return;
    }
    const owner = scope;
    try {
      const bytes = await Promise.all([store.get(key2("draft", owner)), store.get(key2("presets", owner))]);
      if (ownedGeneration !== generation) return;
      ready = true;
      if (bytes[0]) {
        let candidate;
        try {
          candidate = bytes[0].length <= 2e5 ? JSON.parse(bytes[0]) : null;
        } catch (_) {
          candidate = null;
        }
        if (plain(candidate) && Number.isSafeInteger(candidate.savedAt) && candidate.savedAt >= now() - 7 * 864e5 && candidate.savedAt <= now() + 6e4 && validDraft(candidate.value)) answer = { savedAt: candidate.savedAt, value: copy7(candidate.value) };
        else void write("draft", null);
      }
      if (bytes[1] !== null) {
        const candidate = JSON.parse(bytes[1]);
        if (!Array.isArray(candidate) || !candidate.every(validPreset) || new Set(candidate.map((item) => item.id)).size !== candidate.length) throw new Error("invalid saved presets");
        presets = candidate;
      }
    } catch (_) {
      if (ownedGeneration === generation) {
        ready = false;
        try {
          failed();
        } catch (_2) {
        }
      }
    }
  }
  function saveDraft(value) {
    if (!validDraft(value)) return Promise.resolve(false);
    answer = { savedAt: now(), value: copy7(value) };
    return write("draft", answer);
  }
  function clearDraft() {
    answer = null;
    return write("draft", null);
  }
  function restoreDraft(frame) {
    if (!answer) return null;
    const value = answer.value;
    const permutation = (items, size) => items.length === size && items.every((index2) => index2 >= 0 && index2 < size) && new Set(items).size === size;
    const matches = frame.kind === "matching" && frame.matching ? value.matches.length === frame.matching.left.length && value.matches.every((index2) => index2 >= -1 && index2 < frame.matching.left.length) && new Set(value.matches.filter((index2) => index2 >= 0)).size === value.matches.filter((index2) => index2 >= 0).length : !value.matches.length;
    const valid = frame.key === value.key && (frame.kind === "single" || frame.kind === "multiple" ? value.selected.every((index2) => index2 < (frame.options?.length ?? 0)) && (frame.kind !== "single" || value.selected.length <= 1) : !value.selected.length) && (frame.kind === "cloze" ? value.blanks.length <= (frame.blankCount ?? 0) : !value.blanks.length) && matches && (frame.kind === "ordering" ? !!frame.orderItems && permutation(value.order, frame.orderItems.length) : !value.order.length) && (frame.kind === "self" || frame.kind === "exact" && value.text.length <= 2e3 || !value.text);
    if (!valid) {
      void clearDraft();
      return null;
    }
    return copy7(value);
  }
  function changePresets(update) {
    const ownedGeneration = generation;
    const persist = async () => {
      if (ownedGeneration !== generation) return false;
      const next2 = update(presets);
      if (!await write("presets", next2) || ownedGeneration !== generation) return false;
      presets = next2;
      return true;
    };
    const next = presetWrite ? presetWrite.then(persist) : persist();
    presetWrite = next;
    const clear = () => {
      if (presetWrite === next) presetWrite = void 0;
    };
    void next.then(clear, clear);
    return next;
  }
  function savePreset(value) {
    if (!validPreset(value)) return Promise.resolve(false);
    const saved = copy7(value);
    return changePresets((current) => [...current.filter((item) => item.id !== saved.id), saved]);
  }
  function deletePreset(id2) {
    return changePresets((current) => current.filter((item) => item.id !== id2));
  }
  return { bind, saveDraft, clearDraft, restoreDraft, savePreset, deletePreset, presets: () => copy7(presets), available: () => ready && !!scope && !!store, flush: async () => {
    while (writing || writes.size || presetWrite) await (presetWrite ?? tail);
  } };
}

// src/ui/companion/miniapp-catalog.ts
function createMiniAppCatalog() {
  let materialFrame, cardFrame, scope;
  const models = /* @__PURE__ */ new Map();
  const modeOf = (row) => row.mode || "core";
  function matches(card, filter) {
    return (!filter.learningGroup || card.group === filter.learningGroup) && (!filter.questionKind || card.kind === filter.questionKind) && (!filter.section || Array.isArray(card.sections) && card.sections.includes(filter.section)) && (!filter.topic || Array.isArray(card.topics) && card.topics.includes(filter.topic)) && (!filter.tag || Array.isArray(card.tags) && card.tags.some((tag) => tag.toLocaleLowerCase() === filter.tag.toLocaleLowerCase())) && (!filter.knowledgeState || card.knowledgeState === filter.knowledgeState);
  }
  function forView(view, mode, plan) {
    const catalog = view.catalog;
    if (materialFrame !== view.materials || cardFrame !== catalog || scope !== plan) {
      materialFrame = view.materials;
      cardFrame = catalog;
      scope = plan;
      models.clear();
    }
    const cached = models.get(mode);
    if (cached) return cached;
    const modeMaterials = view.materials.filter((row) => modeOf(row) === mode);
    const planIds = new Set(plan?.materialIds ?? []);
    const materials = plan === void 0 ? modeMaterials : !plan || !plan.available || plan.mode && plan.mode !== mode ? [] : modeMaterials.filter((row) => planIds.has(row.id) || !planIds.size && mode === "core");
    const materialIds = new Set(materials.map((row) => row.id));
    const cards = (catalog || []).filter((card) => modeOf(card) === mode && materialIds.has(card.materialId));
    const model = {
      modeMaterials,
      materials,
      cards,
      filtered(filter) {
        if (!Array.isArray(catalog) || !Object.values(filter).some(Boolean)) return materials;
        const counts = /* @__PURE__ */ new Map();
        for (const card of cards) if (matches(card, filter)) {
          const id2 = card.materialId;
          const count = Number.isSafeInteger(card.count) && card.count > 0 ? card.count : 1;
          counts.set(id2, (counts.get(id2) ?? 0) + count);
        }
        return materials.map((row) => ({ ...row, count: counts.get(row.id) ?? 0 }));
      }
    };
    models.set(mode, model);
    return model;
  }
  function tagLabels(cards) {
    const labels = /* @__PURE__ */ new Map();
    for (const card of cards) for (const value of card.tags || []) if (typeof value === "string" && value) {
      const key2 = value.toLocaleLowerCase(), previous = labels.get(key2);
      if (previous === void 0 || value < previous) labels.set(key2, value);
    }
    return Array.from(labels.entries()).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([, label2]) => label2);
  }
  return { forView, matches, tagLabels };
}

// src/ui/companion/miniapp-media-cache.ts
function createMiniAppMediaCache(maxBytes = 64 * 1024 * 1024, maxEntries = 128) {
  const entries = /* @__PURE__ */ new Map();
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 0 || !Number.isSafeInteger(maxEntries) || maxEntries < 1) throw new Error("invalid media cache budget");
  let bytes = 0, owner = "", generation = 0;
  const failure = (status = 0) => Object.assign(new Error("media unavailable"), { status });
  function clear() {
    entries.clear();
    bytes = 0;
    owner = "";
    generation++;
  }
  function forget(id2) {
    const value = entries.get(id2);
    if (value) {
      entries.delete(id2);
      bytes -= value.size;
    }
  }
  function remember(id2, blob) {
    forget(id2);
    if (blob.size > maxBytes) return;
    while (entries.size && (bytes + blob.size > maxBytes || entries.size >= maxEntries)) forget(entries.keys().next().value);
    entries.set(id2, blob);
    bytes += blob.size;
  }
  async function load(asset, bearer, signal, fetcher = fetch) {
    if (!/^[a-f0-9]{64}$/.test(asset.id) || typeof bearer !== "string" || !bearer || bearer.length > 512 || /[\u0000-\u001f\u007f]/.test(bearer) || !Number.isSafeInteger(asset.bytes) || asset.bytes < 1 || asset.bytes > 5e7 || !["image", "audio", "video"].includes(asset.kind)) throw failure();
    if (owner !== bearer) {
      clear();
      owner = bearer;
    }
    const started = generation, cached = entries.get(asset.id), etag = '"' + asset.id + '"';
    const response = await fetcher("/miniapp/media/" + asset.id, { method: "GET", headers: {
      Authorization: "Bearer " + bearer,
      ...cached ? { "If-None-Match": etag } : {}
    }, signal, credentials: "omit", cache: "no-store", redirect: "error", referrerPolicy: "no-referrer" });
    if (response.status === 401 || response.status === 403) {
      clear();
      throw failure(response.status);
    }
    if (generation !== started || signal.aborted) throw failure();
    if (response.headers.get("etag") !== etag) throw failure();
    let blob;
    if (response.status === 304) {
      if (!cached) throw failure();
      blob = cached;
    } else {
      if (!response.ok) throw failure(response.status);
      const length = response.headers.get("content-length");
      if (length !== null && Number(length) !== asset.bytes) throw failure();
      blob = await response.blob();
    }
    if (generation !== started || signal.aborted || blob.size !== asset.bytes || !blob.type.startsWith(asset.kind + "/")) throw failure();
    remember(asset.id, blob);
    return blob;
  }
  return { load, clear, forget, stats: () => ({ bytes, entries: entries.size }) };
}

// src/ui/companion/miniapp-vaults.ts
function readMiniAppVaultAuth(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const data = value;
  if (typeof data.token !== "string" || !data.token || data.token.length > 512 || /[\u0000-\u001f\u007f]/.test(data.token) || !Number.isSafeInteger(data.expiresAt) || Number(data.expiresAt) <= 0) return null;
  const legacy = data.vaultId === void 0 && data.vaults === void 0;
  if (legacy) return { token: data.token, expiresAt: Number(data.expiresAt), ...typeof data.storageScope === "string" ? { storageScope: data.storageScope } : {}, vaults: [] };
  if (typeof data.vaultId !== "string" || !/^[a-f0-9]{48}$/.test(data.vaultId) || typeof data.storageScope !== "string" || !/^[a-f0-9]{64}$/.test(data.storageScope) || !Array.isArray(data.vaults) || !data.vaults.length) return null;
  const vaults = [], ids = /* @__PURE__ */ new Set();
  for (const row of data.vaults) {
    if (!row || typeof row !== "object" || Array.isArray(row) || typeof row.id !== "string" || !/^[a-f0-9]{48}$/.test(row.id) || ids.has(row.id) || typeof row.name !== "string" || !row.name.trim() || row.name.length > 100 || /[\u0000-\u001f\u007f]/.test(row.name)) return null;
    ids.add(row.id);
    vaults.push({ id: row.id, name: row.name });
  }
  if (!ids.has(data.vaultId)) return null;
  return { token: data.token, expiresAt: Number(data.expiresAt), storageScope: data.storageScope, vaultId: data.vaultId, vaults };
}

// src/ui/companion/miniapp-page.ts
var miniAppHtml = String.raw`<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="light dark"><meta name="referrer" content="no-referrer"><title>Anchor Recall — занятие</title><link rel="stylesheet" href="/miniapp/app.css"><script src="https://telegram.org/js/telegram-web-app.js" defer></script><script src="/miniapp/app.js" defer></script></head>
<body><div class="ar-app"><header class="ar-chrome"><div class="ar-brand"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="12" cy="4" r="2.4"></circle><path d="M12 6.5V21M7 10h10M3 14a9 9 0 0 0 18 0M3 14l-1 4m1-4 4 1m14-1 1 4m-1-4-4 1"></path></svg><span>Anchor Recall</span></div><span id="activity" class="ar-activity" aria-hidden="true"></span><button id="fullscreen" class="ar-ghost ar-fullscreen" type="button" aria-label="Развернуть" title="Развернуть" hidden><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path id="fullscreen-icon" d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"></path></svg></button><button id="close" class="ar-ghost" type="button">В чат</button></header>
<p id="window-status" class="ar-window-status" role="status" hidden></p>
<div id="error" class="ar-error" role="alert" hidden><strong id="error-title"></strong><p id="error-text"></p><div class="ar-error-actions"><button id="retry" type="button">Повторить</button><button id="error-close" class="ar-ghost" type="button">В чат</button></div></div>
<main id="content" class="ar-main" tabindex="-1"><section class="ar-landing"><h1>Открываем занятие…</h1><p>Подключаемся к выбранным материалам.</p></section></main><p id="live" class="ar-sr" role="status" aria-live="polite"></p><noscript><p>Для занятия нужен JavaScript. Откройте экран кнопкой в Telegram.</p></noscript></div></body></html>`;
var miniAppClientScript = String.raw`(() => {
'use strict';
const tg = window.Telegram && window.Telegram.WebApp;
const $ = id => document.getElementById(id), root = $('content');
const planParams = new URLSearchParams(location.search).getAll('plan');
const vaultParams = new URLSearchParams(location.hash.slice(1)).getAll('vault');
const launchVaultId = vaultParams.length === 1 && /^[a-f0-9]{48}$/.test(vaultParams[0]) ? vaultParams[0] : '';
const invalidVaultLink = vaultParams.length > 0 && !launchVaultId;
const readVaultAuth = (${readMiniAppVaultAuth.toString()});
function launchPlanId(value) { if (typeof value !== 'string' || !/^p_[A-Za-z0-9_-]{43}$/.test(value)) return ''; try { const bytes = atob(value.slice(2).replace(/-/g,'+').replace(/_/g,'/') + '='); if (bytes.length !== 32 || btoa(bytes).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_') !== value.slice(2)) return ''; return Array.from(bytes,ch => ch.charCodeAt(0).toString(16).padStart(2,'0')).join(''); } catch (_) { return ''; } }
let planId = planParams.length === 1 && planParams[0].length === 64 && /^[a-f0-9]{64}$/.test(planParams[0]) ? planParams[0] : !planParams.length ? launchPlanId(tg && tg.initDataUnsafe && tg.initDataUnsafe.start_param) : '';
const labels = ['', 'Ещё раз', 'Трудно', 'Хорошо', 'Легко'];
const kinds = {single:'Один вариант',multiple:'Несколько вариантов',cloze:'Пропуски',matching:'Сопоставление',ordering:'Порядок',exact:'Точный ответ',self:'Самопроверка'};
const statuses = {pending:'Сохранено в боте',syncing:'Передаётся в Obsidian',applied:'Сохранено в Obsidian',correcting:'Изменение оценки ожидает Obsidian','correction-rejected':'Изменение не применено; сохранена прежняя оценка',stale:'Не применено: карточка изменилась',missing:'Не применено: карточка недоступна',ineligible:'Не применено: повтор недоступен',expired:'Не применено: срок данных истёк','clock-mismatch':'Не применено: проверьте время','epoch-mismatch':'Не применено: подключение изменилось','local-session-active':'Не применено: идёт занятие в Obsidian','core-adapter-unavailable':'Не применено: расписание недоступно'};
let bearer = '', current = null, busy = false, pending = null, retryWork = null, locked = false;
let vaultId = '', vaults = [], storageScope = '', contextGeneration = 0;
const vaultDrafts = new Map();
let draft = {key:'',selected:[],text:'',blanks:[],matches:[],order:[]}, cardDom = null, editingGrade = false, historySize = 20;
let recoveredDraft = '', selectedPreset = '', presetName = '', presetFeedback = '', presetsOpen = false;
function storageFailure() { const notice = $('window-status'); notice.textContent = 'Не удалось сохранить данные на этом устройстве. Незавершённый ответ может потеряться после закрытия окна.'; notice.hidden = false; }
function localStore() {
  const api = tg && tg.DeviceStorage; let native = false; try { native = !!tg && typeof tg.isVersionAtLeast === 'function' && tg.isVersionAtLeast('9.0'); } catch (_) {}
  if (native && api && ['getItem','setItem','removeItem'].every(method => typeof api[method] === 'function')) {
    const call = (method,args) => new Promise((resolve,reject) => { const timer = setTimeout(() => reject(new Error('storage unavailable')),1200); try { api[method](...args,(error,value) => { clearTimeout(timer); if (error || (method === 'getItem' ? value !== null && typeof value !== 'string' : value !== true)) reject(new Error('storage unavailable')); else resolve(value); }); } catch (_) { clearTimeout(timer); reject(new Error('storage unavailable')); } });
    return {get:key => call('getItem',[key]),set:(key,value) => call('setItem',[key,value]),remove:key => call('removeItem',[key])};
  }
  try { const storage = window.localStorage; if (!storage) return null; return {get:async key => storage.getItem(key),set:async (key,value) => storage.setItem(key,value),remove:async key => storage.removeItem(key)}; } catch (_) { return null; }
}
const localState = (${createMiniAppLocalState.toString()})(localStore(),storageFailure);
function retainDraft() { return !current || current.answerHistorySupported !== true || current.retainAnswers === true; }
function persistDraft() { if (!retainDraft()) { if (localState.available()) void localState.clearDraft(); return; } if (localState.available() && current && current.status === 'question' && current.card && !current.card.result && !current.card.selectedRating && draft.key) void localState.saveDraft(draft); }
let picker = false, startConflict = '', shuffleCards = false, studyMode = 'core', busyTimer, waitingTimer, busyFocus = null, mediaEpoch = 0, mediaActive = 0;
let homeScreenStatus = '', homeScreenMessage = '', homeScreenDom = null;
let launch = null, planPrepared = false, planChoosing = !!planId, planContinued = false;
let sectionView = 'study', today = null, week = null, planRange = 'today', settingsPrepared = false, historyOpen = false, presetRefresh = null;
let studyTargetExpanded = true;
const planEdits = new Map(), cardReportEdits = new Map();
let filterPopupClose = null, topicRecallExpanded = false, topicRecallSelected = '';
let resumeNeeded = false, resumeTimer = null, resumeReading = null;
let waitingDom = null, serverClock = null;
let lifetimeTimer = null, connectionExpiresAt = 0, connectionHardExpiresAt = 0;
let lessonTimer = null, sessionTimerDom = null, mediaSuspended = false;
const startSettings = {core:{cardLimit:'',timeLimitMinutes:''},bank:{cardLimit:'',timeLimitMinutes:''}}, settingsOpen = {core:false,bank:false}, studyFilters = {core:{learningGroup:'',questionKind:'',section:'',topic:'',tag:'',knowledgeState:''},bank:{learningGroup:'',questionKind:'',section:'',topic:'',tag:'',knowledgeState:''}};
const knowledgeStateLabels = {new:'Новая',learning:'Изучается','needs-attention':'На уточнении',weak:'Слабая',stable:'Стабильная',strong:'Сильная'};
const mediaQueue = [], mediaEntries = new Map(), mediaControllers = new Set(), objectUrls = new Set(), mediaNodes = new Set();
const mediaCache = (${createMiniAppMediaCache.toString()})();
const mediaDeferred = new Set();
const materialSelections = {core:new Set(),bank:new Set()};
const catalogModel = (${createMiniAppCatalog.toString()})();
const modeOf = row => row && row.mode === 'bank' ? 'bank' : 'core';
const modeLabel = mode => mode === 'bank' ? 'Банк вопросов' : 'Повторения Core';
const modeMaterials = mode => materialCatalog(mode).modeMaterials;
const selectedMaterials = mode => materialSelections[mode || studyMode];
const viewRequest = () => planId ? {kind:'plan',id:planId,answerHistoryVersion:1} : {kind:'view',answerHistoryVersion:1};
const unfinished = () => current && current.session && ['question','result','waiting','paused'].includes(current.status);
function materialCatalog(mode) { return catalogModel.forView(current,mode || studyMode,planChoosing && planId ? launch : undefined); }
function targetMaterials(mode) { return materialCatalog(mode).materials; }
function catalogCards(mode) { return materialCatalog(mode).cards; }
function matchesStudyFilter(card,filter) { return catalogModel.matches(card,filter); }
function pickerMaterials(mode) { return materialCatalog(mode).filtered(studyFilters[mode || studyMode]); }
function sessionLimitFields(mode) { const values = startSettings[mode || studyMode], fields = {}; for (const [key,max] of [['cardLimit',1000],['timeLimitMinutes',90]]) { const raw = values[key].trim(); if (!raw) continue; const number = Number(raw); if (!/^\d+$/.test(raw) || !Number.isSafeInteger(number) || number < 1 || number > max) return null; fields[key] = number; } return fields; }
function startFields(mode) { const chosenMode = mode || studyMode, fields = sessionLimitFields(chosenMode); if (!fields) return null; for (const [key,value] of Object.entries(studyFilters[chosenMode])) if (value) fields[key] = value; return fields; }
function tagFilterLabels(cards) { return catalogModel.tagLabels(cards); }
function el(tag, cls, text) { const node = document.createElement(tag); if (cls) node.className = cls; if (text !== undefined) node.textContent = text; return node; }
function button(text, work, cls) { const node = el('button', cls || '', text); node.type = 'button'; node.addEventListener('click', work); return node; }
function cancelOrderInteraction() { if (cardDom && cardDom.cancelOrder) cardDom.cancelOrder(); }
async function close() { cancelOrderInteraction(); persistDraft(); closeFilterPicker(); releaseMedia(); await localState.flush(); if (tg && typeof tg.close === 'function') tg.close(); }
function setupFullscreen() { const control = $('fullscreen'), notice = $('window-status');
  try { if (!tg || typeof tg.isVersionAtLeast !== 'function' || !tg.isVersionAtLeast('8.0') || typeof tg.requestFullscreen !== 'function' || typeof tg.exitFullscreen !== 'function' || typeof tg.onEvent !== 'function') return;
    const sync = () => { const full = tg.isFullscreen === true, label = full ? 'Свернуть' : 'Развернуть'; control.setAttribute('aria-label',label); control.setAttribute('aria-pressed',String(full)); control.title = label; control.disabled = false; $('fullscreen-icon').setAttribute('d',full ? 'M3 8h5V3m8 0v5h5M8 21v-5H3m18 0h-5v5' : 'M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5'); };
    const failed = () => { sync(); notice.textContent = 'Не удалось изменить режим окна. Можно продолжить занятие.'; notice.hidden = false; };
    tg.onEvent('fullscreenChanged',() => { sync(); notice.hidden = true; }); tg.onEvent('fullscreenFailed',failed);
    control.addEventListener('click',() => { control.disabled = true; notice.hidden = true; try { if (tg.isFullscreen === true) tg.exitFullscreen(); else tg.requestFullscreen(); } catch (_) { failed(); } }); sync(); control.hidden = false;
  } catch (_) { control.hidden = true; }
}
function updateHomeScreenAction() { if (!homeScreenDom) return; homeScreenDom.section.hidden = homeScreenStatus !== 'unknown' && homeScreenStatus !== 'missed'; homeScreenDom.notice.textContent = homeScreenMessage; homeScreenDom.notice.hidden = !homeScreenMessage; }
function setupHomeScreen() {
  try { if (!tg || typeof tg.isVersionAtLeast !== 'function' || !tg.isVersionAtLeast('8.0') || typeof tg.checkHomeScreenStatus !== 'function' || typeof tg.addToHomeScreen !== 'function') return;
    if (typeof tg.onEvent === 'function') tg.onEvent('homeScreenAdded',() => { homeScreenStatus = 'added'; homeScreenMessage = ''; updateHomeScreenAction(); });
    tg.checkHomeScreenStatus(status => { if (homeScreenStatus === 'added') return; homeScreenStatus = ['unsupported','unknown','added','missed'].includes(status) ? status : ''; updateHomeScreenAction(); });
  } catch (_) { homeScreenStatus = ''; updateHomeScreenAction(); }
}
function theme() { document.documentElement.dataset.theme = tg && tg.colorScheme === 'dark' || !tg && matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light'; }
function announce(text) { $('live').textContent = text; }
function setBusy(value, message) { if (value) { cancelOrderInteraction(); closeFilterPicker(true); busyFocus = root.contains(document.activeElement) ? document.activeElement : null; } busy = value; clearTimeout(busyTimer); $('activity').dataset.busy = 'false'; root.setAttribute('aria-busy', String(value)); if (value) { announce(message || 'Загружаем…'); busyTimer = setTimeout(() => { $('activity').dataset.busy = 'true'; }, 150); } updateDisabled(); if (!value && busyFocus) { if (busyFocus.isConnected && !busyFocus.disabled && !busyFocus.closest('[hidden]')) busyFocus.focus({preventScroll:true}); busyFocus = null; } if (!value && resumeNeeded) scheduleResume(); }
function updateDisabled() { root.querySelectorAll('button,input,textarea,select').forEach(node => { node.disabled = node.dataset.localAction !== 'true' && (busy || locked || node.dataset.unavailable === 'true' || !!pending); }); if (cardDom) { cardDom.renderOrder(); updateCheck(); } }
function clearError() { $('error').hidden = true; retryWork = null; }
function error(title, text, retry) { $('error-title').textContent = title; $('error-text').textContent = text; $('error').hidden = false; retryWork = retry || null; $('retry').hidden = !retry; $('error-close').hidden = !tg; announce(title + '. ' + text); }
function failure(status) { const problem = new Error('request failed'); problem.status = status || 0; return problem; }
async function post(path, body, authenticated, credential) {
  if (path === '/miniapp/study' && ['view','plan','today'].includes(body.kind)) body = Object.assign({},body,{answerHistoryVersion:1});
  const generation = contextGeneration, controller = new AbortController(), timer = setTimeout(() => controller.abort(), 20000);
  try { const headers = {'Content-Type':'application/json'}; if (authenticated) headers.Authorization = 'Bearer ' + (credential === undefined ? bearer : credential);
    const response = await fetch(path, {method:'POST',headers,body:JSON.stringify(body),signal:controller.signal,credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer'});
    if (generation !== contextGeneration) throw failure(-1);
    if (!response.ok) throw failure(response.status); const value = await response.json(); if (generation !== contextGeneration) throw failure(-1); return value;
  } catch (problem) { if (problem && Number.isInteger(problem.status)) throw problem; throw failure(0); } finally { clearTimeout(timer); }
}
function handleFailure(problem, retry) {
  if (problem.status === -1) return;
  if (problem.status === 401 || problem.status === 403) { endConnection(); }
  else if (problem.status === 400) { const failedStart = preserveFailedStart(); pending = null; if (failedStart) render(); error(failedStart ? 'Занятие не запущено' : 'Действие недоступно', failedStart ? 'Занятие «' + startConflict + '» не запущено. Обновите список материалов и попробуйте снова.' : 'Данные могли измениться. Обновите экран и попробуйте снова.', () => loadView()); }
  else if (problem.status === 429) error('Нужно немного подождать', 'Сервис получил много запросов. Повторите попытку чуть позже.', retry);
  else error('Не удалось получить ответ', pending && pending.kind === 'resume' ? 'Не удалось восстановить занятие. Текущий вопрос и введённый ответ остаются в этом окне. Повторите подключение.' : pending && pending.kind === 'pause' ? 'Не удалось подтвердить паузу. Повторим тот же запрос; сохранённые ответы и оценки не изменятся.' : pending && pending.kind === 'finish-chat' ? 'Не удалось подтвердить завершение. Повторим тот же запрос; выставленные оценки сохранятся.' : pending ? retainDraft() ? 'Ввод сохранён. Повторим тот же запрос, чтобы не записать ответ дважды.' : 'Ввод остаётся в открытом окне. Повторим тот же запрос, чтобы не записать оценку дважды.' : 'Проверьте соединение и повторите попытку.', retry);
}
function preserveFailedStart() { if (!pending || pending.kind !== 'start') return false; const ids = pending.materialIds || [pending.materialId]; if (pending.mode) studyMode = pending.mode; startConflict = pending.retryWeak === true ? 'Трудные вопросы' : pending.allMaterials === true ? 'Все материалы' : modeMaterials().filter(row => ids.includes(row.id)).map(row => row.title).join(' + ') || 'Выбранные материалы'; picker = true; return true; }
function permutation(values, length) { return Array.isArray(values) && values.length === length && values.every(value => Number.isSafeInteger(value) && value >= 0 && value < length) && new Set(values).size === length; }
function validExerciseView(card) { if (!card || card.kind !== 'matching' && card.kind !== 'ordering') return true; const strings = values => Array.isArray(values) && values.length >= 2 && values.length <= 12 && values.every(value => typeof value === 'string' && value.trim().length > 0 && value.length <= 500);
  if (card.kind === 'matching') return card.matching && strings(card.matching.left) && strings(card.matching.right) && card.matching.left.length === card.matching.right.length && (!card.result || permutation(card.result.correctMatches,card.matching.left.length) && (!card.result.feedback || card.result.feedback.kind === 'matching' && permutation(card.result.feedback.matches,card.matching.left.length)));
  return strings(card.orderItems) && (!card.result || permutation(card.result.correctOrder,card.orderItems.length) && (!card.result.feedback || card.result.feedback.kind === 'ordering' && permutation(card.result.feedback.order,card.orderItems.length)));
}
function validToday(value) { return value && typeof value.timeZone === 'string' && Number.isSafeInteger(value.generatedAt) && Number.isSafeInteger(value.expiresAt) && Array.isArray(value.rows) && value.rows.every(row => row && typeof row.id === 'string' && row.id.length === 64 && /^[a-f0-9]{64}$/.test(row.id) && typeof row.title === 'string' && Number.isSafeInteger(row.startAt) && (row.completed === undefined || typeof row.completed === 'boolean') && (row.skipped === undefined || typeof row.skipped === 'boolean') && typeof row.available === 'boolean'); }
function validStudyTarget(value) { if (!value || typeof value !== 'object' || typeof value.id !== 'string' || !/^[a-f0-9]{64}$/.test(value.id) || typeof value.targetDate !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value.targetDate) || !Number.isFinite(Date.parse(value.targetDate + 'T00:00:00Z')) || new Date(value.targetDate + 'T00:00:00Z').toISOString().slice(0,10) !== value.targetDate || typeof value.timeZone !== 'string' || !['active','transition','completed','disabled','stale'].includes(value.status) || !Number.isSafeInteger(value.available) || value.available < 0 || !Number.isSafeInteger(value.total) || value.total < value.available || value.total > 1000 || !Number.isSafeInteger(value.syncedAt) || value.syncedAt < 0 || !Number.isSafeInteger(value.expiresAt) || value.expiresAt <= value.syncedAt || value.nextDueAt !== undefined && (!Number.isSafeInteger(value.nextDueAt) || value.nextDueAt < 0)) return false; try { new Intl.DateTimeFormat('ru-RU',{timeZone:value.timeZone}).format(value.syncedAt); return true; } catch (_) { return false; } }
function validView(value) { return value && ['materials','question','result','waiting','paused','finished','unavailable','chat-active'].includes(value.status) && typeof value.viewToken === 'string' && value.viewToken.length === 64 && /^[a-f0-9]{64}$/.test(value.viewToken) && (value.chatSessionId === undefined || typeof value.chatSessionId === 'string' && /^[a-zA-Z0-9._:-]{1,128}$/.test(value.chatSessionId)) && Array.isArray(value.materials) && value.materials.every(row => row && (row.mode === undefined || row.mode === 'core' || row.mode === 'bank')) && (!value.session || value.session.mode === undefined || value.session.mode === 'core' || value.session.mode === 'bank') && (!value.launch || value.launch.id === planId && typeof value.launch.title === 'string' && typeof value.launch.available === 'boolean' && Array.isArray(value.launch.materialIds) && value.launch.materialIds.every(id => typeof id === 'string') && (value.launch.mode === undefined || value.launch.mode === 'core' || value.launch.mode === 'bank')) && (value.studyTarget === undefined || validStudyTarget(value.studyTarget)) && Array.isArray(value.history) && validExerciseView(value.card); }
function sameStudyFrame(before, after) { return validView(after) && !!before && !!before.card && !!after.card && !!before.session && !!after.session && before.session.id === after.session.id && before.status === after.status && before.session.mode === after.session.mode && before.session.completed === after.session.completed && before.session.answers === after.session.answers && JSON.stringify(before.card) === JSON.stringify(after.card); }
function rememberServerClock(value) { serverClock = {time:Number.isSafeInteger(value.serverNow) ? value.serverNow : Date.now(),at:performance.now()}; if (Number.isSafeInteger(value.connectionExpiresAt) && value.connectionExpiresAt > 0) connectionExpiresAt = Math.min(value.connectionExpiresAt,connectionHardExpiresAt || value.connectionExpiresAt); }
function serverTime() { return serverClock ? serverClock.time+performance.now()-serverClock.at : Date.now(); }
function waitingRemaining() { const until = current && current.session && current.session.waitUntil; return Number.isSafeInteger(until) ? Math.max(0,until-serverTime()) : 0; }
function endConnection() {
  persistDraft(); contextGeneration++; locked = true; clearError(); clearTimeout(lifetimeTimer); clearTimeout(waitingTimer); clearTimeout(lessonTimer); clearTimeout(resumeTimer); resumeNeeded = false;
  cancelOrderInteraction(); closeFilterPicker(); releaseMedia(); vaultDrafts.clear(); cardDom = null; waitingDom = null;
  const section = landing('Подключение завершено','Закройте это окно и снова откройте занятие кнопкой бота. Уже сохранённые оценки останутся в истории.'), closeWindow = button('Закрыть окно',close,'ar-primary');
  closeWindow.dataset.localAction = 'true'; section.append(closeWindow); root.replaceChildren(section); announce('Подключение завершено. Откройте занятие заново из чата бота.'); setBusy(false);
}
function sessionDeadline() { const session = current && current.session; return session && ['question','result','waiting'].includes(current.status) && Number.isSafeInteger(session.idleExpiresAt) ? session.idleExpiresAt : Infinity; }
function updateSessionTimer() {
  clearTimeout(lessonTimer); if (!sessionTimerDom || !sessionTimerDom.section.isConnected || !current || !current.session || locked) return;
  const session = current.session, paused = current.status === 'paused', end = paused ? Number.isSafeInteger(session.pausedAt) ? session.pausedAt : serverClock.time : serverTime();
  const elapsed = Math.max(0,Math.floor((end-session.startedAt-(session.pausedDurationMs || 0))/1000)), limit = Math.min(90,session.timeLimitMinutes || 90)*60;
  sessionTimerDom.remaining.textContent = durationText(Math.max(0,limit-elapsed));
  sessionTimerDom.section.dataset.paused = String(paused);
  if (!paused && document.visibilityState !== 'hidden' && !(tg && tg.isActive === false)) lessonTimer = setTimeout(updateSessionTimer,1000);
}
function sessionTimerView() {
  if (picker || !current.session || !Number.isSafeInteger(current.session.startedAt) || !['question','result','waiting','paused'].includes(current.status)) return null;
  const section = el('section','ar-session-timer'), cell = el('div'), remaining = el('span','ar-session-remaining'); section.setAttribute('aria-label','Время занятия');
  remaining.setAttribute('role','timer'); remaining.setAttribute('aria-live','off'); remaining.setAttribute('aria-label','Осталось учебного времени'); cell.append(el('span','ar-session-time-label','Осталось'),remaining); section.append(cell);
  sessionTimerDom = {section,remaining}; return section;
}
function scheduleSessionExpiry() {
  clearTimeout(lifetimeTimer); if (locked || !current || document.visibilityState === 'hidden' || tg && tg.isActive === false) return;
  const until = Math.min(connectionExpiresAt || Infinity, sessionDeadline()), remaining = until-serverTime(); if (!Number.isFinite(remaining)) return;
  lifetimeTimer = setTimeout(() => { if (connectionExpiresAt && serverTime() >= connectionExpiresAt) endConnection(); else { resumeNeeded = true; void refreshOnResume(); } },Math.max(0,remaining));
}
function updateWaitingCountdown() {
  clearTimeout(waitingTimer); if (!waitingDom || !waitingDom.timer.isConnected || !current || current.status !== 'waiting') return;
  const remaining = waitingRemaining(), seconds = Math.ceil(remaining/1000), minutes = Math.floor(seconds/60);
  waitingDom.timer.textContent = String(minutes).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');
  waitingDom.description.textContent = remaining ? 'До следующего повтора' : 'Можно продолжить повторение.';
  waitingDom.continue.textContent = remaining && current.session.canContinueEarly ? 'Продолжить сейчас' : 'Продолжить';
  waitingDom.continue.dataset.unavailable = String(remaining > 0 && !current.session.canContinueEarly);
  waitingDom.compatibility.hidden = !remaining || current.session.canContinueEarly === true;
  waitingDom.continue.disabled = busy || locked || !!pending || waitingDom.continue.dataset.unavailable === 'true';
  if (remaining && document.visibilityState !== 'hidden' && !(tg && tg.isActive === false)) waitingTimer = setTimeout(updateWaitingCountdown,Math.min(1000,remaining));
}
function rememberQuietView(value) { current = value; rememberServerClock(value); scheduleSessionExpiry(); updateSessionTimer(); if (value.launch) launch = value.launch; if (cardDom && value.answerHistorySupported === true) cardDom.retentionInput.checked = value.retainAnswers === true; if (!retainDraft() && localState.available()) void localState.clearDraft(); }
function sameWaitingFrame(before,after) { return validView(after) && before && before.status === 'waiting' && after.status === 'waiting' && before.session && after.session && before.session.id === after.session.id && before.session.waitUntil === after.session.waitUntil && before.session.canContinueEarly === after.session.canContinueEarly && before.session.completed === after.session.completed && before.session.answers === after.session.answers; }
function samePausedFrame(before,after) { return validView(after) && before && before.status === 'paused' && after.status === 'paused' && before.session && after.session && before.session.id === after.session.id && before.session.pausedAt === after.session.pausedAt && before.session.completed === after.session.completed && before.session.answers === after.session.answers && JSON.stringify(before.card || null) === JSON.stringify(after.card || null); }
function markSuspended() { cancelOrderInteraction(); persistDraft(); resumeNeeded = true; clearTimeout(resumeTimer); clearTimeout(waitingTimer); clearTimeout(lifetimeTimer); clearTimeout(lessonTimer); closeFilterPicker(); }
function scheduleResume(force) { if (force) resumeNeeded = true; clearTimeout(resumeTimer); if (!resumeNeeded || document.visibilityState === 'hidden' || tg && tg.isActive === false) return; if (connectionExpiresAt && serverTime() >= connectionExpiresAt) { endConnection(); return; } updateWaitingCountdown(); updateSessionTimer(); scheduleSessionExpiry(); if (current && current.status === 'paused') { resumeNeeded = false; return; } resumeTimer = setTimeout(refreshOnResume,180); }
async function refreshOnResume() {
  if (!resumeNeeded || resumeReading || busy || pending || locked || !current || current.status === 'paused' || !bearer || document.visibilityState === 'hidden' || tg && tg.isActive === false) return;
  resumeNeeded = false; const before = current, top = scrollY, left = scrollX, request = sectionView === 'today' ? {kind:'today'} : viewRequest();
  const reading = post('/miniapp/study',request,true); resumeReading = reading;
  try { const value = await reading; if (locked || busy || pending || current !== before) return; if (!validView(value) || value.today !== undefined && !validToday(value.today)) throw failure(0);
    if (sectionView === 'study' && !picker && cardDom && sameStudyFrame(before,value)) { rememberQuietView(value); clearError(); }
    else { const changedCard = sectionView === 'study' && !!before.card && !!before.session && !sameStudyFrame(before,value); if (request.kind === 'today') { today = value.today === undefined ? null : value.today; week = value.week === undefined ? null : value.week; } accept(value,false,picker); window.scrollTo(left,top); if (changedCard && value.status !== 'finished') error('Занятие изменилось','Карточка или её состояние изменились. Проверьте обновлённый экран перед ответом.',null); else clearError(); }
  } catch (problem) { if (!locked && !busy && !pending && current === before && (problem.status === 401 || problem.status === 403 || serverTime() >= sessionDeadline())) { handleFailure(problem,() => loadView()); updateDisabled(); } }
  finally { if (resumeReading === reading) resumeReading = null; if (resumeNeeded) scheduleResume(); }
}
async function postPending() {
  let rebased = false;
  for (;;) { try { return await post('/miniapp/study',pending,true); }
    catch (problem) { if (problem.status !== 409 || rebased || !['check','self-recall','reveal','hint','grade','next','skip','resume'].includes(pending.kind)) throw problem;
      const before = current, fresh = await post('/miniapp/study',viewRequest(),true);
      const unchanged = pending.kind === 'resume' ? samePausedFrame(before,fresh) : sameStudyFrame(before,fresh) || pending.kind === 'next' && sameWaitingFrame(before,fresh);
      if (!unchanged) { problem.freshView = fresh; throw problem; }
      rememberQuietView(fresh); if (pending.kind === 'grade') { delete pending.text; delete pending.response; Object.assign(pending,answerHistoryFields(fresh.card)); } pending = Object.assign({},pending,{requestId:crypto.randomUUID(),viewToken:fresh.viewToken}); rebased = true;
    }
  }
}
function accept(value, entry, pickMaterials) { if (locked) return; cancelOrderInteraction(); if (!validView(value) || value.today !== undefined && !validToday(value.today) || value.week !== undefined && !validToday(value.week)) throw failure(0); const previousKey = draft.key, wasPaused = current && current.status === 'paused'; current = value; rememberServerClock(value); if (value.launch) launch = value.launch; if (value.today) today = value.today; if (value.week) week = value.week; picker = !!pickMaterials && value.status !== 'chat-active' || !!startConflict || planChoosing && value.status !== 'chat-active' || value.status === 'finished' && (!!entry || picker); editingGrade = false; const key = value.card && value.session ? value.session.id + ':' + value.card.id + ':' + value.card.revision : '';
  const notice = $('window-status'); if (value.answerHistoryWarning) { notice.textContent = value.answerHistoryWarning; notice.hidden = false; notice.dataset.noticeKind = 'answer-history'; announce(value.answerHistoryWarning); } else if (notice.dataset.noticeKind === 'answer-history') { notice.hidden = true; delete notice.dataset.noticeKind; }
  ['core','bank'].forEach(mode => { const available = new Set(value.materials.filter(row => modeOf(row) === mode && row.count > 0).map(row => row.id)); selectedMaterials(mode).forEach(id => { if (!available.has(id)) selectedMaterials(mode).delete(id); }); });
  if (!settingsPrepared && value.defaults) { ['core','bank'].forEach(mode => { const values = value.defaults[mode]; if (values) ['cardLimit','timeLimitMinutes'].forEach(key => { startSettings[mode][key] = Number.isSafeInteger(values[key]) && values[key] > 0 ? String(key === 'timeLimitMinutes' ? Math.min(90,values[key]) : values[key]) : ''; }); }); settingsPrepared = true; }
  if (!planChoosing && value.session && value.session.mode && (!startConflict && ['question','result','waiting','paused'].includes(value.status) || entry && value.status === 'finished')) studyMode = value.session.mode;
  if (planChoosing && launch && !planPrepared) { ['core','bank'].forEach(mode => { selectedMaterials(mode).clear(); pickerMaterials(mode).filter(row => row.count > 0).forEach(row => selectedMaterials(mode).add(row.id)); }); studyMode = launch.mode || (pickerMaterials('core').some(row => row.count > 0) ? 'core' : pickerMaterials('bank').some(row => row.count > 0) ? 'bank' : 'core'); planPrepared = launch.available; }
    if (key !== previousKey) { releaseMedia(true); draft = {key,selected:[],text:'',blanks:[],matches:[],order:[]}; recoveredDraft = ''; cardDom = null; historySize = 20;
    if (retainDraft() && ['question','paused'].includes(value.status) && value.card && !value.card.result && !value.card.selectedRating) { const restored = localState.restoreDraft(Object.assign({key},value.card)); if (restored) { draft = restored; recoveredDraft = key; announce('Незавершённый ответ восстановлен на этом устройстве.'); } }
  }
  if (value.card && (value.card.result || value.card.selectedRating) || ['materials','finished','unavailable','chat-active'].includes(value.status)) vaultDrafts.delete(storageScope);
  if (!retainDraft() || value.card && (value.card.result || value.card.selectedRating) || ['materials','finished','unavailable','chat-active'].includes(value.status)) { recoveredDraft = ''; if (localState.available()) void localState.clearDraft(); }
  if (value.card && value.card.result && value.card.result.feedback && value.card.result.feedback.kind === 'choice') draft.selected = value.card.result.feedback.selectedOptionIndexes.slice();
  if (value.card && value.card.result && value.card.result.feedback && value.card.result.feedback.kind === 'matching') draft.matches = value.card.result.feedback.matches.slice();
  if (value.card && value.card.result && value.card.result.feedback && value.card.result.feedback.kind === 'ordering') draft.order = value.card.result.feedback.order.slice();
  render(entry && value.status === 'finished'); scheduleSessionExpiry(); if (wasPaused !== (value.status === 'paused')) { const nextFocus = value.status === 'paused' ? root.querySelector('.ar-paused button') : root.querySelector('textarea,input,[role=combobox],.ar-order-item') || root; if (busy) busyFocus = nextFocus; else if (nextFocus && !nextFocus.disabled) nextFocus.focus({preventScroll:true}); } if (key !== previousKey) { window.scrollTo(0, 0); root.focus({preventScroll:true}); }
}
async function loadView() { if (busy || locked || pending) return; clearError(); setBusy(true, 'Обновляем занятие…'); try { accept(await post('/miniapp/study', viewRequest(), true),true); } catch (problem) { handleFailure(problem, () => loadView()); } finally { setBusy(false); } }
async function loadToday() { if (busy || locked || pending) return; clearError(); setBusy(true,'Загружаем учебный план…'); try { const value = await post('/miniapp/study',{kind:'today'},true); if (!validView(value) || value.today !== undefined && !validToday(value.today) || value.week !== undefined && !validToday(value.week)) throw failure(0); today = value.today === undefined ? null : value.today; week = value.week === undefined ? null : value.week; sectionView = 'today'; accept(value); } catch (problem) { handleFailure(problem,() => loadToday()); } finally { setBusy(false); } }
async function openPlan(id, immediate) {
  if (busy || locked || pending || typeof id !== 'string' || id.length !== 64 || !/^[a-f0-9]{64}$/.test(id)) return;
  clearError(); setBusy(true,'Открываем занятие по плану…'); const previousId = planId; let startPrepared;
  try {
    const value = await post('/miniapp/study',{kind:'plan',id},true); planId = id;
    if (!validView(value) || !value.launch) { planId = previousId; throw failure(0); }
    planChoosing = true; planPrepared = false; planContinued = false; startConflict = ''; sectionView = 'study';
    history.replaceState(null,'','/miniapp/?plan=' + id); accept(value);
    if (immediate && value.studyTarget && value.studyTarget.id === id && canRepeatStudyTarget(value.studyTarget) && value.launch.available && value.launch.mode === 'core' && !unfinished() && value.status !== 'chat-active') {
      const fields = sessionLimitFields('core');
      const materialIds = value.materials.filter(row => row.mode !== 'bank' && row.count > 0 && value.launch.materialIds.includes(row.id)).map(row => row.id);
      if (fields && materialIds.length) startPrepared = Object.assign({materialIds,mode:'core',shuffle:shuffleCards},fields);
    }
  } catch (problem) { handleFailure(problem,() => openPlan(id,immediate)); } finally { setBusy(false); }
  if (startPrepared) act('start',startPrepared);
}
async function sendPending() { if (busy || locked || !pending) return; clearError(); setBusy(true, pending.kind === 'report-card' ? 'Сохраняем отметку для разбора…' : pending.kind === 'plan-action' ? 'Сохраняем изменение плана…' : pending.kind === 'pause' ? 'Ставим занятие на паузу…' : pending.kind === 'resume' ? 'Продолжаем занятие…' : pending.kind === 'finish-chat' ? 'Завершаем занятие в чате…' : pending.kind === 'grade' || pending.kind === 'change-grade' ? 'Сохраняем оценку…' : 'Обновляем занятие…');
  try { const value = await postPending(); if (!validView(value)) throw failure(0); const completed = pending; if (pending.kind !== 'finish') startConflict = ''; if (completed.kind === 'start' && planChoosing) { planChoosing = false; planContinued = false; } pending = null; resumeNeeded = false; if (completed.kind === 'report-card') { cardReportEdits.set(draft.key,{reason:'',note:'',open:true}); announce('Отметка сохранена в Telegram. Подтверждение появится после подключения Obsidian.'); } if (completed.kind === 'plan-action') planEdits.delete(completed.id); accept(value,false,completed.kind === 'finish-chat'); if (completed.kind === 'plan-action') announce('Изменение плана сохранено. Подтверждение появится после подключения Obsidian.'); if (completed.kind === 'pause') announce('Занятие на паузе. Таймер остановлен.'); if (completed.kind === 'resume') announce('Занятие продолжено.'); if (completed.kind === 'finish-chat') announce(value.status === 'chat-active' ? 'В чате открыто другое занятие.' : 'Занятие в чате завершено. Выставленные оценки сохранены.'); if (completed.kind === 'grade') announce('Оценка «' + labels[completed.rating] + '» сохранена. ' + (value.status === 'finished' ? value.session && value.session.mode === 'bank' ? 'Практика завершена.' : 'Занятие завершено.' : value.status === 'waiting' ? 'Ожидаем короткий повтор.' : 'Следующая карточка.')); }
  catch (problem) { if (problem.status === 409) { const failedStart = preserveFailedStart(), finishingPrevious = pending.kind === 'finish' && !!startConflict, finishingChat = pending.kind === 'finish-chat'; if (!failedStart && !finishingPrevious) startConflict = ''; pending = null;
      if (failedStart) { picker = true; render(); }
      try { const fresh = problem.freshView || await post('/miniapp/study', sectionView === 'today' ? {kind:'today'} : viewRequest(), true); accept(fresh,true); if (fresh.status === 'finished') clearError(); else error(failedStart ? 'Занятие не запущено' : finishingChat ? 'Занятие изменилось' : 'Экран обновлён', failedStart ? 'Занятие «' + startConflict + '» не запущено. Данные изменились. Выберите материал ещё раз.' : finishingChat ? 'Обновили экран. Проверьте занятие и повторите завершение, если нужно.' : finishingPrevious ? 'Прежнее занятие не завершено. Данные изменились. Выберите действие ещё раз.' : 'Данные изменились. Проверьте текущую карточку перед следующим действием.', null); } catch (freshError) { handleFailure(freshError, () => loadView()); } }
    else if (problem.status === 400 && pending) { const failedStart = preserveFailedStart(); pending = null;
      try { const fresh = await post('/miniapp/study',viewRequest(),true); accept(fresh,true); if (fresh.status === 'finished') clearError(); else error(failedStart ? 'Занятие не запущено' : 'Действие недоступно',failedStart ? 'Проверьте выбранные материалы и попробуйте снова.' : 'Обновили занятие. Проверьте текущую карточку перед следующим действием.',() => loadView()); } catch (freshError) { handleFailure(freshError,() => loadView()); }
    } else handleFailure(problem, () => sendPending()); }
  finally { setBusy(false); }
}
function act(kind, fields) { if (busy || locked || pending || !current) return; if (connectionExpiresAt && serverTime() >= connectionExpiresAt) { endConnection(); return; } if (kind !== 'finish' && serverTime() >= sessionDeadline()) { resumeNeeded = true; void refreshOnResume(); return; } if (kind === 'start' && planChoosing && launch && planId) fields = Object.assign({},fields || {},{planId}); if (kind === 'start' && (unfinished() || planChoosing && (!launch || !launch.available || !fields || !fields.materialIds.length || fields.materialIds.some(id => !(fields.planId ? targetMaterials(fields.mode) : pickerMaterials(fields.mode)).some(row => row.id === id && row.count > 0))))) return; pending = Object.assign({kind,requestId:crypto.randomUUID(),viewToken:current.viewToken}, fields || {}); sendPending(); }
async function authenticate() {
  if (busy) return; clearError(); locked = false;
  if (invalidVaultLink) { locked = true; root.replaceChildren(landing('Ссылка хранилища недействительна','Откройте занятие новой кнопкой в Telegram.')); return; }
  if (!tg || typeof tg.initData !== 'string' || !tg.initData) { locked = true; $('close').hidden = !tg; root.replaceChildren(landing('Занятие в Telegram','Откройте этот экран кнопкой в чате бота.')); error('Откройте экран из Telegram', 'Воспользуйтесь кнопкой занятия в чате бота. Ссылка из обычного браузера не подключает материалы.', null); return; }
  contextGeneration++;
  setBusy(true, 'Подключаемся к Telegram…');
  try { const requested = vaultId || launchVaultId, result = readVaultAuth(await post('/miniapp/auth', Object.assign({initData:tg.initData},requested ? {vaultId:requested} : planId ? {planId} : {}), false)); if (!result || requested && result.vaultId !== requested) throw failure(0); bearer = result.token; vaultId = result.vaultId || ''; vaults = result.vaults; storageScope = result.storageScope || ''; connectionExpiresAt = result.expiresAt; connectionHardExpiresAt = result.expiresAt; await localState.bind(result.storageScope); accept(await post('/miniapp/study', viewRequest(), true),true); }
  catch (problem) { if ([401,403].includes(problem.status) && (vaultId || launchVaultId || planId)) { locked = true; root.replaceChildren(landing('Ссылка на занятие недоступна','Откройте новое занятие или учебный план кнопкой в Telegram.')); error('Ссылка на занятие недоступна','Подключение или учебный план могли измениться. Откройте новую кнопку бота.',null); } else handleFailure(problem, () => authenticate()); } finally { setBusy(false); }
}
function resetVaultView(nextScope) {
  cancelOrderInteraction(); closeFilterPicker(); releaseMedia();
  [lifetimeTimer,waitingTimer,lessonTimer,resumeTimer].forEach(clearTimeout); resumeNeeded = false; resumeReading = null;
  current = null; cardDom = null; waitingDom = null; sessionTimerDom = null; serverClock = null;
  const remembered = vaultDrafts.get(nextScope); vaultDrafts.delete(nextScope); draft = remembered ? JSON.parse(JSON.stringify(remembered)) : {key:'',selected:[],text:'',blanks:[],matches:[],order:[]};
  recoveredDraft = remembered ? remembered.key : ''; historySize = 20; editingGrade = false; historyOpen = false;
  selectedPreset = ''; presetName = ''; presetFeedback = ''; presetsOpen = false; presetRefresh = null;
  picker = false; startConflict = ''; shuffleCards = false; studyMode = 'core'; settingsPrepared = false;
  planId = ''; launch = null; planPrepared = false; planChoosing = false; planContinued = false; sectionView = 'study'; today = null; week = null; planRange = 'today';
  planEdits.clear(); cardReportEdits.clear(); topicRecallExpanded = false; topicRecallSelected = ''; studyTargetExpanded = true;
  ['core','bank'].forEach(mode => { materialSelections[mode].clear(); settingsOpen[mode] = false; startSettings[mode] = {cardLimit:'',timeLimitMinutes:''}; Object.keys(studyFilters[mode]).forEach(key => { studyFilters[mode][key] = ''; }); });
}
async function switchVault(id) {
  if (busy || pending || locked || id === vaultId || !vaults.some(row => row.id === id)) return;
  if (connectionExpiresAt && serverTime() >= connectionExpiresAt) { endConnection(); return; }
  clearError(); setBusy(true,'Переключаем хранилище…'); contextGeneration++;
  const generation = contextGeneration, hardExpiry = connectionHardExpiresAt;
  try {
    vaultDrafts.delete(storageScope);
    if (storageScope && current && ['question','paused'].includes(current.status) && current.card && !current.card.result && !current.card.selectedRating && draft.key) vaultDrafts.set(storageScope,JSON.parse(JSON.stringify(draft)));
    persistDraft(); await localState.flush();
    const result = readVaultAuth(await post('/miniapp/vault',{vaultId:id},true));
    if (!result || result.vaultId !== id) throw failure(0);
    const value = await post('/miniapp/study',{kind:'view'},true,result.token);
    if (!validView(value) || value.today !== undefined && !validToday(value.today) || value.week !== undefined && !validToday(value.week)) throw failure(0);
    resetVaultView(result.storageScope); bearer = result.token; vaultId = result.vaultId; vaults = result.vaults; storageScope = result.storageScope;
    connectionHardExpiresAt = Math.min(hardExpiry || result.expiresAt,result.expiresAt); connectionExpiresAt = connectionHardExpiresAt;
    await localState.bind(storageScope); if (generation !== contextGeneration) return;
    accept(value,true); try { const url = new URL(location.href), fragment = new URLSearchParams(url.hash.slice(1)); url.searchParams.delete('plan'); fragment.set('vault',vaultId); url.hash = fragment.toString(); history.replaceState(null,'',url); } catch (_) {}
    announce('Открыто хранилище «' + vaults.find(row => row.id === vaultId).name + '».');
  } catch (problem) {
    if (generation !== contextGeneration) return;
    error('Не удалось переключить хранилище',[400,401,403].includes(problem.status) ? 'Хранилище недоступно. Текущие материалы и ответ не изменены. Проверьте подключение в Obsidian.' : 'Проверьте соединение и повторите попытку. Текущие материалы и ответ не изменены.',() => switchVault(id));
  } finally { if (generation === contextGeneration) { setBusy(false); const picker = root.querySelector('#ar-vault'); if (picker && !locked) picker.focus({preventScroll:true}); } }
}
function updateCheck() { if (!cardDom || !current || !current.card) return; const card = current.card; let complete = card.kind === 'single' || card.kind === 'multiple' ? draft.selected.length > 0 : card.kind === 'cloze' ? draft.blanks.length === card.blankCount && draft.blanks.every(text => text.trim().length > 0) : card.kind === 'matching' ? permutation(draft.matches,card.matching.left.length) : card.kind === 'ordering' ? permutation(draft.order,card.orderItems.length) : draft.text.trim().length > 0;
  cardDom.check.disabled = busy || locked || !!pending || !complete; }
function createOrderInput(list, card) {
  const rows = new Map(), help = el('p','ar-sr','Перетаскивайте за всю строку. С клавиатуры: пробел или Enter — взять и положить, стрелки вверх и вниз — переместить, Home и End — в начало и конец, Escape — отменить.');
  help.id = 'ar-order-help'; list.before(help); list.setAttribute('aria-describedby',help.id);
  let pointer = null, keyboard = null, frame = 0, lastFrame = 0, reordering = false;
  const available = () => !busy && !locked && !pending && current && current.status === 'question' && current.card && current.card.id === card.id && current.card.revision === card.revision && !current.card.result;
  const orderRows = order => { const focused = list.contains(document.activeElement) ? document.activeElement : null; reordering = true; order.forEach((item,index) => { const row = rows.get(item); if (list.children[index] !== row) list.insertBefore(row,list.children[index] || null); row.querySelector('.ar-order-number').textContent = String(index + 1); row.setAttribute('aria-posinset',String(index + 1)); }); reordering = false; if (focused && focused.isConnected) focused.focus({preventScroll:true}); };
  const report = item => announce('Позиция ' + (draft.order.indexOf(item) + 1) + ' из ' + draft.order.length + '. ' + card.orderItems[item]);
  const finish = (commit, focus) => {
    const drag = pointer, key = keyboard; if (!drag && !key) return;
    pointer = null; keyboard = null; cancelAnimationFrame(frame); frame = 0; lastFrame = 0;
    if (drag) { if (drag.row.hasPointerCapture(drag.id)) drag.row.releasePointerCapture(drag.id); drag.row.classList.remove('is-dragging'); drag.row.style.removeProperty('width'); if (drag.preview) drag.preview.remove(); if (drag.placeholder) drag.placeholder.remove(); document.body.classList.remove('ar-order-dragging'); }
    if (key) rows.get(key.item).classList.remove('is-keyboard-dragging');
    document.removeEventListener('keydown',escape,true); window.removeEventListener('resize',cancel); if (window.visualViewport) visualViewport.removeEventListener('resize',cancel);
    const item = drag ? drag.item : key.item;
    if (commit && available()) { if (drag && drag.active) { const next = draft.order.filter(value => value !== item); next.splice(drag.target,0,item); draft.order = next; } else if (key) draft.order = key.order.slice(); persistDraft(); }
    orderRows(draft.order); updateCheck();
    if (focus && rows.get(item).isConnected) rows.get(item).focus({preventScroll:true});
    if (commit) report(item); else if (drag && drag.active || key) announce('Перемещение отменено. ' + card.orderItems[item]);
  };
  const cancel = () => finish(false,false), escape = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); finish(false,true); } };
  const listen = () => { document.addEventListener('keydown',escape,true); window.addEventListener('resize',cancel); if (window.visualViewport) visualViewport.addEventListener('resize',cancel); };
  const inside = drag => { const box = list.getBoundingClientRect(); return drag.x >= box.left && drag.x <= box.right && drag.y >= box.top && drag.y <= box.bottom && drag.x >= 0 && drag.x <= innerWidth && drag.y >= 0 && drag.y <= innerHeight; };
  const position = drag => {
    const outside = !inside(drag); drag.outside = outside; drag.preview.classList.toggle('is-outside',outside);
    const box = drag.preview.getBoundingClientRect(), viewport = window.visualViewport, left = viewport ? viewport.offsetLeft : 0, top = viewport ? viewport.offsetTop : 0, width = viewport ? viewport.width : innerWidth, height = viewport ? viewport.height : innerHeight;
    drag.preview.style.left = Math.max(left + 8,Math.min(drag.x - drag.offsetX,left + width - box.width - 8)) + 'px'; drag.preview.style.top = Math.max(top + 8,Math.min(drag.y - drag.offsetY,top + height - box.height - 8)) + 'px';
    if (outside) return;
    const y = drag.y + scrollY - (list.getBoundingClientRect().top + scrollY - drag.listTop); let target = drag.slots.findIndex(slot => y < slot.center); if (target < 0) target = drag.slots.length;
    if (target === drag.target) return; drag.target = target;
    if (target < drag.slots.length) rows.get(drag.slots[target].item).before(drag.placeholder); else list.append(drag.placeholder);
    drag.preview.querySelector('.ar-order-number').textContent = String(target + 1);
  };
  const tick = time => {
    const drag = pointer; if (!drag || !drag.active) return;
    if (!available() || !list.isConnected) { cancel(); return; }
    const elapsed = lastFrame ? Math.min(32,time-lastFrame) : 16; lastFrame = time;
    const viewport = window.visualViewport, top = viewport ? viewport.offsetTop : 0, bottom = top + (viewport ? viewport.height : innerHeight), box = list.getBoundingClientRect();
    if (drag.x >= box.left && drag.x <= box.right && drag.y >= Math.max(top,box.top-8) && drag.y <= Math.min(bottom,box.bottom+8)) { const speed = drag.y < top + 56 ? -Math.min(1,(top + 56-drag.y)/56) : drag.y > bottom - 56 ? Math.min(1,(drag.y-bottom+56)/56) : 0; if (speed) window.scrollBy(0,speed * elapsed * .55); }
    position(drag); frame = requestAnimationFrame(tick);
  };
  card.orderItems.forEach((text,item) => {
    const row = el('li','ar-order-item'), number = el('span','ar-order-number'), label = el('span','ar-literal ar-order-text',text); row.dataset.item = String(item); row.tabIndex = 0; row.setAttribute('aria-describedby',help.id); row.setAttribute('aria-setsize',String(card.orderItems.length)); number.setAttribute('aria-hidden','true'); row.append(number,label); rows.set(item,row); list.append(row);
    row.addEventListener('dragstart',event => event.preventDefault());
    row.addEventListener('pointerdown',event => { if (!event.isPrimary || event.button !== 0 || !available() || pointer || keyboard) return; const rect = row.getBoundingClientRect(); pointer = {id:event.pointerId,item,row,x:event.clientX,y:event.clientY,startX:event.clientX,startY:event.clientY,offsetX:event.clientX-rect.left,offsetY:event.clientY-rect.top,target:draft.order.indexOf(item),active:false}; row.focus({preventScroll:true}); row.setPointerCapture(event.pointerId); listen(); });
    row.addEventListener('pointermove',event => {
      const drag = pointer; if (!drag || drag.id !== event.pointerId || drag.row !== row) return; drag.x = event.clientX; drag.y = event.clientY;
      if (!drag.active) { if (Math.hypot(drag.x-drag.startX,drag.y-drag.startY) < 8) return;
        const rect = row.getBoundingClientRect(); drag.listTop = list.getBoundingClientRect().top + scrollY; drag.slots = draft.order.filter(value => value !== item).map(value => { const box = rows.get(value).getBoundingClientRect(); return {item:value,center:box.top + scrollY + box.height/2}; });
        drag.placeholder = el('li','ar-order-placeholder'); drag.placeholder.setAttribute('aria-hidden','true'); drag.placeholder.style.height = rect.height + 'px'; row.before(drag.placeholder); row.style.width = rect.width + 'px'; row.classList.add('is-dragging');
        drag.preview = el('div','ar-order-item ar-order-preview'); drag.preview.setAttribute('aria-hidden','true'); drag.preview.style.width = Math.min(rect.width,innerWidth-16) + 'px'; drag.preview.append(el('span','ar-order-number',String(drag.target+1)),el('span','ar-literal ar-order-text',text)); document.body.append(drag.preview); document.body.classList.add('ar-order-dragging'); drag.active = true; frame = requestAnimationFrame(tick); announce('Выбрано для перемещения. ' + text);
      }
      event.preventDefault(); position(drag);
    });
    row.addEventListener('pointerup',event => { const drag = pointer; if (!drag || drag.id !== event.pointerId) return; drag.x = event.clientX; drag.y = event.clientY; if (drag.active) { event.preventDefault(); position(drag); } finish(drag.active && !drag.outside,true); });
    row.addEventListener('pointercancel',event => { if (pointer && pointer.id === event.pointerId) cancel(); }); row.addEventListener('lostpointercapture',event => { if (pointer && pointer.id === event.pointerId) cancel(); });
    row.addEventListener('keydown',event => {
      if (event.altKey || event.ctrlKey || event.metaKey || event.isComposing || pointer || !available()) return;
      if (event.key === ' ' || event.key === 'Enter') { event.preventDefault(); event.stopPropagation(); if (event.repeat) return; if (keyboard) finish(true,true); else { keyboard = {item,order:draft.order.slice()}; row.classList.add('is-keyboard-dragging'); listen(); announce('Выбрано для перемещения. ' + text); } return; }
      if (!keyboard || keyboard.item !== item) return;
      if (event.key === 'Tab') { finish(true,false); return; }
      if (!['ArrowUp','ArrowDown','Home','End'].includes(event.key)) return;
      event.preventDefault(); event.stopPropagation(); const from = keyboard.order.indexOf(item), to = event.key === 'Home' ? 0 : event.key === 'End' ? keyboard.order.length - 1 : from + (event.key === 'ArrowUp' ? -1 : 1); if (to < 0 || to >= keyboard.order.length || from === to) return;
      keyboard.order.splice(from,1); keyboard.order.splice(to,0,item); orderRows(keyboard.order); row.focus({preventScroll:true}); row.scrollIntoView({block:'nearest'}); announce('Позиция ' + (to+1) + ' из ' + keyboard.order.length + '. ' + text);
    });
    row.addEventListener('focusout',event => { if (!reordering && keyboard && keyboard.item === item && !row.contains(event.relatedTarget)) finish(true,false); });
  });
  return {cancel,render() { const enabled = !!available(); if (!enabled) cancel(); if (!pointer && !keyboard) orderRows(draft.order); rows.forEach(row => { row.setAttribute('aria-disabled',String(!enabled)); row.tabIndex = enabled ? 0 : -1; }); list.tabIndex = enabled ? 0 : -1; }};
}
function reportCardView() {
  if (current.cardReportsSupported !== true || !current.card) return null;
  const reasons = {'unclear-question':'Неясный вопрос','disputed-answer':'Сомнение в эталоне','too-much-information':'Слишком много информации','missing-context':'Не хватает контекста',other:'Другая причина'}, key = draft.key;
  if (!cardReportEdits.has(key)) cardReportEdits.set(key,{reason:'',note:'',open:false}); const edit = cardReportEdits.get(key), panel = el('details','ar-start-settings ar-card-report'), body = el('div','ar-stack'); panel.append(el('summary','','Нужно уточнить карточку')); panel.open = edit.open;
  panel.addEventListener('toggle',() => { if (panel.isConnected) edit.open = panel.open; });
  const report = (Array.isArray(current.cardReports) ? current.cardReports : []).filter(row => row.cardId === current.card.id).sort((a,b) => b.requestedAt-a.requestedAt)[0], waiting = report && report.status === 'pending';
  const reportLabels = {pending:'Отметка сохранена в Telegram; ожидает Obsidian.',applied:'Карточка отмечена для разбора в Obsidian.',conflict:'Карточка изменилась. Проверьте её перед новой отметкой.',missing:'Карточка больше недоступна в Obsidian.',revoked:'Разрешение на передачу карточки отозвано.',expired:'Срок действия отметки истёк. Обновите учебную копию.'};
  if (report) { const status = el('p','ar-empty',reportLabels[report.status] || 'Статус отметки пока недоступен.'); status.setAttribute('role','status'); body.append(status); }
  const reason = choicePicker('ar-card-report-reason','Причина',[{value:'',label:'Выберите причину'},...Object.entries(reasons).map(([value,label]) => ({value,label}))],edit.reason,value => { edit.reason = value; validate(); }), noteLabel = el('label','ar-field'), note = el('textarea'); note.maxLength = 4000; note.rows = 2; note.value = edit.note; noteLabel.append(el('span','','Заметка · необязательно'),note);
  const save = button('Отправить на разбор',() => { validate(); if (save.disabled) return; persistDraft(); act('report-card',{reason:edit.reason,...(edit.note.trim() ? {note:edit.note.trim()} : {})}); },'ar-ghost');
  const validate = () => { save.dataset.unavailable = String(!!waiting || !Object.prototype.hasOwnProperty.call(reasons,edit.reason) || edit.note.length > 4000); updateDisabled(); }; note.addEventListener('input',() => { edit.note = note.value; validate(); }); body.append(reason.field,noteLabel,el('p','ar-empty','Отметка передастся в Obsidian. Оценка и расписание карточки не изменятся.'),save); panel.append(body); validate(); return panel;
}
function answerHistoryFields(card) { if (!current || current.retainAnswers !== true) return {}; if (card.kind === 'self' || card.kind === 'exact') return {text:draft.text}; if ((card.kind === 'single' || card.kind === 'multiple') && !draft.selected.length || card.kind === 'cloze' && !draft.blanks.some(text => text.trim()) || card.kind === 'matching' && !draft.matches.some(value => value >= 0)) return {}; return {response:card.kind === 'single' || card.kind === 'multiple' ? {selectedOptionIndexes:draft.selected.slice()} : card.kind === 'cloze' ? {clozeAnswers:Array.from({length:card.blankCount},(_,index) => draft.blanks[index] || '')} : card.kind === 'matching' ? {matches:draft.matches.slice()} : {order:draft.order.slice()}}; }
function createCard() {
  const card = current.card, section = el('section','ar-section'), top = el('div'), meta = el('div','ar-meta'), progress = el('progress','ar-progress');
  const count = el('span'), kind = el('span','',kinds[card.kind] || 'Карточка'), mode = el('p','ar-session-mode'); meta.append(count, kind); progress.setAttribute('aria-label','Пройдено карточек'); top.append(mode,meta,progress);
  const heading = el('div'), material = el('p','ar-material',card.materialTitle), title = el('h1','ar-literal',card.question); heading.append(material,title);
  if (recoveredDraft === draft.key) heading.append(el('p','ar-empty ar-draft-recovered','Незавершённый ответ восстановлен на этом устройстве.'));
  const questionMedia = el('div','ar-media'), response = el('div','ar-stack'), options = el('fieldset','ar-options');
  options.append(el('legend','ar-sr','Варианты ответа'));
  if (card.kind === 'single' || card.kind === 'multiple') card.options.forEach((text,index) => { const row = el('label','ar-option'), input = el('input'); input.type = card.kind === 'single' ? 'radio' : 'checkbox'; input.name = 'answer-choice'; input.value = String(index); input.checked = draft.selected.includes(index);
    const status = el('span','ar-option-status'); row.append(input,el('span','ar-option-text',text),status); options.append(row);
    input.addEventListener('change', () => { draft.selected = card.kind === 'single' ? [index] : input.checked ? Array.from(new Set(draft.selected.concat(index))).sort((a,b) => a-b) : draft.selected.filter(value => value !== index); persistDraft(); updateCheck(); }); });
  const fields = [], matchPickers = [], orderList = el('ol','ar-order-list');
  if (card.kind === 'exact' || card.kind === 'cloze' || card.kind === 'self') { const count = card.kind === 'cloze' ? card.blankCount : 1; for (let index = 0; index < count; index++) { const label = el('label','ar-field'), input = el('textarea'); input.rows = card.kind === 'cloze' ? 1 : card.kind === 'self' ? 4 : 3; input.maxLength = card.kind === 'self' ? 4000 : 2000; input.autocomplete = 'off'; input.autocapitalize = 'off'; input.spellcheck = false; input.value = card.kind === 'cloze' ? draft.blanks[index] || '' : draft.text;
      if (card.kind === 'self') input.placeholder = 'Запишите своими словами — или ответьте устно';
      label.append(el('span','',card.kind === 'cloze' ? 'Пропуск ' + (index + 1) : card.kind === 'self' ? 'Ваш ответ по памяти' : 'Ваш ответ'),input); response.append(label); fields.push(input);
      input.addEventListener('input', () => { if (card.kind === 'cloze') draft.blanks = fields.map(field => field.value); else draft.text = input.value; persistDraft(); updateCheck(); }); } if (card.kind === 'cloze') response.classList.add('ar-cloze-fields'); }
  const matchEntries = index => [{value:'',label:'Выберите пару'},...card.matching.right.map((label,value) => ({value:String(value),label,disabled:draft.matches.some((chosen,other) => other !== index && chosen === value)}))];
  const refreshMatches = () => { matchPickers.forEach((picker,index) => picker.update(matchEntries(index),draft.matches[index] >= 0 ? String(draft.matches[index]) : '')); updateCheck(); };
  if (card.kind === 'matching') { if (draft.matches.length !== card.matching.left.length) draft.matches = card.matching.left.map(() => -1); card.matching.left.forEach((text,index) => { const picker = choicePicker('ar-match-' + index,text,matchEntries(index),draft.matches[index] >= 0 ? String(draft.matches[index]) : '',value => { draft.matches[index] = value === '' ? -1 : Number(value); persistDraft(); refreshMatches(); }); picker.field.classList.add('ar-matching-row'); response.append(picker.field); matchPickers.push(picker); }); }
  let orderControl = null;
  if (card.kind === 'ordering') { if (!permutation(draft.order,card.orderItems.length)) draft.order = card.orderItems.map((_,index) => index); orderList.tabIndex = 0; orderList.setAttribute('aria-label','Порядок элементов'); response.append(orderList); orderControl = createOrderInput(orderList,card); }
  const renderOrder = () => { if (orderControl) orderControl.render(); }, cancelOrder = () => { if (orderControl) orderControl.cancel(); };
  const hints = el('aside','ar-hint'), actions = el('div','ar-actions');
  const retention = el('label','ar-shuffle ar-answer-retention'), retentionInput = el('input'); retentionInput.type = 'checkbox'; retentionInput.checked = current.retainAnswers === true; retentionInput.setAttribute('aria-label','Сохранять ответы'); retention.title = 'Запоминается для всех следующих карточек и занятий. Правильные шаблонные ответы сохраняются без копии введённого текста. Выключение не удаляет прежнюю историю.'; retention.append(retentionInput,el('span','','Сохранять ответы')); retentionInput.addEventListener('change',() => { const enabled = retentionInput.checked; if (!enabled && localState.available()) void localState.clearDraft(); act('answer-retention',{enabled}); });
  const submitCheck = () => { if (check.disabled || !check.isConnected || check.closest('[hidden]')) return; const response = card.kind === 'single' || card.kind === 'multiple' ? {selectedOptionIndexes:draft.selected.slice()} : card.kind === 'cloze' ? {clozeAnswers:fields.map(field => field.value)} : card.kind === 'matching' ? {matches:draft.matches.slice()} : card.kind === 'ordering' ? {order:draft.order.slice()} : {text:draft.text}; act('check',{response}); };
  const check = button('Проверить ответ',submitCheck,'ar-primary');
  const checkOnEnter = event => { if (event.key !== 'Enter' || event.shiftKey || event.ctrlKey || event.altKey || event.metaKey || event.isComposing || event.keyCode === 229) return; event.preventDefault(); if (!event.repeat) submitCheck(); };
  if (card.kind !== 'self') fields.forEach(input => { input.title = 'Enter — проверить, Shift+Enter — новая строка'; input.addEventListener('keydown',checkOnEnter); });
  orderList.addEventListener('keydown',event => { if (event.target === orderList) checkOnEnter(event); });
  const secondary = el('div','ar-secondary'), hint = button('Подсказка',() => act('hint'),'ar-ghost'), reveal = button(card.kind === 'self' ? 'Сравнить с эталоном' : 'Показать ответ',() => card.kind === 'self' ? act('self-recall',{text:draft.text}) : act('reveal'),'ar-ghost'); secondary.append(hint,reveal); actions.append(check,secondary);
  if (card.kind === 'self') { check.hidden = true; reveal.className = 'ar-primary'; secondary.className = 'ar-stack'; }
  const feedback = el('section','ar-feedback'), answerMedia = el('div','ar-media'), source = el('details','ar-source-context'), grading = el('section','ar-grading'), selectedGrade = el('div','ar-grade-selected'), report = el('div');
  const next = button('Следующая карточка',() => act('next'),'ar-primary');
  section.append(top,heading,questionMedia,options,response,retention,hints,actions,feedback,answerMedia,source,grading,selectedGrade,report,next);
  cardDom = {section,count,mode,progress,questionMedia,options,response,retention,retentionInput,fields,matchPickers,refreshMatches,renderOrder,cancelOrder,hints,actions,check,hint,feedback,answerMedia,source,grading,selectedGrade,report,next,checkedCriteria:[]};
  return section;
}
function gradeButtons(ratings, work, shortcuts) { const group = el('div','ar-grades'); ratings.forEach(rating => { const node = button(labels[rating], () => work(rating)); node.dataset.rating = String(rating); if (shortcuts) { const key = el('kbd','ar-grade-key',String(rating)); key.setAttribute('aria-hidden','true'); node.prepend(key); node.setAttribute('aria-keyshortcuts',String(rating)); node.title = rating + ' — ' + labels[rating]; } group.append(node); }); return group; }
function recallComparison(answer, reference, criteria) { const suffix = Array.isArray(criteria) && criteria.length ? '\n\nКритерии самопроверки:\n' + criteria.map(text => '• ' + text).join('\n') : ''; const shownReference = suffix && reference.endsWith(suffix) ? reference.slice(0,-suffix.length) : reference; const comparison = el('div','ar-recall-comparison'); for (const [heading,text] of [['Ваш ответ по памяти',answer || 'Устный ответ — без записи.'],['Эталон',shownReference]]) { const column = el('section','ar-recall-column'); column.append(el('h3','',heading),el('p','ar-literal',text)); comparison.append(column); } return comparison; }
function recallCriteria(criteria, checked, change) { const list = el('fieldset','ar-recall-criteria'); list.append(el('legend','',change ? 'Что удалось вспомнить' : 'Отмеченные критерии')); criteria.forEach((text,index) => { const row = el('label','ar-option'), input = el('input'); input.type = 'checkbox'; input.checked = checked.includes(index); if (change) input.addEventListener('change',() => change(index,input.checked)); else input.dataset.unavailable = 'true'; row.append(input,el('span','ar-option-text',text)); list.append(row); }); return list; }
function gradeOnNumber(event) {
  if (event.defaultPrevented || event.repeat || event.isComposing || event.keyCode === 229 || event.ctrlKey || event.altKey || event.metaKey || event.shiftKey || !/^[1-4]$/.test(event.key) || busy || locked || pending || picker || sectionView !== 'study' || !current || !current.card || !current.card.result || !cardDom || !cardDom.grading.isConnected || cardDom.grading.hidden) return;
  const target = event.target;
  if (target instanceof Element && (target.isContentEditable || !target.matches('.ar-recall-criteria input') && target.closest('input,textarea,select,[role="combobox"],[role="listbox"],[contenteditable]:not([contenteditable="false"]),audio,video,.ar-attachment,.ar-history,.ar-order-list'))) return;
  const control = cardDom.grading.querySelector('button[data-rating="' + event.key + '"]');
  if (control && !control.disabled) { event.preventDefault(); control.click(); }
}
function updateCard() {
  const card = current.card, result = card.result, d = cardDom, session = current.session;
  d.retention.hidden = current.answerHistorySupported !== true || !!card.selectedRating; d.retentionInput.checked = current.retainAnswers === true;
  d.mode.textContent = modeLabel(session && session.mode || studyMode);
  d.count.textContent = session ? 'Пройдено ' + session.completed + ' из ' + session.total : 'Карточка'; d.progress.max = session && session.total || 1; d.progress.value = session && session.completed || 0;
  d.options.hidden = card.kind !== 'single' && card.kind !== 'multiple'; d.response.hidden = !['exact','cloze','matching','ordering','self'].includes(card.kind) || card.kind === 'self' && !!result;
  const correct = result && Array.isArray(result.correctOptionIndexes) ? result.correctOptionIndexes : [], chosen = result && result.feedback && result.feedback.kind === 'choice' ? result.feedback.selectedOptionIndexes : draft.selected;
  d.options.querySelectorAll('.ar-option').forEach((row,index) => { const input = row.querySelector('input'), status = row.querySelector('.ar-option-status'); input.checked = chosen.includes(index); input.dataset.unavailable = String(!!result); row.classList.remove('is-good','is-bad','is-missed'); status.textContent = '';
    if (result) { if (correct.includes(index) && (result.matched === undefined || chosen.includes(index))) { row.classList.add('is-good'); status.textContent = result.matched === undefined ? 'верный' : 'верно'; } else if (result.matched !== undefined && chosen.includes(index) && !correct.includes(index)) { row.classList.add('is-bad'); status.textContent = 'лишнее'; } else if (result.matched !== undefined && correct.includes(index)) { row.classList.add('is-missed'); status.textContent = 'пропущено'; } } });
  d.fields.forEach(input => { input.dataset.unavailable = String(!!result); });
  d.matchPickers.forEach(picker => { picker.trigger.dataset.unavailable = String(!!result); }); d.refreshMatches(); d.renderOrder();
  renderMedia(d.questionMedia,card.questionMedia || []); renderMedia(d.answerMedia,result && result.answerMedia || [],card.questionMedia || []);
  d.source.hidden = !result || !card.source; d.source.replaceChildren(); if (!d.source.hidden) { const source = card.source, places = []; d.source.append(el('summary','','Контекст источника')); if (source.excerpt) d.source.append(el('p','ar-literal',source.excerpt)); if (Number.isSafeInteger(source.page) && source.page >= 0) places.push('Страница ' + source.page); if (Number.isFinite(source.timeSeconds) && source.timeSeconds >= 0) places.push(durationText(source.timeSeconds)); if (places.length) d.source.append(el('p','ar-empty',places.join(' · '))); }
  d.hints.hidden = !card.hints.length; d.hints.replaceChildren(el('h2','','Подсказки · ' + card.hints.length + ' из ' + card.totalHints)); card.hints.forEach(text => d.hints.append(el('p','',text)));
  d.actions.hidden = !!result; d.hint.hidden = card.hints.length >= card.totalHints; d.hint.textContent = card.hints.length ? 'Ещё подсказка' : 'Подсказка'; d.hint.dataset.unavailable = String(card.hints.length >= card.totalHints);
  d.feedback.hidden = !result; d.feedback.replaceChildren();
  if (result) { d.feedback.dataset.tone = result.matched === undefined ? '' : result.matched ? 'good' : 'bad'; d.feedback.append(el('h2','',card.kind === 'self' ? 'Сравните с эталоном' : result.matched === undefined ? 'Ответ для самопроверки' : result.matched ? 'Ответ верный' : 'Есть ошибки'));
    if (card.kind === 'self') { d.feedback.append(recallComparison(result.recalledText === undefined ? draft.text : result.recalledText,result.reference,result.selfCheckCriteria)); if (Array.isArray(result.selfCheckCriteria) && result.selfCheckCriteria.length) { if (card.selectedRating) d.checkedCriteria = (result.checkedCriteria || []).slice(); d.feedback.append(recallCriteria(result.selfCheckCriteria,d.checkedCriteria,card.selectedRating ? null : (index,checked) => { d.checkedCriteria = checked ? Array.from(new Set(d.checkedCriteria.concat(index))).sort((a,b) => a-b) : d.checkedCriteria.filter(value => value !== index); })); } }
    else if (card.kind === 'cloze' && result.feedback && result.feedback.kind === 'cloze' && Array.isArray(result.expectedBlanks)) result.expectedBlanks.forEach((text,index) => { const matched = result.feedback.matchedBlanks[index], line = el('div','ar-blank-result',(matched ? '✓ ' : '× ') + 'Пропуск ' + (index + 1) + ' — ' + text); line.dataset.tone = matched ? 'good' : 'bad'; d.feedback.append(line); });
    else if (card.kind === 'matching') result.correctMatches.forEach((expected,index) => { const submitted = result.feedback && result.feedback.kind === 'matching' ? result.feedback.matches[index] : undefined, matched = submitted === undefined || submitted === expected, line = el('div','ar-blank-result',(submitted === undefined ? '' : matched ? '✓ ' : '× ') + card.matching.left[index] + ' → ' + card.matching.right[expected]); if (submitted !== undefined) line.dataset.tone = matched ? 'good' : 'bad'; if (!matched) line.append(el('p','','Ваш вариант: ' + card.matching.right[submitted])); d.feedback.append(line); });
    else if (card.kind === 'ordering') result.correctOrder.forEach((expected,index) => { const submitted = result.feedback && result.feedback.kind === 'ordering' ? result.feedback.order[index] : undefined, matched = submitted === undefined || submitted === expected, line = el('div','ar-blank-result',(submitted === undefined ? '' : matched ? '✓ ' : '× ') + (index + 1) + '. ' + card.orderItems[expected]); if (submitted !== undefined) line.dataset.tone = matched ? 'good' : 'bad'; if (!matched) line.append(el('p','','Ваш вариант: ' + card.orderItems[submitted])); d.feedback.append(line); });
    else d.feedback.append(el('p','ar-literal',result.reference)); }
  d.grading.hidden = !result || !!card.selectedRating && !editingGrade; d.grading.replaceChildren();
  if (!d.grading.hidden) { d.grading.append(el('p','',editingGrade ? 'Выберите другую оценку' : session && session.mode === 'bank' ? 'Насколько уверенно удалось ответить?' : 'Насколько легко удалось вспомнить?'),gradeButtons(card.allowedRatings, rating => act(editingGrade ? 'change-grade' : 'grade',editingGrade ? {attemptId:card.attemptId,rating} : {rating,advance:true,...answerHistoryFields(card),...(card.kind === 'self' && result.selfCheckCriteria && result.selfCheckCriteria.length ? {checkedCriteria:d.checkedCriteria.slice()} : {})}),true)); if (editingGrade) d.grading.append(button('Оставить прежнюю',() => { editingGrade = false; render(); },'ar-ghost')); }
  d.selectedGrade.hidden = !card.selectedRating || editingGrade; d.selectedGrade.replaceChildren();
  if (card.selectedRating) { const text = el('p','','Оценка: '); text.append(el('strong','',labels[card.selectedRating])); const history = current.history.find(row => row.attemptId === card.attemptId); if (history) text.append(el('span','ar-sync',statuses[history.syncStatus] || 'Статус пока недоступен')); d.selectedGrade.append(text);
    if (card.canChangeGrade) d.selectedGrade.append(button('Изменить оценку',() => { editingGrade = true; render(); },'ar-ghost')); }
  const nextStep = current.nextStep || {kind:'card'}; d.next.textContent = nextStep.kind === 'finished' ? 'Завершить повторение' : nextStep.kind === 'waiting' ? 'К короткому повтору' : nextStep.kind === 'material' ? 'К следующему материалу' + (nextStep.materialTitle ? ' · ' + nextStep.materialTitle : '') : 'Следующая карточка';
  d.next.hidden = !card.selectedRating || editingGrade; updateCheck();
  d.report.replaceChildren(); const report = reportCardView(); d.report.hidden = !report; if (report) d.report.append(report);
  const restored = d.section.querySelector('.ar-draft-recovered'); if (restored) restored.hidden = recoveredDraft !== draft.key || current.status !== 'question';
}
function answerEvidenceComparison(evidence) { const section = el('div','ar-recall-comparison'); for (const [label,text] of [[evidence.answerMatch === true ? 'Ответ верный · эталон' : 'Ваш ответ',evidence.answerMatch === true ? evidence.reference : evidence.answer || 'Текст ответа не записан.'],['Эталон этой попытки',evidence.reference || 'Самопроверка по критериям.']]) { if (evidence.answerMatch === true && label === 'Эталон этой попытки') continue; const column = el('section','ar-recall-column'); column.append(el('h3','',label),el('p','ar-literal',text)); section.append(column); } return section; }
function historyView(lastSession) {
  if (!current.history.length && !lastSession && !(current.answerMistakes || []).length) return null; const details = el('details','ar-history'), summary = el('summary','',lastSession ? 'История последнего занятия' : current.history.length ? 'История · ' + current.history.length : 'История ответов'), list = el('div','ar-history-list'); details.append(summary,list);
  function fill() { list.replaceChildren(); const repeated = (current.answerMistakes || []).filter(row => row.count >= 2); if (repeated.length) { const patterns = el('section','ar-answer-mistakes'); patterns.append(el('h3','','Повторяющиеся ошибки')); repeated.forEach(row => { const item = el('div','ar-answer-mistake'); item.append(el('p','ar-literal',row.question),el('p','ar-literal','«' + row.answer + '» — повторений: ' + row.count)); patterns.append(item); }); list.append(patterns); } if (lastSession && current.session) list.append(el('p','ar-empty','Пройдено карточек: ' + current.session.completed + ' из ' + current.session.total + '. Ответов: ' + current.session.answers + '.')); current.history.slice(-historySize).reverse().forEach(row => { const item = el('article','ar-history-item'), footer = el('div','ar-history-footer'), text = el('div','',labels[row.rating]); text.append(el('span','ar-sync',statuses[row.syncStatus] || 'Статус пока недоступен')); item.append(el('p','',row.question)); footer.append(text);
    if (row.answerEvidence) { const recall = el('details','ar-recall-history'); recall.append(el('summary','',row.answerEvidence.answerMatch === false ? 'Ошибка и эталон' : row.answerEvidence.kind !== 'self' && row.answerEvidence.answerMatch === null ? 'Ответ без автоматической проверки' : 'Сохранённый ответ'),answerEvidenceComparison(row.answerEvidence)); if (row.answerEvidence.criteria && row.answerEvidence.criteria.length) recall.append(recallCriteria(row.answerEvidence.criteria,row.answerEvidence.checkedCriteria || [],null)); item.append(recall); }
    else if (row.recall) { const recall = el('details','ar-recall-history'); recall.append(el('summary','','Ответ и эталон'),recallComparison(row.recall.answer,row.recall.reference,row.recall.criteria)); if (row.recall.criteria && row.recall.criteria.length) recall.append(recallCriteria(row.recall.criteria,row.recall.checkedCriteria || [],null)); item.append(recall); }
    if (row.canChangeGrade && Array.isArray(row.allowedRatings) && row.allowedRatings.length) footer.append(button('Изменить',() => { const existing = item.querySelector('.ar-grades'); if (existing) existing.remove(); else item.append(gradeButtons(row.allowedRatings,rating => act('change-grade',{attemptId:row.attemptId,rating}))); },'ar-ghost')); item.append(footer); list.append(item); });
    if (historySize < current.history.length) list.append(button('Показать ещё',() => { historySize += 20; fill(); },'ar-ghost')); updateDisabled(); }
  details.addEventListener('toggle',() => { if (details.open && !list.childNodes.length) fill(); }); return details;
}
function landing(title, text) { const section = el('section','ar-landing'); section.append(el('h1','',title)); if (text) section.append(el('p','',text)); return section; }
function cardCountLabel(count) { const last = count % 10, lastTwo = count % 100; return count + ' ' + (last === 1 && lastTwo !== 11 ? 'карточка' : last >= 2 && last <= 4 && (lastTwo < 12 || lastTwo > 14) ? 'карточки' : 'карточек'); }
function materialCountLabel(count) { const last = count % 10, lastTwo = count % 100; return count + ' ' + (last === 1 && lastTwo !== 11 ? 'материал' : last >= 2 && last <= 4 && (lastTwo < 12 || lastTwo > 14) ? 'материала' : 'материалов'); }
function durationText(seconds) { const value = Math.max(0,Math.floor(seconds)); return Math.floor(value / 60) + ':' + String(value % 60).padStart(2,'0'); }
function summaryView() { const value = current.summary; if (!value || current.status !== 'finished') return null; const section = el('section','ar-summary'), stats = el('dl','ar-summary-stats'); section.append(el('h2','','Итоги занятия')); const add = (label,text) => { const row = el('div'); row.append(el('dt','',label),el('dd','',String(text))); stats.append(row); }; add('Время',durationText(value.elapsedSeconds)); add('Карточки',value.completed + ' из ' + value.total); add('Ответы',value.answers); add('Пропущено',value.skipped); if (value.unavailable) add('Стали недоступны',value.unavailable); section.append(stats);
  const reason = value.reason === 'inactive' ? 'Занятие завершено после 30 минут без учебных действий. Сохранённые оценки остались в истории.' : value.reason === 'expired' ? 'Занятие завершено: учебные данные изменились или устарели. Выберите материалы заново; если их нет — синхронизируйте Telegram в Obsidian.' : value.reason === 'time-limit' ? 'Время занятия истекло. Сохранённые ответы остались в истории.' : value.reason === 'manual' ? 'Занятие завершено вручную.' : ''; if (reason) section.append(el('p','ar-empty ar-session-end',reason));
  if (value.grades) section.append(el('p','ar-empty','Ваши оценки: ещё раз — ' + value.grades.again + ', трудно — ' + value.grades.hard + ', хорошо — ' + value.grades.good + ', легко — ' + value.grades.easy + '.'));
  if (value.correctness) section.append(el('p','ar-empty','Проверка ответов: верно — ' + value.correctness.correct + ', с ошибками — ' + value.correctness.incorrect + ', без автоматической проверки — ' + value.correctness.unchecked + '.'));
  if (current.session && modeOf(current.session) === 'bank' && current.weakRetry) { const retry = button('Практиковать трудные вопросы · ' + current.weakRetry.cardCount,() => { const fields = startFields('bank'); if (!fields || !current.weakRetry.available) return; planChoosing = false; planContinued = false; picker = false; studyMode = 'bank'; act('start',Object.assign({retryWeak:true,mode:'bank',shuffle:shuffleCards},fields)); },'ar-ghost'); retry.dataset.unavailable = String(!current.weakRetry.available || !startFields('bank')); section.append(retry); }
  return section;
}
const planCommandLabels = {pending:'Ожидает подключения Obsidian',applied:'Подтверждено Obsidian',conflict:'Задача изменилась. Обновите план и проверьте её.',missing:'Задача больше недоступна.',revoked:'Доступ к задаче отключён.',expired:'Срок действия изменения истёк. Обновите план.'};
function calendarStateText(value) { const labels = {waiting:'Google Calendar: ожидает обновления',synced:'Google Calendar: обновлён',disabled:'Google Calendar: синхронизация отключена','not-routed':'Задача не отправляется в Google Calendar',error:'Google Calendar: обновление не завершено',conflict:'Google Calendar: обнаружены встречные изменения'}; if (!value || !Object.prototype.hasOwnProperty.call(labels,value.state)) return ''; let text = labels[value.state]; if (Number.isSafeInteger(value.checkedAt)) { try { text += ' · проверено ' + new Intl.DateTimeFormat('ru-RU',{...(week || today ? {timeZone:(week || today).timeZone} : {}),day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(value.checkedAt); } catch (_) {} } return text; }
function planCommandFor(id) { return (Array.isArray(current.planCommands) ? current.planCommands : []).filter(row => row.entryId === id).sort((a,b) => b.requestedAt-a.requestedAt)[0]; }
function validPlanAction(value) { return value && typeof value.revision === 'string' && /^[a-f0-9]{64}$/.test(value.revision) && typeof value.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value.date) && typeof value.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value.time) && typeof value.canMoveDate === 'boolean' && (value.durationMinutes === undefined || Number.isSafeInteger(value.durationMinutes) && value.durationMinutes >= 1 && value.durationMinutes <= 1440); }
function planActionPanel(row, expired, afterLesson) {
  const section = el('div','ar-stack'), actions = el('div','ar-plan-actions'), command = planCommandFor(row.id), waiting = command && command.status === 'pending';
  if (command) { const line = el('p','ar-plan-command',planCommandLabels[command.status] || 'Статус изменения пока недоступен'); line.dataset.status = command.status; line.setAttribute('role','status'); section.append(line); }
  const calendar = command ? command.status === 'applied' ? command.calendar : null : row.calendar, calendarText = calendarStateText(calendar);
  if (calendarText) { const line = el('p','ar-plan-command',calendarText); line.dataset.status = calendar.state === 'error' || calendar.state === 'conflict' ? 'conflict' : calendar.state; line.setAttribute('role','status'); section.append(line); }
  if (current.planActions !== true || !validPlanAction(row.action)) return section.childElementCount ? section : null;
  const toggle = button(row.completed ? 'Вернуть в работу' : afterLesson ? 'Отметить задачу выполненной' : 'Выполнено',() => act('plan-action',{id:row.id,revision:row.action.revision,action:row.completed ? 'reopen' : 'complete'}),afterLesson && !row.completed ? 'ar-primary' : 'ar-ghost');
  const move = button('Перенести занятие',() => { const value = planEdits.get(row.id); if (value) value.open = !value.open; else planEdits.set(row.id,{revision:row.action.revision,date:row.action.date,time:row.action.time,duration:String(row.action.durationMinutes || 30),open:true}); render(); },'ar-ghost');
  [toggle,move].forEach(control => { control.dataset.unavailable = String(!!expired || !!waiting); actions.append(control); }); section.append(actions);
  const edit = planEdits.get(row.id); if (!edit || !edit.open) return section;
  const form = el('form','ar-plan-edit'), fields = el('div','ar-plan-edit-fields'), status = el('p','ar-empty'), footer = el('div','ar-plan-actions'); status.setAttribute('role','status');
  const date = el('input'), time = el('input'), duration = el('input'); date.type = 'date'; date.value = edit.date; date.dataset.unavailable = String(!row.action.canMoveDate); time.type = 'time'; time.value = edit.time; duration.type = 'text'; duration.inputMode = 'numeric'; duration.maxLength = 4; duration.value = edit.duration;
  [['Дата',date],['Время',time],['Длительность · мин',duration]].forEach(([text,input]) => { const label = el('label','ar-field'); label.append(el('span','',text),input); fields.append(label); });
  const save = button('Сохранить перенос',() => {},'ar-primary'); save.type = 'submit'; const cancel = button('Отмена',() => { planEdits.delete(row.id); render(); },'ar-ghost'); footer.append(save,cancel);
  const validate = () => { const validDate = /^\d{4}-\d{2}-\d{2}$/.test(edit.date) && Number.isFinite(Date.parse(edit.date + 'T00:00:00Z')) && new Date(edit.date + 'T00:00:00Z').toISOString().slice(0,10) === edit.date, validTime = /^([01]\d|2[0-3]):[0-5]\d$/.test(edit.time), minutes = Number(edit.duration), validDuration = /^\d+$/.test(edit.duration) && Number.isSafeInteger(minutes) && minutes >= 1 && minutes <= 1440, changed = edit.revision !== row.action.revision; status.textContent = changed ? 'Задача изменилась. Проверьте новые данные перед переносом.' : !validDate || !validTime || !validDuration ? 'Укажите дату, время и длительность от 1 до 1440 минут.' : ''; status.hidden = !status.textContent; date.setAttribute('aria-invalid',String(!validDate)); time.setAttribute('aria-invalid',String(!validTime)); duration.setAttribute('aria-invalid',String(!validDuration)); save.dataset.unavailable = String(!!expired || !!waiting || changed || !validDate || !validTime || !validDuration); updateDisabled(); };
  [[date,'date'],[time,'time'],[duration,'duration']].forEach(([input,key]) => input.addEventListener('input',() => { edit[key] = input.value; validate(); }));
  form.addEventListener('submit',event => { event.preventDefault(); validate(); if (!save.disabled) act('plan-action',{id:row.id,revision:row.action.revision,action:'reschedule',date:edit.date,time:edit.time,durationMinutes:Number(edit.duration)}); });
  if (edit.revision !== row.action.revision) footer.append(button('Загрузить актуальное время',() => { planEdits.set(row.id,{revision:row.action.revision,date:row.action.date,time:row.action.time,duration:String(row.action.durationMinutes || 30),open:true}); render(); },'ar-ghost'));
  form.append(fields,status,footer); section.append(form); validate(); return section;
}
function canRepeatStudyTarget(target) { return validStudyTarget(target) && ['active','transition'].includes(target.status) && target.available > 0 && serverTime() < target.expiresAt; }
function studyTargetView() {
  const target = current.studyTarget; if (!target) return null;
  const stale = target.status === 'stale' || serverTime() >= target.expiresAt;
  const status = stale ? 'stale' : target.status, captions = {active:'Подготовка активна',transition:'Возвращаемся к обычным повторениям',completed:'Подготовка завершена',disabled:'Подготовка выключена',stale:'Нужна синхронизация'};
  const details = el('details','ar-study-target'), summary = el('summary'), copy = el('span','ar-study-target-copy'), body = el('div','ar-study-target-body');
  details.open = studyTargetExpanded; details.dataset.studyTargetStatus = status; details.dataset.studyTargetId = target.id;
  const date = new Intl.DateTimeFormat('ru-RU',{timeZone:'UTC',day:'numeric',month:'long',year:'numeric'}).format(Date.parse(target.targetDate + 'T12:00:00Z'));
  const formatTime = at => new Intl.DateTimeFormat('ru-RU',{timeZone:target.timeZone,day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(at);
  copy.append(el('strong','','Подготовка к дате'),el('span','ar-study-target-date',date));
  summary.append(copy,el('span','ar-study-target-status',captions[status]));
  body.append(el('p','ar-study-target-count','К повторению сейчас: ' + cardCountLabel(stale ? 0 : target.available) + '. Всего для подготовки: ' + target.total + '.'));
  if (target.nextDueAt !== undefined && !stale) body.append(el('p','ar-empty','Следующее повторение: ' + formatTime(target.nextDueAt)));
  let description = status === 'stale' ? 'Учебная копия устарела. Откройте Obsidian и синхронизируйте выбранные материалы.'
    : status === 'disabled' ? 'Режим выключен в Obsidian. Обычные повторения доступны в разделе «Занятие».'
    : status === 'completed' ? 'Обычные повторения продолжаются в разделе «Занятие».'
    : target.total === 0 ? 'В Telegram нет карточек выбранной подготовки. Проверьте выбор материалов и синхронизацию в Obsidian.'
    : target.available === 0 ? 'Сейчас повторять нечего.' : '';
  if (description) body.append(el('p','ar-empty',description));
  body.append(el('p','ar-study-target-sync','Синхронизация копии с Obsidian: ' + formatTime(target.syncedAt)));
  const repeat = button('Повторить подготовку',() => {
    if (!details.isConnected || busy || locked || pending || current.studyTarget !== target) return;
    if (!canRepeatStudyTarget(target)) { announce('Обновите данные подготовки перед запуском.'); void loadToday(); return; }
    void openPlan(target.id,true);
  },'ar-primary ar-study-target-repeat');
  repeat.dataset.unavailable = String(!canRepeatStudyTarget(target)); body.append(repeat);
  details.addEventListener('toggle',() => { if (details.isConnected) studyTargetExpanded = details.open; });
  details.append(summary,body); return details;
}
function todayView() {
  const data = planRange === 'week' && week ? week : today, section = landing(planRange === 'week' && week ? 'Ближайшие 7 дней' : 'Сегодня',data ? 'Учебный план · ' + data.timeZone : current.studyTarget ? 'Подготовка и учебные задачи' : 'Учебный план не передан или устарел.');
  const target = studyTargetView(); if (target) section.append(target);
  if (week) { const range = el('nav','ar-views'); range.setAttribute('aria-label','Период учебного плана'); [['today','Сегодня'],['week','7 дней']].forEach(([value,label]) => { const control = button(label,() => { planRange = value; render(); }); control.setAttribute('aria-pressed',String(planRange === value)); range.append(control); }); section.append(range); }
  if (!data) { section.append(el('p','ar-empty',target ? 'Занятия с указанным временем пока не переданы. Их передачу можно включить в Obsidian: «Интеграции → Telegram».' : 'В Obsidian откройте «Интеграции → Telegram», включите «Напоминать в Telegram по учебному плану» и нажмите «Синхронизировать сейчас».'),button('Обновить план',() => loadToday(),'ar-ghost')); return section; }
  const expired = Date.now() >= data.expiresAt; if (expired) section.append(el('p','ar-empty','Данные плана устарели. Обновите список.')); if (!data.rows.length) section.append(el('p','ar-empty',planRange === 'week' ? 'В переданной копии нет ближайших занятий с указанным временем.' : 'На сегодня нет переданных занятий с указанным временем.'));
  const list = el('div','ar-today-list'); let previousDay = ''; data.rows.forEach(row => { const item = el('article','ar-today-item'); let time, day; try { time = new Intl.DateTimeFormat('ru-RU',{timeZone:data.timeZone,hour:'2-digit',minute:'2-digit'}).format(row.startAt); day = new Intl.DateTimeFormat('ru-RU',{timeZone:data.timeZone,weekday:'long',day:'numeric',month:'long'}).format(row.startAt); } catch (_) { time = new Date(row.startAt).toISOString().slice(11,16) + ' UTC'; day = new Date(row.startAt).toISOString().slice(0,10) + ' UTC'; }
    if (planRange === 'week' && day !== previousDay) { const heading = el('h2','',day); heading.className = 'ar-plan-day'; list.append(heading); previousDay = day; }
    const state = row.completed ? 'Выполнено' : row.skipped ? 'Пропущено' : row.available ? 'Доступно' : 'Сейчас недоступно', open = button('Открыть занятие',() => openPlan(row.id),'ar-ghost'); open.dataset.unavailable = String(expired || !row.available);
    item.append(el('p','ar-today-time',time + ' · ' + state),el('h2','',row.title),open); const controls = planActionPanel(row,expired,false); if (controls) item.append(controls); list.append(item);
  }); section.append(list); try { section.append(el('p','ar-empty','Копия плана действует до ' + new Intl.DateTimeFormat('ru-RU',{timeZone:data.timeZone,day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(data.expiresAt) + '.')); } catch (_) {} section.append(button('Обновить план',() => loadToday(),'ar-ghost')); return section;
}
function navigationView() { const section = el('div','ar-navigation'), nav = el('nav','ar-views'); if (vaults.length > 1) { const entries = vaults.map(row => ({value:row.id,label:row.name})), picker = choicePicker('ar-vault','Хранилище',entries,vaultId,id => { picker.update(entries,vaultId); void switchVault(id); }); picker.field.classList.add('ar-vault-picker'); picker.trigger.querySelector('.ar-filter-value').id = 'ar-vault-value'; picker.trigger.setAttribute('aria-describedby','ar-vault-value'); section.append(picker.field); } nav.setAttribute('aria-label','Разделы мини-приложения'); [['study','Занятие'],['today','Сегодня']].forEach(([view,label]) => { const control = button(label,() => { if (view === 'today') loadToday(); else { sectionView = 'study'; render(); } }); control.setAttribute('aria-pressed',String(sectionView === view)); nav.append(control); }); section.append(nav); return section; }
function syncStatusView() {
  const sync = current.sync; if (!sync || !Number.isSafeInteger(sync.generatedAt) || !Number.isSafeInteger(sync.pendingAnswers) || sync.pendingAnswers < 0) return null;
  const commands = Array.isArray(current.planCommands) ? current.planCommands : [], reports = Array.isArray(current.cardReports) ? current.cardReports.filter(row => row.status === 'pending').length : 0, waiting = sync.pendingAnswers + reports + commands.filter(row => row.status === 'pending').length, details = el('details','ar-sync-state');
  let updated; try { updated = new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}).format(sync.generatedAt); } catch (_) { updated = new Date(sync.generatedAt).toISOString(); }
  details.append(el('summary','',waiting ? 'Ожидают Obsidian · ' + waiting : 'Состояние синхронизации'),el('p','ar-empty','Учебная копия обновлена: ' + updated));
  if (waiting) details.append(el('p','ar-empty','Telegram: результаты и изменения сохранены. Ожидают подтверждения Obsidian: ' + waiting + '.'));
  const calendar = new Map(); (week || today || {rows:[]}).rows.forEach(row => { if (row.calendar) calendar.set(row.id,row.calendar); }); commands.slice().sort((a,b) => a.requestedAt-b.requestedAt).forEach(row => { if (row.status === 'applied' && row.calendar) calendar.set(row.entryId,row.calendar); else if (row.status === 'pending') calendar.delete(row.entryId); });
  const delayed = Array.from(calendar.values()).filter(value => value.state === 'waiting').length, failed = Array.from(calendar.values()).filter(value => value.state === 'error' || value.state === 'conflict').length;
  if (delayed) details.append(el('p','ar-empty','Google Calendar: ожидают обновления ' + delayed + ' занятий.'));
  if (failed) details.append(el('p','ar-empty','Google Calendar: требуется проверка ' + failed + ' занятий. Подробности — в учебном плане.'));
  details.append(button('Обновить экран',() => sectionView === 'today' ? loadToday() : loadView(),'ar-ghost')); return details;
}
function closeFilterPicker(restoreFocus) { if (filterPopupClose) filterPopupClose(!!restoreFocus); }
function filterPicker(key, label, values, display) {
  const selected = studyFilters[studyMode][key], available = new Set(values), entries = [{value:'',label:'Все'}];
  if (selected && !available.has(selected)) values = values.concat(selected);
  values.forEach(value => entries.push({value,label:display(value) + (!available.has(value) ? ' · недоступно' : '')}));
  const picker = choicePicker('ar-filter-' + studyMode + '-' + key,label,entries,selected,value => { studyFilters[studyMode][key] = value; render(); const next = root.querySelector('button[name="' + key + '"]'); if (next) next.focus({preventScroll:true}); });
  picker.trigger.name = key; return picker.field;
}
function choicePicker(id, label, entries, selected, onChange) {
  const field = el('div','ar-field ar-filter-field');
  const trigger = button('',() => { if (filterPopupClose && trigger.getAttribute('aria-expanded') === 'true') closeFilterPicker(true); else open(); },'ar-filter-trigger');
  trigger.id = id; trigger.setAttribute('role','combobox'); trigger.setAttribute('aria-labelledby',id + '-label'); trigger.setAttribute('aria-haspopup','listbox'); trigger.setAttribute('aria-expanded','false'); trigger.setAttribute('aria-controls',id + '-list');
  const caption = el('span','',label), copy = el('span','ar-filter-value'), arrow = el('span','ar-filter-chevron'); caption.id = id + '-label'; arrow.setAttribute('aria-hidden','true'); trigger.append(copy,arrow); field.append(caption,trigger); caption.addEventListener('click',() => { if (!trigger.disabled) trigger.click(); });
  const update = (values,value) => { entries = values; selected = value; const chosen = entries.find(entry => entry.value === selected) || entries[0]; copy.textContent = chosen.label; trigger.title = chosen.label; trigger.dataset.placeholder = String(!selected); };
  update(entries,selected);
  function open(index, focusSearch) {
    if (busy || locked || pending || trigger.disabled || !trigger.isConnected) return;
    closeFilterPicker(); const popup = el('div','ar-filter-popup'), list = el('div','ar-filter-options'), search = entries.length > 8 ? el('input','ar-filter-search') : null;
    list.id = id + '-list'; list.setAttribute('role','listbox'); list.setAttribute('aria-label',label);
    if (search) { search.type = 'search'; search.placeholder = 'Найти'; search.setAttribute('aria-label','Найти: ' + label); search.autocomplete = 'off'; popup.append(search); }
    popup.append(list); document.body.append(popup); trigger.setAttribute('aria-expanded','true'); let buttons = [], prefix = '', prefixAt = 0;
    const finish = restore => { if (filterPopupClose !== finish) return; filterPopupClose = null; trigger.setAttribute('aria-expanded','false'); popup.remove(); document.removeEventListener('pointerdown',outside,true); document.removeEventListener('focusin',outside,true); document.removeEventListener('scroll',scrolled,true); window.removeEventListener('resize',resized); if (window.visualViewport) { visualViewport.removeEventListener('resize',resized); visualViewport.removeEventListener('scroll',resized); } if (restore && trigger.isConnected && !trigger.disabled) trigger.focus({preventScroll:true}); };
    const outside = event => { if (!popup.contains(event.target) && !trigger.contains(event.target)) finish(false); };
    const scrolled = event => { if (!popup.contains(event.target)) finish(false); }, resized = () => { if (search && document.activeElement === search) position(); else finish(false); };
    const position = () => { const viewport = window.visualViewport, left = viewport ? viewport.offsetLeft : 0, top = viewport ? viewport.offsetTop : 0, width = viewport ? viewport.width : innerWidth, height = viewport ? viewport.height : innerHeight, rect = trigger.getBoundingClientRect(); const below = Math.max(0,top + height - rect.bottom - 14), above = Math.max(0,rect.top - top - 14), up = above > below; popup.style.width = Math.min(Math.max(rect.width,260),width - 16) + 'px'; popup.style.left = Math.max(left + 8,Math.min(rect.left,left + width - popup.getBoundingClientRect().width - 8)) + 'px'; popup.style.maxHeight = Math.max(0,Math.min(336,height - 16,Math.max(below,above))) + 'px'; popup.style.top = (up ? Math.max(top + 8,rect.top - popup.getBoundingClientRect().height - 6) : rect.bottom + 6) + 'px'; };
    const focus = at => { if (!buttons.length) return; const option = buttons[(at + buttons.length) % buttons.length]; option.focus({preventScroll:true}); const item = option.getBoundingClientRect(), frame = list.getBoundingClientRect(); if (item.top < frame.top) list.scrollTop -= frame.top - item.top; else if (item.bottom > frame.bottom) list.scrollTop += item.bottom - frame.bottom; };
    const fill = () => { list.replaceChildren(); buttons = []; const query = search ? search.value.trim().toLocaleLowerCase() : ''; entries.filter(entry => !query || entry.label.toLocaleLowerCase().includes(query)).forEach(entry => { const option = button('',() => { if (option.disabled || busy || locked || pending || !trigger.isConnected) return; finish(false); update(entries,entry.value); onChange(entry.value); if (trigger.isConnected && !trigger.disabled) trigger.focus({preventScroll:true}); },'ar-filter-option'); option.setAttribute('role','option'); option.setAttribute('aria-selected',String(entry.value === selected)); option.setAttribute('aria-disabled',String(!!entry.disabled)); option.disabled = !!entry.disabled; option.dataset.value = entry.value; option.tabIndex = -1; const check = el('span','ar-filter-check',entry.value === selected ? '✓' : ''); check.setAttribute('aria-hidden','true'); option.append(el('span','ar-filter-option-label',entry.label),check); list.append(option); if (!entry.disabled) buttons.push(option); }); if (!list.childElementCount) list.append(el('p','ar-filter-empty','Ничего не найдено')); position(); };
    const keys = event => { if (event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return; if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); finish(true); return; } if (event.key === 'Tab') { finish(true); return; } const at = buttons.indexOf(document.activeElement), typing = search && event.target === search; let next; if (event.key === 'ArrowDown') next = at < 0 ? 0 : at + 1; else if (event.key === 'ArrowUp') next = at < 0 ? buttons.length - 1 : at - 1; else if (event.key === 'Home' && !typing) next = 0; else if (event.key === 'End' && !typing) next = buttons.length - 1; else if (!typing && event.key.length === 1 && event.key !== ' ') { const now = Date.now(); prefix = now - prefixAt < 700 ? prefix + event.key.toLocaleLowerCase() : event.key.toLocaleLowerCase(); prefixAt = now; next = buttons.findIndex(option => option.textContent.toLocaleLowerCase().startsWith(prefix)); if (next < 0) return; } else return; event.preventDefault(); event.stopPropagation(); focus(next); };
    filterPopupClose = finish; fill(); popup.addEventListener('keydown',keys); if (search) search.addEventListener('input',fill); document.addEventListener('pointerdown',outside,true); document.addEventListener('focusin',outside,true); document.addEventListener('scroll',scrolled,true); window.addEventListener('resize',resized); if (window.visualViewport) { visualViewport.addEventListener('resize',resized); visualViewport.addEventListener('scroll',resized); }
    const selectedIndex = buttons.findIndex(option => option.dataset.value === selected); if (search && focusSearch !== false && index === undefined) search.focus({preventScroll:true}); else focus(index === undefined ? Math.max(0,selectedIndex) : index);
  }
  trigger.addEventListener('keydown',event => { if (event.altKey || event.ctrlKey || event.metaKey || event.isComposing || !['ArrowDown','ArrowUp','Home','End'].includes(event.key)) return; event.preventDefault(); event.stopPropagation(); open(event.key === 'Home' ? 0 : event.key === 'End' ? -1 : undefined,false); });
  return {field,trigger,update};
}
function applyPreset(value) {
  studyMode = value.mode; selectedPreset = value.id; presetName = value.name; presetsOpen = true;
  const rows = targetMaterials(), selected = selectedMaterials(), available = new Set(rows.filter(row => row.count > 0).map(row => row.id)); selected.clear(); value.materials.filter(id => available.has(id)).forEach(id => selected.add(id));
  const cards = catalogCards(), allowed = {learningGroup:cards.map(card => card.group),questionKind:cards.map(card => card.kind),section:cards.flatMap(card => card.sections || []),topic:cards.flatMap(card => card.topics || []),tag:cards.flatMap(card => card.tags || []),knowledgeState:cards.map(card => card.knowledgeState)};
  let removed = selected.size !== value.materials.length; Object.keys(studyFilters[studyMode]).forEach(key => { const wanted = value.filters[key], found = allowed[key].find(item => typeof item === 'string' && (key === 'tag' ? item.toLocaleLowerCase() === wanted.toLocaleLowerCase() : item === wanted)); studyFilters[studyMode][key] = wanted && found || ''; if (wanted && !found) removed = true; });
  startSettings[studyMode].cardLimit = value.cardLimit; startSettings[studyMode].timeLimitMinutes = value.timeLimitMinutes ? String(Math.min(90,Number(value.timeLimitMinutes))) : ''; shuffleCards = value.shuffle;
  presetFeedback = removed ? 'Сценарий применён. Недоступные материалы и фильтры исключены; проверьте выбор.' : 'Сценарий применён. Можно начать занятие.'; render(); const name = $('ar-preset-name'); if (name) name.focus({preventScroll:true}); announce(presetFeedback);
}
function presetView() {
  if (!localState.available() || planChoosing) return null;
  const presets = localState.presets(), panel = el('details','ar-start-settings ar-presets'), body = el('div','ar-stack'), nameLabel = el('label','ar-field'), name = el('input'), status = el('p','ar-empty',presetFeedback), actions = el('div','ar-secondary');
  panel.append(el('summary','','Сценарии занятий')); panel.open = presetsOpen; panel.addEventListener('toggle',() => { if (panel.isConnected) presetsOpen = panel.open; }); status.setAttribute('role','status'); status.hidden = !presetFeedback;
  const entries = [{value:'',label:'Новый сценарий'},...presets.map(value => ({value:value.id,label:value.name + ' · ' + modeLabel(value.mode)}))];
  const picker = choicePicker('ar-preset-choice','Сохранённый сценарий',entries,selectedPreset,id => { const value = presets.find(value => value.id === id); if (value) applyPreset(value); else { selectedPreset = ''; presetName = ''; presetFeedback = ''; presetsOpen = true; render(); const input = $('ar-preset-name'); if (input) input.focus({preventScroll:true}); } }); body.append(picker.field);
  name.id = 'ar-preset-name'; name.type = 'text'; name.maxLength = 60; name.autocomplete = 'off'; name.value = presetName; name.placeholder = 'Например, английский на 10 минут'; nameLabel.append(el('span','','Название сценария'),name); body.append(nameLabel);
  async function work(remove) {
    if (busy || locked || pending) return; const fields = startFields(), chosen = targetMaterials().filter(row => selectedMaterials().has(row.id) && row.count > 0).map(row => row.id), title = presetName.trim();
    if (!remove && (!fields || !chosen.length || !title || title.length > 60 || presets.some(value => value.id !== selectedPreset && value.name.toLocaleLowerCase() === title.toLocaleLowerCase()))) return;
    setBusy(true,remove ? 'Удаляем сценарий…' : 'Сохраняем сценарий…');
    const id = selectedPreset || crypto.randomUUID(); let saved = false;
    try { saved = remove ? await localState.deletePreset(id) : await localState.savePreset({id,name:title,mode:studyMode,materials:chosen,filters:Object.assign({},studyFilters[studyMode]),cardLimit:startSettings[studyMode].cardLimit.trim(),timeLimitMinutes:startSettings[studyMode].timeLimitMinutes.trim(),shuffle:shuffleCards});
      if (saved) { selectedPreset = remove ? '' : id; presetName = remove ? '' : title; presetFeedback = remove ? 'Сценарий удалён.' : 'Сценарий сохранён на этом устройстве.'; } else presetFeedback = 'Не удалось сохранить изменение сценария. Проверьте доступ к хранилищу и повторите попытку.';
      presetsOpen = true; render();
    } finally { setBusy(false); const input = $('ar-preset-name'); if (input) input.focus({preventScroll:true}); announce(presetFeedback); }
  }
  const save = button(selectedPreset ? 'Обновить сценарий' : 'Сохранить сценарий',() => { void work(false); },'ar-ghost'), remove = button('Удалить сценарий',() => { void work(true); },'ar-ghost');
  const validate = () => { presetName = name.value; const duplicate = presets.some(value => value.id !== selectedPreset && value.name.toLocaleLowerCase() === presetName.trim().toLocaleLowerCase()), chosen = targetMaterials().some(row => row.count > 0 && selectedMaterials().has(row.id)); save.dataset.unavailable = String(!presetName.trim() || duplicate || !chosen || !startFields()); remove.dataset.unavailable = String(!selectedPreset); name.setAttribute('aria-invalid',String(duplicate)); status.textContent = duplicate ? 'Сценарий с таким названием уже есть.' : presetFeedback; status.hidden = !status.textContent; updateDisabled(); };
  name.addEventListener('input',validate); name.addEventListener('keydown',event => { if (event.key === 'Enter' && !event.isComposing && !event.repeat && !event.ctrlKey && !event.altKey && !event.metaKey && !event.shiftKey) { event.preventDefault(); validate(); if (save.dataset.unavailable !== 'true') void work(false); } }); actions.append(save,remove); body.append(actions,status); panel.append(body); presetRefresh = validate; validate(); return panel;
}
function topicRecallPicker(materials) {
  const section = el('section','ar-stack ar-topic-recall'), toggle = button('Вспомнить тему',() => { topicRecallExpanded = !topicRecallExpanded; show(); },'ar-ghost'), body = el('div','ar-stack');
  let allowed = [], selected = '';
  const options = choicePicker('ar-topic-recall-card','Карточка с планом темы',[{value:'',label:'Выберите план темы'}],topicRecallSelected,value => { topicRecallSelected = value; selected = value; updateStart(); });
  const start = button('Начать вспоминание темы',() => { const card = allowed.find(row => row.id === selected), fields = startFields('bank'); if (!card || !fields || unfinished()) return; act('start',Object.assign({},fields,{materialIds:[card.materialId],mode:'bank',cardLimit:1,shuffle:false,topicRecallCardId:card.id})); },'ar-primary');
  const note = el('p','ar-empty'); note.setAttribute('role','status');
  body.id = 'ar-topic-recall-body'; toggle.setAttribute('aria-controls',body.id); body.append(options.field,note,start); section.append(toggle,body);
  function show() { body.hidden = !topicRecallExpanded; toggle.setAttribute('aria-expanded',String(topicRecallExpanded)); }
  function updateStart() { start.dataset.unavailable = String(!allowed.some(row => row.id === selected) || !startFields('bank') || !!unfinished()); updateDisabled(); }
  function update(ids) {
    allowed = catalogCards('bank').filter(row => ids.includes(row.materialId) && typeof row.recallPrompt === 'string' && matchesStudyFilter(row,studyFilters.bank));
    if (!allowed.some(row => row.id === topicRecallSelected)) topicRecallSelected = '';
    selected = topicRecallSelected;
    options.update([{value:'',label:'Выберите план темы'},...allowed.map(row => ({value:row.id,label:(materials.find(material => material.id === row.materialId)?.title || 'Материал') + ' · ' + row.recallPrompt}))],selected);
    note.textContent = unfinished() ? 'Завершите или продолжите текущее занятие, прежде чем начинать новое.' : !ids.length ? 'Сначала выберите материал.' : !allowed.length ? 'Подготовьте в Obsidian карточку с планом темы: свободный ответ, самопроверка, Банк. Затем синхронизируйте материал.' : 'Выберите подготовленную автором карточку с планом. Откроется только она; остальные вопросы материала в этот подход не входят.';
    options.trigger.dataset.unavailable = String(!allowed.length || !!unfinished()); updateStart();
  }
  show(); return {section,update};
}
function renderMaterials() { presetRefresh = null; const section = landing('Занятие',startConflict ? 'Занятие «' + startConflict + '» не запущено. Выберите материалы ещё раз.' : studyMode === 'bank' ? 'Выберите материалы для практики.' : 'Выберите материалы для повторения.'), modes = el('div','ar-study-modes'), list = el('fieldset','ar-options ar-material-list'), search = el('input'), materials = pickerMaterials(), selected = selectedMaterials(); search.type = 'search'; search.placeholder = 'Найти материал'; search.setAttribute('aria-label','Найти материал');
  modes.setAttribute('role','tablist'); modes.setAttribute('aria-label','Режим занятия'); list.id = 'study-materials'; list.setAttribute('role','tabpanel'); list.setAttribute('aria-labelledby','study-mode-' + studyMode);
  const changeMode = mode => { if (busy || locked || pending || mode === studyMode) return; studyMode = mode; clearError(); render(); const control = root.querySelector('[data-study-mode="' + mode + '"]'); if (control) control.focus({preventScroll:true}); };
  ['core','bank'].forEach(mode => { const count = pickerMaterials(mode).reduce((total,row) => total + row.count,0), tab = button('',() => changeMode(mode)); tab.id = 'study-mode-' + mode; tab.dataset.studyMode = mode; tab.setAttribute('role','tab'); tab.setAttribute('aria-selected',String(mode === studyMode)); tab.setAttribute('aria-controls','study-materials'); tab.tabIndex = mode === studyMode ? 0 : -1; tab.append(el('span','',modeLabel(mode)),el('span','ar-mode-count',String(count))); tab.addEventListener('keydown',event => { if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key) || event.ctrlKey || event.altKey || event.metaKey) return; event.preventDefault(); changeMode(event.key === 'Home' ? 'core' : event.key === 'End' ? 'bank' : mode === 'core' ? 'bank' : 'core'); }); modes.append(tab); }); section.append(modes);
  const start = button(studyMode === 'bank' ? 'Начать практику' : 'Начать повторение',() => { const fields = startFields(); if (fields) { const ids = materials.filter(row => selected.has(row.id) && row.count > 0).map(row => row.id), available = modeMaterials().filter(row => row.count > 0), scope = !planChoosing && ids.length === available.length && available.every(row => selected.has(row.id)) ? {allMaterials:true} : {materialIds:ids}; act('start',Object.assign({mode:studyMode,shuffle:shuffleCards},scope,fields)); } },'ar-primary'), selection = el('div','ar-secondary');
  if (Array.isArray(current.catalog)) { const filters = el('div','ar-study-filters ar-material-filters'), cards = catalogCards(), groups = Array.from(new Set(cards.map(card => card.group).filter(Boolean))).sort(), questionKinds = Array.from(new Set(cards.map(card => card.kind))), sections = Array.from(new Set(cards.flatMap(card => card.sections || []))).sort(), topics = Array.from(new Set(cards.flatMap(card => card.topics || []))).sort(), tags = tagFilterLabels(cards), states = Object.keys(knowledgeStateLabels).filter(state => cards.some(card => card.knowledgeState === state)); const selectedTag = tags.find(tag => tag.toLocaleLowerCase() === studyFilters[studyMode].tag.toLocaleLowerCase()); if (selectedTag) studyFilters[studyMode].tag = selectedTag; const addFilter = (key,label,values,display) => { if (values.length || studyFilters[studyMode][key]) filters.append(filterPicker(key,label,values,display)); }; addFilter('learningGroup','Учебная группа',groups,value => value); addFilter('questionKind','Тип вопроса',questionKinds,value => value === 'free' ? 'Свободный ответ' : kinds[value] || value); addFilter('section','Раздел',sections,value => value); addFilter('topic','Тема',topics,value => value); addFilter('tag','Тег',tags,value => value); addFilter('knowledgeState','Состояние знаний',states,value => knowledgeStateLabels[value] || value); if (filters.childElementCount) section.append(filters); if (states.length || studyFilters[studyMode].knowledgeState) section.append(el('p','ar-empty','Состояние знаний — по последней синхронизации с Obsidian.')); }
  const shuffle = el('label','ar-shuffle'), shuffleInput = el('input'); shuffleInput.type = 'checkbox'; shuffleInput.checked = shuffleCards; shuffle.append(shuffleInput,el('span','','Перемешать карточки')); shuffleInput.addEventListener('change',() => { shuffleCards = shuffleInput.checked; });
  const settings = el('details','ar-start-settings'), limits = el('div','ar-study-filters'), settingsError = el('p','ar-empty','Укажите от 1 до 1000 карточек и от 1 до 90 минут или оставьте поле пустым.'); settings.append(el('summary','','Настройки занятия'),limits,settingsError); settingsError.setAttribute('role','status'); [['cardLimit','Карточек',1000],['timeLimitMinutes','Минут',90]].forEach(([key,label,max]) => { const field = el('label','ar-field'), input = el('input'); input.type = 'text'; input.inputMode = 'numeric'; input.autocomplete = 'off'; input.maxLength = 4; input.placeholder = key === 'timeLimitMinutes' ? 'До 90 минут' : 'Без лимита'; input.value = startSettings[studyMode][key]; input.setAttribute('aria-label',label); input.addEventListener('input',() => { startSettings[studyMode][key] = input.value; const raw = input.value.trim(), value = Number(raw); input.setAttribute('aria-invalid',String(!!raw && (!/^\d+$/.test(raw) || !Number.isSafeInteger(value) || value < 1 || value > max))); updateSelection(); }); field.append(el('span','',label),input); limits.append(field); });
  const settingsMode = studyMode; settings.open = settingsOpen[settingsMode]; settings.addEventListener('toggle',() => { if (settings.isConnected) settingsOpen[settingsMode] = settings.open; });
  const topicRecall = studyMode === 'bank' && current.topicRecallSupported === true ? topicRecallPicker(materials) : null;
  const visible = () => materials.filter(row => row.title.toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase()));
  const all = button('Выбрать все материалы',() => { visible().filter(row => row.count > 0).forEach(row => selected.add(row.id)); fill(); },'ar-ghost'), none = button('Снять весь выбор',() => { selected.clear(); fill(); },'ar-ghost'); selection.append(all,none); if (Object.values(studyFilters[studyMode]).some(Boolean)) selection.append(button('Сбросить фильтры',() => { Object.keys(studyFilters[studyMode]).forEach(key => { studyFilters[studyMode][key] = ''; }); render(); const next = root.querySelector('[role="combobox"]') || root; next.focus({preventScroll:true}); },'ar-ghost'));
  function updateSelection() { const chosen = materials.filter(row => selected.has(row.id) && row.count > 0), fields = startFields(), count = Math.min(chosen.reduce((total,row) => total + row.count,0),fields && fields.cardLimit || Infinity); start.textContent = chosen.length ? 'Начать · ' + materialCountLabel(chosen.length) + ' · ' + cardCountLabel(count) : studyMode === 'bank' ? 'Начать практику' : 'Начать повторение'; const validSettings = !!fields; start.dataset.unavailable = String(!chosen.length || !validSettings || !!unfinished()); settingsError.hidden = validSettings; none.dataset.unavailable = String(!chosen.length); if (topicRecall) topicRecall.update(chosen.map(row => row.id)); if (presetRefresh) presetRefresh(); updateDisabled(); }
  let materialPage = 0; const materialPageSize = 100, pager = el('div','ar-secondary'), pageStatus = el('span','ar-count'); pager.setAttribute('aria-label','Страницы материалов'); pageStatus.setAttribute('aria-live','polite');
  const previousPage = button('Предыдущие материалы',() => { materialPage--; fill(); (previousPage.disabled ? nextPage : previousPage).focus({preventScroll:true}); },'ar-ghost'), nextPage = button('Следующие материалы',() => { materialPage++; fill(); (nextPage.disabled ? previousPage : nextPage).focus({preventScroll:true}); },'ar-ghost'); pager.append(previousPage,pageStatus,nextPage);
  function fill() { const query = search.value.trim(), found = visible(), pages = Math.ceil(found.length / materialPageSize); materialPage = Math.max(0,Math.min(materialPage,pages - 1)); all.textContent = query ? 'Выбрать найденные' : 'Выбрать все материалы'; all.dataset.unavailable = String(!found.some(row => row.count > 0 && !selected.has(row.id))); list.replaceChildren(el('legend','ar-sr',studyMode === 'bank' ? 'Материалы для практики' : 'Материалы для повторения')); found.slice(materialPage * materialPageSize,(materialPage + 1) * materialPageSize).forEach(row => { const node = el('label','ar-option ar-material-choice'), input = el('input'); input.type = 'checkbox'; input.checked = selected.has(row.id); input.dataset.unavailable = String(row.count <= 0); node.append(input,el('span','ar-option-text',row.title),el('span','ar-count',String(row.count))); input.addEventListener('change',() => { if (input.checked) selected.add(row.id); else selected.delete(row.id); all.dataset.unavailable = String(!found.some(item => item.count > 0 && !selected.has(item.id))); updateSelection(); }); list.append(node); }); if (!found.length) list.append(el('p','ar-empty',materials.length ? 'Материалы не найдены.' : planChoosing && planId ? 'Для этого занятия в выбранном режиме сейчас нет карточек.' : studyMode === 'bank' ? 'В выбранных материалах нет доступных вопросов Банка.' : 'В выбранных материалах сейчас нет карточек Core к повторению.')); pager.hidden = pages <= 1; previousPage.dataset.unavailable = String(materialPage === 0); nextPage.dataset.unavailable = String(materialPage + 1 >= pages); pageStatus.textContent = found.length ? String(materialPage * materialPageSize + 1) + '–' + Math.min(found.length,(materialPage + 1) * materialPageSize) + ' из ' + found.length : ''; updateSelection(); }
  search.addEventListener('input',() => { materialPage = 0; fill(); }); if (materials.length > 6) section.append(search); section.append(selection,list,pager,settings,shuffle,start); if (topicRecall) section.append(topicRecall.section); fill(); const savedScenarios = presetView(); if (savedScenarios) section.append(savedScenarios);
  const shortcut = el('div','ar-stack'), shortcutNotice = el('p','ar-empty'); shortcutNotice.setAttribute('role','status'); shortcut.append(button('Добавить ярлык',() => { homeScreenMessage = ''; updateHomeScreenAction(); try { tg.addToHomeScreen(); } catch (_) { homeScreenMessage = 'Не удалось добавить ярлык. Можно продолжить занятие.'; updateHomeScreenAction(); } },'ar-ghost'),shortcutNotice); homeScreenDom = {section:shortcut,notice:shortcutNotice}; updateHomeScreenAction(); section.append(shortcut);
  if (unfinished()) { const previous = el('div','ar-stack'); previous.append(el('p','ar-empty','Есть прежнее незавершённое занятие: пройдено ' + current.session.completed + ' из ' + current.session.total + '.'),button('Продолжить прежнее занятие',() => { startConflict = ''; picker = false; planChoosing = false; planContinued = !!planId; studyMode = modeOf(current.session); clearError(); render(); },'ar-ghost'),button('Завершить прежнее занятие',() => act('finish'),'ar-ghost')); section.append(previous); }
  return section;
}
function render(collapseHistory) {
  cancelOrderInteraction(); closeFilterPicker();
  clearTimeout(waitingTimer); clearTimeout(lessonTimer); waitingDom = null; sessionTimerDom = null; if (!current) return; if (current.status === 'paused') suspendMedia(); const focused = root.contains(document.activeElement) ? document.activeElement : null, oldHistory = root.querySelector('.ar-history'); if (oldHistory) historyOpen = oldHistory.open; const wasOpen = historyOpen;
  if (sectionView === 'today') { mediaNodes.forEach(node => node.pause()); root.replaceChildren(navigationView(),todayView()); const sync = syncStatusView(); if (sync) root.append(sync); updateDisabled(); return; }
  if ((current.status === 'question' || current.status === 'result') && current.card && !picker) { if (!cardDom) createCard(); root.replaceChildren(cardDom.section); updateCard(); }
  else { let section; if (current.status === 'materials' || picker) section = renderMaterials();
    else if (current.status === 'paused') { section = landing('Занятие на паузе','Учебное время заморожено. Автоматические запросы остановлены.'); section.classList.add('ar-paused'); if (connectionExpiresAt) section.append(el('p','ar-empty','Подключение доступно до '+new Date(connectionExpiresAt).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})+'. После этого откройте занятие заново.')); section.append(button('Продолжить занятие',() => act('resume'),'ar-primary'),button('Завершить занятие',() => act('finish'),'ar-ghost')); }
    else if (current.status === 'waiting') { section = landing('Короткая пауза'); const description = el('p'), timer = el('div','ar-waiting-countdown'), proceed = button('Продолжить',() => act('next',waitingRemaining() > 0 && current.session && current.session.canContinueEarly ? {early:true} : {}),'ar-primary'), compatibility = el('p','ar-empty','Для досрочного продолжения обновите плагин и синхронизируйте Telegram.'); timer.setAttribute('role','timer'); timer.setAttribute('aria-live','off'); timer.setAttribute('aria-label','До следующего повтора'); section.append(description,timer,proceed,compatibility); waitingDom = {description,timer,continue:proceed,compatibility}; }
    else if (current.status === 'finished') { const session = current.session; section = landing(session && session.mode === 'bank' ? 'Практика завершена' : 'Занятие завершено',session ? 'Пройдено карточек: ' + session.completed + ' из ' + session.total + '. Ответов: ' + session.answers + '.' : 'Все ответы сохранены в истории.'); section.append(button('Выбрать материалы',() => { picker = true; render(); },'ar-primary')); }
    else if (current.status === 'chat-active') { section = landing('Прежнее занятие в чате',current.chatSessionId ? 'Завершите его, чтобы выбрать материалы в приложении. Выставленные оценки сохранятся.' : 'Откройте приложение заново кнопкой бота.'); if (current.chatSessionId) section.append(button('Завершить и выбрать материалы',() => act('finish-chat',{chatSessionId:current.chatSessionId}),'ar-primary')); section.append(button('Проверить снова',() => loadView(),'ar-ghost')); }
    else { section = landing('Материалы недоступны','Откройте Obsidian и проверьте подключение Telegram и выбранные материалы, затем синхронизируйте их.'); section.append(button('Обновить экран',() => loadView(),'ar-primary')); if (current.materials.some(row => row.count > 0)) section.append(button('Выбрать доступный материал',() => { picker = true; render(); },'ar-ghost')); }
    root.replaceChildren(section); }
  if (launch) { const context = el('aside','ar-plan-context'); context.append(el('p','','По учебному плану: ' + launch.title)); if (!launch.available) context.append(el('p','ar-empty','Занятие по этому напоминанию сейчас недоступно. Обновите экран или проверьте план в Obsidian.'),button('Обновить экран',() => loadView(),'ar-ghost')); else if (planContinued && unfinished()) context.append(button('Выбрать занятие по плану',() => { planChoosing = true; picker = true; studyMode = launch.mode || (pickerMaterials('core').some(row => row.count > 0) ? 'core' : 'bank'); render(); },'ar-ghost')); root.prepend(context); }
  const summary = summaryView(); if (summary) { if (launch && current.status === 'finished') { const controls = planActionPanel(launch,false,true); if (controls) summary.append(controls); } root.prepend(summary); } const timer = sessionTimerView(); if (timer) root.prepend(timer); root.prepend(navigationView());
  const history = picker && current.status !== 'finished' && !planId ? null : historyView(picker && current.status === 'finished'); if (history) { history.open = !collapseHistory && !!wasOpen; root.append(history); }
  if (current.session && ['question','result','waiting'].includes(current.status) && !picker && !(current.card && current.card.selectedRating && current.nextStep && current.nextStep.kind === 'finished')) { const bottom = el('div','ar-bottom'); bottom.append(button('Пропустить сейчас',() => act('skip'),'ar-ghost'),button('Пауза',() => act('pause'),'ar-ghost'),button('Завершить занятие',() => act('finish'),'ar-ghost')); if (!current.card || current.card.selectedRating) bottom.firstChild.hidden = true; root.append(bottom); }
  const sync = syncStatusView(); if (sync) root.append(sync);
  if (current.status !== 'paused') resumeMedia(); updateWaitingCountdown(); updateSessionTimer(); updateDisabled(); if (focused && focused.isConnected && !focused.disabled && !focused.closest('[hidden]')) focused.focus({preventScroll:true});
}
function releaseMedia(keepCached) { mediaEpoch++; mediaQueue.splice(0); mediaDeferred.clear(); mediaSuspended = false; mediaControllers.forEach(controller => controller.abort()); mediaControllers.clear(); mediaNodes.forEach(node => { node.pause(); node.removeAttribute('src'); node.load(); }); mediaNodes.clear(); objectUrls.forEach(url => URL.revokeObjectURL(url)); objectUrls.clear(); mediaEntries.clear(); if (!keepCached) mediaCache.clear(); }
function suspendMedia() { mediaSuspended = true; mediaNodes.forEach(node => node.pause()); mediaControllers.forEach(controller => controller.abort('pause')); }
function resumeMedia() { if (!mediaSuspended) return; mediaSuspended = false; const deferred = [...mediaDeferred]; mediaDeferred.clear(); deferred.forEach(load => load()); pumpMedia(); }
function pumpMedia() { while (!mediaSuspended && mediaActive < 2 && mediaQueue.length) { const work = mediaQueue.shift(); mediaActive++; work().finally(() => { mediaActive--; pumpMedia(); }); } }
function renderMedia(container, assets, shown) { const keys = JSON.stringify([assets,shown || []]); if (container.dataset.assets === keys) return; container.dataset.assets = keys; container.replaceChildren();
  assets.forEach(asset => {
    const shared = (shown || []).find(previous => previous.id === asset.id);
    if (shared) {
      // A content hash identifies the same file; keep its question player and answer-only text.
      if (asset.caption && asset.caption !== shared.caption) container.append(el('p','ar-empty ar-literal',asset.caption));
      if (asset.alt && asset.alt !== shared.alt && asset.alt !== asset.caption) container.append(el('p','ar-sr',asset.alt));
      return;
    }
    const figure = el('figure','ar-attachment'), status = el('div','ar-media-status'), label = asset.kind === 'image' ? 'Изображение' : asset.kind === 'audio' ? 'Аудио' : 'Видео'; status.append(el('span','',label)); figure.append(status); if (asset.caption) figure.append(el('figcaption','',asset.caption)); container.append(figure);
    let running = false; const epoch = mediaEpoch;
    const load = () => { if (epoch !== mediaEpoch) return; if (mediaSuspended) { mediaDeferred.add(load); return; } if (running) return; running = true; status.replaceChildren(el('span','','Загружаем ' + label.toLocaleLowerCase() + '…'));
      mediaQueue.push(async () => { if (epoch !== mediaEpoch) return; const controller = new AbortController(); mediaControllers.add(controller); const timer = setTimeout(() => controller.abort(),60000);
        try { let url = mediaEntries.get(asset.id); if (!url) { const blob = await mediaCache.load(asset,bearer,controller.signal); if (epoch !== mediaEpoch) return; url = URL.createObjectURL(blob); objectUrls.add(url); mediaEntries.set(asset.id,url); }
          if (epoch !== mediaEpoch) return; if (mediaSuspended) { running = false; mediaDeferred.add(load); return; } const node = el(asset.kind === 'image' ? 'img' : asset.kind); if (asset.kind === 'image') node.alt = asset.alt || asset.caption || 'Вложение карточки'; else { node.controls = true; node.preload = 'metadata'; mediaNodes.add(node); }
          node.addEventListener('error',() => { if (epoch !== mediaEpoch || node.parentNode !== figure) return; running = false; status.replaceChildren(el('span','','Не удалось открыть вложение.'),button('Повторить',load,'ar-ghost')); figure.replaceChild(status,node); if (asset.kind !== 'image') { node.pause(); node.removeAttribute('src'); node.load(); mediaNodes.delete(node); } if (mediaEntries.get(asset.id) === url) mediaEntries.delete(asset.id); mediaCache.forget(asset.id); objectUrls.delete(url); URL.revokeObjectURL(url); updateDisabled(); },{once:true});
          node.src = url; figure.replaceChild(node,status);
        } catch (problem) { if (epoch !== mediaEpoch) return; running = false; if (controller.signal.aborted && controller.signal.reason === 'pause') { status.replaceChildren(el('span','','Загрузка на паузе.')); mediaDeferred.add(load); if (!mediaSuspended) { mediaDeferred.delete(load); load(); } return; } status.replaceChildren(el('span','','Не удалось загрузить вложение.'),button('Повторить',load,'ar-ghost')); if (problem.status === 401 || problem.status === 403) { locked = true; handleFailure(problem); updateDisabled(); } }
        finally { clearTimeout(timer); mediaControllers.delete(controller); }
      }); pumpMedia(); };
    if (asset.kind !== 'image' && asset.bytes > 5000000) status.append(button('Загрузить',load,'ar-ghost')); else load();
  });
}
$('close').addEventListener('click',close); $('error-close').addEventListener('click',close); $('retry').addEventListener('click',() => { if (retryWork && !busy) retryWork(); });
document.addEventListener('keydown',gradeOnNumber);
document.addEventListener('visibilitychange',() => { if (document.visibilityState === 'hidden') markSuspended(); else scheduleResume(); });
window.addEventListener('blur',markSuspended);
window.addEventListener('focus',() => scheduleResume());
window.addEventListener('online',() => { if (pending && pending.kind === 'resume' && !busy && !locked) void sendPending(); });
window.addEventListener('pagehide',event => { clearTimeout(resumeTimer); clearTimeout(lifetimeTimer); clearTimeout(lessonTimer); cancelOrderInteraction(); persistDraft(); closeFilterPicker(); releaseMedia(); cardDom = null; if (!event.persisted) bearer = ''; clearTimeout(waitingTimer); });
window.addEventListener('pageshow',event => { if (event.persisted) { if (bearer && current && !locked) scheduleResume(true); else { bearer = ''; locked = false; authenticate(); } } });
theme(); if (tg) { try { tg.ready(); tg.expand(); tg.onEvent('themeChanged',theme); if (typeof tg.isVersionAtLeast === 'function' && tg.isVersionAtLeast('8.0')) { tg.onEvent('deactivated',markSuspended); tg.onEvent('activated',() => scheduleResume(true)); } } catch (_) {} }
setupFullscreen();
setupHomeScreen();
authenticate();
})();`;

// src/styles/features/companion/miniapp-style.ts
var miniAppCss = String.raw`
.ar-session-timer{padding:10px 14px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel)}.ar-session-timer>div{display:flex;align-items:center;justify-content:space-between;gap:12px;min-inline-size:0}.ar-session-time-label{font-size:14px;color:var(--ar-muted)}.ar-session-remaining{font-size:24px;font-weight:600;line-height:1.25;font-variant-numeric:tabular-nums}.ar-session-timer[data-paused=true]{color:var(--ar-muted)}
.ar-waiting-countdown{font-size:clamp(32px,8vw,44px);font-weight:600;font-variant-numeric:tabular-nums;line-height:1.15;color:var(--ar-accent);letter-spacing:.02em}
.ar-answer-retention{justify-self:start;max-inline-size:100%;padding:4px 0;margin-block:0 4px}.ar-answer-retention input{flex:none;inline-size:20px;block-size:20px;accent-color:var(--ar-accent);margin:0}.ar-answer-retention span{line-height:1.45}.ar-answer-mistakes{display:grid;gap:10px;padding-block:14px}.ar-answer-mistakes h3{font-size:15px}.ar-answer-mistake{border-inline-start:2px solid var(--ar-bad);padding-inline-start:12px;display:grid;gap:5px;font-size:14px}
:root{color-scheme:light;--ar-bg:var(--tg-theme-bg-color,#f8f8fb);--ar-panel:var(--tg-theme-secondary-bg-color,#fff);--ar-ink:var(--tg-theme-text-color,#24232b);--ar-muted:var(--tg-theme-hint-color,#65616f);--ar-line:#dedce5;--ar-accent:#7150bd;--ar-accent-ink:#fff;--ar-selected:#f0eafa;--ar-good:#187246;--ar-bad:#a8313c;--ar-warning:#805710;--ar-radius:12px}
:root[data-theme=dark]{color-scheme:dark;--ar-bg:var(--tg-theme-bg-color,#191b20);--ar-panel:var(--tg-theme-secondary-bg-color,#22252c);--ar-ink:var(--tg-theme-text-color,#ededf4);--ar-muted:var(--tg-theme-hint-color,#afb2c1);--ar-line:#3c404b;--ar-accent:#b7a3fa;--ar-accent-ink:#211a36;--ar-selected:#302c40;--ar-good:#79d2a4;--ar-bad:#f3a0a8;--ar-warning:#e1c17a}
*{box-sizing:border-box}html,body{margin:0;min-block-size:100%;background:var(--ar-bg);color:var(--ar-ink)}body{font:16px/1.45 Inter,"Segoe UI",system-ui,sans-serif;overflow-wrap:anywhere;-webkit-text-size-adjust:100%}[hidden]{display:none!important}button,input,textarea{font:inherit;color:inherit}button,input,textarea{-webkit-tap-highlight-color:transparent}button{border:1px solid var(--ar-line);background:var(--ar-panel);border-radius:var(--ar-radius);min-block-size:48px;padding:11px 14px;display:inline-flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;line-height:1.35;touch-action:manipulation;transition:background-color 120ms ease,border-color 120ms ease,color 120ms ease}button:disabled{opacity:.48;cursor:default}button:focus-visible,input:focus-visible,textarea:focus-visible,summary:focus-visible{outline:2px solid var(--ar-accent);outline-offset:3px}button:not(:disabled):active{filter:brightness(.95)}button.ar-primary{background:var(--ar-accent);color:var(--ar-accent-ink);border-color:var(--ar-accent);font-weight:600;inline-size:100%}button.ar-ghost{border-color:transparent;background:transparent;color:var(--ar-muted);padding-inline:10px}input:not([type=checkbox]):not([type=radio]),textarea{inline-size:100%;min-block-size:48px;padding:12px 14px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel);line-height:1.45}textarea{resize:vertical;min-block-size:100px}input::placeholder,textarea::placeholder{color:var(--ar-muted);opacity:.85}input[type=checkbox],input[type=radio]{appearance:none;-webkit-appearance:none;display:grid;place-content:center;inline-size:22px;block-size:22px;border:1.5px solid var(--ar-muted);border-radius:6px;background:var(--ar-bg);color:var(--ar-accent-ink);margin:0;flex:0 0 22px;cursor:inherit;transition:background-color 120ms ease,border-color 120ms ease}input[type=radio]{border-radius:50%}input[type=checkbox]:checked{background:var(--ar-accent);border-color:var(--ar-accent)}input[type=checkbox]:checked::after{content:"";inline-size:6px;block-size:11px;border-inline-end:2px solid currentColor;border-block-end:2px solid currentColor;transform:translateY(-1px) rotate(45deg)}input[type=checkbox]:indeterminate{background:var(--ar-accent);border-color:var(--ar-accent)}input[type=checkbox]:indeterminate::after{content:"";inline-size:10px;block-size:2px;background:currentColor;border:0;border-radius:1px;transform:none}input[type=radio]:checked{border-color:var(--ar-accent)}input[type=radio]:checked::after{content:"";inline-size:10px;block-size:10px;border-radius:50%;background:var(--ar-accent)}input:disabled{opacity:1}input:not([type=checkbox]):not([type=radio])[aria-invalid=true],textarea[aria-invalid=true]{border-color:var(--ar-bad)}h1,h2,h3,p{margin:0}h1{font-size:21px;line-height:1.35;font-weight:600}h2{font-size:18px;font-weight:600}h3{font-size:15px;font-weight:600}.ar-app{inline-size:100%;max-inline-size:640px;min-block-size:100dvh;margin-inline:auto;padding-block-start:max(env(safe-area-inset-top),var(--tg-content-safe-area-inset-top,0px));padding-inline-start:max(env(safe-area-inset-left),var(--tg-content-safe-area-inset-left,0px));padding-inline-end:max(env(safe-area-inset-right),var(--tg-content-safe-area-inset-right,0px));padding-block-end:max(20px,env(safe-area-inset-bottom),var(--tg-content-safe-area-inset-bottom,0px))}.ar-chrome button{min-block-size:44px}.ar-chrome{display:flex;align-items:center;gap:8px;padding:12px 16px;border-block-end:1px solid var(--ar-line)}.ar-brand{display:flex;align-items:center;gap:9px;flex:1;min-inline-size:0;font-size:17px;font-weight:600}.ar-brand svg{inline-size:21px;block-size:21px;color:var(--ar-accent);flex:none}.ar-activity{inline-size:16px;block-size:16px;flex:none;visibility:hidden;border:2px solid var(--ar-line);border-block-start-color:var(--ar-accent);border-radius:50%}.ar-activity[data-busy=true]{visibility:visible;animation:ar-spin .8s linear infinite}@keyframes ar-spin{to{transform:rotate(360deg)}}.ar-main{padding:22px;display:grid;gap:20px;min-inline-size:0;outline:none}.ar-stack{display:grid;gap:16px;min-inline-size:0}.ar-section{display:grid;gap:20px;min-inline-size:0}.ar-meta{display:flex;align-items:center;justify-content:space-between;gap:12px;color:var(--ar-muted);font-size:13px}.ar-progress{display:block;inline-size:100%;block-size:3px;border:0;border-radius:9px;overflow:hidden;margin-block-start:10px;appearance:none;background:var(--ar-line);color:var(--ar-accent)}.ar-progress::-webkit-progress-bar{background:var(--ar-line)}.ar-progress::-webkit-progress-value{background:var(--ar-accent)}.ar-progress::-moz-progress-bar{background:var(--ar-accent)}.ar-material{color:var(--ar-muted);font-size:13px;margin-block-end:8px}.ar-literal{white-space:pre-wrap;overflow-wrap:anywhere}.ar-options{border:0;padding:0;margin:0;display:grid;gap:10px;min-inline-size:0}.ar-option{display:flex;align-items:center;gap:13px;min-block-size:56px;padding:12px 15px;background:var(--ar-panel);border:1px solid var(--ar-line);border-radius:var(--ar-radius);transition:background-color 100ms ease,border-color 100ms ease;cursor:pointer}.ar-option:has(input:checked){background:var(--ar-selected);border-color:var(--ar-accent)}.ar-option:has(input:focus-visible){outline:2px solid var(--ar-accent);outline-offset:3px}.ar-option input:focus-visible{outline:none}.ar-option:has(input:disabled){cursor:default}.ar-option-text{flex:1;min-inline-size:0;white-space:pre-wrap}.ar-option-status{font-size:12px;flex:none}.ar-option.is-good .ar-option-status{color:var(--ar-good)}.ar-option.is-bad .ar-option-status{color:var(--ar-bad)}.ar-option.is-missed .ar-option-status{color:var(--ar-warning)}.ar-field{display:grid;gap:8px;min-inline-size:0}.ar-field>span{font-size:14px;color:var(--ar-muted)}.ar-cloze-fields{display:grid;gap:12px}.ar-cloze-fields textarea{min-block-size:48px}.ar-actions{display:grid;gap:8px}.ar-secondary{display:flex;justify-content:space-between;flex-wrap:wrap;gap:2px 8px}.ar-hint{padding-inline-start:13px;border-inline-start:2px solid var(--ar-accent);display:grid;gap:8px}.ar-hint h2{font-size:13px;font-weight:500}.ar-hint p{font-size:14px;color:var(--ar-muted);white-space:pre-wrap}.ar-feedback{display:grid;gap:10px}.ar-feedback[data-tone=good]>h2{color:var(--ar-good)}.ar-feedback[data-tone=bad]>h2{color:var(--ar-bad)}.ar-feedback p{color:var(--ar-muted);font-size:15px;white-space:pre-wrap}.ar-blank-result{padding:10px 12px;border:1px solid var(--ar-line);border-radius:10px;white-space:pre-wrap;font-size:14px}.ar-blank-result[data-tone=good]{color:var(--ar-good)}.ar-blank-result[data-tone=bad]{color:var(--ar-bad)}.ar-grading{display:grid;gap:10px}.ar-grading>p{font-size:14px;color:var(--ar-muted)}.ar-grades{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.ar-grades button{font-size:14px;padding-inline:8px}.ar-grades button[data-rating="4"]{color:var(--ar-accent)}.ar-grade-selected{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:14px}.ar-grade-selected p{color:var(--ar-muted)}.ar-grade-selected strong{color:var(--ar-ink);font-weight:500}.ar-sync{display:block;font-size:12px;color:var(--ar-muted);margin-block-start:3px}.ar-error{margin:16px 22px 0;padding:14px;border:1px solid var(--ar-bad);border-radius:var(--ar-radius);display:grid;gap:8px}.ar-error p{font-size:14px;color:var(--ar-muted)}.ar-error-actions{display:flex;gap:8px;flex-wrap:wrap}.ar-landing{display:grid;gap:18px;padding-block:8px}.ar-landing>p{color:var(--ar-muted);font-size:15px}.ar-empty{color:var(--ar-muted);font-size:14px}.ar-material-list{display:grid;gap:10px}.ar-material-choice:has(input:disabled){opacity:.48;cursor:default}.ar-count{font-size:13px;color:var(--ar-muted);flex:none}.ar-media{display:grid;gap:10px}.ar-media:empty{display:none}.ar-attachment{margin:0;display:grid;gap:8px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);overflow:hidden;padding:12px;background:var(--ar-panel)}.ar-attachment img{display:block;inline-size:100%;max-block-size:440px;object-fit:contain;border-radius:6px}.ar-attachment video{display:block;inline-size:100%;max-block-size:400px;border-radius:6px}.ar-attachment audio{inline-size:100%;min-inline-size:0}.ar-attachment figcaption{font-size:13px;color:var(--ar-muted);white-space:pre-wrap}.ar-media-status{display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:14px;color:var(--ar-muted)}.ar-history{border-block-start:1px solid var(--ar-line);padding-block-start:16px}.ar-history summary{font-size:14px;color:var(--ar-muted);cursor:pointer;min-block-size:44px;display:flex;align-items:center;gap:8px}.ar-history summary::before{content:"›";font-size:22px}.ar-history[open] summary::before{transform:rotate(90deg)}.ar-history-list{display:grid;gap:0}.ar-history-item{padding-block:14px;border-block-start:1px solid var(--ar-line);display:grid;gap:8px}.ar-history-item>p{font-size:14px;white-space:pre-wrap}.ar-history-footer{display:flex;justify-content:space-between;align-items:center;gap:12px;font-size:13px;color:var(--ar-muted)}.ar-history-footer button{font-size:13px}.ar-bottom{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;border-block-start:1px solid var(--ar-line);padding-block-start:10px}.ar-bottom button{font-size:13px}.ar-sr{position:absolute;inline-size:1px;block-size:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
.ar-fullscreen{flex:none;inline-size:44px}.ar-fullscreen svg{inline-size:20px;block-size:20px}.ar-window-status{margin:12px 22px 0;color:var(--ar-muted);font-size:14px}.ar-shuffle{display:flex;align-items:center;gap:10px;min-block-size:44px;font-size:14px;color:var(--ar-muted);cursor:pointer}.ar-shuffle:has(input:disabled){opacity:.48;cursor:default}
.ar-matching-row{gap:9px;padding-block:4px}.ar-matching-row>span{color:var(--ar-ink);font-size:16px;white-space:pre-wrap}.ar-order-list:focus-visible,.ar-order-item:focus-visible{outline:2px solid var(--ar-accent);outline-offset:3px}.ar-order-list{position:relative;list-style:none;margin:0;padding:0;display:grid;gap:10px;min-inline-size:0}.ar-order-item,.ar-order-preview{display:grid;grid-template-columns:20px minmax(0,1fr);align-items:center;gap:10px;min-block-size:56px;padding:14px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel);color:var(--ar-ink)}.ar-order-item{touch-action:none;user-select:none;-webkit-user-select:none;cursor:grab;transition:background-color 100ms ease,border-color 100ms ease}.ar-order-item[aria-disabled=true]{cursor:default;touch-action:auto;user-select:text;-webkit-user-select:text}.ar-order-item.is-dragging{position:absolute;opacity:0;pointer-events:none}.ar-order-item.is-keyboard-dragging{border-color:var(--ar-accent);background:var(--ar-selected);outline:2px solid var(--ar-accent);outline-offset:2px}.ar-order-number{font-size:13px;color:var(--ar-muted)}.ar-order-text{min-inline-size:0;white-space:pre-wrap;overflow-wrap:anywhere}.ar-order-placeholder{min-inline-size:0;border:1.5px dashed var(--ar-accent);border-radius:var(--ar-radius);background:var(--ar-selected)}.ar-order-preview{position:fixed;z-index:110;pointer-events:none;box-shadow:0 8px 24px rgb(0 0 0 / .2);border-color:var(--ar-accent);will-change:transform}.ar-order-preview.is-outside{border-color:var(--ar-bad);opacity:.75}body.ar-order-dragging,body.ar-order-dragging *{cursor:grabbing!important;user-select:none!important;-webkit-user-select:none!important}

.ar-grade-key{display:inline-flex;align-items:center;justify-content:center;min-inline-size:20px;block-size:20px;border:1px solid var(--ar-line);border-radius:4px;font-family:inherit;font-size:12px;line-height:1;color:var(--ar-muted);flex:none}
.ar-plan-context{display:grid;gap:8px;border-inline-start:2px solid var(--ar-accent);padding-inline-start:12px;font-size:14px;color:var(--ar-muted);min-inline-size:0}.ar-plan-context button{justify-self:start}
.ar-views{display:flex;gap:8px}.ar-views button{flex:1;min-inline-size:0;font-size:14px}.ar-views button[aria-pressed=true]{border-color:var(--ar-accent);background:var(--ar-selected);color:var(--ar-accent)}.ar-study-filters{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;min-inline-size:0}.ar-start-settings>summary,.ar-source-context>summary{display:flex;align-items:center;gap:10px;list-style:none;cursor:pointer;min-block-size:44px;padding-block:11px;font-size:14px;color:var(--ar-muted)}.ar-start-settings>summary::-webkit-details-marker,.ar-source-context>summary::-webkit-details-marker{display:none}.ar-start-settings>summary::before,.ar-source-context>summary::before{content:"";flex:none;inline-size:7px;block-size:7px;border-inline-end:1.5px solid currentColor;border-block-end:1.5px solid currentColor;transform:rotate(-45deg);margin-inline:2px 3px}.ar-start-settings[open]>summary::before,.ar-source-context[open]>summary::before{transform:translateY(-2px) rotate(45deg)}.ar-start-settings[open]{display:grid;gap:8px}.ar-source-context{border-inline-start:2px solid var(--ar-line);padding-inline-start:12px}.ar-source-context p{font-size:14px;margin-block-end:8px}.ar-summary{display:grid;gap:12px;min-inline-size:0}.ar-summary-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:0}.ar-summary-stats dt{font-size:13px;color:var(--ar-muted)}.ar-summary-stats dd{margin:0;font-size:18px}.ar-today-list{display:grid;gap:16px}.ar-today-item{display:grid;gap:6px;padding-block-end:14px;border-block-end:1px solid var(--ar-line);min-inline-size:0}.ar-today-item h2{font-size:16px}.ar-today-item button{justify-self:start}.ar-today-time{font-size:13px;color:var(--ar-muted)}

.ar-plan-actions{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.ar-plan-actions button{font-size:14px}.ar-plan-edit{display:grid;gap:12px;padding:14px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel);min-inline-size:0}.ar-plan-edit-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;min-inline-size:0}.ar-plan-edit-fields input{min-inline-size:0}.ar-plan-edit-fields .ar-field:last-child{grid-column:1/-1}.ar-plan-command{font-size:13px;color:var(--ar-muted);white-space:pre-wrap}.ar-plan-command[data-status=conflict],.ar-plan-command[data-status=missing],.ar-plan-command[data-status=expired],.ar-plan-command[data-status=revoked]{color:var(--ar-warning)}.ar-sync-state{border-block-start:1px solid var(--ar-line);padding-block-start:8px;display:block;min-inline-size:0}.ar-sync-state summary{cursor:pointer;min-block-size:44px;display:flex;align-items:center;gap:8px;color:var(--ar-muted);font-size:13px;list-style:none}.ar-sync-state summary::-webkit-details-marker{display:none}.ar-sync-state summary::before{content:"›";font-size:20px}.ar-sync-state[open] summary::before{transform:rotate(90deg)}.ar-sync-state[open]>p{margin-block-end:8px}

.ar-material-filters>.ar-filter-field:last-child:nth-child(odd){grid-column:1/-1}.ar-filter-trigger{inline-size:100%;min-inline-size:0;min-block-size:48px;justify-content:space-between;padding:11px 13px;text-align:start}.ar-filter-value{min-inline-size:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ar-filter-chevron{flex:none;inline-size:8px;block-size:8px;border-inline-end:1.5px solid currentColor;border-block-end:1.5px solid currentColor;transform:translateY(-2px) rotate(45deg);margin-inline:5px 3px;opacity:.8}.ar-filter-trigger[aria-expanded=true]{border-color:var(--ar-accent);background:var(--ar-selected)}.ar-filter-trigger[data-placeholder=true] .ar-filter-value{color:var(--ar-muted)}.ar-filter-trigger[aria-expanded=true] .ar-filter-chevron{transform:translateY(2px) rotate(225deg)}.ar-filter-popup{position:fixed;z-index:100;display:grid;grid-template-rows:auto minmax(0,1fr);max-inline-size:calc(100vw - 16px);min-inline-size:0;padding:6px;background:var(--ar-panel);color:var(--ar-ink);border:1px solid var(--ar-line);border-radius:14px;box-shadow:0 10px 30px rgb(0 0 0 / .18);overflow:hidden}.ar-filter-options{overflow:auto;overscroll-behavior:contain;min-block-size:0;min-inline-size:0;scroll-padding-block:4px;scrollbar-width:thin;scrollbar-color:var(--ar-muted) transparent}.ar-filter-popup:has(>.ar-filter-options:first-child){grid-template-rows:minmax(0,1fr)}.ar-filter-popup input.ar-filter-search{min-block-size:48px;padding:10px 12px;border-radius:8px;margin-block-end:6px}.ar-filter-option{display:flex;inline-size:100%;min-inline-size:0;min-block-size:44px;gap:12px;padding:10px 12px;border:0;border-radius:8px;background:transparent;text-align:start;justify-content:space-between}.ar-filter-option-label{flex:1;min-inline-size:0;white-space:normal;overflow-wrap:anywhere}.ar-filter-option[aria-selected=true]{background:var(--ar-selected);color:var(--ar-accent)}.ar-filter-option:focus-visible{outline-offset:-2px}.ar-filter-check{flex:0 0 18px;inline-size:18px;text-align:center;color:var(--ar-accent);font-size:17px}.ar-filter-empty{padding:12px;color:var(--ar-muted);font-size:14px}
.ar-study-modes{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;padding:4px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel)}.ar-study-modes button{min-inline-size:0;padding:10px 8px;border-color:transparent;background:transparent;font-size:14px;gap:6px}.ar-study-modes button[aria-selected=true]{border-color:var(--ar-accent);background:var(--ar-selected);color:var(--ar-accent)}.ar-mode-count{font-size:12px;flex:none;color:var(--ar-muted)}.ar-session-mode{font-size:12px;color:var(--ar-muted);margin-block-end:8px}
.ar-recall-comparison{display:grid;gap:12px;min-inline-size:0}.ar-recall-column{display:grid;align-content:start;gap:10px;min-inline-size:0;padding:14px 16px;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel)}.ar-recall-column h3{font-size:14px;color:var(--ar-muted);font-weight:500}.ar-recall-column p{color:var(--ar-ink);font-size:15px;white-space:pre-wrap}.ar-recall-criteria{border:0;padding:0;margin:8px 0 0;display:grid;gap:8px;min-inline-size:0}.ar-recall-criteria legend{font-size:14px;color:var(--ar-muted);padding:0;margin-block-end:10px}.ar-recall-criteria .ar-option{font-size:14px;min-block-size:48px;padding:10px 12px;gap:10px}.ar-recall-history>.ar-recall-comparison{margin-block:10px}.ar-history .ar-recall-history>summary::before{transform:none}.ar-history .ar-recall-history[open]>summary::before{transform:rotate(90deg)}
@media(min-width:600px){.ar-recall-comparison{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(hover:hover){button:hover:not(:disabled):not(.ar-ghost):not(.ar-primary){border-color:var(--ar-accent)}button.ar-primary:hover:not(:disabled){filter:brightness(.96)}input:not([type=checkbox]):not([type=radio]):hover:not(:disabled):not([aria-invalid=true]),textarea:hover:not(:disabled):not([aria-invalid=true]){border-color:var(--ar-muted)}button.ar-ghost:hover:not(:disabled){background:var(--ar-selected);color:var(--ar-ink)}.ar-option:hover:has(input:enabled),.ar-order-item:hover:not([aria-disabled=true]){border-color:var(--ar-accent)}.ar-filter-option:hover:not(:disabled){background:var(--ar-selected);color:var(--ar-ink)}}
@media(max-width:380px){.ar-main{padding:18px 16px;gap:18px}.ar-error{margin-inline:16px}.ar-option{padding-inline:12px;gap:10px}.ar-option-status{max-inline-size:75px;text-align:end;font-size:11px}.ar-chrome{padding-inline:12px}.ar-brand{font-size:16px}}
@media(max-width:400px){.ar-plan-edit-fields{grid-template-columns:minmax(0,1fr)}}
@media(min-width:480px){.ar-main{padding:26px 28px}.ar-error{margin-inline:28px}}
@media(forced-colors:active){input[type=checkbox],input[type=radio]{appearance:auto;-webkit-appearance:auto;accent-color:auto}input[type=checkbox]::after,input[type=radio]::after{display:none}.ar-filter-popup{border-color:CanvasText}.ar-filter-option[aria-selected=true]{outline:1px solid Highlight;outline-offset:-2px}}
.ar-study-target{min-inline-size:0;border:1px solid var(--ar-line);border-radius:var(--ar-radius);background:var(--ar-panel);overflow-wrap:anywhere}.ar-study-target>summary{display:flex;align-items:center;flex-wrap:wrap;gap:8px 14px;min-block-size:48px;padding:14px;list-style:none;cursor:pointer}.ar-study-target>summary::-webkit-details-marker{display:none}.ar-study-target>summary::before{content:"";flex:none;inline-size:7px;block-size:7px;border-inline-end:1.5px solid currentColor;border-block-end:1.5px solid currentColor;transform:rotate(-45deg);margin-inline:2px 3px}.ar-study-target[open]>summary::before{transform:translateY(-2px) rotate(45deg)}.ar-study-target>summary:focus-visible{outline:2px solid var(--ar-accent);outline-offset:3px;border-radius:var(--ar-radius)}.ar-study-target-copy{display:grid;gap:4px;flex:1 1 160px;min-inline-size:0}.ar-study-target-copy strong{font-size:16px;font-weight:600}.ar-study-target-date,.ar-study-target-status,.ar-study-target-sync{font-size:13px;line-height:1.5;color:var(--ar-muted)}.ar-study-target-status{flex:0 1 auto;max-inline-size:100%}.ar-study-target[data-study-target-status=active] .ar-study-target-status{color:var(--ar-accent)}.ar-study-target[data-study-target-status=stale] .ar-study-target-status{color:var(--ar-warning)}.ar-study-target-body{display:grid;gap:12px;padding:0 14px 14px;min-inline-size:0}.ar-study-target-count{font-size:15px;line-height:1.5}.ar-study-target-repeat{inline-size:100%;min-inline-size:0;white-space:normal;overflow-wrap:anywhere}
.ar-navigation{display:grid;min-inline-size:0;gap:12px}.ar-vault-picker{display:grid;grid-template-columns:auto minmax(0,1fr);align-items:center;gap:10px}.ar-vault-picker>span{font-size:13px;color:var(--ar-muted)}.ar-vault-picker .ar-filter-trigger{inline-size:100%;min-inline-size:0}.ar-vault-picker .ar-filter-value{min-inline-size:0;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
`;

// src/infrastructure/companion/media-binary.ts
var COMPANION_MEDIA_BINARY_CONTENT_TYPE = "application/octet-stream";
var MAX_COMPANION_MEDIA_FRAME_HEADER_BYTES = 16384;
var MAX_COMPANION_MEDIA_FRAME_BYTES = 8 + MAX_COMPANION_MEDIA_FRAME_HEADER_BYTES + MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES;
var magic = 1095912770;
function metadata2(value) {
  record2(value);
  keys(value, ["version", "method", "path", "scope", "epoch", "enrollment", "time", "nonce", "payload"]);
  invalid(value.version === 1 && value.method === "POST" && value.path === "/bridge/snapshot");
  token2(value.scope);
  token2(value.epoch);
  token2(value.enrollment);
  token2(value.nonce);
  timestamp(value.time);
  record2(value.payload);
  keys(value.payload, ["operation", "asset", "offset"]);
  invalid(value.payload.operation === "media-chunk");
  validateCompanionMediaIdentity(value.payload.asset);
  invalid(Number.isSafeInteger(value.payload.offset) && Number(value.payload.offset) >= 0 && Number(value.payload.offset) < value.payload.asset.bytes && Number(value.payload.offset) % COMPANION_MEDIA_CHUNK_BYTES === 0);
}
function decodeCompanionMediaFrame(value) {
  invalid(value.byteLength >= 9 && value.byteLength <= MAX_COMPANION_MEDIA_FRAME_BYTES);
  const frame = Buffer.from(value);
  invalid(frame.readUInt32BE(0) === magic);
  const length = frame.readUInt32BE(4);
  invalid(length > 0 && length <= MAX_COMPANION_MEDIA_FRAME_HEADER_BYTES && frame.byteLength > 8 + length);
  const bytes = frame.subarray(8 + length);
  invalid(bytes.byteLength <= MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES);
  const envelope = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(frame.subarray(8, 8 + length)));
  metadata2(envelope);
  const payload = { ...envelope.payload, data: bytes.toString("base64") };
  validateCompanionMediaChunk(payload, MAX_COMPANION_BINARY_MEDIA_CHUNK_BYTES);
  return JSON.stringify({ ...envelope, payload });
}

// src/infrastructure/companion/server/http-content.ts
var import_node_zlib2 = require("node:zlib");
var MAX_COMPRESS_BYTES = 8 * 1024 * 1024;
function acceptsGzip(header) {
  if (typeof header !== "string") return false;
  const qualities = /* @__PURE__ */ new Map();
  for (const part of header.split(",")) {
    const match = /^\s*([a-z*]+)\s*(?:;\s*q=(0(?:\.\d{0,3})?|1(?:\.0{0,3})?))?\s*$/i.exec(part);
    if (!match) return false;
    const name = match[1].toLowerCase(), value = match[2] === void 0 ? 1 : Number(match[2]);
    qualities.set(name, Math.min(qualities.get(name) ?? 1, value));
  }
  return (qualities.get("gzip") ?? qualities.get("*") ?? 0) > 0;
}
async function sendCompanionText(request, response, text4) {
  response.setHeader("Vary", "Accept-Encoding");
  const raw = Buffer.from(text4);
  if (raw.length >= 1024 && raw.length <= MAX_COMPRESS_BYTES && acceptsGzip(request.headers["accept-encoding"])) {
    const compressed = await new Promise((resolve7, reject) => (0, import_node_zlib2.gzip)(raw, { level: 6 }, (error, value) => error ? reject(error) : resolve7(value)));
    if (compressed.length < raw.length) {
      response.setHeader("Content-Encoding", "gzip");
      response.setHeader("Content-Length", compressed.length);
      response.end(compressed);
      return;
    }
  }
  response.setHeader("Content-Length", raw.length);
  response.end(raw);
}

// src/infrastructure/companion/server/http-shared.ts
function mediaType(asset) {
  const mime = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", avif: "image/avif", bmp: "image/bmp", mp3: "audio/mpeg", m4a: "audio/mp4", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/ogg", flac: "audio/flac", wav: "audio/wav", mp4: "video/mp4", m4v: "video/mp4", webm: asset.kind === "audio" ? "audio/webm" : "video/webm", mov: "video/quicktime", ogv: "video/ogg", mkv: "video/x-matroska" };
  invalid(mime[asset.format], "media unavailable");
  return mime[asset.format];
}
async function readBody(request, limit, allowBinary = false) {
  const binary = request.headers["content-type"] === COMPANION_MEDIA_BINARY_CONTENT_TYPE;
  invalid(binary ? allowBinary && request.rawHeaders.filter((key2, index2) => index2 % 2 === 0 && key2.toLowerCase() === "content-type").length === 1 : request.headers["content-type"] === "application/json");
  invalid(request.headers["content-encoding"] === void 0);
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    const bytes2 = Buffer.from(chunk);
    size += bytes2.length;
    invalid(size <= (binary ? MAX_COMPANION_MEDIA_FRAME_BYTES : limit), "request too large");
    chunks.push(bytes2);
  }
  const bytes = Buffer.concat(chunks);
  return binary ? decodeCompanionMediaFrame(bytes) : new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}
function sharedCompanionHandler(gateway, now = Date.now) {
  return async (request, response) => {
    response.setHeader("Content-Type", "application/json");
    response.setHeader("Cache-Control", "no-store");
    if (request.url === "/bridge/snapshot") response.setTimeout?.(12e4);
    response.setHeader("X-Content-Type-Options", "nosniff");
    response.setHeader("Referrer-Policy", "no-referrer");
    try {
      if (request.url?.startsWith("/miniapp")) {
        invalid(gateway.config.miniAppUrl, "Mini App unavailable");
        const mediaGet = request.method === "GET" && /^\/miniapp\/media\/[a-f0-9]{64}$/.test(request.url);
        if (request.method === "GET" && !mediaGet) {
          const page2 = request.url === "/miniapp/" || request.url.length === "/miniapp/?plan=".length + 64 && /^\/miniapp\/\?plan=[a-f0-9]{64}$/.test(request.url) ? { type: "text/html", body: miniAppHtml } : request.url === "/miniapp/app.js" ? { type: "text/javascript", body: miniAppClientScript } : request.url === "/miniapp/app.css" ? { type: "text/css", body: miniAppCss } : void 0;
          invalid(page2);
          response.setHeader("Content-Type", page2.type + "; charset=utf-8");
          response.setHeader("Content-Security-Policy", "default-src 'none'; script-src 'self' https://telegram.org; style-src 'self'; img-src 'self' blob:; media-src 'self' blob:; connect-src 'self'; base-uri 'none'; object-src 'none'; form-action 'none'; frame-ancestors https://web.telegram.org https://*.telegram.org https://telegram.org https://t.me https://*.t.me");
          response.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
          await sendCompanionText(request, response, page2.body);
          return;
        }
        invalid(mediaGet || request.method === "POST" && ["/miniapp/auth", "/miniapp/study", "/miniapp/media", "/miniapp/vault"].includes(request.url));
        invalid(mediaGet && request.headers.origin === void 0 && request.rawHeaders.every((v, i) => i % 2 !== 0 || v.toLowerCase() !== "origin") || request.headers.origin === new URL(gateway.config.miniAppUrl).origin && request.rawHeaders.filter((v, i) => i % 2 === 0 && v.toLowerCase() === "origin").length === 1);
        invalid(request.headers["sec-fetch-site"] === void 0 || ["same-origin", "none"].includes(String(request.headers["sec-fetch-site"])));
        if (mediaGet) {
          invalid(request.headers["content-encoding"] === void 0 && request.headers["transfer-encoding"] === void 0 && (request.headers["content-length"] === void 0 || request.headers["content-length"] === "0"));
          for await (const chunk of request) invalid(Buffer.from(chunk).length === 0);
        }
        const bodyLimit = request.url === "/miniapp/study" ? 128e3 : request.url === "/miniapp/auth" ? 16384 : 1024;
        const payload = mediaGet ? { id: request.url.slice("/miniapp/media/".length) } : JSON.parse(await readBody(request, bodyLimit));
        if (request.url === "/miniapp/auth") {
          try {
            response.end(JSON.stringify(await gateway.miniAppAuthenticate(payload, now())));
          } catch {
            response.statusCode = 401;
            response.end('{"error":"unauthorized"}');
          }
          return;
        }
        const authorization = request.headers.authorization;
        invalid(typeof authorization === "string" && /^Bearer [a-f0-9]{64}$/.test(authorization) && request.rawHeaders.filter((v, i) => i % 2 === 0 && v.toLowerCase() === "authorization").length === 1, "Mini App unauthorized");
        const sessionToken = authorization.slice(7);
        if (request.url === "/miniapp/study") await sendCompanionText(request, response, JSON.stringify(await gateway.miniAppStudy(sessionToken, payload, now())));
        else if (request.url === "/miniapp/vault") response.end(JSON.stringify(await gateway.miniAppSwitchVault(sessionToken, payload, now())));
        else {
          record2(payload);
          keys(payload, ["id"]);
          invalid(typeof payload.id === "string" && /^[a-f0-9]{64}$/.test(payload.id));
          const loaded = await gateway.miniAppMedia(sessionToken, payload.id, now());
          const type = mediaType(loaded.asset), etag = `"${payload.id}"`;
          response.setHeader("Content-Type", type);
          response.setHeader("ETag", etag);
          if (mediaGet) response.setHeader("Vary", "Authorization");
          if (mediaGet && request.headers["if-none-match"] !== void 0) {
            invalid(typeof request.headers["if-none-match"] === "string" && /^"[a-f0-9]{64}"$/.test(request.headers["if-none-match"]) && request.rawHeaders.filter((v, i) => i % 2 === 0 && v.toLowerCase() === "if-none-match").length === 1);
            if (request.headers["if-none-match"] === etag) {
              response.statusCode = 304;
              response.end();
              return;
            }
          }
          response.setHeader("Content-Length", loaded.bytes.byteLength);
          response.end(loaded.bytes);
        }
        return;
      }
      invalid(request.method === "POST");
      let result;
      if (["/pair/start", "/pair/status", "/pair/confirm"].includes(request.url ?? "")) {
        const payload = JSON.parse(await readBody(request, 16384));
        result = request.url === "/pair/start" ? await gateway.pairStart(payload, now()) : request.url === "/pair/status" ? await gateway.pairStatus(payload, now()) : await gateway.pairConfirm(payload, now());
      } else {
        invalid(["/bridge/snapshot", "/bridge/pending", "/bridge/ack"].includes(request.url ?? ""));
        const signature = request.headers["x-anchor-signature"];
        invalid(typeof signature === "string" && request.rawHeaders.filter((value, index2) => index2 % 2 === 0 && value.toLowerCase() === "x-anchor-signature").length === 1);
        result = await gateway.bridge(
          request.url,
          await readBody(request, request.url === "/bridge/snapshot" ? MAX_COMPANION_BRIDGE_BYTES : 512e3, request.url === "/bridge/snapshot"),
          signature,
          now(),
          request.headers["content-type"] === COMPANION_MEDIA_BINARY_CONTENT_TYPE
        );
      }
      response.statusCode = 200;
      response.end(JSON.stringify(result));
      void gateway.flush().catch(() => void 0);
    } catch (error) {
      const miniApp = request.url?.startsWith("/miniapp"), message = error instanceof Error ? error.message : "";
      response.statusCode = miniApp && message === "Mini App unauthorized" ? 401 : miniApp && message === "stale Mini App view" ? 409 : 400;
      response.end(JSON.stringify({ error: miniApp ? response.statusCode === 401 ? "unauthorized" : response.statusCode === 409 ? "view-changed" : "request-rejected" : "request rejected" }));
    }
  };
}
function createSharedCompanionHttpServer(gateway) {
  const server = (0, import_node_http.createServer)(sharedCompanionHandler(gateway));
  server.requestTimeout = 1e4;
  server.headersTimeout = 1e4;
  server.maxHeadersCount = 30;
  server.timeout = 15e3;
  return server;
}

// src/infrastructure/companion/server/polling.ts
var runningBots = /* @__PURE__ */ new Set();
var TelegramPollingConfigurationError = class extends Error {
};
var TelegramLongPoller = class {
  constructor(token5, gateway, http) {
    this.token = token5;
    this.gateway = gateway;
    this.http = http;
    invalid(/^\d+:[A-Za-z0-9_-]{20,256}$/.test(token5));
  }
  running = false;
  async call(method, payload, signal) {
    if (signal.aborted) throw new Error("Telegram polling stopped");
    const controller = new AbortController();
    let rejectPending = () => {
    };
    const interrupted = new Promise((_, reject) => {
      rejectPending = () => reject(new Error("polling interrupted"));
    });
    const abort = () => {
      controller.abort();
      rejectPending();
    };
    signal.addEventListener("abort", abort, { once: true });
    if (signal.aborted) abort();
    const timer = setTimeout(abort, 35e3);
    try {
      const body = await Promise.race([this.http(`https://api.telegram.org/bot${this.token}/${method}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), signal: controller.signal }).then(async (response) => {
        const value = await response.json();
        record2(value);
        if (value.error_code === 409) throw new TelegramPollingConfigurationError("Another poller or webhook is active; inspect bot configuration");
        invalid(response.ok);
        return value;
      }), interrupted]);
      record2(body);
      invalid(Buffer.byteLength(JSON.stringify(body)) <= 1e6);
      return body;
    } catch (error) {
      if (error instanceof TelegramPollingConfigurationError) throw error;
      throw new Error("Telegram API request unconfirmed");
    } finally {
      clearTimeout(timer);
      signal.removeEventListener("abort", abort);
    }
  }
  async pollOnce(signal) {
    if (signal.aborted) return;
    try {
      const offset = this.gateway.nextUpdateOffset();
      const body = await this.call("getUpdates", { timeout: 20, limit: 100, allowed_updates: ["message", "callback_query", "poll_answer"], ...offset === void 0 ? {} : { offset } }, signal);
      invalid(body.ok === true && Array.isArray(body.result) && body.result.length <= 100 && Buffer.byteLength(JSON.stringify(body)) <= 1e6, "invalid Telegram polling response");
      let previous = -1;
      for (const update of body.result) {
        record2(update);
        timestamp(update.update_id);
        invalid(Number(update.update_id) > previous);
        previous = Number(update.update_id);
      }
      for (const update of body.result) {
        if (signal.aborted) return;
        await this.gateway.telegramUpdate(update, Date.now());
      }
      void this.gateway.flush().catch(() => void 0);
    } catch (error) {
      if (error instanceof TelegramPollingConfigurationError) throw error;
      if (!signal.aborted) throw new Error("Telegram polling unconfirmed; preserve state and retry");
    }
  }
  async run(signal) {
    const botId = this.token.split(":")[0];
    invalid(!this.running && !runningBots.has(botId), "poller already running");
    this.running = true;
    runningBots.add(botId);
    try {
      if (signal.aborted) return;
      const me = await this.call("getMe", {}, signal);
      record2(me.result);
      if (me.ok !== true || String(me.result.id) !== botId || typeof me.result.username !== "string" || me.result.username.toLowerCase() !== this.gateway.config.botUsername.toLowerCase())
        throw new TelegramPollingConfigurationError("Bot identity does not match operator configuration");
      const webhook = await this.call("getWebhookInfo", {}, signal);
      record2(webhook.result);
      if (webhook.ok !== true || webhook.result.url !== "") throw new TelegramPollingConfigurationError("A webhook is configured; remove it explicitly before long polling");
      while (!signal.aborted) {
        try {
          await this.pollOnce(signal);
        } catch (error) {
          if (error instanceof TelegramPollingConfigurationError) throw error;
          if (!signal.aborted) await new Promise((resolve7) => {
            const done = () => {
              clearTimeout(timer);
              signal.removeEventListener("abort", done);
              resolve7();
            };
            const timer = setTimeout(done, 5e3);
            signal.addEventListener("abort", done, { once: true });
            if (signal.aborted) done();
          });
        }
      }
    } catch (error) {
      if (!signal.aborted) throw error;
    } finally {
      this.running = false;
      runningBots.delete(botId);
    }
  }
};

// src/infrastructure/companion/server/transport.ts
var import_node_crypto15 = require("node:crypto");

// src/infrastructure/companion/server/telegram-media-cache.ts
var import_node_fs6 = require("node:fs");
var import_promises7 = require("node:fs/promises");
var import_node_path7 = require("node:path");
var import_node_crypto14 = require("node:crypto");
var MAX_ENTRIES = 1e4;
var MAX_BYTES = 12e6;
function check7(value) {
  if (!value) throw new Error("Media cache unavailable");
}
function privateFile5(info) {
  check7(info.isFile() && info.nlink === 1);
  if (process.platform !== "win32") check7((info.mode & 63) === 0 && (process.getuid === void 0 || info.uid === process.getuid()));
}
function validTelegramFileId(value) {
  return typeof value === "string" && /^[A-Za-z0-9_-]{1,1024}$/.test(value);
}
var TelegramMediaFileCache = class _TelegramMediaFileCache {
  constructor(directory, token5, observe) {
    this.directory = directory;
    this.observe = observe;
    this.file = (0, import_node_path7.join)(directory, "telegram-media-files.json");
    this.scope = (0, import_node_crypto14.createHash)("sha256").update(token5).digest("hex");
  }
  file;
  scope;
  entries = /* @__PURE__ */ new Map();
  tail = Promise.resolve();
  writable = true;
  static async open(stateDirectory, options) {
    check7(/^\d+:[A-Za-z0-9_-]+$/.test(options.botToken));
    const cache = new _TelegramMediaFileCache((0, import_node_path7.resolve)(stateDirectory), options.botToken, options.observe);
    try {
      await privateDirectory(cache.directory);
      let info;
      try {
        info = await (0, import_promises7.lstat)(cache.file);
      } catch (error) {
        if (error.code === "ENOENT") return cache;
        throw error;
      }
      check7(!info.isSymbolicLink());
      privateFile5(info);
      check7(info.size > 0 && info.size <= MAX_BYTES);
      const file = await (0, import_promises7.open)(cache.file, import_node_fs6.constants.O_RDONLY | (import_node_fs6.constants.O_NOFOLLOW ?? 0));
      let raw;
      try {
        const opened = await file.stat();
        privateFile5(opened);
        check7(opened.size > 0 && opened.size <= MAX_BYTES);
        const buffer = Buffer.alloc(opened.size + 1);
        let length = 0;
        while (length < buffer.length) {
          const read = await file.read(buffer, length, buffer.length - length, length);
          if (!read.bytesRead) break;
          length += read.bytesRead;
        }
        check7(length === opened.size && (await file.stat()).size === opened.size);
        raw = buffer.subarray(0, length).toString("utf8");
      } finally {
        await file.close();
      }
      const parsed = JSON.parse(raw);
      check7(parsed && typeof parsed === "object" && !Array.isArray(parsed));
      const value = parsed;
      check7(Object.keys(value).sort().join(",") === "entries,scope,version" && value.version === 1 && typeof value.scope === "string" && /^[a-f0-9]{64}$/.test(value.scope));
      check7(Array.isArray(value.entries) && value.entries.length <= MAX_ENTRIES);
      const seen = /* @__PURE__ */ new Set();
      for (const row of value.entries) {
        check7(row && typeof row === "object" && !Array.isArray(row) && Object.keys(row).sort().join(",") === "fileId,key");
        check7(typeof row.key === "string" && /^[a-f0-9]{64}$/.test(row.key) && validTelegramFileId(row.fileId) && !seen.has(row.key));
        seen.add(row.key);
        if (value.scope === cache.scope) cache.entries.set(row.key, row.fileId);
      }
    } catch {
      cache.entries.clear();
      cache.writable = false;
      recordPerformance(cache.observe, "media.cache.invalid", 0);
    }
    return cache;
  }
  matchesBot(token5) {
    return (0, import_node_crypto14.createHash)("sha256").update(token5).digest("hex") === this.scope;
  }
  key(enrollment, asset, method) {
    check7(/^[a-f0-9]{48}$/.test(enrollment));
    validateCompanionMediaIdentity(asset);
    check7(["sendPhoto", "sendAudio", "sendVideo", "sendDocument"].includes(method));
    return (0, import_node_crypto14.createHash)("sha256").update([this.scope, enrollment, asset.id, asset.kind, asset.format, asset.bytes, method].join("|")).digest("hex");
  }
  get(enrollment, asset, method) {
    return this.entries.get(this.key(enrollment, asset, method));
  }
  has(enrollment, asset, method) {
    return this.get(enrollment, asset, method) !== void 0;
  }
  async set(enrollment, asset, method, fileId) {
    check7(validTelegramFileId(fileId));
    const key2 = this.key(enrollment, asset, method);
    if (this.entries.get(key2) === fileId) return;
    this.entries.delete(key2);
    this.entries.set(key2, fileId);
    if (this.entries.size > MAX_ENTRIES) this.entries.delete(this.entries.keys().next().value);
    await this.persist();
  }
  async invalidate(enrollment, asset, method) {
    if (this.entries.delete(this.key(enrollment, asset, method))) await this.persist();
  }
  persist() {
    const write = this.tail.then(async () => {
      if (!this.writable) return;
      const temp = this.file + "." + (0, import_node_crypto14.randomUUID)() + ".tmp";
      try {
        await privateDirectory(this.directory);
        try {
          const info = await (0, import_promises7.lstat)(this.file);
          check7(!info.isSymbolicLink());
          privateFile5(info);
        } catch (error) {
          if (error.code !== "ENOENT") throw error;
        }
        const raw = JSON.stringify({ version: 1, scope: this.scope, entries: [...this.entries].map(([key2, fileId]) => ({ key: key2, fileId })) });
        check7(Buffer.byteLength(raw) <= MAX_BYTES);
        const file = await (0, import_promises7.open)(temp, "wx", 384);
        try {
          await file.writeFile(raw);
          await file.sync();
        } finally {
          await file.close();
        }
        await (0, import_promises7.rename)(temp, this.file);
      } catch {
        this.writable = false;
        recordPerformance(this.observe, "media.cache.invalid", 0);
      } finally {
        await (0, import_promises7.unlink)(temp).catch(() => void 0);
      }
    });
    this.tail = write.catch(() => void 0);
    return this.tail;
  }
};

// src/infrastructure/companion/server/transport.ts
function staleFileResponse(value) {
  if (!value || typeof value !== "object") return false;
  const response = value;
  return response.ok === false && response.error_code === 400 && typeof response.description === "string" && /^(?:Bad Request: )?(?:wrong file identifier\/HTTP URL specified$|wrong remote file identifier specified(?:$|:)|file reference (?:expired|invalid)$|FILE_REFERENCE_(?:EXPIRED|INVALID)$)/i.test(response.description);
}
function returnedFileId(result, method) {
  let file = result[method.slice(4).toLowerCase()];
  if (method === "sendPhoto") file = Array.isArray(file) ? file[file.length - 1] : void 0;
  const id2 = file && typeof file === "object" ? file.file_id : void 0;
  return validTelegramFileId(id2) ? id2 : void 0;
}
var BotTransport = class {
  constructor(options) {
    this.options = options;
  }
  ready() {
    return this.options.enabled === true && !!this.options.http && !!this.options.token;
  }
  supportsNativePolls() {
    return this.ready();
  }
  cachedMedia(enrollment, asset) {
    try {
      return this.ready() && this.options.mediaCache?.matchesBot(this.options.token) === true && this.options.mediaCache.has(enrollment, asset, mediaMethod(asset));
    } catch {
      return false;
    }
  }
  async call(method, payload, authorize, owned) {
    invalid(this.options.enabled === true && this.options.http && this.options.token && /^\d+:[A-Za-z0-9_-]+$/.test(this.options.token), "transport disabled");
    invalid(["sendMessage", "sendRichMessage", "answerCallbackQuery", "sendPhoto", "sendAudio", "sendVideo", "sendDocument", "editMessageMedia", "editMessageText", "sendPoll", "stopPoll"].includes(method));
    try {
      invalid(authorize?.() !== false, "delivery revoked");
      const keyboard = payload.reply_markup?.inline_keyboard;
      const webApps = Array.isArray(keyboard) ? keyboard.flatMap((row) => Array.isArray(row) ? row.filter((button) => button && button.web_app !== void 0) : []) : [];
      if (owned && "studyPlan" in owned) {
        invalid(method === "sendMessage");
        validateStudyPlanPayload(payload, owned.studyPlan, owned.vaultId);
      } else if (webApps.length) {
        invalid(method === "sendMessage" && owned && "miniAppUrl" in owned && webApps.length === 1);
        if (keyboard?.length === 5) validateReminderMiniAppPayload(payload, owned.miniAppUrl, owned.vaultId);
        else {
          invalid(keyboard?.length === 1 && keyboard[0].length === 1);
          const button = webApps[0];
          keys(button, ["text", "web_app"]);
          record2(button.web_app);
          keys(button.web_app, ["url"]);
          invalid(owned.planId === void 0 || typeof owned.planId === "string" && /^[a-f0-9]{64}$/.test(owned.planId));
          invalid(button.text === "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043D\u044F\u0442\u0438\u0435" && button.web_app.url === miniAppLaunchUrl(owned.miniAppUrl, owned.planId, owned.vaultId));
        }
      }
      invalid(payload.gradeAnswer === void 0 || method === "editMessageText");
      invalid(payload.pollId === void 0 || method === "stopPoll");
      invalid(payload.rich_message === void 0 || method === "sendRichMessage" || method === "editMessageText");
      let body = JSON.stringify(payload), headers = { "Content-Type": "application/json" };
      const media = isMediaMethod(method), editing = method === "editMessageMedia" || method === "editMessageText";
      let identity5, nativeMethod, cached;
      let pollRequest;
      const cache = this.options.mediaCache?.matchesBot(this.options.token) ? this.options.mediaCache : void 0;
      if (method === "answerCallbackQuery") {
        keys(payload, ["callback_query_id", "text"]);
        invalid(typeof payload.callback_query_id === "string" && payload.callback_query_id.length > 0 && payload.callback_query_id.length <= 128);
        invalid(payload.text === void 0 || payload.text === GRADE_SAVED_NOTICE);
      }
      if (method === "sendPoll") {
        validateNativePollPayload(payload);
        pollRequest = payload;
      }
      if (method === "sendRichMessage") validateRichCheckboxDemoPayload(payload);
      if (method === "stopPoll") {
        keys(payload, ["chat_id", "message_id", "pollId"]);
        invalid(Number.isSafeInteger(payload.chat_id) && Number(payload.chat_id) > 0 && validNativePollId(payload.pollId));
        body = JSON.stringify({ chat_id: payload.chat_id, message_id: payload.message_id });
      }
      if (editing || method === "stopPoll") invalid(Number.isSafeInteger(payload.message_id) && Number(payload.message_id) > 0);
      if (method === "editMessageText" && payload.rich_message !== void 0) validateRichCheckboxDemoPayload(payload, true);
      else if (method === "editMessageText") {
        keys(payload, ["chat_id", "message_id", "text", "link_preview_options", "reply_markup", "gradeAnswer"]);
        invalid(Number.isSafeInteger(payload.chat_id) && Number(payload.chat_id) > 0);
        const question = payload.reply_markup?.inline_keyboard;
        if (payload.gradeAnswer !== void 0) validateGradePanelEdit(payload.text, payload.reply_markup, payload.gradeAnswer);
        else if (payload.reply_markup === void 0) invalid(payload.text === MEDIA_LOADING_ERROR);
        else if (Array.isArray(question) && question.some((row) => Array.isArray(row) && row.some((button) => button?.text === "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u0435\u0439\u0447\u0430\u0441"))) validateQuestionPanelEdit(payload.text, payload.reply_markup);
        else if (typeof payload.text === "string" && payload.text.startsWith("\u0417\u0430\u043D\u044F\u0442\u0438\u0435 \xB7 ")) validateSessionPanelEdit(payload.text, payload.reply_markup);
        else if (typeof payload.text === "string" && payload.text.startsWith("\u041F\u043E\u0434\u0441\u043A\u0430\u0437\u043A")) validateHintPanelEdit(payload.text, payload.reply_markup);
        else validateGradePanelEdit(payload.text, payload.reply_markup);
        record2(payload.link_preview_options);
        keys(payload.link_preview_options, ["is_disabled"]);
        invalid(payload.link_preview_options.is_disabled === true);
        const { gradeAnswer: _privateAnswer, ...publicPayload } = payload;
        body = JSON.stringify(publicPayload);
      }
      if (media) {
        keys(payload, ["chat_id", "assetId", "kind", "format", "bytes", "side", "caption", "disable_notification", "enrollment", ...method === "editMessageMedia" ? ["message_id"] : []]);
        invalid(Number.isSafeInteger(payload.chat_id) && Number(payload.chat_id) > 0 && typeof payload.enrollment === "string" && /^[a-f0-9]{48}$/.test(payload.enrollment));
        const asset = { id: payload.assetId, kind: payload.kind, format: payload.format, bytes: payload.bytes };
        validateCompanionMediaIdentity(asset);
        identity5 = asset;
        invalid(payload.side === "question" || payload.side === "answer");
        invalid(typeof payload.disable_notification === "boolean");
        invalid(payload.caption === void 0 || typeof payload.caption === "string" && payload.caption.length <= 500);
        nativeMethod = mediaMethod(identity5);
        invalid(method === "editMessageMedia" || method === nativeMethod, "media unavailable");
        cached = cache?.get(payload.enrollment, identity5, nativeMethod);
        recordPerformance(this.options.observe, cached ? "media.cache.hit" : "media.cache.miss", 0);
        if (cached) {
          body = JSON.stringify(method === "editMessageMedia" ? { chat_id: payload.chat_id, message_id: payload.message_id, media: { type: nativeMethod.slice(4).toLowerCase(), media: cached, ...typeof payload.caption === "string" ? { caption: payload.caption } : {} } } : { chat_id: payload.chat_id, [nativeMethod.slice(4).toLowerCase()]: cached, disable_notification: payload.disable_notification, ...typeof payload.caption === "string" ? { caption: payload.caption } : {} });
        } else {
          body = await this.multipart(method, payload, identity5, nativeMethod);
          headers = {};
        }
      }
      let response = await this.request(method, body, headers, media, authorize);
      if (cached && identity5 && nativeMethod && cache && staleFileResponse(response)) {
        recordPerformance(this.options.observe, "media.cache.invalid", 0);
        await cache.invalidate(payload.enrollment, identity5, nativeMethod);
        invalid(authorize?.() !== false, "delivery revoked");
        body = await this.multipart(method, payload, identity5, nativeMethod);
        response = await this.request(method, body, {}, true, authorize);
      }
      record2(response);
      invalid(response.ok === true);
      if (method === "answerCallbackQuery") invalid(response.result === true);
      else if (method === "stopPoll") {
        record2(response.result);
        invalid(response.result.id === payload.pollId && response.result.is_closed === true);
        return;
      } else {
        record2(response.result);
        invalid(Number.isSafeInteger(response.result.message_id) && Number(response.result.message_id) > 0 && (!editing || response.result.message_id === payload.message_id));
        if (method === "sendRichMessage") {
          record2(response.result.chat);
          invalid(response.result.chat.id === payload.chat_id && response.result.chat.type === "private");
        }
        if (method === "sendPoll") {
          invalid(pollRequest);
          record2(response.result.poll);
          record2(response.result.chat);
          const poll = response.result.poll;
          invalid(validNativePollId(poll.id) && response.result.chat.id === pollRequest.chat_id && response.result.chat.type === "private" && poll.type === "regular" && poll.is_anonymous === false && poll.is_closed === false && poll.allows_revoting === false && poll.allows_multiple_answers === pollRequest.allows_multiple_answers && poll.question === pollRequest.question && Array.isArray(poll.options) && poll.options.length === pollRequest.options.length);
          for (let index2 = 0; index2 < pollRequest.options.length; index2++) {
            record2(poll.options[index2]);
            invalid(poll.options[index2].text === pollRequest.options[index2].text);
          }
          return { messageId: response.result.message_id, pollId: poll.id };
        }
        const fileId = nativeMethod ? returnedFileId(response.result, nativeMethod) : void 0;
        if (fileId && identity5 && nativeMethod && cache) await cache.set(payload.enrollment, identity5, nativeMethod, fileId).catch(() => void 0);
        return response.result.message_id;
      }
    } catch {
      throw new Error("Telegram delivery unconfirmed");
    }
  }
  async multipart(method, payload, identity5, nativeMethod) {
    invalid(this.options.loadMedia, "media unavailable");
    let start = performance.now();
    const loaded = await this.options.loadMedia(payload.enrollment, identity5.id);
    recordPerformance(this.options.observe, "media.read", performance.now() - start);
    validateCompanionMediaIdentity(loaded.asset);
    invalid(loaded.asset.id === identity5.id && loaded.asset.kind === identity5.kind && loaded.asset.format === identity5.format && loaded.asset.bytes === identity5.bytes && loaded.bytes instanceof Uint8Array && loaded.bytes.byteLength === identity5.bytes);
    start = performance.now();
    const hash2 = (0, import_node_crypto15.createHash)("sha256").update(loaded.bytes).digest("hex");
    recordPerformance(this.options.observe, "media.hash", performance.now() - start);
    invalid(hash2 === identity5.id, "media unavailable");
    const type = nativeMethod === "sendPhoto" ? identity5.format === "png" ? "image/png" : "image/jpeg" : nativeMethod === "sendAudio" ? identity5.format === "mp3" ? "audio/mpeg" : "audio/mp4" : nativeMethod === "sendVideo" ? "video/mp4" : "application/octet-stream";
    const form = new FormData();
    form.set("chat_id", String(payload.chat_id));
    if (method === "editMessageMedia") {
      form.set("message_id", String(payload.message_id));
      form.set("media", JSON.stringify({ type: nativeMethod.slice(4).toLowerCase(), media: "attach://asset", ...typeof payload.caption === "string" ? { caption: payload.caption } : {} }));
    } else {
      form.set("disable_notification", String(payload.disable_notification));
      if (typeof payload.caption === "string") form.set("caption", payload.caption);
    }
    form.set(method === "editMessageMedia" ? "asset" : method.slice(4).toLowerCase(), new Blob([new Uint8Array(loaded.bytes).buffer], { type }), "media." + identity5.format);
    return form;
  }
  async request(method, body, headers, media, authorize) {
    const controller = new AbortController(), start = performance.now();
    let timer;
    try {
      invalid(authorize?.() !== false, "delivery revoked");
      invalid(this.options.http);
      const request = this.options.http(`https://api.telegram.org/bot${this.options.token}/${method}`, { method: "POST", headers, body, signal: controller.signal });
      return await Promise.race([request.then(async (r) => {
        const value = await r.json();
        if (r.ok) {
          record2(value);
          invalid(value.ok === true);
        } else invalid(r.status === 400 && staleFileResponse(value));
        return value;
      }), new Promise((_, reject) => {
        timer = setTimeout(() => {
          controller.abort();
          reject(new Error("timeout"));
        }, media ? 6e4 : 1e4);
      })]);
    } finally {
      if (timer) clearTimeout(timer);
      recordPerformance(this.options.observe, "telegram.api", performance.now() - start);
      if (body instanceof FormData) recordPerformance(this.options.observe, "telegram.upload", performance.now() - start);
    }
  }
};

// src/infrastructure/companion/server/shared-transport.ts
var deliveryError = "Telegram delivery unconfirmed";
var sleep = (milliseconds) => new Promise((resolve7) => {
  setTimeout(resolve7, milliseconds);
});
var PacedBotTransport = class {
  constructor(base, clock = () => performance.now(), wait = sleep, observe) {
    this.base = base;
    this.clock = clock;
    this.wait = wait;
    this.observe = observe;
  }
  tail = Promise.resolve();
  outstanding = 0;
  nextGlobal = Number.NEGATIVE_INFINITY;
  lastClock = Number.NEGATIVE_INFINITY;
  nextChat = /* @__PURE__ */ new Map();
  ready() {
    return this.base.ready?.() !== false;
  }
  supportsNativePolls() {
    return this.base.supportsNativePolls?.() === true;
  }
  cachedMedia(enrollment, asset) {
    return this.base.cachedMedia?.(enrollment, asset) === true;
  }
  authorize(check8) {
    if (check8?.() === false) throw new Error(deliveryError);
  }
  time() {
    const now = this.clock();
    if (!Number.isFinite(now) || now < this.lastClock) throw new Error(deliveryError);
    this.lastClock = now;
    return now;
  }
  gate(work) {
    const next = this.tail.then(work);
    this.tail = next.then(() => void 0, () => void 0);
    return next;
  }
  async start(method, payload, chat, authorize, owned) {
    for (; ; ) {
      this.authorize(authorize);
      const next = await this.gate(async () => {
        this.authorize(authorize);
        let now = this.time();
        const chatDelay = chat === void 0 ? 0 : (this.nextChat.get(chat) ?? now) - now;
        if (chatDelay > 0) return { delay: chatDelay };
        while (this.nextGlobal > now) {
          await this.wait(Math.ceil(this.nextGlobal - now));
          this.authorize(authorize);
          now = this.time();
        }
        this.authorize(authorize);
        this.nextGlobal = now + 50;
        for (const [id2, until] of this.nextChat) if (until <= now) this.nextChat.delete(id2);
        if (chat !== void 0) this.nextChat.set(chat, now + 1e3);
        return { delivery: this.base.call(method, payload, authorize, owned) };
      });
      if ("delivery" in next) return next;
      this.authorize(authorize);
      await this.wait(Math.ceil(next.delay));
      this.authorize(authorize);
    }
  }
  async call(method, payload, authorize, owned) {
    const queued = performance.now();
    let counted = false;
    try {
      this.authorize(authorize);
      if (!this.ready() || this.outstanding >= 128 || !["sendMessage", "sendRichMessage", "answerCallbackQuery", "sendPhoto", "sendAudio", "sendVideo", "sendDocument", "editMessageMedia", "editMessageText", "sendPoll", "stopPoll"].includes(method)) throw new Error(deliveryError);
      const captured = JSON.parse(JSON.stringify(payload));
      const chat = method !== "answerCallbackQuery" ? captured.chat_id : void 0;
      if (method !== "answerCallbackQuery" && (!Number.isSafeInteger(chat) || Number(chat) <= 0)) throw new Error(deliveryError);
      this.outstanding++;
      counted = true;
      const capturedOwner = owned === void 0 ? void 0 : JSON.parse(JSON.stringify(owned));
      const started = await this.start(method, captured, chat, authorize, capturedOwner);
      recordPerformance(this.observe, "transport.wait", performance.now() - queued);
      return await started.delivery;
    } catch {
      throw new Error(deliveryError);
    } finally {
      if (counted) this.outstanding--;
    }
  }
};

// src/infrastructure/companion/server/cli-shared.ts
var usage = "Anchor Recall shared Telegram companion (Node >=24)\nUse --config /private/config.json to start, or --check --config /private/config.json for offline validation.\nWithout arguments or with --help, no listener, state or Telegram request is started.\n";
async function readConfig(path) {
  const file = await (0, import_promises8.open)(path, import_node_fs7.constants.O_RDONLY | (import_node_fs7.constants.O_NOFOLLOW ?? 0));
  try {
    const info = await file.stat();
    invalid(info.isFile() && info.size <= 16384 && (info.mode & 63) === 0, "private config required");
    const raw = await file.readFile("utf8");
    invalid(Buffer.byteLength(raw) <= 16384);
    const value = JSON.parse(raw);
    validateSharedConfig(value);
    return value;
  } finally {
    await file.close();
  }
}
async function main() {
  const args = process.argv.slice(2);
  if (!args.length || args.length === 1 && args[0] === "--help") {
    process.stdout.write(usage);
    return;
  }
  const check8 = args.includes("--check"), rest = args.filter((arg) => arg !== "--check");
  invalid(args.filter((arg) => arg === "--check").length <= 1 && rest.length === 2 && rest[0] === "--config" && rest[1] && !rest[1].startsWith("--"));
  invalid(Number(process.versions.node.split(".")[0]) >= 24, "Node >=24 required");
  const config = await readConfig(rest[1]);
  if (check8) {
    process.stdout.write("Configuration valid. No state, listener or Telegram request was started.\n");
    return;
  }
  const mediaRoot = new CompanionMediaRoot(config.stateDirectory);
  const metrics2 = new CompanionPerformance(), observe = metrics2.observe;
  const mediaCache = await TelegramMediaFileCache.open(config.stateDirectory, { botToken: config.botToken, observe });
  const transport = new PacedBotTransport(new BotTransport({ enabled: true, token: config.botToken, http: fetch, mediaCache, observe, loadMedia: (enrollment, id2) => mediaRoot.read(enrollment, id2) }), void 0, void 0, observe);
  const gateway = new SharedCompanionGateway(config, transport, { mediaRoot, observe }), http = createSharedCompanionHttpServer(gateway);
  const poller = new TelegramLongPoller(config.botToken, gateway, fetch), abort = new AbortController();
  let timer, metricsTimer, pollLoop;
  const reportPerformance = () => {
    const measurements = metrics2.snapshot(true);
    if (Object.keys(measurements).length) process.stdout.write(JSON.stringify({ event: "companion.performance", measurements }) + "\n");
  };
  let ticking = Promise.resolve(), tickBusy = false, startup = Promise.resolve(), stopping;
  const stop = () => stopping ??= (async () => {
    abort.abort();
    if (timer) clearInterval(timer);
    if (metricsTimer) clearInterval(metricsTimer);
    await startup.catch(() => void 0);
    if (http.listening) await new Promise((resolve7, reject) => {
      http.close((error) => error ? reject(error) : resolve7());
      http.closeIdleConnections();
    });
    await Promise.all([pollLoop?.catch(() => void 0), ticking.catch(() => void 0)]);
    try {
      await gateway.drain();
    } finally {
      await gateway.close();
      reportPerformance();
    }
  })();
  const fail6 = () => {
    process.exitCode = 1;
    process.stderr.write("Companion stopped. Inspect the private state before restarting; sensitive details were withheld.\n");
    void stop().catch(() => {
      process.exitCode = 1;
    });
  };
  const onSignal = () => {
    void stop().catch(fail6);
  };
  process.on("SIGINT", onSignal);
  process.on("SIGTERM", onSignal);
  http.on("error", fail6);
  startup = (async () => {
    await gateway.start();
    if (abort.signal.aborted) return;
    await new Promise((resolve7, reject) => {
      http.once("error", reject);
      http.listen(config.port ?? 8787, config.host ?? "127.0.0.1", resolve7);
    });
  })();
  try {
    await startup;
    if (abort.signal.aborted) return;
    pollLoop = poller.run(abort.signal);
    void pollLoop.catch(fail6);
    timer = setInterval(() => {
      if (tickBusy || abort.signal.aborted) return;
      tickBusy = true;
      ticking = gateway.tick(Date.now()).then(() => gateway.flush()).catch(fail6).finally(() => {
        tickBusy = false;
      });
    }, 3e4);
    metricsTimer = setInterval(reportPerformance, 6e4);
    process.stdout.write("Shared companion started. Telegram polling and the plugin HTTPS bridge require the configured network access.\n");
  } catch {
    await stop();
    throw new Error("startup failed");
  }
}
void main().catch(() => {
  process.stderr.write("Companion refused to start: invalid arguments/configuration or unavailable private state/listener.\n");
  process.exitCode = 1;
});
